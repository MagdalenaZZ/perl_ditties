#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: pfam2svg.pl Pfam.out fasta


Parses output from Pfam, and makes and svg-file with the proteins in it

'
}



my $pfam = shift;
my $fasta = shift;

	open (PFAM, "<$pfam") || die "I can't open $pfam\n";
	my @pfam = <PFAM>;
	close (PFAM);

    open (FAS, "<$fasta") || die "I can't open $fasta\n";
#	my @fas = <FAS>;
#	close (FAS);

    # calculate the length of the protein
my %h;

my $head;
my $pix = "10000"; 


while  ( <FAS> ) {

    if ($_ =~/^>/){
        my $head = $_;
        my $seq = <FAS>;
        $head =~s/>//;
        chomp $head;
        chomp $seq;
        my $len = length($seq);
        $h{$head} = ($len/$pix);
#        print "$head\t$len\n";
    }
    else {
         }
}

# make svg header



    open (OUT, ">$pfam.svg") || die "I can't open $pfam.svg\n";

    print OUT '<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="50000px" height="1000px" viewBox="0 0 50000 1000" enable-background="new 0 0 50000 1000" xml:space="preserve">
   <!-- this is a comment that gets ignored -->
    ';
    
# make a list of coordinates for each point

my $hi = "20";
my $x =10;
my $y = 10;
my %seen;
my %doms;

foreach my $line (@pfam) {
    chomp $line;
#    print "$line\n";
    my @arr = split(/\s+/,$line);
    #print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[6]\n";
    $arr[0]=~s/\.1\.\.pep//;
# print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[6]\n";


    # print gene-name
    if (exists $h{$arr[0]}) {
#        print "$arr[0]\t$h{$arr[0]}\n";
        print OUT "\t<text x=\"$x\" y=\"$y\" fill=\"black\">$arr[0]</text>\n";
        $y = $y+$hi;        
        print OUT "\t <rect x=\"$x\" y=\"$y\" width=\"$h{$arr[0]}\" height=\"$hi\"  style=\"fill:rgb(255,255,255);stroke-width:1;stroke:rgb(0,0,0)\"/>\n";
        delete $h{$arr[0]};
        my $x1000 = ($x/$pix);
        my $y1000 = ($y/$pix);
        $seen{$arr[0]}= "$x\t$y";
        #$seen{$arr[0]}= "$x1000\t$y1000";

         $y = $y+$hi+$hi+$hi;
    }
#    else {
#        print "missing $line\n";
#    }

    # make domain colours

    unless (exists $doms{$arr[6]}) {
        my $r = 255 - int(rand(100));
        my $g = 255 - int(rand(100));
        my $b = 255 - int(rand(100));
        $doms{$arr[6]} = "$r,$g,$b";
    }


    # now print the domain
    if (exists $seen{$arr[0]}) {
#        print "SEEN $arr[3]\t$arr[4]\n";
        my ($nx, $ny) = split (/\t/, $seen{$arr[0]});
        #print "SEEN $nx\t$ny\n";
        my $y1 = ($ny-2);
        my $x1 = ($arr[3] /$pix)+$x;
        my $ry = ($hi+4);
        my $len2 = ($arr[4] - $arr[3])/$pix;
        my $tx = ($arr[3]+4+ $x);
        my $ty = ($ny + $hi - 4);
        print OUT "\t  <rect x=\"$x1\" y=\"$y1\" width=\"$len2\" height=\"$ry\" rx=\"3\" ry=\"3\"   style=\"fill:rgb($doms{$arr[6]});stroke:black;stroke-width:1\"/>\n";
        #print OUT "\t  <text x=\"$tx\" y=\"$ty\" fill=\"black\">$arr[6]</text>\n";
    }

    else {
        print "This domain: $line\nhas no length, check if it exists in fasta\n";

    }
        
   

}



    print OUT '
</svg>
    ';

close (OUT);



