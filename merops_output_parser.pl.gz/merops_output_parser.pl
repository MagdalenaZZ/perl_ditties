#!/usr/local/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: merops_output_parser.pl infile outfile


Give the program the raw merops output, and it will filter it


'
}


	my $in = shift;	
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);


	open (OUT, ">$out") || die "I can't open $out\n";


    # parse file and get rid of duplicates and empty lines

 my %seen;
my %pr;


   foreach my $line (@in) {
    chomp $line;

    unless ($line =~/\w/ ) {
        next;
    }
       if (exists $seen{$line}) {
           print "WARN:duplicate line: $line\n";
       }
       else {
           # make hash with gene
           

           my @arr = split(/\t/, $line );

           if (scalar(@arr)> 6 ) {
               my $species = $in;
                $species  =~s/\.merops\.raw//;
               my $gene = $arr[0];
               my $merops= $arr[1];
               my $hits= $arr[3];
               my $family= $arr[5];

               #print "$arr[5]:\t$arr[6]:\t$arr[7]:\t$arr[3]:\t$arr[4]:\n";

#        $pr{$merops}{$species}{$gene};
            
            push (@{ $pr{$merops}{$species}{$gene}}, "$hits\t$family");
#        {$hits}{$family} = 1;

            #   now parse the array

            #foreach my $l (@arr) {

                          
            #print "$gene\t$merops\t$family\n";
                #print "$arr[2]:\t:$arr[4]:\t:$arr[6]\n";

                    #}
           }
           else {
            print "Rejected line $line\n";
           }

        }

   }




   # print the results
   
my $meropsct = keys %pr;

my %res;

   foreach my $merops (sort keys %pr ) {

        my $speciesct = keys %{$pr{$merops}} ;

             foreach my $species (sort keys %{$pr{$merops}}) {

#                print "MER:$merops;$meropsct;SPE:$species;$speciesct;GENE:\n";
                        my $genect = keys  %{$pr{$merops}{$species}} ;
                    foreach my $gene (sort keys %{$pr{$merops}{$species}}) {

#                        print "MER:$merops;$meropsct;SPE:$species;$speciesct;GENE:$gene;$genect\n";
#                        print "$merops\t$species\t$genect\n";
                        
                        my $len = scalar (@{$pr{$merops}{$species}{$gene}});

                        foreach my $i ( 0..$len-1) {
                                #print "SCORE:${$pr{$merops}{$species}{$gene}}[$i]\n";

                            if (${$pr{$merops}{$species}{$gene}}[$i] =~/\>/ || ${$pr{$merops}{$species}{$gene}}[$i] =~/\</ ) {
                                #print "INCOMPLETE:$merops\t$species\t$gene\t$genect\n";
                                $res{$merops}{$species}{$gene}{incomp}+= 1;
                            }
                            else {
                                #print "COMPLETE:$merops\t$species\t$gene\t$genect\n";
                                    $res{$merops}{$species}{$gene}{complete}+= 1;
                            }

                        }

                    }

            }
   }


# For each gene filter if it is complete or not

   my %tot;

   foreach my $merops (sort keys %res ) {

             foreach my $species (sort keys %{$res{$merops}}) {
                    my $genect = keys  %{$res{$merops}{$species}} ;

#                    print " ${$res{$merops}{$species}{complete}} ";

                    foreach my $gene (sort keys %{$res{$merops}{$species}}) {
#                        print "$gene\n";
                        my $cct= $res{$merops}{$species}{$gene}{complete};
                        my $ict= $res{$merops}{$species}{$gene}{incomp};
                        
                        if (defined $cct) {
#                            print "$merops\t$species\t$gene\t$cct\tcomplete\n";
                             $tot{$merops}{$species}{complete}+= 1;
                        }
                        elsif (defined $ict) {
#                            print "$merops\t$species\t$gene\t$ict\tincomplete\n";
                            $tot{$merops}{$species}{incomp}+= 1;

                        }

                    }

#                    if (  ${$res{$merops}{$species}} =~/complete/ ) {
#                        print "COMPLETE:$merops\t$species\t${$res{$merops}{$species}{complete}}\n";
#                    }
             }
   }


   # final output

   foreach my $merops (sort keys %tot ) {

             foreach my $species (sort keys %{$tot{$merops}}) {
                    my $genect = keys  %{$tot{$merops}{$species}} ;

#                    print " ${$res{$merops}{$species}{complete}} ";

                        my $tcct= $tot{$merops}{$species}{complete};
                        my $tict= $tot{$merops}{$species}{incomp};

                        unless (defined  $tcct ) {
                            $tcct= "0";
                        }
                        unless (defined  $tict ) {
                            $tict= "0";
                        }

                        print OUT "$merops\t$species\t$tcct\($tict\)\n";

                        #}

            }


   }




   close (OUT);




