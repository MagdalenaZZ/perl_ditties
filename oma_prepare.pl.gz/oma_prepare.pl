#!/usr/local/bin/perl -w
# mz3 script for preparing for oma splitting a fasta-file to several chunks

use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV == 2 ) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: oma_preprocess.pl <prefix>  <int>
prefix = prefix for the output filename
<int>  is the number of oma-processes you want to start

'
}

my $prefix = shift;
my $int= shift;

unless (-e "$prefix") {

system "mkdir $prefix";
print "Making file $prefix\n";


}

unless (-e "$prefix/DB") {

system "mkdir $prefix/DB";

}


unless (-e "$prefix/parameters.drw") {

system "cp ~/bin/OMA.0.99t/parameters.drw $prefix/parameters.drw";

unless (-e "$prefix/parameters.drw") {
    print "Failed to get the parameter-file from ~/bin/OMA.0.99t/parameters.drw. Please restart with a parameter-file in the folder\n";
    die;
    }
}



my $folder = cwd();
my @paths = read_dir( "$folder", prefix => 1 ) ;
my @inputs;

		print "Reading files:\n";

		foreach my $elem (@paths) {
            if ($elem=~/sl\.fas$/) {
                push (@inputs, $elem);
                print "$elem\n";
            }
            elsif ($elem=~/\.fasta$/) {
                push (@inputs, $elem);
                print "$elem\n";
            }
            elsif ($elem=~/\.protein\.fa$/) {
                push (@inputs, $elem);
                print "$elem\n";
            }
            else {
                print "ignoring $elem\n";
            }

		}	

        if (scalar @inputs < 1) {
            print "Can't find any files, make sure they are called sl.fas or .fasta\n";
            die;
        }
     foreach my $file (@inputs) {

         # OPEN INPUT AND OUTPUT
        open (IN, "<$file") || die "I can't open $file\n";
        my @in = <IN>;
        close (IN);
        #print "$file\n";
        my @arr = split(/\./, $file);
        my @arr2 = split(/\//, $arr[0]);
        my $pre = $arr2[-1]; 
        #print "$arr[0]\t$arr2[-1]\t$prefix/DB/$pre.fa\n";
        open (OUT, ">$prefix/DB/$pre.fa") || die "I can't open  $prefix/DB/$pre.fa\n";

        my $head;

        foreach my $line (@in) {
            chomp $line;

            # split headers
            if ($line=~/^>/) {
                $line=~s/#//g;
                $line=~s/|//g;
                $line=~s/\\//g;
                #print OUT "$line\n";
                $head=$line;

            }

            # and sequences
            else {
                $line=~s/#//g;
                $line=~s/\*//g;
                $line=~s/\+//g;
                $line=~s/U//g;
                $line=~s/X//g;
                if (length($line)> 49) {
                    print OUT "$head\n$line\n";
                }
            }

        }

                print "Finished writing $file\n";        
            close (OUT);
    }
    
    #
    # start oma
    my $cwd = cwd();
    print "cd $cwd/$prefix/\n";
#   system ("cd $cwd/$prefix/");
   chdir $prefix;

   $cwd = cwd();
    print "I'm in $cwd\n";
    my $index = "01";
    system "bsub.py  5 $prefix\_00 oma";
    print "I'm waiting for a little while, please be patient, job will be finished within minutes\n";
    sleep (360);

    while ($index < $int ) {
        system "bsub.py -q basement 5 $prefix\_$index oma";
        sleep (5);
        $index = $index+1;
    }

    $cwd = cwd();
    print "I'm finishing in $cwd\n";
    print "All jobs submitted\n";
