#!/usr/local/bin/perl -w

use strict;




unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: tab_merger.pl <PREFIX> *files



'
}



# print "@ARGV\n";

my $prefix = shift;

my @files = @ARGV;

foreach my $file (@files) {

    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$4}' > $file.1  ";
    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$3}' > $file.2  ";

}


my %h;

# get the RPKMs
foreach my $file (@files) {

    open (IN , "<$file.1") || die;

    while (<IN>) {
        chomp;
        my @arr = split("\t", $_);
        
        push ( @{$h{$arr[0]}} , $arr[1] ); 
        #print "$arr[0]\t$arr[1]";

    }

    close (IN);
}

# get the reads
my %h2;

foreach my $file (@files) {

    open (IN , "<$file.2") || die;

    while (<IN>) {
        chomp;
        $_=~s/^ID=//;
        my @arr = split("\t", $_);
        
        push ( @{$h2{$arr[0]}} , $arr[1] ); 
        #print "$arr[0]\t$arr[1]";

    }

    close (IN);
    #system "rm -f $file.1 $file.2";
}






open ( OUT , ">$prefix.merged.RPKM") || die;
open ( OUT2 , ">$prefix.merged.reads") || die;



print OUT "ID\t";
print OUT2 "ID\t";



foreach my $file (@files) {

    $file=~s/\.BEDcoverage\.final\.count//g;
    $file=~s/\.bam//g;
    $file=~s/\.count//g;

    my @arr = split("\/", $file);
    $file=$arr[-1];
    #print "$file\n";
    #$file =~s/#/-/g;

        $file=~s/#/-/;
    my @arr2 = split(/\./,$file);
    $file=$arr2[0];
}


# make header
my $files = join ("\t", @files);

print OUT "$files\n";
print OUT2 "$files\n";


# print data

foreach my $gene (sort keys %h) {
    my $exp = join ("\t", @{$h{$gene}});
    print OUT "$gene\t$exp\n";
}

foreach my $gene (sort keys %h2) {
    my $exp = join ("\t", @{$h2{$gene}});
    print OUT2 "$gene\t$exp\n";
}



close (OUT);
close (OUT2);

exit;


=pod	
11440_1#12	aPS
11449_1#24	aPS
11450_1#12	aPS
11440_1#7	Cyst wall
11440_1#10	EGU_naPS
11449_1#22	EGU_naPS
11450_1#10	EGU_naPS
11440_1#13	Larvae
11449_1#1	Larvae
11450_1#13	Larvae
11440_1#8	MCana
11449_1#20	MCana
11450_1#8	MCana
11440_1#4	MCnoBC
11449_1#17	MCnoBC
11450_1#5	MCnoBC
11440_1#9	MCu
11449_1#21	MCu
11450_1#9	MCu
11440_1#5	MCvitro
11449_1#18	MCvitro
11450_1#6	MCvitro

11440_1#6	MCvivo
11449_1#19	MCvivo
11450_1#7	MCvivo
11440_1#11	naPS
11449_1#23	naPS
11450_1#11	naPS
11440_1#1	PC1
11449_1#14	PC1
11450_1#2	PC1

11440_1#2	PC2
11449_1#15	PC2
11450_1#3	PC2
11440_1#3	PC3
11449_1#16	PC3
11450_1#4	PC3

=cut





