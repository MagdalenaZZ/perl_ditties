#!/usr/bin/perl -w


use strict;
use Cwd;
use File::Slurp;

if (@ARGV < 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: KOget.pl KOlist   domain-list pfam-result 

Takes a list of genes and KO-numbers and associates them. It sends queries to KEGG, retrieves web-pages and parses them for information. Then it links that to genes and domains


1. Make a list of genes to investigate with KO.
2. Submit those genes to KAAS
3. Download the txt results file
4. Use that file as input 1; KOlist
5. Take pfam results for all genes in the list as input 3; pfam-result
6. Take the original query list of domains as input 2;  domain-list


What can possibly go wrong...  :-)



'
}

my $in = shift;


        open (IN, "<$in") || die "I can't open $in\n";
    	my @in= <IN>;
    	close (IN);

my %KOs;
# my %genes;

# Make a list of KOs

foreach my $line (@in) {
    chomp $line;

    my @arr = split (/\s+/,  $line);
    push (@arr, " ");
    push (@arr, " ");
    if ( $arr[1] =~/\w+/) {
#        print "$arr[1]\n";
        $KOs{$arr[1]}{$arr[0]}=1;
    }

}

#=pod

# wget them

system "rm -fr KOs_$in";
mkdir "KOs_$in";

chdir "KOs_$in";

foreach my $elem (keys %KOs) {

system "wget \"http://www.genome.jp/dbget-bin/www_bget?$elem\" ";
sleep(1);

}

print "\n\n\n\n";
#=cut

# read in each resulting file, and parse it
my $cwd = cwd();

my @files = read_dir( "$cwd", prefix => 1 ) ;

my %keg;

foreach my $file (@files) {


        open (IN2, "<$file") || die "I can't open $file\n";
#    	my @in2= <IN2>;
#    	close (IN2);

        $file=~s/www_bget\?//;
        $file=~s/$cwd//;
        $file=~s/\///;
        #print "FILE:$file\n";
        

        my $def2;

        while (<IN2>) {
        chomp $_;
            if ($_=~/Definition/) {
                my $def = <IN2>;
                chomp $def;
                my @arr2 = split(/hidden">/, $def);
                my @arr3 = split( /\[/, $arr2[-1]);
                $arr3[0]=~s/<br>//;
                #print "DEF:$arr3[0]\n";
                $def2=$arr3[0];
                $keg{$file}{$def2}{"0"}=1;
            }
            elsif ($_=~/show_pathway/ and $_=~/align/  ) {
                my $met = $_;
                my @arr4 = split (/show_pathway\?/, $met);
                my @arr5 = split (/\+/,$arr4[1] );
                #print "PATH:$arr5[0]\n";
                my @arr6 = split (/"left">/,$arr4[1] );
                my @arr7 = split (/</,$arr6[1] );
                #print "PATH_DEF:$arr7[0]\n";
                #print "MET:$met\n";
                $keg{$file}{$def2}{ "$arr5[0]\t$arr7[0]"} = 1;
            }
        }
        close (IN2);


}


# report output

open (OUT, ">$in.kos") || die "I can't open $in.kos\n";

my %kg;

foreach my $koval (keys %keg) {

    if (exists $KOs{$koval} ) {
        #print "Exists $koval\n";
        foreach my $gene ( keys %{ $KOs{$koval} } ) {
            foreach my $defi ( keys %{ $keg{$koval} } ) {
                foreach my $path ( keys %{ $keg{$koval}{$defi} } ) {
#                    unless ($path =~/^0$/) {
                        print OUT "$gene\t$koval\t$defi\t$path\n";
                        $kg{$gene}{ "$koval\t$defi\t$path" }=1;
#                    }
                }
            }
        }
    }
    else {
        #print "Dont exist $koval\n";

    }

}

chdir "..";

__END__


# filter the domains to only those relevant
my %gen;
my %gen2;

my $in4 = shift;

        open (IN4, "<$in4") || die "I can't open $in4\n";
    	my @in4= <IN4>;
    	close (IN4);

        foreach my $lin4 ( @in4) {
            chomp $lin4;
                if ( $lin4=~/\w+/ ) {
                    $gen{$lin4}{0}=1;
                }
            
        }
=pod
        foreach my $lin4 ( @in4) {
            chomp $lin4;
            if ($lin4=~/^>/) {
                $lin4=~s/\>//;
                if ( $lin4=~/\w+/ ) {
                    $gen{$arr[0]}{0}=1;
                }
            }
        }

=cut

print "Successfully read in list of domains\n";
# get the list of domains in those genes



my $in3 = shift;

        open (IN3, "<$in3") || die "I can't open $in3\n";
    	my @in3= <IN3>;
    	close (IN3);

foreach my $lin (@in3 ) {
chomp $lin;

    my @arr =split(/\s+/, $lin);
#    print "$lin\n";
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");

    if ( exists $gen{$arr[6]} ) {
        $gen2{$arr[0]}{$arr[6]}=1;
    }

}

# now I have a HoH of $gen { domain } { gene }

# compare it to the genes I've got info for, so I know which domains go in which pathway

open (OUT2, ">$in.kosdom") || die "I can't open $in.kosdom\n";


foreach my $gn2 ( keys  %gen2 ) {
    
    if (exists $kg{$gn2}) {

        foreach my $dom3 ( keys %{ $gen2{$gn2} } ) {
            foreach my $pah ( keys %{ $kg{$gn2} } ) {

                print OUT2 "$dom3\t$gn2\t$pah\n";
            }
        }
    }



}

close (OUT2);

print "Finished now\n";
exit;












