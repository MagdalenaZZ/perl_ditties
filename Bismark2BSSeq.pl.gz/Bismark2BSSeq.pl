#!/usr/local/bin/perl -w
###

use strict;
   


unless (@ARGV > 2) {
        &USAGE;
}


sub USAGE {
die '


Perl-program for converting a Bismark cov output to BSSeq input tables 


Usage: Bismark2BSSeq.pl <outprefix> <input-file>

Ex: Bismark2BSSeq.pl out *.cov



Written by: magdalena.z@kcl.ac.uk

'
}



    my $out = shift;
    my @ins =@ARGV;
    

my %a;


#print "Region\t@ins\n";

# read in input files and make a complete hash

foreach my $file (@ins) {

	open (IN, "<$file") or die "Cant find file $file\n" ;

	while (<IN>) {
		chomp;

		#print "$_\n";
		my @ar = split("\t", $_);
		my $chr =$ar[0];
		$chr=~s/HS_//;
		my $start =$ar[1];
		my $end =$ar[2];
		my $methpercent =$ar[3];
		my $methc =$ar[4];
		my $unmethc =$ar[5];
		my $cov =  $methc+$unmethc;

		#print "X\t$chr\t$start\t$end\t$methc\t$cov\n";
		#my @tmp=qw(0 0);
		#print @tmp\n";
		my $key = "$chr\_$start\_$end";
		#print "$key\n";
		$a{"$key"}=["0","0"];

	}

	close (IN);


}


# read in the input files again and fill the table

my $i=0;

foreach my $file (@ins) {

	open (IN, "<$file") or die "Cant find file $file\n" ;
	

	while (<IN>) {
		chomp;

		#print "$_\n";
		my @ar = split("\t", $_);
		my $chr =$ar[0];
		$chr=~s/HS_//;
		my $start =$ar[1];
		my $end =$ar[2];
		my $methpercent =$ar[3];
		my $methc =$ar[4];
		my $unmethc =$ar[5];
		my $cov =  $methc+$unmethc;
		my $key = "$chr\_$start\_$end";

		if (exists $a{$key}) {
		    #	print "$i\t$file\t$chr\t$start\t$end\t$methc\t$cov\t$a{$key}[0]\n";

			#my @tmp = $a{$key};
			push @{$a{$key}}, "$methc\_$cov"; #  (@($a{$key}), "2");
			#print "@tmp\n";
			#print "x @{$a{$key}}\n";
		    	#push(@{$a{"$chr\t$start\t$end"}}, "$methc\t$cov" )
		}
		else {
			print "Should not happen\n";
		}
		#print "X\t$chr\t$start\t$end\t$methc\t$cov\n";
		#my @tmp=0;
		#print "@tmp\n";
		#$a{"$chr\t$start\t$end"}=@tmp;

	}

	close (IN);

	# Go through hash and pad up missing bits
	

	foreach my $key (keys %a) {
	
	    my @tmp =	@{$a{$key}};
	    my $len = scalar(@tmp);
	    #print "$len @tmp\n";

	    if ($len > (2+$i)) {
		#print "IFIF $len @tmp\n";
	    }
	    else {
		    push @{$a{$key}}, "0\_0";
	    		my @tmp2 =	@{$a{$key}};
			#print "ELSE $len @tmp2\n";
	    }
	}


$i++;

}



# Make output matrices
#

open OUTC, ">", "$out.Cov" or die "$out.Cov\n" ;
open OUTM, ">", "$out.M" or die "$out.M\n" ;
open OUTG, ">", "$out.Genome" or die "$out.Genome\n" ;

print OUTG "ID\tChr\tPos\tPos2\n";
print OUTC "Region\t@ins\n";
print OUTM "Region\t@ins\n";


foreach my $key (sort keys %a) {


    #print "$key\n";
	my $head = $key;
	$head =~ s/_/\t/g;
	#print "$head\t";
	my @tmp = @{$a{$key}};
	my @M='';
	my @cov='';
	if (scalar(@tmp)>1) {
		foreach my $ele (@tmp) {
		    #print "ELE $ele\n";
			my @ts = split("_",$ele);
			if (scalar(@ts)==2) {
			    	#print "ELE $ele\n";
				#print "TS\t$ts[0]\t$ts[1]\n";
				push (@M,$ts[0]);
				push (@cov,$ts[1]);
		    	}
		}
    	}
	else {
	    print "Error @tmp\n";
	}

	print OUTM "$key\t@M\n";
	print OUTC "$key\t@cov\n";
	print OUTG "$key\t$head\n";

}



close(OUTM);
close(OUTC);
close(OUTG);






# M - number reads supporting methylation at a single loci
# C - number of reads per loci
#
#


# Make an R object 


print "

M = read.table( \"$out.M\", header=TRUE, row.names=1 )
g = read.table( \"$out.Genome\", header=TRUE, row.names=1 )
Cov = read.table( \"$out.Cov\", header=TRUE, row.names=1 )

library(bsseq)

$out <- BSseq(chr = g\$Chr, pos = g\$Pos, M = as.matrix(M), Cov = as.matrix(Cov), sampleNames = colnames(Cov))    



";



exit;







