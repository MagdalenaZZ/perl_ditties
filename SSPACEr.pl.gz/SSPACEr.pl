#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/SSPACEr.pl 



';

}


my $in = shift;
my $out = "$in.gff";

 open (IN, "<$in") or die 'Cant find infile  ';

 open (OUT, ">$out") or die 'Cant find outfile $out ';



