#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_fix_altforms.pl input.gff 

Takes a gff-file with mistakenly made alternative splice-forms to genes and corrects them

i.e. 

pathogen_EmW_scaffold_01	RATT	gene	1300839	1301574	.	+	.	ID=EmuJ_000749900.1
pathogen_EmW_scaffold_01	RATT	gene	1300839	1302422	.	+	.	ID=EmuJ_000749900.2
pathogen_EmW_scaffold_01	RATT	gene	1300839	1302422	.	+	.	ID=EmuJ_000749900.3
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1301574	.	+	.	ID=EmuJ_000749900.1.1;Parent=EmuJ_000749900.1
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1302422	.	+	.	ID=EmuJ_000749900.2.1;Parent=EmuJ_000749900.2
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1302422	.	+	.	ID=EmuJ_000749900.3.1;Parent=EmuJ_000749900.3
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.1:exon:1;Parent=EmuJ_000749900.1.1
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.2:exon:1;Parent=EmuJ_000749900.2.1
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.3:exon:1;Parent=EmuJ_000749900.3.1
pathogen_EmW_scaffold_01	RATT	CDS	1301100	1301570	.	+	.	ID=EmuJ_000749900.3:exon:2;Parent=EmuJ_000749900.3.1
pathogen_EmW_scaffold_01	RATT	CDS	1301100	1301574	.	+	.	ID=EmuJ_000749900.1:exon:2;Parent=EmuJ_000749900.1.1
pathogen_EmW_scaffold_01	RATT	CDS	1302086	1302422	.	+	.	ID=EmuJ_000749900.2:exon:2;Parent=EmuJ_000749900.2.1
pathogen_EmW_scaffold_01	RATT	CDS	1302086	1302422	.	+	.	ID=EmuJ_000749900.3:exon:3;Parent=EmuJ_000749900.3.1

Becomes:

pathogen_EmW_scaffold_01	RATT	gene	1300839	1302422	.	+	.	ID=EmuJ_000749900
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1301574	.	+	.	ID=EmuJ_000749900.1;Parent=EmuJ_000749900
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1302422	.	+	.	ID=EmuJ_000749900.2;Parent=EmuJ_000749900
pathogen_EmW_scaffold_01	RATT	mRNA	1300839	1302422	.	+	.	ID=EmuJ_000749900.3;Parent=EmuJ_000749900
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.1:exon:1;Parent=EmuJ_000749900.1
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.2:exon:1;Parent=EmuJ_000749900.2
pathogen_EmW_scaffold_01	RATT	CDS	1300839	1300915	.	+	.	ID=EmuJ_000749900.3:exon:1;Parent=EmuJ_000749900.3
pathogen_EmW_scaffold_01	RATT	CDS	1301100	1301570	.	+	.	ID=EmuJ_000749900.3:exon:2;Parent=EmuJ_000749900.3
pathogen_EmW_scaffold_01	RATT	CDS	1301100	1301574	.	+	.	ID=EmuJ_000749900.1:exon:2;Parent=EmuJ_000749900.1
pathogen_EmW_scaffold_01	RATT	CDS	1302086	1302422	.	+	.	ID=EmuJ_000749900.2:exon:2;Parent=EmuJ_000749900.2
pathogen_EmW_scaffold_01	RATT	CDS	1302086	1302422	.	+	.	ID=EmuJ_000749900.3:exon:3;Parent=EmuJ_000749900.3

Gene re-calculated and duplicates removed
Parents and IDs changed for all




'
}

# format

	my $in = shift;
	my $out = "$in" . ".altered.gff";
	open (IN, "<$in") || die "I can't open $in\n";
	open (OUT, ">$out") || die "I can't open $out\n";

	my @gff = <IN>;
	close (IN);

    my %gff;

my $fixgene=0;
my @rest='';


## find all genes and alts, and give them co-ords
    
my %genecoord;

foreach my $line (@gff) {
    chomp $line;
    my @arr = split(/\s+/, $line);
    if ($arr[2]=~/gene/) {

        # now deal with the new one
        if ($arr[8]=~/\./) {
            $arr[8]=~s/\.\d$//;

            # alread exists - so this is second or later altform
            if (exists $genecoord{$arr[8]}) {
                my($os,$oe)=split(/\t/, $genecoord{$arr[8]} ); 
                #print "$os\t$oe\t$arr[3]\t$arr[4]\n";
                my $min = ($arr[3], $os)[$arr[3] > $os];
                my $max = ($arr[4], $oe)[$arr[4] < $oe];
                #print "new $min\t$max\n";
                $genecoord{$arr[8]}="$min\t$max\talt";
            }
            # is new
            $genecoord{$arr[8]}="$arr[3]\t$arr[4]";
        }
        elsif (exists $genecoord{$arr[8]}) {
            print "Warning - same geneID exists twice!!!   $arr[8] \nFix it and try again\n\n";
            die;
        }
        else {
            $genecoord{$arr[8]}="$arr[3]\t$arr[4]";
        }

    }
}


## go through the gff 

foreach my $line (@gff) {
    chomp $line;
    my @arr = split(/\s+/, $line);

# if it is a CDS     
    if ($arr[2]=~/CDS/) {

        # if the gene needs to be fixed
        if ($fixgene=~/1/) {
            my @arr3 =  split(/\./,$arr[8]);
            $arr[8]=~s/\.\d$//;
            my $newline = join("\t", @arr);
            #push (@rest, $newline);   
            print OUT "$newline\n";
        }
        # if it is good
        else {
            print OUT "$line\n";
        }
    
    }
# if this is an mRNA
    elsif ($arr[2]=~/mRNA/) {

        # if it needs to be fixed
        if ($fixgene=~/1/) {
            $arr[8]=~s/\.1//;
            $arr[8]=~s/\.\d$//;
            my $newline = join("\t", @arr);
            #push (@rest, $newline);
            print OUT "$newline\n";
        }
        # if it is already good
        else {
            print OUT "$line\n";
        }
    }

# if it is a gene not needing to be fixed
    elsif ($arr[2]=~/gene/) {

        # now deal with the new one
        if ($arr[8]=~/\.\d$/) {
            $arr[8]=~s/\.\d$//;
            
        # get the new coords, and delete the key
            if (exists $genecoord{$arr[8]} ) {
                my($s,$e)= split(/\t/, $genecoord{$arr[8]} );
                delete $genecoord{$arr[8]};

                $arr[3]= $s;
                $arr[4]= $e;

                my $newline = join("\t", @arr);
                #print "$line\n";
                print OUT "$newline\n";
            }
            else {
                print "Warning: line ignored $line\n";
            }
            $fixgene=1;
        }
        elsif ($fixgene=~/1/ and $arr[8]=~/\.\d$/ ) {
            # dont print, just ignore
        }
        elsif (exists $genecoord{$arr[8]} and $genecoord{$arr[8]}=~/alt/ ) {
            print "This gene exists in two forms after all $arr[8]\n";
        }


# if it is a gene that is already good
        else { 
            print OUT "$line\n";
            $fixgene=0;
        }
    }
    else  {
        print "Unexpected $line\n";
    }


}


close (OUT);


exit;




