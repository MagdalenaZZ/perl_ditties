#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: smalt_2_stats.pl input.sam

mz3 script for cleaning a smalt output so it can be parsed by mh12s BWAstats



'
}

	my $in = shift;
	open (IN, "$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);



my $lastline = 0;


foreach my $line (@in) {
#	print "Line: $line";
	my @ar = split (/\s+/,$line );
	my @al = split (/\s+/,$lastline );
#	print "Ar_0: $ar[0]\n";
	if ($ar[0]=~/right/) {
#grabs second mate
#		print "Right: $line";
		my $zero=0;
		if ($zero > $ar[8]){
# match if the value is negative
#		print "Negative pair: $lastline";
#		print "Negative right: $line";
		$lastline = $line;
		}
		elsif ($zero > $al[8]){
# match if the value is negative on the left hand side
#			print "Negative left: $lastline";
#			print "Negative pair: $line";
			$lastline = $line;
		}
		else {
# print the positive numbers
		print "$lastline";
		print "$line";
		$lastline = $line;
		}
	}

	elsif ($ar[0]=~/left/) {
#grabs first mate		
#	print "Left: $lastline";

	$lastline = $line;
	}


}



# clean the raw-file a little bit 