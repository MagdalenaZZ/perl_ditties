#!/usr/local/bin/perl -w
# mz3 script for preparing for Pfam
use strict;

unless (@ARGV == 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: merops_preprocess.pl <input.fa> <prefix> <int>
prefix = prefix for the output filename
<int>  is the number of sequences you want the file to have

'
}

### this is the splitter-part of the script ####

my $in = shift;
my $out = shift;
my $size = shift;
my $chunk = 9999;
my $chunk2 = $chunk * 2;

$size--;
$size--;
$size--;

open (IN, "<$in");
#my @in = <IN>;
my @files;
#my $length = scalar(@in);

#my $targetsize = 50*1024*1024;
my $targetsize = $size;
my $fileprefix = $out;
my $outfile = "01";
#my $outsize = 0;
my $outfh;
#my $temp='';
my $lastline;


        open ($outfh, ">$fileprefix\_$outfile\.fa"); 
        my $index = 0;
        print  "$index\tPrinting to file $fileprefix\_$outfile\.fa\n";
        $outfile++;


# local $/ = ">";
while (my $line = <IN>)  {
  chomp($line);

#    $line=~s/\#/\*/;

    if ($line=~/>/) {

    # open filehandle
        if ($index >= $size )  {
             if ($outfh) {
            close($outfh);
        }

        open ($outfh, ">$fileprefix\_$outfile\.fa"); 
        print  "$index\tPrinting to file $fileprefix\_$outfile\.fa\n";
        $index =0;
        $outfile++;

        }
        $index++;
    
        # print sequence-name
    
        print $outfh "$line\n";
    
        # make last name
         $lastline = $line;
        #print $outfh "$line\n"; 
     }

 else {
# if line is longer than 10.000 bases, break it
   my $l_count = $line =~ tr/[A-Z][a-z]//; 
#    print "LINE:$l_count:$line:\n";

    if ( ( $l_count > $chunk) & ($l_count < $chunk2) ) {
        my $start  = substr $line, 0, $chunk; 
        my $start1 = substr $line, $chunk, $l_count; 
#        print "IF:$l_count:$chunk:$chunk2:\n";
#        print "$lastline\n";
        print "Splitting $lastline to 2 sequences\n";
        print $outfh "$start\n";
        print $outfh "$lastline.2\n";
        print $outfh "$start1\n";
            $index++;
    }
    elsif ($l_count > $chunk ) {
        my $start  = substr $line, 0, $chunk; 
        my $start1 = substr $line, $chunk, $chunk;
        my $start2 = substr $line, $chunk2, $l_count;
#        print "ELSIF:$l_count:$chunk:$chunk2:\n";
        print "Splitting $lastline to 3 sequences\n";
        print $outfh "$start\n";
        print $outfh "$lastline.2\n";
        print $outfh "$start1\n";
        print $outfh "$lastline.3\n";
        print $outfh "$start2\n";
            $index++;
            $index++;
    }
    else {
#        print "ELSE:$l_count:\n";
        print $outfh "$line\n";

    }

    }

} 
