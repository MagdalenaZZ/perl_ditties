#!/usr/bin/perl
use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 


perl ~/bin/perl/gff_red_blue.pl


Reads in a gff-file and colours features on + blue, and features on - strand red


';

}


my $in = shift;

open (IN, "<$in") or die "Cant find file $in\n" ;
open (OUT, ">$in.gff") or die "Cant find file $in.gff\n" ;


while (<IN>) {
chomp;

    if ($_=~/fw/ and $_=~/CDS/) {
        print OUT "$_;colour=4\n";
    }

    elsif ($_=~/rv/ and $_=~/CDS/) {
        print OUT "$_;colour=2\n";
    }

    else  {
        print OUT "$_\n";
    }


}

exit;


__END__

XS:A:+
XS:A:-
