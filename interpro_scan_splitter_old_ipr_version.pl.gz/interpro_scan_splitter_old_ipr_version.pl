#!/usr/local/bin/perl -w
# mz3 script for splitting a protein-file to several pfamscan jobs

use strict;

unless (@ARGV == 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: interproscan_splitter.pl <input.fa> <prefix> <int>
prefix = prefix for the output filename
<int>  is the approximate number of bytes you want the file to be 

the output will print a series of commands, you have to execute each one, and then follow each by pressing ctrl+a+d
To resume screen - press screen -r

'
}

### this is the splitter-part of the script ####

my $in = shift;
my $out = shift;
my $size = shift;


open (IN, "<$in");
#my @in = <IN>;
my @files;
#my $length = scalar(@in);

#my $targetsize = 50*1024*1024;
my $targetsize = $size;
my $fileprefix = $out;
my $outfile = 0;
my $outsize = 0;
#my $outfh= "$fileprefix\_$outfile";
my $outfh;

my $temp='';

local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
  #print "LINE:$line:\n";
  next unless $line;
  # discard initial empty chunk
#  if($line =~ /^\$\$$/ || $outfile == 0){
#  if($line =~m/\_/ || $outfile == 0){
  if($line =~m/\w+/ || $outfile == 0){

        $outsize += length($temp);
        #print "SIZE:$outsize:\n";
        if ( $outfile == 0 || ($outsize - $targetsize) > 0)  {
              ++$outfile;
              if($outfh) {close($outfh);}
              my $inf = "$fileprefix\_$outfile";
              open ($outfh,  ">$inf");
              push (@files,  "$fileprefix\_$outfile" );
#              print "$outfh\t$fileprefix\_$outfile\n";
              $outsize = 0;
        }
        $temp='';
    }
  $temp = $temp.$line;
  print $outfh "\>$line";
}


######################
#
#
#
# make a shell-file
foreach my $file (@files) {
# my $format = "summary";
# print "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam\n";
#

print "screen iprscan_chado -f $file \n" ;
print "then do ctrl+a+d\n\n" ;


# system "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -pfamB -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam";
}




