#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  khmer_wrapper.pl  kmer reads_1 reads_2 

This script produces three bsub commands for you to submit to command-line

';

}



my $kmer = 31;
my $file1 = shift;
my $file2 = shift;
my $base = 0;


if ($file1=~/\w+/) { 
    # nothing
    my @arr = split(/\//,$file1);    
    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;
}



print "Lets do this....\n";

#print "$file1\t$file2\n";

    open (IN, "<$file1");
    unless (-e "$base\_1.fasta" ) {
        open (OUT, ">$base\_1.fasta");
    }
print "Converting file $file1\n";

while (<IN>) {
    #print "IN\n";
    my @arr1 = split(/\s+/, $_);
    print OUT "$arr1[0]\n";

}

print "Converting file $file2\n";

open (IN2, "<$file2");
unless (-e "$base\_2.fasta" ) {
    open (OUT2, ">$base\_2.fasta");
}

while (<IN2>) {
    my @arr2 = split(/\s+/, $_);
    print OUT2 "$arr2[0]\n";

}


system "~mh12/git/python/fastn_shuffle.py   $base\_1.fasta  $base\_2.fasta  $base.fasta";




# do kmehr

print "bsub.py  -q small 10 $base\_$kmer\_2 /nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py  -C 20 -k $kmer -N 4 -x 2e9 --paired   $base.fasta  \n";

print "bsub.py --dep=\"$base\_$kmer\_2\" -q small 10 $base\_$kmer\_3 /nfs/users/nfs_m/mz3/bin/screed/khmer/sandbox/strip-and-split-for-assembly.py $base\_corrected.fa.keep  \n";

print "\n";

