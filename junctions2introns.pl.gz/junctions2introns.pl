#!/usr/bin/perl -w

use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: junctions2introns.pl file.junc read_cutoff

'}


my $file = shift;
my $cutoff = shift;



open (FH, "<$file") ||  die ;
open (OUT, ">$file.gff") ||  die ;

while (<FH>) {
    #print "$_";
    if ($_ =~/pathogen/) {
        my @arr = split(/\s+/ ,$_);
        my ($bl1,$bl2) = split(/,/,$arr[10]);
        my ($bs1,$bs2) = split(/,/,$arr[11]);
        my $juns = $arr[1]+$bl1+1;
        my $june = $arr[1]+$bs2;
        #print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[4]\t$arr[5]\t$arr[10]\t$arr[11]\t$juns\t$june\n"; 
        if ($arr[4] > $cutoff) {
            print OUT "$arr[0]\tjunctions\tintron\t$juns\t$june\t.\t$arr[5]\tscore=$arr[4]\tID=$arr[3];score=$arr[4]\n"; 
        }
    }
}


close (FH);
close (OUT);


