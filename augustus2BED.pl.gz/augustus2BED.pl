#!/usr/bin/perl -w
# mz3 script for adding parent-children relationship to a gtf file and make it into gff

use strict;

# my @array;
my @result;

while (<>) {
	chomp;
# tr/=/ /;
	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];

	my $note = $line[8];
#print "$note\n";
	$name =~ s/ //g;
#	$note =~ s/"//g;
#	$note =~ s/;//;
#	$current_ID = $note;
#	print "$current_ID\n";


# print "$start $end \n";

if ($start < $end) {
# print "$_ \n";
print "$name\t$method\t$tag\t$start\t$end\t$score\t$strand\t.\t$note\n";
# print "Keep: $start  $end \n ";
}
elsif ($start > $end) {	
#print "Turn: $start  $end \n ";
# print "$name\t$method\t$tag\t$end\t$start\t$score\t$strand\t$note\n ";
print "$name\t$method\t$tag\t$end\t$start\t$score\t$strand\t.\t$note\n";
}
else {
print "This line is weird: $_";
}


}

 print @result;


__END__


sub USAGE {

die 'Usage: perl augustus2BED.pl <gff-file> > outputname


'
}



