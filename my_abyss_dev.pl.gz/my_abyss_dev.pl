#!/usr/local/bin/perl -w

use strict;
use Getopt::Std;

my %opts;
unless (@ARGV) {
        &USAGE;
}
getopts('hvtsi:o:k:n:l:q:m:', \%opts);
&USAGE if $opts{h};

sub USAGE {

die 'Usage: my_abyss_pe.pl [-vh] -i <path_to_fast(a|q) -o <output_prefix> -k <kmer size> [options]

THIS SCRIPT WOULD BSUB YOUR JOB AUTOMATICALLY, DO NOT BSUB IT PLEASE!!!

	-i: 	directory to fasta or fastq files (not compatible with -l)
	-l:	libraries config file (not compatible with -i)
	-o: 	output prefix (your_abyss by default)
	-k INT: kmer size
	-n INT: ABySS option; is the minimum number of pairs 
	    	needed to consider joining two contigs.
	    	Determined by trail. (10 by default)
	-q INT: Quality threshold to trim end of the reads. (default Q < 3)
	-v: No run (verbose). Will print only the job call
	-t: Transcriptome assembly (for RNAseq)
	-m INT: Memory (Gb) for bsub process (30 default)
	
If you want to assemble libaries with different insert sizes, you need a lib config file.
For the lib config file, create tab-separated file with library name, pair status (paired|unpaired) 
and whole path to the fastq files:

Example:

lib1	paried	/path_to/fastq_pairs1_1	/path_to/fastq_pairs1_2
lib2	unpaired	/path_to/fastq_file
lib3	paired /path_to/fastq_pairs2_1	/path_to/fastq_pairs2_2

'
}


### TEST NEW ABYSS##
#my $path = "/nfs/users/nfs_a/as9/bin/SR_assemblers/abyss_bin_1.2.2/bin"; # ABySS v.1.2.2
#my $path = "/nfs/users/nfs_a/as9/bin/SR_assemblers/abyss_bin_1.2.4/bin"; # ABySS v.1.2.4
###
#system("source /software/pathogen/etc/test.cshrc.pathogen");
#my $path = "/nfs/users/nfs_a/as9/bin/SR_assemblers/abyss_bin_1.2.6"; # ABySS v.1.2.6
my $path = "/nfs/users/nfs_a/as9/bin/SR_assemblers/abyss_bin_1.2.7/bin"; # ABySS v.1.2.7

my $abyssp = "$path/ABYSS-P";
my $pe = "$path/abyss-pe";
my $bsub = "/nfs/users/nfs_a/as9/bin/bsub_abyss_pe.pl";
my $mpi = "/nfs/users/nfs_a/as9/bin/mpiSub";
my $in = "";
my $out = "your_abyss";
my $k = "";
my $n = 10; #Default
my $c = 0;
my $cpus = 2; #CPUS
my $libs = "";
my $numfiles = "";
my @files;
if ($opts{i} and $opts{l}) {
	die "The options -i and -l are not compatible... Use one or the other\n";
}
elsif ($opts{i} and $opts{k}) {
	$in = $opts{i};
	$k = $opts{k};
	$numfiles = `ls $in/ | grep -c fast`;
	chomp $numfiles;
	#print "in $in kmer $k"; <STDIN>;
}
elsif ($opts{l} and $opts{k}) {
	$k = $opts{k};
	($libs, $in) = LIBS($opts{l});
	#print $in; <STDIN>;
	@files = split (/\s+/, $in);
	$numfiles = scalar @files;
}
else {
	print STDERR "No input/kmer size specified...\n";
	&USAGE;
}


if ($opts{o}) {
	$out = $opts{o};
} else {
	print STDERR "No output prefix specified... Your result would be named 'your_abyss.*'\n";
}

if ($opts{n}) {
	$n = $opts{n};
}

my $abyssopt = "-v -k $k -g --coverage-hist=coverage.hist -s $out-bubbles.fa -o $out-1.fa";

if ($opts{t}) {
	$abyssopt = "-v -E0 -k $k -g --coverage-hist=coverage.hist -s $out-bubbles.fa -o $out-1.fa";
}

if ($opts{q}) {
	$abyssopt .= " --trim-quality=$opts{q}";
} else {
	$abyssopt .= " --standard-quality";
}

my $peopt = "v=-v k=$k j=8 n=$n ";

if ($k > 60) {
	$peopt .= "s=200 ";
}

if ($opts{t}) {
	$peopt .= "OVERLAP_OPTIONS=--no-scaffold SIMPLEGRAPH_OPTIONS=--no-scaffold";
}


#print $numfiles; <STDIN>;

my $host = `hostname`;
chomp $host;
my $q = "normal";
#my $q = "parallel";
$c = $numfiles;


if ($c > 1) {
	$cpus = $c*2;
} else {
	$cpus = 4;
}

if ($cpus > 16) {
	$cpus = 16;
}

my $qmem = 15;

if ($opts{m}) {
	$qmem = $opts{m};
}

if ($qmem > 15) {
	$q = "hugemem";
}

if ($opts{s}) {
	$q = "hugemem-restricted";
}

my $random = int(rand(100000));

#my $call2 = "$pe $peopt in='$in/*.fast*' name=$out";
my $call = "$bsub -extra '-n $cpus' $q $qmem $out.o $out.e $out.abyss.$random $mpi $abyssp $abyssopt \"$in/*.fast*\"";
my $call2 = "$bsub -extra \"-w 'done($out.abyss.$random)'\" normal 15 $out-pe.o $out-pe.e $out\_pe '\"$pe $peopt in='$in/*.fast*' name=$out\"'";

if ($libs) {
	$call = "$bsub -extra '-n $cpus' $q $qmem $out.o $out.e $out.abyss.$random $mpi $abyssp $abyssopt \"$in\"";
	$call2 = "$bsub -extra \"-w 'done($out.abyss.$random)'\" normal 15 $out-pe.o $out-pe.e $out\_pe '\"$pe $peopt name=$out $libs\"'";
}

if ($host =~ /pcs4/) {
	$q = "long";
	$call = "$bsub -extra '-n 8' $q $qmem $out.o $out.e $out.abyss.$random $mpi $abyssp $abyssopt \"$in/*.fast*\"";
} elsif ($host =~ /seq1/) {
	$q = "phrap";
	$qmem = 30;
	if ($libs) {
		$call2 = "$bsub -extra \"-w 'done($out.abyss.$random)'\" $q 15 $out-pe.o $out-pe.e $out\_pe '\"$pe $peopt in='$in/*.fast*' name=$out\"'";

	}
	$call = "$bsub -extra '-n 4' $q $qmem $out.o $out.e $out.abyss.$random $mpi $abyssp $abyssopt \"$in/*.fast*\"";
	$call2 = "$bsub -extra \"-w 'done($out.abyss.$random)'\" $q 15 $out-pe.o $out-pe.e $out\_pe '\"$pe $peopt in='$in/*.fast*' name=$out\"'";
}

if ($opts{v}) {
	print ("ABYSS-P:\n$call\n\n");
	print ("abyss-pe job:\n$call2\n");
} else {
	system ("$call");
	system ("$call2");
}

sub LIBS {

my $file = shift @_;
open FILE, "$file" || die "Cannot open $file\n";
my %hash;
my @se;
my @allfiles;
while (<FILE>) {
	if (/^\w+/) {
		my @line = split (/\s+/, $_);
		my $lib = $line[0];
		my $status = $line[1];
		if ($status eq "paired") {
			push(@{$hash{$lib}}, $line[2]);
			push(@{$hash{$lib}}, $line[3]);
			push(@allfiles, $line[2]);
			push(@allfiles, $line[3]);
		} 
		elsif ($status eq "unpaired") {
			push(@se, $line[2]);
			push(@allfiles, $line[2]);
		}
	}
}
#print "-@allfiles"; <STDIN>;
my $allunpair = join(" ", @allfiles);
#print "madre $allunpair"; <STDIN>;
my $libs = join(" ", sort keys %hash);
my $libvar = "lib='\"'\"'$libs'\"'\"'";
my $opts .= "$libvar ";
foreach my $key (sort keys %hash) {
	my $join = join(" ", @{$hash{$key}});
	$opts .= "$key='\"'\"'$join'\"'\"' ";
}
if (@se) {
	my $join = join(" ", @se);
	$opts .= "se='\"'\"'$join'\"'\"' ";
}

return ($opts, $allunpair);

}
