#!/usr/bin/perl
use strict;


unless (@ARGV > 2) {
        &USAGE;
}



sub USAGE {

die '

Usage:

perl ~/bin/perl/diff_me.pl   <file.rpkm>  <order> 

Example:

perl ~/bin/perl/diff_me.pl  HOMEO.emu.rpkm 3 10


    order - file with all the conditions ordered




WARNING - nonfunctional script!!!!!


';

}




my $rpkm = shift;
my $order = shift;


# make an R input file



open (RF, ">$rpkm.code.R") || die "$!";

print RF "

x<-read.table(\"$rpkm\", header=TRUE)
#x<-x[,-1]
row.names(x)

x.m = data.matrix(x)

library(gplots)

pdf(\"$rpkm\.pdf\")

heatmap.2(x.m,  Rowv=NA, Colv=NA, col=rev(redgreen(20)), margins=c(5,10), key=FALSE, symkey=FALSE, density.info=\"none\", trace=\"none\")

dev.off()

svg(\"$rpkm\.svg\")

heatmap.2(x.m, Rowv=NA, Colv=NA, col=rev(redgreen(20)), margins=c(5,10), key=FALSE, symkey=FALSE, density.info=\"none\", trace=\"none\")

dev.off()



";


close(RF);

system  "R-3.0.0 CMD BATCH $rpkm.code.R\n ";

print "\n";



