#!/usr/bin/perl -w


if (@ARGV < 2 ) {
    print '
    
    
    Usage: randomlist.pl list range 
   

    Example:  perl randomlist.pl file.list 10-25  reps

    Range: range of length of outputfile, 10-25 will give outputfiles of lengths 10-25 lines

    Reps: Number of outputfiles to write


    
    ';

            exit;
}


my $in = shift;
my $range = shift;
my $reps= shift;

my @ranges=split(/\-/,$range);



open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;

my $max = scalar(@in);






while ($reps > 0 ) {

my %randoms;
my $nos; 

if (scalar(@ranges)<2) {

#print "Shortrange $nos \n";
$nos = $ranges[0];

}

else {

$nos = int(rand($ranges[1]-$ranges[0]+1))+ $ranges[0];
print "Longrange $nos\n";

}



while ( (keys %randoms) < $nos ) {
    my $nums= int(rand($max));
    my $lens = keys %randoms;
    #print "Lens $lens\n";    
    $randoms{$nums}=1;

}

my @outlist;

foreach my $key (keys %randoms) {
    my $el = $in[$key];
    chomp $el;
    $el=~s/\s+//g;
    $el=~s/ //g;
    #print ":$el:\n";
    push (@outlist,"$el");
}

open (OUT, ">$in.$range.$reps.list") || die "I can't open $in.$range.$reps.list\n";

foreach my $ele (@outlist) {
    print OUT "$ele\n";
}

$reps--;
close(OUT);

sleep(0.5);



}



close(IN);


exit;












