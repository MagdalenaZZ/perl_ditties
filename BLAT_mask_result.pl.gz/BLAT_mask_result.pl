#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_result.pl blatout.psl file_1.fastq file_2.fastq

Takes a blat-output, and retrieves the hits from a fastq file.

Then masks the hits with low-quality Ns and outputs new balanced fastq-files


Warning: psl-files should have no header


' . "\n";
}


my $blat = shift;
my $fastq1 = shift;
my $fastq2 = shift;


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        if ($arr[0]> 11 and $arr[1] < 2 ) {
        #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]" ;
                
                # make a hit-match
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}


#__END__
# read the fastq-files line by line, and print the reads with a match to another file

=pod
if ($file =~ /\.gz$/) {
open(IN, "gunzip -c $file |") || die "can't open pipe to $file";
}
else {
open(IN, $file) || die "can't open $file";
}
=cut


if ($fastq1 =~ /\.gz$/) {
    open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";
}
else {
    open(FAS1, $fastq1) || die "can't open $fastq1";
}

if ($fastq2 =~ /\.gz$/) {
    open(FAS2, "gunzip -c $fastq2 |") || die "can't open pipe to $fastq2";
}
else {
    open(FAS2, $fastq2) || die "can't open $fastq2";
}

open (OUT1, ">$fastq1.chosen.fastq")|| die;
open (OUT2, ">$fastq2.chosen.fastq")|| die;

#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "$_";
            my $seq = <FAS1>;
            my $mid = <FAS1>;
            my $qual = <FAS1>;
            print OUT1 "$_$seq$mid$qual";
        }

    }
}


while (<FAS2>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/2$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "$_";
            my $seq = <FAS2>;
            my $mid = <FAS2>;
            my $qual = <FAS2>;
            print OUT2 "$_$seq$mid$qual";
        }

    }
}

close (FAS1);
close (FAS2);
close (OUT1);
close (OUT2);




# read in the temp-fastqs, and trim them according to the best BLAT-hit


open (IN1, "<$fastq1.chosen.fastq")|| die;
open (IN2, "<$fastq2.chosen.fastq")|| die;

open (OUT1, ">$fastq1.trimmed.fastq")|| die;
open (OUT2, ">$fastq2.trimmed.fastq")|| die;



while (<IN1>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        #$head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            #print  "$_$seq$mid$qual";

            my ($min,$max) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";

            #print "$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $new_qual = substr($qual, $min, $len, $polyI );
            #print "$seq, $min, $len, $polyN\n";
            print OUT1 "$_$seq$mid$qual";
        }
        else {
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            print OUT1 "$_$seq$mid$qual";
        }

    }
}



while (<IN2>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        #$head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print  "$_$seq$mid$qual";

            my ($min,$max) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";

            #print "$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $new_qual = substr($qual, $min, $len, $polyI );
            #print "$seq, $min, $len, $polyN\n";
            print  "$_$seq$mid$qual";
        }
        else {
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            print OUT2 "$_$seq$mid$qual";
        }
        

    }
}




close (IN1);
close (IN2);
close (OUT1);
close (OUT2);

