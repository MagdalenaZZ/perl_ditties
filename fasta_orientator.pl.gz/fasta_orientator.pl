#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: fasta_orientator.pl fasta.fas

Takes one fasta-file, and then does pairwise alignments of all the sequences within it, to make sure the sequences are all the right orientation

It uses the longest sequence as the "right orientation".



'
}


my $dom1 = shift;
#my $dom2 = shift;

my $rhead;
my $rseq;
my $rlen=0;


# read all fastas to a hash
	open (IN, "<$dom1") || die "I can't open $dom1\n";
#	my @doms = <IN>;
#
my %h;

    while (<IN>) {
        chomp $_;
        if ($_ =~/^>/) {
            my $head = $_;
            $head =~s/.1..pep//;
            $head =~s/.2..pep//;
            $head =~s/.3..pep//;
            $head =~s/>//;
            my $seq = <IN>;
            chomp $seq;

            if ($head =~/\w+/ and $seq =~/\w+/) {
                $h{$head} = $seq;
                
                # save the longest
                my $len =length($seq);
                if ($len > $rlen) {
                    $rhead = $head;
                    $rseq = $seq;
                    $rlen = $len;
                }


            }

        }
    }

close (IN);

my %alns;


# print reference
open (A, ">A.seq") || die "I can't open A.seq\n";
print A ">$rhead\n$rseq\n";
close (A);

if (-s "$dom1.fr.fas" ) {
    die "Output file already exists\n";
}

open (OUT, ">$dom1.fr.fas") || die "I can't open $dom1.fr.fas\n";

#__END__


foreach my $gene1 (keys %h){ 

            open (B, ">B.seq") || die "I can't open B.seq\n";
            print  B ">$gene1\n$h{$gene1}\n";
#           print A "$gene1\n$h{$gene1}\n";
#           print B "$gene2\n$h{$gene2}\n";
            close (B);

            open (C, ">C.seq") || die "I can't open C.seq\n";
            
            my $revseq = $h{$gene1};
            my $rgene1 = $gene1 . "rev";
            $revseq =~tr/ACGTacgt/TGCAtgca/;
            $revseq = reverse($revseq);
            #print "$h{$gene1}\n$revseq\n";
            print  C ">$rgene1\n$revseq\n";
#           print A "$gene1\n$h{$gene1}\n";
#           print B "$gene2\n$h{$gene2}\n";
            close (C);


            system "stretcher -asequence A.seq -bsequence B.seq -outfile AB.aln"; 
            system "stretcher -asequence A.seq -bsequence C.seq -outfile AC.aln";


                my $fscore;
                my $rscore;


            # read in forward align
            open (ALN1, "<AB.aln") || die "I can't open AB.aln\n";


               while (<ALN1>) {
                   chomp $_;
                   if ($_ =~/# Identity:/) {
                       $fscore= $_;
                       my @fscore = split(/\(/,$fscore);
                       $fscore = $fscore[1];
                       $fscore=~s/\%\)//;
#                   print "$score\n";

                   }
               }

            # read in reverse alignc
            open (ALN2, "<AC.aln") || die "I can't open A.aln\n";

               while (<ALN2>) {
                   chomp $_;
                    if ($_ =~/# Identity:/) {
                       $rscore= $_;
                       my @rscore = split(/\(/,$rscore);
                       $rscore = $rscore[1];
                       $rscore=~s/\%\)//;
#                   print "$score\n";

                   }
               }

            close (ALN1);
            close (ALN2);
            system "rm -f AB.aln AC.aln";

            # it is right orientation
            if ($fscore > $rscore) {
                print OUT ">$gene1\n$h{$gene1}\n";
                #print ">$gene1\n$h{$gene1}\n";
            }

            # it is wrong orientation - flip it
            else {
                print  OUT  ">$rgene1\n$revseq\n";
                #print  ">$rgene1\n$revseq\n";

            }



#        }
#    }

}

system "mv A.seq reference_for_orientation.fas";
system "rm -f B.seq C.seq";

print "\nOutput file is $dom1.fr.fas\n ";


exit;





