#!/usr/local/bin/perl -w
#
use strict;

unless (@ARGV == 1) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: brenda_parser.pl enzyme.dat
ftp://ftp.ebi.ac.uk/pub/databases/intenz/enzyme/enzyme.dat



'
}

### this is the splitter-part of the script ####

my $in = shift;


open (IN, "<$in");
my @in = <IN>;
close (IN);

my $ec;
my $prod;
my $gid;
my %h;

foreach my $line (@in) {
    chomp $line;
    if ($line=~/^ID/ ) {
        $line=~s/^ID//;
        $line=~s/ //g;
        $ec = $line;
    }
    elsif ($line=~/^DE/) {
        $line=~s/^DE//;
        $line=~s/ //g;
        $line=~s/\.$//;

        $prod=$line;

    }
    elsif ($line=~/^DR/) {
        my @arr=split(/([,;])/, $line);
#        print "$arr[0]\t $arr[1]\t$arr[2]\n";
        foreach my $elem (@arr) {
            if ($elem=~/\w+_\w+/) {
                my @arr2=split(/_/, $elem);
#                print "$arr2[0]\n";

                $h{  "$ec\t$prod" } { $arr2[0] } +=1;
            }
        }

    }
    else {
    }

}


foreach my $ecn ( sort keys %h ) {
    my $max = 0;
    my $best;

    foreach my $name ( keys %{$h{$ecn}}  ) {

#        print "$name\t$h{$ecn}{$name}\n";
        if (  $h{$ecn}{$name} > $max  ) {
            $best = $name;
        }
    }

    print "$ecn\t$best\n";
}

