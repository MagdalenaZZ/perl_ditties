#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta_from_gff_gene.pl ref.fas input.gff out-prefix <offset>

Takes a gff-file and a fasta-file and makes fasta-file from it.


Example:
perl ~/bin/perl/fasta_from_gff_gene.pl genome.fa  file.gff 
perl ~/bin/perl/fasta_from_gff_gene.pl genome.fa  file.gff 10


NOT WORKING  --> if you set offset to "adaptive", it will extend to next gene

# make sure the fasta is single-line

offset will add a set of bases to the start or the end of your sequence (it is optional, and should only be used when there are not CDS which should be cobbled together)



'
}


	my $ref = shift;
	my $in = shift;
	my $out = $in;
    my $off = 1;

    if (@ARGV) {
        $off = shift;
        if ($off=~/^0$/) {
            $off=1;
        }
    }

    $off = 1;

# get the genes from the gff

my %gff;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

    my $gene;

    foreach my $ele (@in) {
        chomp $ele;
        my @arr = split(/\t/, $ele);
        if ($arr[2]=~/gene/ and $arr[3]=~/\d+/ and $arr[4]=~/\d+/  ) {
            $gff{$arr[0]}{"$arr[3]\t$arr[4]\t$arr[6]"}{"GENE"}="$ele";
            $gene ="$arr[3]\t$arr[4]\t$arr[6]";
            #print "$arr[3]\t$arr[4]\t$arr[6]\n";
        
        }
        elsif ($arr[3]=~/\d+/ and $arr[4]=~/\d+/  ) {
            push( @{$gff{$arr[0]}{$gene}{"CDS"}}, "$ele") ;

        }
        else {
            print "Bad line: $ele\n";
        }
    }


# read in the fasta

open (FAS, "<$ref") || die "I can't open $ref\n";

my %fas;
$/ = ">";   



while (<FAS>) {
    chomp;
    if ($_=~/\w+/) {
        my @ar2 = split(/\n/,$_);
        my $head = shift(@ar2);
        my $seq = join("", @ar2);
        #print "$head\t$seq\n";
        if ($head =~/\w+/ and $seq=~/\w+/){
            $fas{$head}=$seq;
        }
    }
}

$/ = "\n";  

# extranct the genes from the fasta

open (OUT, ">$out.fas") || die "I can't open $out.fas\n";
open (OUG, ">$out.gff") || die "I can't open $out.gff\n";	


foreach my $scaf (sort keys %gff ) {
   
    my $seq;
    #print "$scaf";
    if (exists $fas{$scaf}) {
        #print "$scaf exists\n";
        $seq= $fas{$scaf};
    }
    else {
        print "$scaf does not exists in fasta, will be ignored - check you chose the right fasta and gff-file\n\n";
    }


    # get the gene coordinates from the fasta

    foreach my $gen (sort keys %{$gff{$scaf}} ) {
        

        # now get the fasta-sequence covering that gene
        my ($start,$end,$ori)=split(/\t+/, $gen );
        #
        #print "$scaf\t$gen\t:$start:$end:$ori:\t$gen\t$gff{$scaf}{$gen}{GENE}\n";

        #print "S:$start:\tOF:$off:\n";
            $start = $start - $off;
            my $adjust = $start - $off+1;

            my $len = ($end - $start  + $off );
            $end = $end + $off;
            my $sub = substr($seq, $start, $len);
            print OUT ">$scaf\_$start\-$end\-$len\n$sub\n";
            print OUT ">$gff{$scaf}{$gen}{GENE}\n$sub\n";


        # now re-position the gff-file
        
        # recalculate gene-positions
        my @new_gene = split(/\t/, $gff{$scaf}{$gen}{GENE});
        $new_gene[0]="$scaf\_$start\-$end\-$len";
        $new_gene[3]=($new_gene[3]-$adjust-$off);
        $new_gene[4]= ($new_gene[4]-$adjust-$off);
        my $new_gene = join("\t", @new_gene);

        #print "$gff{$scaf}{$gen}{GENE}\n";
        print OUG "$new_gene\n";  
        #print  "$new_gene\n";

         if (exists $gff{$scaf}{$gen}{CDS}  ) {
            foreach my $cds ( @{ $gff{$scaf}{$gen}{CDS} } ) {
           
           
                # recalculate other posistions 
                
                               
                my @new_cds= split(/\s+/, $cds);
                
                #print "CDS " . scalar(@new_cds) . " $adjust $cds\n";

                if (scalar(@new_cds)>7) {
                    $new_cds[0]="$scaf\_$start\-$end\-$len"; 
                    $new_cds[3]=($new_cds[3]-$adjust-$off);
                    $new_cds[4]=($new_cds[4]-$adjust-$off);
                    my $new_cd = join("\t", @new_cds);

                    #print "$gff{$scaf}{$gen}{GENE}\n";
                    print OUG "$new_cd\n";
                }
            }
        }
        else {
            print "empty CDS $gen\n";
        }


        

    }
}




	close (OUT);
	close (OUG);


# make files for artemis

system "samtools faidx $out.fas";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $out.gff";

print "You can use the files test.bam.trans.gff.fas and test.bam.trans.gff.gff.gz for Artemis \n\n";

__END__

