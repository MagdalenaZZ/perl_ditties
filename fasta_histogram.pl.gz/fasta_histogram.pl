#!/usr/bin/perl -w

use strict;

use GD;
use GD::Graph::hbars;
use GD::Graph::lines;
use GD::Graph::points;
use GD::Graph::linespoints;
use GD::Graph::histogram;

unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: fasta_histogram.pl file.fasta 

This program takes a fasta and makes a histogram of assembly-lengths

    ' . "\n";
}

my $query = shift;
my $scaling_factor = 100000;

unless (-s "$query.fai") {
    system "samtools faidx $query ";
}

open (FAS, "<$query.fai") || die "I can't open $query.fai\n";
#my @fas = <FAS>;
#close (FAS);
# Open reference 
my %fas;
my @fas;
my $max = 0;

# Determine maximum length and save data to fas

while (<FAS>) {
    #print "$_";
    my @arr = split(/\s+/, $_);
    $fas{$arr[0]} = $arr[1];
    if ($arr[1]=~/\d+/) {
        push (@fas, $arr[1]);
        #print "$arr[1]\n";
    }
    else {
        #print "not digit $arr[1]\n"
    }

}

close (FAS);

open (FAS, "<$query.fai") || die "I can't open $query.fai\n";

while (<FAS>) {

    my @arr = split(/\s+/, $_);
    
    if ($arr[1] > $max) {
        $max = $arr[1];
        print "Max $max\n";
    }
    #print "$arr[0]\t$arr[1]\n";

}

close (FAS);

# Determine X-bins max

my $roundup;

sub roundup {
    my $n = shift;
    return(($n == int($n)) ? $n : int($n + 1))
}

$max = $max / $scaling_factor;
$roundup = $scaling_factor* roundup($max);

print "$max\t $roundup\n";

my %res;

# for each bin, count up how many transcripts are in that bin

for (my $start = 0; $start < $roundup; $start += $scaling_factor ) {
    #print "$start\t$roundup\n";
    foreach my $key (keys %fas ) {
        #print "key $fas{$key}\n";
        if ( $fas{$key} >= $start and $fas{$key} < ($start+$scaling_factor) ) {
            #print "Match $start $fas{$key} \n";
            $res { $start } += 1;
        }
    }
    unless (exists $res{ $start }) {
        $res { $start } = 0;
    }
}

open (OUT, ">$query.txt") || die;
foreach my $key2 (sort {$a <=> $b} keys %res ) {
    print OUT "$key2\t$res{$key2}\n";
}
close (OUT);


#my ($ymax, $yticks) = scale($max,$scaling_factor);

#$opt{y_max_value}   = $max + $scaling_factor;          # Fixed
#$opt{y_tick_number} = 10;
#plot(\%opt, \@data, 'hb');
#print "@fas\n";


draw_graph( "$query.png" , @fas );

sub draw_graph {
    my ( $filename, @fas ) = @_;
    my $graph = new GD::Graph::histogram( 1000, 1000 );
    $graph->set(
        x_label           => 'Data',
        y_label           => 'Count',
        title             => 'A Histogram Chart',
        x_labels_vertical => 1,
        bar_spacing       => 1,
        shadow_depth      => 0,
        shadowclr         => 'dred',
        transparent       => 0,
        histogram_type => 'count',
        histogram_bins => $max ,
        x_max_value       => $roundup,
        y_min_value       => 0,
        x_min_value       => 0,

      )
      or warn $graph->error;

    my $gd = $graph->plot( \@fas ) or die $graph->error;

    open( IMG, '>' . $filename ) or die $!;
    binmode IMG;
    print IMG $gd->png;
}

