#!/usr/bin/perl -w
# mz3 script for adding parent-children relationship to a gtf file and make it into gff

use strict;


unless (@ARGV > 0 ) {
        &USAGE;
}

my $in = shift;
my $out = $in;
$out =~s/gtf/gff/;

open (IN, "<$in") or die "Cant find infile $in\n" ;

#=pod
if (-e "$out") {
    die "File $out already exists, cant overwrite\n";
}
else {
    print "outfile $out\n\n";
}
#=cut

open (OUT, ">$out") or die "Cant find infile $out\n" ;

# my @array;
my $current_ID = "";
my $last_ID = "";
my $counter = "1";
my @result = '';
my $ID_number = "1";
my %seen;
my $tstart;
my $tend;
my $gstart;
my $gend;



while (<IN>) {
	chomp;
    tr/=/ /;

    unless ($_=~/exon/) {
        # ignore;
        next;
    }

	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $note = $line[9];
	my $note2 = $line[11];

	$note =~ s/"//g;
	$note =~ s/;//g;
	$note2 =~ s/"//g;
	$note2 =~ s/;//g;

    my $gene = $note;
    my $trans = $note2;
    

    #print "NOTE:$gene:$trans:\n";

=pod
if ($tag =~ /transcript/) {
	$ID_number ++;
	
    # check if that gene has been seen before - if it has, don't output it again
    unless (exists $seen{$note}) {
        my $newline = "$name\t$method\tgene\t$start\t$end\t.\t$strand\t.\tID=$name.$note\n";
    	push (@result, $newline);
        $seen{$note}=1;
        $ID_number=1;
    }

#	print" $newline";
	my $newline2 = "$name\t$method\ttranscript\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans;Parent=$name.$note\n";
#	print "$newline2";
	push (@result, $newline2);

	$last_ID = $note;
	$counter = "0";
}
=cut

    # this is an old gene
    if ($tag =~ /exon/ and exists $seen{$gene} and exists $seen{$trans}) {	

        
        my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans.Exon$counter;Parent=$name.$note.$trans\n";
        push (@result, $newline);
        #print "E $newline";
        #	$last_ID = $note;
        $counter++;

        my($tstart,$tend) = split(/\t/, $seen{$trans});
        my($gstart,$gend) = split(/\t/, $seen{$gene});
        # find out which start is first
            my $tmin = ($tstart, $start)[$tstart > $start];
            my $tmax = ($end, $tend)[$end < $tend];
            my $gmin = ($gstart, $start)[$gstart > $start];
            my $gmax = ($end, $gend)[$end < $gend];

            #print "$seen{$trans}\t$start\t$end\t:\t$min\t$max\n";

        $seen{$trans} = "$tmin\t$tmax";
        $seen{$gene} = "$gmin\t$gmax";
    }


    # if this is a new transcript
    elsif ($tag =~ /exon/ and exists $seen{$gene} ) {	

        
        
        my $transline = "$trans\t$name\t$method\tmRNA\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans;Parent=$name.$note\n";
        my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans.Exon$counter;Parent=$name.$note.$trans\n";
        
        #print "T $transline";
        #print "T $newline";

        push (@result, $transline);
        push (@result, $newline);

        #print "$note\t$transline";

        #	$last_ID = $note;
        
        # start a new transcript
            $seen{$trans}="$start\t$end";
            $counter++;
    }


    # this is a new gene
    elsif ($tag =~ /exon/ ) {
        
        $counter=1;

        # first print the old gene
        my $geneline = "$gene\t$name\t$method\tgene\t$start\t$end\t.\t$strand\t.\tID=$name.$note\n";
        my $transline = "$trans\t$name\t$method\tmRNA\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans;Parent=$name.$note\n";
        my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t.\tID=$name.$note.$trans.Exon$counter;Parent=$name.$note.$trans\n";

        push (@result, $geneline);
        push (@result, $transline);
        push (@result, $newline);

        #print "G $geneline";
        #print "$transline";
        #print  @result;
        #print "G $transline";
        #print "G $newline";

        # then start the new gene
        $seen{$gene}="$start\t$end";
        $seen{$trans}="$start\t$end";

        $counter++; 
    }



    else {
        print "This line is not transcript or exon: $_";
    }

}




foreach my $ele (@result) {

   if ($ele=~/\w+/) { 
    
    my @line = split(/\t/, $ele);
    my $head = shift(@line);
    #print "$head " . scalar(@line) . "\n";

    # for genes
    if ($line[2]=~/gene/) {

        #my $gene = $line[0];
        #print "GENE\t$head\n";

        my($start,$end)= split(/\t/, $seen{$head});
        $line[3] = $start;
        $line[4] = $end;
        my $res = join("\t", @line);
        print OUT "$res";
    }

    # for transcripts
    elsif ($line[2]=~/mRNA/) {
        #my $trans = $line[0];
        #print "TRANS\t$head\n";
        my($start,$end)= split(/\t/, $seen{$head});
        $line[3] = $start;
        $line[4] = $end;
        my $res = join("\t", @line);
        print OUT "$res";
    }
    # for genes
    else {
        print OUT "$ele";
    }

}

}


# print OUT @result;

 close (OUT);

sub USAGE {

die 'Usage: perl cufflinks2gff.pl <gtf-file> 

This version re-names those blasted cufflinks-names


'
}

__END__

