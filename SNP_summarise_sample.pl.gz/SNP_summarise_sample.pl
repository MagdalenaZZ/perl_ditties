#!/usr/bin/perl
use strict;

unless (@ARGV >1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/SNP_summarise_sample.pl file.vcf.gz column


This script will summarise instances of homozygous and heterozygous calls for samples in the column you ask for 
(put 1 for sample 1)

example: 

perl ~/bin/perl/SNP_summarise_sample.pl SNPs.vcf.gz 2


';

}

my $in = shift;
my $col = shift;
#$col = $col+8;
#my $gs = shift;
#my $rosetta = "/Users/magz/gsea_home/my_refs/ENSMUSG_vs_symbol.txt";


my %syms;

#open (IN, "< bcftools view $in |") || die "Cannot find file $in \n";
open my $ins, "bcftools view $in |" || die "Error \n";
open (OUT, "> $in.$col") || die "\nCannot write to file $in.$col\n";
$col = $col+8;

# Tese are the categories of SNPs to count up

my $SNPhom=0;
my $SNPhet=0;
my $match=0;
my $null=0;
my $SNPhetns=0;
my $SNPcomp=0;


# Go through the vcf file and count up the instances of different SNP classes

while (<$ins>) {
    chomp;

   my @ar=split(/\t/, $_);
#	print "$col $_\n";
    if ($_=~/^#/) {
        #if ($_=~/#CHROM/) {
        #    print OUT "$ar[0]\t$ar[1]\t$ar[2]\t$ar[3]\t$ar[4]\t$ar[5]\t$ar[6]\t$ar[7]\t$ar[8]\t$ar[$col]\n";
        #}
        #else {
         #   print OUT "$_\n";
        #}
    }
    
    elsif ($ar[$col]=~/0\/1/){
        #print OUT "$_\n";
	$SNPhet++;
    }
    elsif ($ar[$col]=~/0\/0/) {
        #print OUT "$_\n";
	$match++;
    }
    elsif ($ar[$col]=~/1\/0/) {
        #print OUT "$_\n";
	$SNPhet++;
    }
    elsif ($ar[$col]=~/0\/2/) {
        #print OUT "$_\n";
	$SNPhet++;
    }
    elsif ($ar[$col]=~/1\/2/) {
        #print OUT "$_\n";
	$SNPhetns;
    }
    elsif ($ar[$col]=~/1\/1/) {
        #print OUT "$_\n";
	$SNPhom++;
    }
    elsif ($ar[$col]=~/2\/2/) {
        #print OUT "$_\n";
        $SNPhom++;
    }
    elsif($ar[$col]=~/\.\/\./) {
        #print "Couldnt call $ar[$col]\n";
        $null++;
    }
    else {
	print OUT "$ar[$col]\tUndefined $_\n";	
	$SNPcomp++;
    }

}

print OUT "$SNPhom SNPs homo not same as reference # $SNPhet SNPS het # $SNPhetns SNPs het none same as ref # $match Homo same as reference # $null not called # $SNPcomp its complicated\n\n";


close(OUT);
#system "bcftools view  -O z  $in.$col  > $in.$col.vcf.gz";

exit;
__END__


