#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=1) {
        &USAGE;
}


sub USAGE {

die 'Usage: 


    BAM2fastq_get_fasta.pl file.bam.fastq

    Takes the output from BAM2fastq.pl and sanitises it



'
}


	my $in = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	open (OUT, ">$in.fas") || die "I can't open $in.fas\n";

    # read in fasta

my %fas;
my $inseq = 0;
my $inqual = 0;
my $seq_name = 0 ;
my $seq_name2 = 0 ;
my $i = 1;

while (<IN>) {
    chomp;
   
    if (/^@(\S+)/) {
        $seq_name = $_;
        $seq_name =~s/^@//;

        #print "$seq_name\n";
        $inseq = 1;
        $inqual = 0;
        $seq_name2 = "$seq_name" . "_$i" ;
        $i++;
    }
    elsif ($_=~/^\+$/) {
        #print "End of seq $_\n";
        $inseq = 0;
        $inqual = 1;
    }	
    elsif ($inseq=~/1/) {
        #print "SEQ $_\n";
        if (exists  $fas{$seq_name2}{"SEQ"}) {
            #print "is $seq_name2\n";
            $_=~s/\s+//g;
            $fas{$seq_name2}{"SEQ"}=$fas{$seq_name2}{"SEQ"} . "$_";
        }
        else {
            $_=~s/\s+//g;
            $fas{$seq_name2}{"SEQ"}="$_";
            #print "make $seq_name2\n";
        }

    }	
    elsif ($inqual=~/1/) {
        #print "QUAL $_\n";
        if (exists  $fas{$seq_name2}{"QUAL"}) {
            $_=~s/\s+//g;
            $fas{$seq_name2}{"QUAL"}=$fas{$seq_name2}{"QUAL"} . "$_";
        }
        else {
            $_=~s/\s+//g;
            $fas{$seq_name2}{"QUAL"}= "$_";
        }


    }

    else {
    }

}


close(IN);

#__END__

foreach my $key (sort keys %fas) {
    #print "$key\n";
    #my $sl = length($fas{$key}{SEQ});
    #my $ql = length($fas{$key}{QUAL});

    #print "$sl $ql\n";
    #print "$fas{$key}{SEQ}\n";
    #print "$fas{$key}{QUAL}\n";

    my @arr = split(/n/, $fas{$key}{SEQ} );

    my $start = 0 ;
    my $end = 0 ;
    foreach my $el (@arr) {
        if ($el=~/\w+/) {

        my $len = length($el) ;
        my $sub = substr(  $fas{$key}{SEQ}, $start, $len );
        my $qual = substr( $fas{$key}{QUAL}, $start, $len );

        $end =  $start + $len;
        print OUT "\@$key $start $end\n";
        #print "$el\n";
        print OUT "$sub\n\+\n";
        print OUT "$qual\n";

        $start = $start + $len;
        $start++;

        }
        else {
            $start++;
            #$end++;
        }
    }

}


close(OUT);




