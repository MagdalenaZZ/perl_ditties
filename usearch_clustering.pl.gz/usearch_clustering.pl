#!/usr/bin/perl
use strict;

#print "HI";

unless (@ARGV >= 1) {
        &USAGE;
}


sub USAGE {

die '

Usage: perl ~/bin/perl/usearch_clustering.pl Velvet_folder

This script will take your output from a velvet assembly, or a fasta-file, and cluster it.

Warning: by default it takes both transcripts and unused reads!

The script will output a unified fasta-file

';

}


#my $velfol = 0;
my $velfol = shift;
my $fold = 0;

if (-d $velfol) {
    print "\nYou input a velvet folder\n\n";
    $fold= 1;
}
else {
    print "\nYou input a fasta file\n\n";
}


my @arr = split(/\//,$velfol);

if ($fold =~/1/) {
    my $f1;
    my $f2;

    if (-e "$velfol/transcripts.fa") {
        $f1 = "$velfol/transcripts.fa";
    }
    else {
        print "\nWARNING - the velvet-folder does not contain the results-file transcripts.fa .\nPlease ensure that velvet has finished without errors and that you are calling the right folder\n";
        exit;
    }

    if (-e "$velfol/UnusedReads.fa") {
        $f2 = "$velfol/UnusedReads.fa";
    }


#print "cat $f1 $f2 > $arr[-1].fa \n ";
#print "cat $arr[-1].fa | sed 's/\\//-/' >  $arr[-1].fa.tmp \n";
#print  "fasta2singleLine.py $arr[-1].fa.tmp $arr[-1].fa.sl \n";
    system "cat $f1 $f2 > $arr[-1].fa ";
    system "cat $arr[-1].fa | sed 's/\\//-/' >  $arr[-1].fa.tmp";
    system "~mz3/bin/perl/revcomp.pl $arr[-1].fa.tmp > $arr[-1].fa.tmp.rc";
    system "cat $arr[-1].fa.tmp.rc | sed 's/\>/\>revcomp_/' > $arr[-1].fa.tmp.rc2  ";
    system "cat  $arr[-1].fa.tmp $arr[-1].fa.tmp.rc2 >  $arr[-1].fa.tmp2 ";
    system "fasta2singleLine.py $arr[-1].fa.tmp2 $arr[-1].fa.sl ";
    system "rm -f $arr[-1].fa.tmp $arr[-1].fa.tmp2 $arr[-1].fa.tmp.rc2 $arr[-1].fa.tmp.rc $arr[-1].fa ";

}

else {

    system "cat $arr[-1] | sed 's/\\//-/' >  $arr[-1].fa.tmp";
    system "~mz3/bin/perl/revcomp.pl $arr[-1].fa.tmp > $arr[-1].fa.tmp.rc";
    system "cat $arr[-1].fa.tmp.rc | sed 's/\>/\>revcomp_/' > $arr[-1].fa.tmp.rc2  ";
    system "cat  $arr[-1].fa.tmp $arr[-1].fa.tmp.rc2 >  $arr[-1].fa.tmp2 ";
    system "fasta2singleLine.py $arr[-1].fa.tmp2 $arr[-1].fa.sl ";
    system "rm -f $arr[-1].fa.tmp $arr[-1].fa.tmp2 $arr[-1].fa.tmp.rc2 $arr[-1].fa.tmp.rc $arr[-1].fa ";

}


system "perl ~mz3/bin/perl/fasta_uniq_seq.pl $arr[-1].fa.sl";


# now split the fasta into chunks, and do each one of the chunks separately
open (IN, "$arr[-1].fa.sl")|| die;

my $out=$arr[-1];
my $targetsize = 1000000;
my $fileprefix = $out;
my $outfile = 0;
my $outsize = 0;
my $outfh;
my $temp='';
my @files;



local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
    #  print "LINE:$line:\n"; 
  next unless $line;
    # discard initial empty chunk  
    #  if($line =~ /^\$\$$/ || $outfile == 0){
  if($line =~m/\_/   || $outfile == 0){
        $outsize += length($temp);
        #        print "SIZE:$outsize:\n";
        if ( $outfile == 0 || ($outsize - $targetsize) > 0)  { 
              ++$outfile; 
              if($outfh) {close($outfh);}
              open ($outfh, '>', "$fileprefix\_$outfile.fa"); 
              push (@files,  "$fileprefix\_$outfile.fa" );
              #              print "$outfh\t$fileprefix\_$outfile\n";
              $outsize = 0;
        }
        $temp='';
    }
  $temp = $temp.$line;
  print $outfh "\>$line";  
} 

#__END__


######################
#
#
#
# make a shell-file
print "bsubbing this now:\n";

foreach my $file (@files) {

    print "$file\n";
    my $format = "summary";

#system "usearch6.0.307_i86linux32 -sortbylength $file -minseqlength 64 -output $file.sorted.fa";wait;
#system "usearch6.0.307_i86linux32 -cluster_fast $file.sorted.fa -id 0.97 -sizeout -output $file.sorted.fast.fa";wait;
#system "usearch6.0.307_i86linux32 -cluster_smallmem $file.sorted.fa -id 0.97 -sizeout -uc $file.uc  -output $file.sorted.small.fa";wait;

#print  "~mz3/bin/usearch7.0.959_i86linux32 -sortbylength $file -minseqlength 64 -output $file.sorted.fa\n";
#print "~mz3/bin/usearch7.0.959_i86linux32 -cluster_fast $file.sorted.fa -id 0.97 -sizeout -output $file.sorted.fast.fa\n";
#print "~mz3/bin/usearch7.0.959_i86linux32 -cluster_smallmem $file.sorted.fa -id 0.97 -sizeout -uc $file.uc  -output $file.sorted.small.fa\n";

    system  "~mz3/bin/usearch7.0.959_i86linux32 -sortbylength $file -minseqlength 64 -output $file.sorted.fa\n";wait;
#print "~mz3/bin/usearch7.0.959_i86linux32 -cluster_fast $file.sorted.fa -id 0.97 -sizeout -output $file.sorted.fast.fa\n";
    system "~mz3/bin/usearch7.0.959_i86linux32 -cluster_smallmem $file.sorted.fa -id 0.97 -sizeout -uc $file.uc  -output $file.sorted.small.fa\n";wait;




    system "perl ~mz3/bin/perl/usearchParser_revcomp.pl $file.uc $file";
    print "perl ~mz3/bin/perl/usearchParser_revcomp.pl $file.uc $file\n";

#system "rm -f $file.sorted.fast.fa $file.sorted.small.fa $file.sorted.fa ";

}

# now merge the results and run on the merged one
my $fls = join(" ", @files);
system  "cat $fls > $velfol.combined\n";










print "Completed successfully!\n";


exit;



__END__

    60	17:23	usearch -cluster_fast reads.fasta -consout cons.fasta -id 0.97 -sizeout
    61	17:23	usearch -sortbysize cons.fasta -output cons_bysize.fasta
    62	17:24	usearch -cluster_smallmem cons_bysize.fasta -id 0.97 -centroids otus.fasta
    63	17:24	usearch6.0.307_i86linux32 -cluster_fast reads.fasta -consout cons.fasta -id 0.97 -sizeout
    64	17:24	usearch6.0.307_i86linux32 -cluster_fast derep.fa -consout cons.fasta -id 0.97 -sizeout
    65	17:25	usearch6.0.307_i86linux32 -sortbysize cons.fasta -output cons_bysize.fasta
    67	17:25	usearch6.0.307_i86linux32 -cluster_fast reads.fasta -consout cons.fasta -id 0.97 -sizeout
    70	17:26	usearch6.0.307_i86linux32 -sortbysize cons.fasta -output cons_bysize.fasta
    71	17:26	usearch6.0.307_i86linux32 -cluster_smallmem cons_bysize.fasta -id 0.97 -centroids otus.fasta
    77	17:28	usearch6.0.307_i86linux32 -cluster_fast reads.fasta -consout cons.fasta -id 0.97 -sizeout -alnout alnout.aln
    81	17:30	usearch6.0.307_i86linux32 -cluster_fast reads.fasta -consout cons.fasta -id 0.90 -sizeout -alnout alnout.aln
    84	17:33	usearch6.0.307_i86linux32 -cluster_fast reads.fasta -consout cons.fasta -id 0.80 -sizeout -alnout alnout.aln
    86	17:34	history | grep usearch
   109	17:52	usearch6.0.307_i86linux32 -sortbylength reads.fasta -output seqs_sorted.fasta -minseqlength 64







