#!/usr/bin/perl -w
# mz3 script for making utr hints-files for augustus

use strict;
use Data::Dumper;
use Getopt::Std;



unless (@ARGV > 5) {
        &USAGE;
}





my $help = join(@ARGV); 

if ( $help =~/--h/ or $help =~/-help/ ) { 
        &USAGE;
}

my %opt;
$opt{"--s"} = 0;
$opt{"--a"} = 0;


push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");

foreach my $elem (@ARGV) {
    
    my $arg1 = shift(@ARGV);
    chomp $arg1;
    
    if ($arg1 =~/--a/ or $arg1 =~/--s/ ) {
        $opt{$arg1} = 1;
    }
    else {
        my $arg2 = shift(@ARGV);
        $opt{$arg1} = "$arg2";
        #print "KEYS\t$arg1\t$arg2\n";
    }
}




sub USAGE {

die '

Usage: perl ~/bin/perl/UTRmaker.pl --c  transcript-output.gtf --g genes.gff ---p prefix  --s <cut-off> --t <cut>


Mandatory:

  --c :  transcripts.gff - the output from wiggleJunkie.pl
  --g :  genes.gff   - your known genes in a gff


Optional:

  --p : output prefix 
  --u : cut-off; if the resulting UTR is longer than this it will be trimmed down to <cut> basepairs (default 1000 bp)
  --t : cut;  is the size of the UTR-fragment left behind (default 50 bp)
  --s : my transcripts file is made from single-stranded RNA
  --a : I have alternatively spliced genes, and want UTRs for all transcripts 


Output from this progam:

*.intersect : the transcripts overlapping with an annotated gene
*.orphans : the transcripts not overlapping with an annotated gene
*.transferred : file matching up the transcripts with the overlapping gene, and the number of bases with which they overlap
 

'
}



#####_####_####_####_####_####_####_#####

# Get help


if ($opt{"--h"}) {
    &USAGE;
}

#####_####_####_####_####_####_####_#####
print "\n";

# make sure there is a file
my $c;
#my @cuff;


if ($opt{"--c"}) {
    #print $opt{"--c"} . "\n";
    VALIDATEC();
} else {
	print "\nPlease give me cufflinks output i.e.  --c  cufflinks-output.gtf  \n";
    &USAGE;
}


#####_####_####_####_####_####_####_#####

sub VALIDATEC {
    # sub validate checks that there is an inputfile, and reads it
	$c = $opt{"--c"};
    open (CUFF, "<$c") || die "I can't open $c\n";
	print "Reading in cufflinks file: $c\n";
    #@cuff2 = <CUFF>;
    close (CUFF);
}

#####_####_####_####_####_####_####_#####
print "\n";

# make sure there is a file
my $g;
my @gff;

if ($opt{"--g"}) {
    #print $opt{"--g"} . "\n";
    VALIDATEG();
} else {
	print "\nPlease give me gff file i.e.  --g  file.gtf  \n";
    &USAGE;
}


#####_####_####_####_####_####_####_#####

sub VALIDATEG {
    # sub validate checks that there is an inputfile, and reads it
	$g = $opt{"--g"};

    print "Reading in gff file: $g\n";

    # check that bedtools executes
    system "~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -b $g -a $g" || die "Your gff-file does not work in bedtools, make sure it is compatible\n";
    my $exit_value  = $? >> 8;
    if ($exit_value != 0) { die "Your gff-file does not work in BEDtools, make sure it is compatible with BEDtools and try again\n\n";};
    open (GFF, "<$g") || die "I can't open $g\n";
    @gff = <GFF>;
    close (GFF);
}

#####_####_####_####_####_####_####_#####

print "\n";

# checi if there is a prefix
my $p = "OUTPUT";

if ($opt{"--p"} and $opt{"--p"}=~/\w+/) {
    # print $opt{"--p"} . "\n";
    $p = $opt{"--p"};
	print "Prefix is set to $p \n";

    
} else {
	print "\nNo prefix given, it will be set to $p \n";
}

#####_####_####_####_####_####_####_#####


print "\n";

# check if there is a cutoff
my $u = 1000;

if ($opt{"--u"} and $opt{"--u"}=~/^\d+$/) {
    # print $opt{"--p"} . "\n";
    $u = $opt{"--u"};
	print "Cuff-off is set to $u \n";  
}
elsif ($opt{"--u"} ) {
    # print $opt{"--p"} . "\n";
    $u = $opt{"--u"};
	print "Please give cuff-off as a number, i.e. 1000\n"; 
    &USAGE;
}

else {
	print "\nNo cut-off given, it will be set to $u \n";
}

#####_####_####_####_####_####_####_#####

print "\n";

# check if there is a cut
my $t = 50;

if ($opt{"--t"} and $opt{"--t"}=~/^\d+$/) {
    # print $opt{"--t"} . "\n";
    $t = $opt{"--t"};
	print "Cut is set to $t \n";  
}
elsif ($opt{"--t"} ) {
    # print $opt{"--p"} . "\n";
    $t = $opt{"--t"};
	print "Please give cut as a number, i.e. 50\n";
    &USAGE;
}

else {
	print "\nNo cut given, it will be set to $t \n";
}

#####_####_####_####_####_####_####_#####

print "\n";

# check if there is s
my $s = 0;

if ($opt{"--s"}) {
    # print $opt{"--t"} . "\n";
    $s = 1;
	print "Single-stranded cuff-links \n";  
}
else {
	print "\nNot single-stranded cufflinks \n";
}

#####_####_####_####_####_####_####_#####

print "\n";

# check if there is s
my $a = 0;

if ($opt{"--a"}) {
    # print $opt{"--t"} . "\n";
    $s = 1;
	print "Alternative transcripts in gff-file \n";  
}
else {
	print "No alternative transcripts in gff-file \n";
}

#####_####_####_####_####_####_####_#####




print "\n--------STARTING CALCULATIONS------------\n\n";



### get all the cufflinks transcripts which overlaps with a gene


# make a nice cufflinks-file
#system "perl ~/bin/perl/cufflinks2gff.pl  $c > $c.gff "; wait;
system "cat  $c | grep -w gene > $c.gene "; wait;
system "cat  $g | grep -w gene > $g.gene "; wait;


# it is stranded
if ($s=~/1/) {
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -u -s > $p.intersect"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -v -s > $p.orphans"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -wao -s > $p.transferred"; wait;


}
else {
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -u  > $p.intersect"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -v  > $p.orphans"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -wao > $p.transferred"; wait;

}


#__END__

# Make a file with the transferred annotation

system "cat $p.transferred |  cut -f 9,18,19 >  $p.transferred2";
system "mv $p.transferred2  $p.transferred";


### get all the cufflinks exons for those transcripts
system "cat $p.intersect |  awk -F'\t' '{print \$9}' > $c.intersect.list"; wait;
print "Finding overlaps, please be patient\n";
#system "perl ~mz3/bin/perl/my_grep.pl -i $c.gff -f $c.intersect.list -o $c.gff.chosen2 -w "; wait;
system " cat $c.gff.chosen2 | grep -w -e CDS -e exon | sort -k1,1 -k4,4n | uniq >$c.gff.chosen3 ";
#system " cat $c.gff.chosen2 | grep -w -e CDS -e exon  >$c.gff.chosen3 ";



### Make hashes of genes

# make stats
my $orphan = `cat $p.orphans | wc -l `;
my $isect = `cat $p.intersect | wc -l `;
my $gene_number = `cat $g.gene  | wc -l `;
chomp $orphan; 
chomp $isect; 
chomp $gene_number; 

print "\n\nFor your $gene_number genes, $isect transcripts overlap, and $orphan transcripts dont\'t overlap with a known gene \n\n";



# Read in GFF file with genes

my %gff;
foreach my $line (@gff) {
    chomp $line;
    my @arr = split (/\t/,$line);
    my @arr2 = split (/;/,$arr[8]);


    if ($arr[2]=~/mRNA/ || $arr[2]=~/transcript/  ) {
        $gff{$arr[0]}{"$arr[3]\t$arr[4]\t$arr[6]\t$arr2[0]"} = $line ;
        #print "gene $arr[3]\t$arr[4]\t$arr[6]\t$arr2[0]\n";
    }
    #elsif ($arr[2]=~/gene/ ) {
    #$gene_number++;
        #}
        # elsif ($arr[2]=~/mRNA/ ||  $arr[2]=~/transcript/ and $a=~/1/) {
        #$gff{$arr2[0]}{"$arr[3]\t$arr[4]\t$arr[6]\t$arr[8]"} = $line ;
        #print "gene $arr[3]\t$arr[4]\t$arr[6]\t$arr2[0]\n";
        #}
    else {
        #print "Disregard";
    }
}





my %cuff;


=pod
print "cat $p.intersect |  awk -F'\\t' '{print \$9}' > $c.intersect.list\n"; 
print  "cat  $c | grep -w -f $c.intersect.list | grep -w CDS >  $c.gff.chosen \n ";
#print "Running my_grep.pl, please be patient\n";
print "perl ~mz3/bin/perl/my_grep.pl -i $c.gff.chosen -f $c.intersect.list -o $c.gff.chosen2 -w \n"; 
print " cat $c.gff.chosen2 | grep -w CDS >$c.gff.chosen3 \n";
=cut



#### get rid of all those cufflinks exons which are internal to a gene ####
### get all the cufflinks exons for those transcripts

system "cat $p.intersect |  awk -F'\\t' '{print \$9}' > $c.intersect.list"; wait;
system "cat  $c | grep -w -f $c.intersect.list | grep -w CDS >  $c.gff.chosen  ";
print "Running my_grep.pl, please be patient\n";
system "perl ~mz3/bin/perl/my_grep.pl -i $c.gff.chosen -f $c.intersect.list -o $c.gff.chosen2 -w "; wait;
system " cat $c.gff.chosen2 | grep -w CDS >$c.gff.chosen3 ";


#__END__

# read in all transcripts

open (CUFF, "<$c.gff.chosen3" || die "I can't open $c.gff.chosen3\n");
my @cuff = <CUFF>;
close (CUFF);



# store all transcripts in hash %cuff
foreach my $line2 (@cuff) {
    chomp $line2;
    my @arr2 = split (/\t/,$line2);
    $cuff{$arr2[0]}{"$arr2[3]\t$arr2[4]\t$arr2[6]\t$arr2[8]"} = $line2 ;
}






# hash containing gene and all the overlaps

my %leftovers; 
my %ovls;    # $olvs { $contig  } {  $gene  } { "OVL" }     # direct overlaps
             #                                { "GENE" }   # info about the gene
             #                                { "CUFF" }   # the cufflinks models belonging to that


# for each cuff contig
foreach my $cont (keys %cuff) {

    #print "$cont\n";

    # loop through all the cuff-entries
   foreach my $pos (keys %{$cuff{$cont}} ) {
       #chomp $pos;
       my ($start, $end, $ori, $name ) = split(/\t/, $pos);
        chomp $ori; 
        my @nm = split(/;/,$name);
        #chomp $name;
        $nm[-1]=~s/Parent=//;
        my @ts = split(/\:/, $name);
        $ts[0]=~s/ID=//;
        #print "TS $start\t$end\t$ori\t$ts[0]\n";

       foreach my $gene  (keys %{$gff{$cont}} ) {
           my ($gstart, $gend, $gori, $gname) = split(/\t/, $gene);
            chomp $gori; 
            #print "GENE $gname\t$gstart\t$gend\t$gori\t$gname\n";



           # if the cuff-CDS is contained in a gene - get rid
           if (  $start >= $gstart  and $gend >= $end and $s=~/0/ ) {
               # delete that position
               delete $cuff{$cont}{$pos};
               #print "DELETE_CONTAINED $start $end $ori $name\t$gstart $gend $gori $gname \n";
           }
           # now remove only the stranded ones
           elsif (  $start >= $gstart  and $gend >= $end and $s=~/1/ and $ori=~/$gori/) {

               # delete that position
               delete $cuff{$cont}{$pos};
               #print "DELETE_STRANDED $start $end $ori $name\t$gstart $gend $gori $gname \n";
           }

            # find overlap completely
           elsif (   $gstart >= $start  and $end >= $gend ) {
                # this is a cuff overlapping with a gene

                #print "OVERLAP_COMPLETELY $start $end $ori $name\t$gstart $gend $gori $gname \n";

                # $ls = $start;
                my $le = $gstart -1;
                my $rs = $gend + 1;
                #my $re = $end;
                #$ovls{$cont}{$gname}{"LOVL"}{"$start\t$le\t$ori\t$name"} = 1;
                #$ovls{$cont}{$gname}{"ROVL"}{"$rs\t$end\t$ori\t$name"} = 1;
                $ovls{$cont}{$gname}{"CUFFL"}{"$nm[-1]\t$gori"} = "$gstart\t$le\t$ts[0]";
                $ovls{$cont}{$gname}{"CUFFR"}{"$nm[-1]\t$gori"} = "$rs\t$gend\t$ts[0]";
           }
            # find overlaps to the left
           elsif (  $gstart >= $start  and  $end >= $gstart   ) {
                # this is a cuff overlapping with a gene
                my $le = $gstart -1;
                #print "OVERLAP_LEFT $start $end $ori $name\t$gstart $gend $gori $gname \n";
                #$ovls{$cont}{$gname}{"LOVL"}{"$start\t$le\t$ori\t$name"} = 1;
                $ovls{$cont}{$gname}{"CUFFL"}{"$nm[-1]\t$gori"} ="$le\t$gend\t$ts[0]" ;
           }
            # find overlaps to the right
           elsif (   $gend >= $start  and $end >= $gend  ) {
                # this is a cuff overlapping with a gene
                my $rs = $gend + 1;
                #print "OVERLAP_RIGHT $start $end $ori $name\t$gstart $gend $gori $gname \n";
                #$ovls{$cont}{$gname}{"ROVL"}{"$rs\t$end\t$ori\t$name"} = 1;
                $ovls{$cont}{$gname}{"CUFFR"}{"$nm[-1]\t$gori"} = "$gstart\t$rs\t$ts[0]" ;
           }
            # save  nonoverlapping  ones
            elsif ( $start > $gend ) {
                $leftovers{"$nm[-1]\t$gori"}{"L"}{$pos}="$gname\t$ts[0]";
                #print "LO $nm[-1]\t$gori\t$pos\t$gname\t$ts[0]\n";
            }
            elsif ( $gstart >= $end ) {
                $leftovers{"$nm[-1]\t$gori"}{"R"}{$pos}="$gname\t$ts[0]";
                #print "RO $nm[-1]\t$gori\t$pos\t$gname\t$ts[0]\n";
            }


           else {
               print "ELSE $start $end $ori $name\t$gstart $gend $gori $gname \t$ts[0]\n";

           }

       }
   }

}









#__END__

### have to bring back transcripts which are non-overlapping, but part of the same cufflinks


print "Finished step 1 \n";
# for each cuff contig
foreach my $cont (keys %ovls) {

    foreach my $gene (keys %{$ovls{$cont}}) {

        foreach my $cuf (keys %{$ovls{$cont}{$gene}{"CUFFL"}}) {
            #print "L $cont\t$gene\t$cuf\t $ovls{$cont}{$gene}{CUFFL}{$cuf}\n";
            my ($gs,$ge)=split(/\t/,  $ovls{$cont}{$gene}{CUFFL}{$cuf} );
            if (exists $leftovers{$cuf}{"L"}) {
                #print "L exists\n";
                foreach my $frag (keys %{$leftovers{$cuf}{"L"}}) {
                    #print "$cuf:\t:$frag:$leftovers{$cuf}{L}{$frag}:L\n";
                    my @arr = split(/\t/, $frag);
                    my @ori = split(/\t/,$cuf);
                    # check if is floating fragment 
                    unless ($arr[1] < $gs) {
                        $arr[1]=$gs;
                    }

                    $frag = join("\t", @arr);
                    #chomp $frag;
                    #print "$cuf:\t:$frag:L\n";
                    if ($arr[1] > $arr[0]) {
                        $ovls{$cont}{$gene}{"LOVL"}{"$frag\t$ori[1]"} = 1;
                        #print "Lif $cont\t:$gene:\t$frag\n";
                        }
                    else {
                        #print "filtered \n";
                    }
                }

            }


        }
        foreach my $cuf (keys %{$ovls{$cont}{$gene}{"CUFFR"}}) {
            #print "R $cont\t$gene\t$cuf\t $ovls{$cont}{$gene}{CUFFR}{$cuf}\n";            
            my ($gs,$ge)=split(/\t/,  $ovls{$cont}{$gene}{CUFFR}{$cuf} );

            if (exists $leftovers{$cuf}{"R"}) {
                #print "R exists\n";
                foreach my $frag (keys %{$leftovers{$cuf}{"R"}}) {
                    #print "$cuf:\t:$frag:$leftovers{$cuf}{R}{$frag}:R\n";
                    my @arr = split(/\t/, $frag);
                    my @ori = split(/\t/,$cuf);
                    # check if is floating fragment 
                    unless ($arr[0] > $ge) {
                        $arr[0]=$ge;
                    }

                    $frag = join("\t", @arr);
                    #chomp $frag;
                    #print "$cuf:\t:$frag:R\n";

                    if ($arr[1] > $arr[0]) {
                        $ovls{$cont}{$gene}{"ROVL"}{"$frag\t$ori[1]"} = 1;
                        #print "Rif $cont\t:$gene:\t$frag\n";
                        }
                    else {
                        #print "filtered \n";
                    }


                    #print ":$cuf:\t:$frag:\n";
                    #chomp $frag;
                    #$ovls{$cont}{$gene}{"ROVL"}{$frag} = 1;
                }

            }



        }

    
    }
    
}
print "Finished step 2 \n";





open (OUT, ">$g.utr.gff" ) || die "I can\'t open $g.utr.gff\n";


foreach my $cont (keys %ovls) {

    #print "$cont\n";

    
    foreach my $gene (keys %{$ovls{$cont}}) {
        
        #print "$cont\t$gene\n";

        my $i = 1;
        foreach my $cuf (keys %{$ovls{$cont}{$gene}{"LOVL"}}) {
            #$cuf=~s/\n/\t/g;
            my ($start, $end, $ori, $name, $nori)= split(/\t/, $cuf );
            
            $name =~s/ID=//;
            my @name = split(/\:/,$name);
            #print "$name[0]\n";

            my $parent = $gene;
            $parent =~s/ID=/Parent=/;
            my @nm = split(/;/,$name);
            chomp $name;
            $nm[-1]=~s/Parent=//;
            
            # get the orientation right
            
            if ( $nori =~/\-/ ) {
                #print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$ori\t\.\t$gene:3UTR:$i\;$parent;note=$nm[-1];colour=2\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
                print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$nori\t\.\t$gene.3UTR.$name[0]\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
            }
            else {
                #print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$ori\t\.\t$gene:3UTR:$i\;$parent;note=$nm[-1];colour=2\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
                print OUT "$cont\tutrmaker\tfive_prime_UTR\t$start\t$end\t\.\t$nori\t\.\t$gene.5UTR.$name[0]\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
            }        
        
        }

        $i = 1;

        foreach my $cuf (keys %{$ovls{$cont}{$gene}{"ROVL"}}) {

            #$cuf=~s/\n/\t/g;
            my ($start, $end, $ori, $name,$nori)= split(/\t/, $cuf );

            $name =~s/ID=//;
            my @name = split(/\:/,$name);
            #print "$name[0]\n";
            
            my $parent = $gene;
            $parent =~s/ID=/Parent=/;
            my @nm = split(/;/,$name);
            chomp $name;
            $nm[-1]=~s/Parent=//;


            # get the orientation right
            
            if ( $nori =~/\-/ ) {
                #print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$ori\t\.\t$gene:3UTR:$i\;$parent;note=$nm[-1];colour=2\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
                print OUT "$cont\tutrmaker\tfive_prime_UTR\t$start\t$end\t\.\t$nori\t\.\t$gene.5UTR.$name[0]\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
            }
            else {
                #print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$ori\t\.\t$gene:3UTR:$i\;$parent;note=$nm[-1];colour=2\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
                print OUT "$cont\tutrmaker\tthree_prime_UTR\t$start\t$end\t\.\t$nori\t\.\t$gene.3UTR.$name[0]\n";   #curation=3\'UTR co-ordinates defined by RNA-Seq experiments\n";
            }

        }


    }
}


close (OUT);





system "cat $g.utr.gff | awk -F';' '{print \$1}' | sort -k1,1 -k9,9 -k4,4n > $g.with_utr.CDS";
system "~mz3/bin/perl/fix_children_gff4Artemis.pl  $g.with_utr.CDS $g.with_utr.CDS.gff2 ";
#print "cat $g.with_utr.CDS.gff2 | awk \'m =\/CDS\/ \{print \$0\";colour=2\"} \!m {print \$0\}\'   > $g.with_utr.CDS.gff \n";

system "cat $g.with_utr.CDS.gff2 | awk \'m =\/CDS\/ \{print \$0\";colour=2\"} \!m {print \$0\}\'   > $g.with_utr.CDS.gff ";
system "cat $g  $g.with_utr.CDS.gff2 | sort -k1,1 -k4,4n > $g.with_utr.gff";
system "~mz3/bin/perl/gff2art.pl $g.with_utr.gff";
system "~mz3/bin/perl/gff2art.pl $g.with_utr.CDS.gff ";

exit;





__END__





### make nice output

#__END__




if ($file_type == 0) {
system `perl ~/bin/perl/augustus2gff.pl $aug_file > $newfile && 
cat  $newfile | grep -w mRNA > $p.temp.aug.gff &&
cat  $c | grep -w transcript > $p.temp.cuff.gff &&
cat  $p.temp.cuff.gff | sed s/transcript/CDS/ > $p.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $p.temp.cuff.gff -b $p.temp.aug.gff -u -s > $p.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $p.bed.gff -b $p.temp.aug.gff | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i  $outfile -s > $p.temp2.UTR.gff `; wait;

}

elsif ($file_type == 1) {
    
system `cat $aug_file| grep -w mRNA > $p.temp.aug.gff &&
cat  $c | grep -w transcript > $p.temp2.cuff.gff && cat $p.temp2.cuff.gff | sort -nk 4,4 > $p.temp.cuff.gff  &&
cat  $p.temp.cuff.gff | sed s/transcript/CDS/ > $p.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $p.temp.cuff.gff -b $p.temp.aug.gff -u -s > $p.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $p.bed.gff -b $p.temp.aug.gff -s | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $outfile -s | sort -k1,1 -k3,3n > $p.temp2.UTR.gff `; wait;

#print "system `cat $aug_file| grep -w mRNA > $p.temp.aug.gff &&
#cat  $c | grep -w transcript > $p.temp2.cuff.gff && cat $p.temp2.cuff.gff | sort -nk 4,4 > $p.temp.cuff.gff  &&
#cat  $p.temp.cuff.gff | sed s/transcript/CDS/ > $p.cuff.art.gff &&
#~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $p.temp.cuff.gff -b $p.temp.aug.gff -u -s > $p.bed.gff &&
#~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $p.bed.gff -b $p.temp.aug.gff -s | sed s/transcript/CDS/ > $outfile &&
#~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $outfile -s | sort -k1,1 -k3,3n > $p.temp2.UTR.gff\n"

}
# intersectBed picks up the cufflinks models which overlaps with the genes
# subtractBed  Removes the portion(s) of an interval that is overlapped by another feature(s).
# mergeBed Merges overlapping BED/GFF/VCF entries into a single interval.

#=cut 

sleep (5);
# fix the output of mergeBed


my $infile ="$p.temp2.UTR.gff";

open (OUT, ">$p.UTR.gff.temp" || die "I can't open $p.UTR.gff.temp\n");

open (IN, "<$infile" || die "I can't open $infile\n");
my @list = <IN>;
my $counter = 1;

#my @lists = sort { $a <=> $b } (@list);

foreach my $line (@list) {
 	my ($scaffold, $start, $end, $strand) = split (/\s+/, $line);
	my $start2 = ($start+1);
	print OUT "$scaffold\thint\tUTR\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";
#	print "$scaffold\thint\tCDS\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";

$counter++;
}

# system `rm -fr $p.temp2.cuff.gff $p.bed.gff $p.temp.aug.gff $p.temp.cuff.gff $outfile $p.temp2.UTR.gff `;

close (IN);
close (OUT);

#### fix the lengths of unreasonable UTRs  #### only tested with alternavtive 1 - nice gff

if ($cutoff == 0) {
exit;
}

system "cat $p.UTR.gff.temp $aug_file | grep -w -e mRNA -e transcript -e UTR | grep -v exon | sort  -k1,1  > $p.UTR.gff.temp2 ";


my $oldline= 0;

open (IN, "<$p.UTR.gff.temp2 ");
open (OUT2, ">$p.UTR.gff");
open (ERR, ">$p.UTR.gff.err");
open (ERR2, ">$p.UTR.gff.err.gff");

my @in = <IN>;

# make hash with genes and UTRs

my %gen=();
my %utr=();
my $lastline=0;

# $gen{geneID}{CDS} = line
#             {5UTR} = line
#             {3UTR} = line
#             {mRNA} = line
#             {gene} = line


foreach my $line (@in) {

    chomp $line;
	my @line = split (/\s+/, $line);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

     if ($lastline=~/$name/) {

    if ($tag=~/mRNA/ or $tag=~/transcript/ ) {
#        print "mRNA:$line\n";
        $gen{$start} = $line;
        $gen{$end} = $line;
#       print "mRNA:$start\t$end\n";

    }
    elsif ($tag=~/UTR/ ) {
        my @utr;
        # split too long into two
           my $length = ($end-$start);

    		if ($length > $cutoff )	{

                # make a new for forward
    		    my $nstart = ($end - $cut);
#                my ($s, $e) = sort {$a <=> $b} ($nstart , $end);
                push (@utr, "$name\t$method\t$tag\t$nstart\t$end\t$score\t$strand\t$dot\t$key.a" );
                # make a new for reverse
    		    my $nend = ($start + $cut);
#                ($s, $e) = sort {$a <=> $b} ($start , $nend);
                push (@utr, "$name\t$method\t$tag\t$start\t$nend\t$score\t$strand\t$dot\t$key.b" );

#               print "$line\n";
#               print "$name\t$method\t$tag\t$nstart\t$end\t$score\t$dot\t$key.a\n";
#               print "$name\t$method\t$tag\t$start\t$nend\t$score\t$dot\t$key.b\n";

             }

             else {
                 push (@utr, $line);
            }

        foreach my $elem (@utr) {
#            print "Elem:$elem\n";

	my @uline = split (/\s+/, $elem);
	my $uname = $uline[0];
	my $umethod = $uline[1];
	my $utag = $uline[2];
	my $ustart = $uline[3];
	my $uend = $uline[4];
	my $uscore = $uline[5];
	my $ustrand = $uline[6];
	my $udot = $uline[7];
	my $ukey = $uline[8];

    if ($ustart == $uend) {
        next;
        print ERR "Warning 203: utr is 0 length $elem\n";
    }
        my $more = ($uend+1);
        my $less = ($uend-1);
        my $smore = ($ustart+1);
        my $sless = ($ustart-1);

        if ($more < 1) {
            $more = 1;
        }
        if ($smore < 1) {
            $smore = 1;
        }
        if ($less < 1) {
            $less = 1;
        }
        if ($sless < 1) {
            $sless = 1;
        }


        #        print "UTR:$line\n";
#        print "UTR:$more\t$less\t$smore\t$sless\t$ukey\n";

                if ( exists $utr{$more} and $utr{$more}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$more} with $elem\n";
                                print ERR2 "$utr{$more}\n";
                }
                  
                if ( exists $utr{$smore} and $utr{$smore}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$smore} with $elem\n";
                                print ERR2 "$utr{$smore}\n";
                }

                                if ( exists $utr{$less} and $utr{$less}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$less} with $elem\n";
                                print ERR2 "$utr{$less}\n";
                }

                                if ( exists $utr{$sless} and $utr{$sless}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$sless} with $elem\n";
                                print ERR2 "$utr{$sless}\n";
                }


#        if ( exists $utr{$more} or exists $utr{$smore} or  exists  $utr{$less}  or exists $utr{$sless}  ) {
#            if ($utr{$more}=~/\w+/ or $utr{$smore}=~/\w+/  or $utr{$less}=~/\w+/  or $utr{$sless}=~/\w+/ ) {
#            print "Warning 225: overwriting $utr{$more} with $elem\n";
#        }
#       }
       $utr{$more}=$elem;
       $utr{$less}=$elem;
       $utr{$smore}=$elem;
       $utr{$sless}=$elem;

#        print "UTR:$more\nUTR:$less\nUTR:$smore\nUTR:$sless\n";

       }

    }
    else {
        print "Exception\n";

    }

}
    else {
        #now we are on a new scaffold
        unshift (@in, $line);
#        print "OLD:$lastline\nNEW:$line\n";
        $lastline=$line;
        &eval;
#        print OUT2 "-----NEW SCAFFOLD----\n";
          }

$lastline=$line;
}


&eval;


close (OUT2);
close (ERR);
close (ERR2);

# system `rm -fr $p.UTR.gff.temp $p.UTR.gff.temp2`;

 unless (-s "$p.UTR.gff.err") {
     system `rm -fr $p.UTR.gff.err $p.UTR.gff.err.gff`;
     print "Fishined with no errors\n";
 }


print "Looking for UTR introns\n";

system "perl /nfs/users/nfs_m/mz3/bin/perl/utr_splitter.pl $p.UTR.gff $c $p";


exit 0;


#########################


sub eval {
my $contig;
foreach my $pos (sort {$a <=> $b} keys %utr) {
#            print "POS2:$pos\n";
            if (exists $gen{$pos}) {                
#                print "Match\n$utr{$pos}\n$gen{$pos}\n";
            my @line = split(/\s+/, $gen{$pos});
            my @nline = split(/\s+/, $utr{$pos});

     # get gene-details
    my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];
        $contig=$name;
        my @arr= split(/[:;]/, $key);
        $arr[0]=~s/ID=//;
        $key = $arr[0];
        # get utr-details        
	    my $nname = $nline[0];
	    my $nmethod = $nline[1];
	    my $ntag = $nline[2];
	    my $nstart = $nline[3];
    	my $nend = $nline[4];
    	my $nscore = $nline[5];
    	my $ndot = $nline[7];
    	my $nkey = $nline[8];
        $nkey =~s/ID=hint/comment=hint/; 
        # plus-strand
            if ($strand=~m/^\+$/){
                if ( ($start - $nend) == 1) {
                            print OUT2 "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;colour=3;$nkey\n";
                        }
                elsif ( ($nstart - $end) == 1) {
                    	    print  OUT2 "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;colour=2;$nkey\n";
                }
                else {
                    print ERR "Warning 254: weird overlap $gen{$pos}\nWarning 254: weird overlap $utr{$pos}\n\n";
                    print ERR2 "$utr{$pos}\n";

                }
            }        
        # minus-strand
            elsif ($strand=~m/^\-$/){

                if ( ($start - $nend) == 1) {
    	    	    	print  OUT2  "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;colour=2;$nkey\n";       
                        }
                elsif ( ($nstart - $end) == 1) {
                        print  OUT2  "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;colour=3;$nkey\n";
                }
                else {
                    print ERR "Warning 273: weird overlap $gen{$pos}\nWarning 273: weird overlap $utr{$pos}\n\n";
                    print ERR2 "$utr{$pos}\n";

                }
            }
            else {
                print "Warning: unknown strand\n";
            }
            }
            else {
#                print "NO MATCH:\n$pos\n";
            }
}        
# print "Finished contig $contig\n";
%utr=();
%gen=();
#print "dump\n";
#print Dumper(%utr);
#print "dump2\n";

}





__END__



