#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: Venn_in_R.pl outfile file(s)
 


This program takes a set of files and makes a Venn diagram showing the overlaps between them






    ' . "\n";
}




my $out = shift;
my @files = @ARGV;


# make the file to print to

open (R, ">$out.venn.R") || die "I can't open $out.venn.R\n";
#open (OUT, ">$files[0].out") || die "I can't open $files[0].out\n";


# set up some things
print R "library(gplots)\n"; # more basic diagram, no colours or fancy stuff but pdf output
print R "require(VennDiagram)\n"; # nicer plots but svg annotation up the wall


print R "vn <- list()\n";

my $i=1;

# read in data

foreach my $file (@files) {

        print R " x$i<-read.table(\"$file\",header=F) \n";
	print R "vn[[$i]] <- x$i\$V1\n";
	print R "names(vn)[$i] <- \"$file\"\n";
        #print R " x$i=x$i+1\n";
	$i++;
}

$i--;

# now plot the graph


print R "try(venn.diagram(vn, filename=\"$out.venn.png\", imagetype=\"png\", fill = rainbow($i), cex=1, alpha=0.3, force.unique=TRUE, height = 300, width = 300, resolution =100))\n";
# print R "venn.diagram(vn, filename=\"$out.venn.svg\", imagetype=\"svg\", fill = rainbow($i), cex=2, alpha=0.3, force.unique=TRUE, height = 30, width = 30, resolution =10)\n";

#=pod	

print R "fn <- paste(\"$out\",\".venn.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";

print R '
 xx <- venn(vn, show.plot=FALSE)
xx
#par(xpd=TRUE)
venn(vn)
';
print R "dev.off()\n";

;
#=cut

close(R);
	
system "R CMD BATCH $out.venn.R >$out.venn.Rout";


exit;










