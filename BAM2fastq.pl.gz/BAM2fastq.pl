#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage:  BAM2fastq.pl  reference.genome file.bam


Warning - the output fasta is MULTILINE
which confuses many scripts

Warning 2 - BAM-file has to be sorted!!!

'
}



my $ref = shift;
my $bam = shift;

unless (-s " $ref.fai") {
    system "samtools faidx $ref";
}

system " samtools mpileup -uf $ref $bam | bcftools view -cg - | vcfutils.pl vcf2fq > $bam.fastq " ;


exit;



