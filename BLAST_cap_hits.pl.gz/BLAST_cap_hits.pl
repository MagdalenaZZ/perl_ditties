#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

sub USAGE {

die 'Usage: BLAST_cap_hits.pl BLASToutput <n> outputname

Takes a blast tab-output, and chooses the n best hits


'
}



my $blast = shift;
my $n = shift;
#$n--;
my $out = shift;



	open (IN, "<$blast") || die "I can't open $blast\n";
	my @blast = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
#	open (OUT2, ">$out.errors") || die "I can't open $out.errors\n";

my $index = 0;

my %hash;

foreach my $elem (@blast) {
        chomp $elem;

		my @arr = split(/\s+/, $elem);
		if ($arr[0]=~/\w+/) {
#			print "$arr[0]\t$elem\n";

            push (@{$hash{$arr[0]}}, $elem);
#			shift @list;
		}
		else {
#			print OUT2 "$arr[0] is not in gff-file\n";
#			shift @blast;
		}

}


foreach my $key (keys %hash) {

#    print "$key\n";

    my @arr = @{$hash{$key}};
    my @splice = splice(@arr, 0, $n); 
#    print "$arr[0]\n";
    foreach my $hit (@splice) {
        print OUT "$hit\n";
    }
#print OUT2 "$line does not have a BLAST-hit\n";
}

close (OUT);
#close (OUT2);


