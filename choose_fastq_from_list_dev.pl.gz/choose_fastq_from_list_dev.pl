#!/usr/local/bin/perl
#In the rare case that someone is trying to do the same thing as me...here is a handy perl script that takes a fastq file and a headers file and outputs a fastq file from the headers


use strict;

unless (@ARGV > 2) {
        &USAGE;
}

####### Usage: perl parsefastq.pl fastq_file headers_file > output_file

open(FILE, "$ARGV[0]") or die "Fastaq file not found";

my @fastqarray = <FILE>;

close FILE;


open(FILE2, "$ARGV[1]") or die "Headers file not found";
open(OUT, ">$ARGV[2]") or die "$!";


my @headers = <FILE2>;

close FILE2;

my @backfastqarray = @fastqarray;
my $size = @fastqarray;
my %fastqhash=();
my @fastqstringarray;
my @greparray;


for(my $i=0;$i<$size;$i++) {

my @fastqstringa = splice(@fastqarray,0,4);
push(@fastqstringarray,[@fastqstringa]);

}



@greparray = grep(/@/, @backfastqarray);

my $size2 = @greparray;


for(my $i=0;$i<$size2;$i++) {
my $key = $greparray[$i];
$fastqhash{$key} = "@{$fastqstringarray[$i]}";

}


foreach my $element(@headers) {


print OUT $fastqhash{$element};

}


close (OUT);


sub USAGE {
die '

Perl-program for choosing fastq-files from names in a list


####### Usage: perl parsefastq.pl fastq_file headers_file > output_file

Written by: jgibbons

'
}