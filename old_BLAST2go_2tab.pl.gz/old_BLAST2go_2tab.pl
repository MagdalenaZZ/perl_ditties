#!/usr/bin/perl -w

use strict;



sub USAGE {

die 'Usage: blast2go_2tab.pl infile outfile

Do Blast2GO and then export as annot_GO_file




'
}


	my $in = shift;
	my $out = "temp2";
	my $out3 = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my $aspect;
my $term;
my $dbxref;
my $date = "20110915;";
my $evidence;
my $autocomm;



__END__

pcs4a[mz3]13: cat annot_GOs_20110910_1832.txt | head
EmW_004020	tuftelin-interacting protein 11	GO:0016070	RNA metabolic process	P
EmW_004020	tuftelin-interacting protein 11	GO:0010467	gene expression	P
EmW_004020	tuftelin-interacting protein 11	GO:0044424	intracellular part	C
EmW_004030	caspase 2	GO:0008233	peptidase activity	F
EmW_004030	caspase 2	GO:0043065	positive regulation of apoptosis	P
EmW_004030	caspase 2	GO:0005515	protein binding	F
EmW_004030	caspase 2	GO:0005737	cytoplasm	C
EmW_004040	swi snf matrix actin dependent regulator of subfamily member 1	GO:0031981	nuclear lumen	C
EmW_004040	swi snf matrix actin dependent regulator of subfamily member 1	GO:0016407	acetyltransferase activity	F
EmW_004040	swi snf matrix actin dependent regulator of subfamily member 1	GO:0043232	intracellular non-membrane-bounded organelle	C



/GO="
aspect=C;
GOid=GO:0020030;
term=infected host cell surface knob;
db_xref=PMID:9291676;
date=20100302;
evidence=TAS;
autocomment=From EMBL file"



/GO="aspect=F;GOid=GO:0050839;term=cell adhesion molecule binding;db_xref=PMID:9786187;date=20100302;evidence=TAS;autocomment=From EMBL file"
/GO="aspect=P;GOid=GO:0020033;term=antigenic variation;db_xref=PMID:18785843;date=20100302;evidence=TAS;autocomment=From EMBL file"
/GO="aspect=C;GOid=GO:0020002;term=host cell plasma membrane;db_xref=PMID:11420100;date=20100302;evidence=TAS;autocomment=From EMBL file"
/GO="aspect=F;GOid=GO:0004872;term=receptor activity;date=20100131;evidence=IEA;autocomment=From EMBL file"
/GO="aspect=P;GOid=GO:0016337;term=cell-cell adhesion;db_xref=PMID:11316367;date=20100302;evidence=TAS;autocomment=From EMBL file"