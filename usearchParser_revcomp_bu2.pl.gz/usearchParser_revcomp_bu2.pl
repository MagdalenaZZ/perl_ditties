#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  usearchParser.pl  uc original.fasta


Takes the output from usearch and calls consensus


';

}

my $uc = shift;
my $fas = shift;

my %fas;
my %clus;




###  parse cluster file  ####

open (CLU, "<$uc") || die;

while (<CLU>) {
    chomp;
    my @arr = split(/\t/, $_);
    if ($arr[0]=~/^H$/) {

        my $arr8 = $arr[8];
        my $arr9 = $arr[9];

        # check orientation, only save ff and fr
        $arr[8]=~s/revcomp_//;
        $arr[9]=~s/revcomp_//;
        my $rc = 0;

        if ($arr9=~/revcomp_/) {
            $rc +=1;
        }


        #print "\n$arr[0]\t$arr8\t$arr9\t$rc\n";
        # deal with revcomp
        if ($arr8=~/revcomp_/) {
            #print "Line will be ignored";

        }
        # deal with initial
        elsif (scalar %clus < 1 ) {
                $clus{$arr[8]}{ $arr[8] } = 0;
                $clus{$arr[8]}{ $arr[9] } = $rc;
                #print "First $arr[8]\t$arr[9]\t$rc\n";
        }
        # deal with the following
        else {
            
            my $second = 0;

            # check if exists as first key
                if (exists $clus{$arr[8]} ) {
                    print "exists 1 $arr[8] \t$rc\n";
                    print "Some error 1\n";
                    die;
                }
                # check if exists as second key
                elsif (exists $clus{$arr[9]} ) {

                        #print "exists 2 $arr[9] \t$rc\n";
                        $clus{$arr[9]}{ $arr[8] } = $rc;
                        $clus{$arr[9]}{ $arr[9] } = 0;
                        #print "added $arr[9] \t $arr[8]\n";
                    }

                # or - check if exists as member of another cluster
                else {
                    #print "Now checking secondary keys\n";
                    
                    for my $ke ( keys %clus ) {
                        #print "KE $ke\n";

                        # first element is secondary key
                        if (exists $clus{$ke}{$arr[8]} ) {
                            #print "exists 8 $arr[8]\t $clus{$ke}{$arr[8]}\t$rc; added $ke $arr[8] 0 $arr[9]  $rc\n";
                            #$clus{$ke}{ $arr[9] } = $rc;
                            #$second = 1;
                            #print "Some error 2\n";
                            #die;
                            
                            # check if it is forward or reverse

                            # it is forward match and Im forward
                            if ( $clus{$ke}{$arr[8]}=~/0/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[9] } = $rc;
                                $second = 1;
                            }
                            # it is forward match and Im reverse
                            elsif ( $clus{$ke}{$arr[8]}=~/0/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[9] } = $rc;
                                $second = 1;
                            }
                            # it is reverse match and Im forward
                            elsif ( $clus{$ke}{$arr[8]}=~/1/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[9] } = 1;
                                $second = 1;
                            }
                            # it is reverse match and Im reverse
                            elsif ( $clus{$ke}{$arr[8]}=~/1/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[9] } = 0;
                                $second = 1;
                            }
                            else {
                                print "Some error 2\n";
                                die;
                            }
                            

                        }

                        elsif (exists $clus{$ke}{$arr[9]} ) {
                            #print "exists 9 $arr[9] \t $clus{$ke}{$arr[9]}\t$rc; added $ke $arr[8] \n";

                            # check if it is forward or reverse

                            # it is forward match and Im forward
                            if ( $clus{$ke}{$arr[9]}=~/0/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[8] } = $rc;
                                $second = 1;
                            }
                            # it is forward match and Im reverse
                            elsif ( $clus{$ke}{$arr[9]}=~/0/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[8] } = $rc;
                                $second = 1;
                            }
                            # it is reverse match and Im forward
                            elsif ( $clus{$ke}{$arr[9]}=~/1/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[8] } = 1;
                                $second = 1;
                            }
                            # it is reverse match and Im reverse
                            elsif ( $clus{$ke}{$arr[9]}=~/1/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[8] } = 0;
                                $second = 1;
                            }
                            else {
                                print "Some error 3\n";
                                die;
                            }

                        }
                        else {
                            #print "Did not exist $arr[8] $arr[9] \n";
                        }

                    }

                    if ($second=~/0/) {
                        #print "Did not exist anywhere, have to do new $arr[8] \t$arr[9] \t\n";
                            $clus{$arr[8]}{ $arr[8] } = 0;
                            $clus{$arr[8]}{ $arr[9] } = $rc;
                            #print "Making $arr[8]\t$arr[9]\t$rc\n";
                    }

                }
        }
    }
}


close (CLU);




###  parse fasta file  ####

open (FAS, "<$fas") || die "Cant find file $fas";


while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head} = $seq;
        
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}



close (FAS);




# marry up clusters and sequences, and make a separete fasta, and align it


# printing all fasta-files

mkdir "$uc\_fas";

open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";

my %files;


open (FAS3, ">$fas.unclustered2") || die;


foreach my $key (sort keys %clus) {
    #print "$key\n";
    #if ($key =~/revcomp_/) {
        #print "next\n";
        #next;
        #}

    


    open (FH, ">$uc\_fas/$key.fas") || die "Cant open file $uc\_fas/$key.fas ";
    
    $files{ "$key.fas" } = 1;

=pod
    my $sca = scalar keys %{$clus{$key}} ;
    #print "$sca\t$key\n";

    if ($sca > 1) {
        $files{ "$key.fas" } = 1;
    }
    else {
        print FAS3 "SINGLE\t$sca\t$key\n";
    }
=cut
    #print OT "\n$key\t";
    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
        
        if (exists $fas{$key2} ) {
            #print "NORMAL: $key\t$key2\t$clus{$key}{$key2}\t$fas{$key2}\n";

            # check if sequence should be reversed, and if so, reverse it

            if ($clus{$key}{$key2} =~/1/) {
                  $fas{$key2} = reverse($fas{$key2});
                  $fas{$key2} =~ tr/ACGTacgt/TGCAtgca/;
            }

            print OT "$key\t$key2\t$clus{$key}{$key2}\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }



        else {
            print "Warning - no sequence for $key2 in file $fas\n";
        }
    }

    close (FH);
}

close (OT);


#__END__

chdir "$uc\_fas";


# calculating consensus

foreach my $key (keys %files) {

    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
    system "perl  ~/bin/perl/consensus_caller.pl  $key.mfa 10";wait;

}

chdir "..";



# now go back and retrieve those sequences that are not in a cluster 


open (FAS2, ">$fas.unclustered") || die;


foreach my $key (sort keys %fas) {
    unless ($key =~/revcomp_/) {
        #print "KEY $key\n";
        print FAS2 ">$key\n$fas{$key}\n";
    }
}

close (FAS2);

# now go and retrieve the consensi, and the rejected sequences

#sleep(10);

system "cat $uc\_fas/\*consensus.fa > $fas.consensus ";wait;
system "cat $uc\_fas/\*rejected > $fas.rejected ";wait;
system "cat $uc\_fas/\*accepted  > $fas.clustered ";wait;
system "cat $fas.consensus $fas.unclustered $fas.rejected > $fas.merged.fas  ";wait;


exit;


# exonerate --model est2genome --bestn 1 --minintron 10 --showtargetgff true --showcigar true ../unc_velvet_70.59.fa ../pathogen_HYM_scaffold_70.sl.fas




__END__





