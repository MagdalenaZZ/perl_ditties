#!/usr/local/bin/perl -w
#
# Run DESeq or EdgeR (or others?) based on a table of read counts for multiple conditions
# and replicates
#
# Run topGO to get GO term overrepresentation

use strict;
use Getopt::Long;

my $help;
my $outdir = 'out';

my $r_prog = "R-2.15";
my $topgo_wrap = '/nfs/users/nfs_a/ar11/scripts/run_topGO2.pl';

# Genes must be at least this unique to enter analysis
# q-value cutoffs for DE results
my $exp_cutoff = 0.01;

my $topgo = '';
my $ignore = '';
my %ignore = ();
my @go_types = ('BP', 'MF', 'CC');

my $ann_file = '';

GetOptions
(
	"h|help"	=> \$help,
	"o|outdir:s"	=> \$outdir,
	"a|ann:s"	=> \$ann_file,
	"e|exp_cut:f"	=> \$exp_cutoff,
	"t|topgo:s"	=> \$topgo,
	"ignore:s"	=> \$ignore
);

if($help)
{
	print_usage();
	exit;
}

my($exp_file, $cond1, $cond2) = @ARGV;

if(!defined $cond2)
{
	print_usage("Missing arguments!\n");
	exit;
}
else
{
	print STDERR "Running with: $exp_file, $cond1, $cond2\n";
}

if($ignore)
{
	open(IG, "<$ignore") or die "$!";
	
	while(<IG>)
	{
		chomp;
	
		$ignore{$_} = 1;
	}
	close IG;
}

my $input_file = 'input.dat';
my $ma_plot = 'ma_plot.png';
my $deseq_scores = 'scores.dat';
my $cons_dat = 'cons.dat';
my $lib_dat = 'lib.dat';
my $logged_file = 'logged_input.dat';

if(!-e $outdir)
{
	mkdir $outdir;
}

# Get annotation
my ($desc, $go);

if(defined $ann_file && $ann_file ne '')
{
	($desc) = get_ann($ann_file);
}

# Extract data from expression files
my($exp_dat, $all_ids, $headers) = get_exp($exp_file, $cond1, $cond2);

# Create tabular file of expression values for DESeq
open(OUT, ">$outdir/$input_file") or die "$!";

# Do we have reps of both? If not, can't do ecdf plot
my $full_reps = 0;
if(scalar keys %{$headers->{$cond1}} >= 2 && scalar keys %{$headers->{$cond2}} >=2)
{
        $full_reps = 1;
}

my @header = ("gene");

# For deseq
my @conds = ();

foreach my $cond ($cond1, $cond2)
{
	foreach my $rep (sort {$a<=>$b} keys %{$headers->{$cond}})
	{
		push @header, "$cond\.$rep";
		push @conds, $cond;
	}
}

my $header = join "\t", @header;

print OUT "$header\n";

foreach my $id (sort keys %{$all_ids})
{
	my @row = ($id);

	foreach my $cond ($cond1, $cond2)
	{
		foreach my $rep (sort {$a<=>$b} keys %{$headers->{$cond}})
	        {
			if(!exists $exp_dat->{$id}->{$cond}->{$rep})
			{
				$exp_dat->{$id}->{$cond}->{$rep} = 0;
			}	

			push @row, $exp_dat->{$id}->{$cond}->{$rep};
		}
	}

	my $row = join "\t", @row;

	print OUT "$row\n";
}

# Log input data for drawing plots and normalisation
log_data("$outdir/$input_file", "$outdir/$logged_file");

runDESeq("$outdir/$input_file", \@conds);

my($scores, $uplist, $downlist) = analyseDESeq($exp_cutoff);

if($topgo && $ann_file)
{
	runTopGO($uplist, $downlist, $topgo);
}

sub runTopGO
{
	my($uplist, $downlist, $go) = @_;

	open(UP, ">$outdir/topgo_uplist.dat") or die "$!";

	foreach my $id (@$uplist)
	{
		print UP "$id\n";
	}
	close UP;

	open(DOWN, ">$outdir/topgo_downlist.dat") or die "$!";

	foreach my $id (@$downlist)
	{
		print DOWN "$id\n";
	}
	close DOWN;

	my $topgo_file = "$outdir/topgo.res";

	open(OUT, ">$topgo_file") or die "$!";

	foreach my $type (@go_types)
	{
		chomp(my @res = `$topgo_wrap $outdir/topgo_uplist.dat $go $type`);
	
		foreach my $line (@res)
		{
			print OUT "UP\t$type\t$line\n";
		}
	}

	foreach my $type (@go_types)
        {
                chomp(my @res = `$topgo_wrap $outdir/topgo_downlist.dat $go $type`);

                foreach my $line (@res)
                {
                        print OUT "DOWN\t$type\t$line\n";
                }
        }

	
	close OUT;
}

sub runDESeq
{
        my($dat_file, $conds) = @_;

        my $cond_string = join "\",\"", @$conds;

        # Need to set this if there are no replicates
        my $pool_string = '';

        if(scalar @$conds == 2)
        {
                $pool_string = ',method="blind", sharingMode="fit-only"';
        }

        open(OUT, ">$outdir/temp.R") or die "$!";

        print OUT <<R_CODE;

        library(DESeq, lib.loc="~ar11/R/library/")
        countsTable <- read.delim("$dat_file", header=TRUE, stringsAsFactors=TRUE)
        rownames(countsTable) <- countsTable\$gene
        countsTable <- countsTable[ , -1]
        conds <- c("$cond_string")
        cds <- newCountDataSet(countsTable, conds)
        cds <- estimateSizeFactors(cds)
        sizeFactors(cds)
        cds <- estimateDispersions(cds $pool_string)

R_CODE

        print OUT <<R_CODE;

        res <- nbinomTest(cds, "$cond1", "$cond2")
        write.table(res, "$outdir/$deseq_scores")
        png("$outdir/$ma_plot")
        plot(res\$baseMean, res\$log2FoldChange, log="x", col=ifelse(res\$padj < $exp_cutoff, "red", "black"))

R_CODE

        close OUT;

        my @result = `$r_prog --no-save < $outdir/temp.R`;
}

sub analyseDESeq
{
	my($cutoff) = @_;

        open(IN, "<$outdir/$deseq_scores") or die "$!: $outdir/$deseq_scores";

        my @up = ();
        my @down = ();

	my %scores = ();

        while(<IN>)
        {
                chomp;

                next if /^\"id/;

		s/"//g;

                my($row, $id, @fields) = split / /;

                next if !defined $fields[6] || $fields[6] eq 'NA';

		$scores{$id} = {	"baseMeanA" => $fields[1],
					"baseMeanB" => $fields[2],
					"foldChange" => $fields[3],
					"log2FoldChange" => $fields[4],
					"pval" => $fields[5],
					"padj" => $fields[6]			
		};

                if($fields[6] <= $cutoff)
                {
                        if($fields[3] < 1)
                        {
                                push @down, $id;
                        }
                        if($fields[3] >= 1)
                        {
                                push @up, $id;
                        }
                }
        }
        close IN;

	my $up_count = scalar @up;
	my $down_count = scalar @down;

	open(RES, ">$outdir/res_$cutoff\.dat") or die "$!";

	print RES "$up_count genes up and $down_count genes down between $cond1 and $cond2 with q-value <= $cutoff\n\n";

	foreach my $id (sort {$scores{$a}->{'padj'}<=>$scores{$b}->{'padj'}} @up)
	{
		my $ann = exists $desc->{$id} ? $desc->{$id} : '';

		print RES "UP\t$id\t$scores{$id}->{'padj'}\t$scores{$id}->{'baseMeanA'}\t$scores{$id}->{'baseMeanB'}\t$scores{$id}->{'foldChange'}\t$ann\n";
	}

	foreach my $id (sort {$scores{$a}->{'padj'}<=>$scores{$b}->{'padj'}} @down)
	{
		my $ann = exists $desc->{$id} ? $desc->{$id} : '';

		print RES "DOWN\t$id\t$scores{$id}->{'padj'}\t$scores{$id}->{'baseMeanA'}\t$scores{$id}->{'baseMeanB'}\t$scores{$id}->{'foldChange'}\t$ann\n";
	}

	close RES;

	return(\%scores, \@up, \@down);
}


sub get_ann
{
	my($file) = @_;

	my %desc = ();
	my %go = ();

	open(F, "<$file") or die "$!";

	while(<F>)
	{
		chomp;

		my($gene, $desc) = split /\t/;

		$desc{$gene} = $desc;
	}
	close F;

	return(\%desc);
}

sub runR
{
	my $code = shift;

	 print STDERR "Running R with $code\n";

	open(R, ">$outdir/r.temp") or die "$!";

	print R $code;
	close R;

	my $res = `R --no-save < $outdir/r.temp`;

	#unlink "$outdir/r.temp";

	return $res;
}

sub get_exp
{
	my ($dat, $a, $b) = @_;

	my %results = ();
	my %all_ids = ();
	my %header_info = ();

	open(DAT, "<$dat") or die "$!";

	my %headers = ();

	while(<DAT>)
	{
		chomp;

		if(/^id/)
		{
			my ($junk, @header) = split /\t/;

			my $h = 0;

			foreach my $col (@header)
			{
				$h++;

				my($cond, $rep) = split /\./, $col;
			
				next unless $cond1 eq $cond || $cond2 eq $cond;

				$headers{$h} = [$cond, $rep];

				$header_info{$cond}->{$rep} = 1;

			}
		}
		else
		{
			my(@a) = split /\t/;

			# Ignore any ids we want to exclude e.g. in mixtures of species
			next if exists $ignore{$a[0]};

			foreach my $index (keys %headers)
			{
				$results{$a[0]}->{$headers{$index}->[0]}->{$headers{$index}->[1]} = $a[$index];

				$all_ids{$a[0]} = 1;
			}
		}
	}
	close DAT;

	return (\%results, \%all_ids, \%header_info);
}

sub log_data
{
        my($file_in, $file_out) = @_;

        open(IN, "<$file_in") or die "$!";
        open(OUT, ">$file_out") or die "$!";

        while(<IN>)
        {
                chomp;
                my($id, @cols) = split /\t/;

                my @new_cols = ();

                if($id eq 'gene')
                {
                          print OUT "$_\n";
                }
                else
                {
                        foreach my $col (@cols)
                        {
                                $col = log2($col + 1);

                                push @new_cols, $col;
                        }

                        my $row = join "\t", @new_cols;
                        print OUT "$id\t$row\n";
                }

        }

        close IN;
}

sub log2
{
	return log($_[0])/log(2);
}

sub print_usage
{
	my $err_msg = shift;

	print <<USAGE;

	Read count data file format:
	- Tab separated with integer read counts
	- Header line with "id" as first column
	- Each column header thereafter is <condition>.<rep> e.g. naive.1, naive.2, infected.1 etc.

	Annotation file format:
	<id>\t<desc>

	GO term format:
	<id>\t<GO:1,GO:2,GO:3>

	USAGE: [options] expression_file cond1 cond2

        -h | -help		help
        -o | -outdir		outdir (out)
        -a | -ann		ann_file
        -e | -exp_cut		DESeq q-value cutoff (0.01)
        -t | -topgo		File of GO terms for running topGO
	-ignore			File with list of ids to ignore (e.g. in mixtures of species)

USAGE

	print "$err_msg\n" if defined $err_msg;
}
