#!/usr/local/bin/perl -w
# mz3 script for sorting and choosing sequence length

use strict;
    use Bio::SeqIO;


unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {
die '

Perl-program for preparing proteins for clanTox analysis  
Usage <input-file> <PREFIX> 

It only takes proteins shorter than 300 aa




Written by: mz3@sanger.ac.uk

'
}

    my $input_file = shift;
    my $output_file =shift;

    my $seq_in  = Bio::SeqIO->new( -format => 'fasta',
                                   -file => $input_file);

    # loads the whole file into memory - be careful
    # if this is a big file, then this script will
    # use a lot of memory

    my $seq;
    my @seq_array;
    while( $seq = $seq_in->next_seq() ) {
       push(@seq_array,$seq);
    }

    # now do something with these. First sort by length,
    # find the average and median lengths and print them out

    @seq_array = sort { $a->length <=> $b->length } @seq_array;

    my $total = 0;
    my $count = 0;
    foreach my $seq ( @seq_array ) {
       $total += $seq->length;
       $count++;
    }

 #   print "Mean length ",$total/$count," Median ",$seq_array[$count/2]->length,"\n";



#         my $outfile = shift or die $usage;
#         my $outfileformat = shift or die $usage;

      # create one SeqIO object to read in,and another to write out
         my $seq_out = Bio::SeqIO->new('-file' => ">temp",
                                       '-format' => 'fasta');

        # write each entry in the input file to the output file
         foreach my $seq (@seq_array) {
         $seq_out->write_seq($seq);
         }

# choose of a certain length


system '~mh12/git/python/fasta2singleLine.py temp temp2';
open (INFILE, "temp2");
open (OUTFILE, ">$output_file");

my %hash;
my $key;

while (<INFILE>) {
	chomp;
	if (/^\>/) {
	tr />//d;
	$key = $_;
	}

	else {
	$hash{$key} .= $_;
	}
	
}

foreach my $sequence (keys %hash)  {
	
	my $length = length ($hash{$sequence});
		if ($length < 300) {
	print OUTFILE "\>$sequence\n$hash{$sequence}\n";
	}


}

system "rm -f temp" ; 
system "rm -f temp2" ; 

close (INFILE);
close (OUTFILE);


system "perl ~mz3/bin/perl/merops_preprocess.pl  $output_file  $output_file 9999 ";


system "rm -f  $output_file ";
exit;


__END__


	my $line = $_;
	push $line ;

#	if (scalar($_) > $size)  {
#	print "$_ /n";
#	}

}


         exit;


__END__

         # create one SeqIO object to read in,and another to write out
         my $seq_in = Bio::SeqIO->new('-file' => "<$infile",
                                      '-format' => $infileformat);


 
