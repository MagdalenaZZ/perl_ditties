#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: xstream_output_parser.pl infile outfile




'
}


## parse infile

my $infile= shift;
my $outfile = shift;
 
open (IN, "<$infile");
my @in = <IN>;

open (OUT, ">$outfile");
open (OUT2, ">$outfile.fa");

my @stats;

my %gene;
my $i =1;

my $cgene;
my $start=0;
my $repno=0;

foreach my $line (@in) {
    chomp $line;
    my @arr;
#    print "LINE:$line:$start:\n";
    

    if ($line=~m/^Repeat/) {

#       $gene{$line}=1;
        @arr = split(/\s+/, $line);
        my $len = scalar(@arr);
#        print "LINE:$line:$len:\n";        
# filter multiple repeats
        if (scalar(@arr)<3) {
            my $repeat=$arr[1];
            $start=0;
            $repno="r" . $arr[1];
#            print "Repeat_MUL:$repno:$repeat:\n";
            $gene{$repno}{NULL}{repeat}=$line;
            $i=1;
        }
        else {
            my @arr2 =split(/\./, $arr[2]);
            $cgene=$arr2[0];
            $repno="r" . $arr[1];
#            print "Repeat_SIN:$repno:$cgene:\n";
            $gene{$repno}{$cgene}{repeat}=$line;
            $start++;
             $i=1;

        }
        
    }
# catch repeat genes 
    elsif ($line=~m/EmW_/) {
            $cgene=$line;
            $start++;
#            print "Repeat3_MULPAR:$repno:$cgene:\n";
    }

# remove initial lines
    elsif ($start==0){
        
    }
    elsif ($line=~m/\d+-\d+/) {
        $gene{$repno}{$cgene}{positions}=$line;
#        print "Positions: $line\n";
        
    }
    elsif ($line=~m/\d+/ ) {
        if ($line=~m/[A-Z]/ ) {
            #print "Consensus: $line\n";
        }
        elsif (exists $gene{$repno}{$cgene}{copies} ) {
            $gene{$repno}{$cgene}{error} = $line;
#            print "Error: $line\n";
#            print "Length: $line\n\n";
        }
        elsif (exists $gene{$repno}{$cgene}{length} )  {
            $gene{$repno}{$cgene}{copies} = $line;
#            print "Copy number: $line\n";
#            print "Length: $line\n\n";
        }
        else {
            $gene{$repno}{$cgene}{length} = $line;
#            print "Length: $line\n";
        }

    }
    elsif  ($line=~m/\w+/ ) {
        if ($line=~m/Positions/) {
        }
        elsif ($line=~m/Period/) {
        }
        elsif ($line=~m/Copy/) {
        }
        elsif ($line=~m/Number/) {
        }
        elsif ($line=~m/Error/) {
        }
        elsif ($line=~m/Consensus/) {
        }
        else {

            print OUT2 "\>$cgene\t$i\t$repno\n";
            print OUT2 "$line\n";
            $i++;
        }
    }
    else {
#        print "ELSE:$line\n";
    }


    #           

            #}

}

# make stats
#
# how many repeats are there?
my $repsize = scalar keys %gene;
print "There are $repsize repeats in the genome\n";

# how many copies have each repeat, and in how many genes?
#
print OUT "Repeat\tlength\tError\tIn_genes\tTotal_rep\tGenes\n";

foreach my $rep (sort keys %gene) {
    my @gens;
    my $len;
    my $err;
    my $genesize = scalar(keys %{$gene{$rep}});
    if ($genesize > 1 ){
        $genesize--;
    }
    my %totrep;
#    print "In repeat $rep there are $genesize genes\n";
    foreach my $gen (sort keys %{$gene{$rep}}) {
        unless ($gen=~m/NULL/) {
#            print "$rep has gene $gen \n";
#            print "$gene{$rep}{$gen}{copies}\n";
            $totrep{$rep}+=$gene{$rep}{$gen}{copies};
            push (@gens, $gen);
            $len = $gene{$rep}{$gen}{length};
            $err = $gene{$rep}{$gen}{error};

        }


    }
    my $totgen = join("\t", @gens);

#    print "Repeat $rep exist in $totrep{$rep} copies\n";

    print OUT "$rep\t$len\t$err\t$genesize\t$totrep{$rep}\t$totgen\n";
}






close (OUT);
