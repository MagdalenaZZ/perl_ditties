#!/usr/bin/perl -w

use strict;





if (@ARGV < 1) {

	print "\n\nUsage: fasta_uniq.pl fasta \n\n" ;
    print " mz3 script for tidying up ENSEMBL_names \n\n";

	exit ;
}

my $filenameA = shift;


open (LIST, "/nfs/users/nfs_m/mz3/bin/perl/ENSEMBL.species.lists") or die "oops1!\n" ;

my @list = <LIST>;

my %ref;

foreach my $elem ( @list) {
    chomp $elem;
    my @arr = split(/\t/, $elem);
    
    my $prefix = substr($arr[2], 0,6);

    $ref{$prefix}=$arr[3];
#    print ":$prefix:\t$arr[3]\n";
}



open (OUT, ">$filenameA.renamed") or die "oops2!\n" ;


open (IN, "$filenameA") or die "oops3!\n" ;

my %new;

while (<IN>) {


    if (/^>(\S+)/) {

    	my $seq_name = $_;
        $seq_name=~s/>//;
        chomp $seq_name;

        my $prefix = substr($seq_name, 0,6);
        $prefix=~s/0//g;
#        print "PREFIX:$prefix:\n";

        if ( exists $ref{$prefix}) {
        	$seq_name=~s/$prefix/$ref{$prefix}_/;
        	$seq_name=~s/P00000//;
        	$seq_name=~s/G00000//;
            $seq_name=~s/T00000//;

#            print "NEW: $seq_name\n";
        }
        else {
#        	print "No exist\n";
        }

        

    	my $seq = <IN> ;
    	chomp($seq) ;
        my $new_name;
        $new{$seq_name} = $seq ;
    }
}

foreach my $ele (sort keys %new) {
    print OUT ">$ele\n$new{$ele}\n";
}


close (OUT);
close (LIST);
close (IN);

