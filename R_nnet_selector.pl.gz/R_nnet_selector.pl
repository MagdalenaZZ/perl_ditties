#!/usr/bin/perl -w


if (@ARGV < 2 ) {
    print "\nUsage: R_nnet_selector.pl file.class.txt <cut-off> Survivals.txt\n\n\n" ;

    print "\nExample: R_nnet_selector.pl myset_GENENORM.r.HC.shared.ud.pergene.1.10_20_5.15:10.class.txt 0.7 Surviv.txt \n\n\n" ;
    #print "\nExample: R_nnet_wrapper.pl myv_COMBAT tmpsig Celltype~. 1412:1442 20,30,5 20:3  \n\n\n" ;

    print "\nTakes the output file *.class.txt from R_nnet_wrapper.pl, applies a score cut-off and re-calculates the survival with the pruned set \n" ;
    print "\ncut-off between 0-inf, where 0 is 100% confidence in best prediction, 1 gives a ~95% cutoff, and 10 ~50%\n" ;

        exit;
}




# Input
#
my $eset= shift; # Expression set
my $cu=shift; # cutoff
my $surv=shift;

open (R, ">$eset.$cu.R") || die "I can't open $eset.$cu.R\n";

#print R "library(ggplot2)\n";


# Read in the table and pick the right columns
print R "ud =  read.table(\"$eset\", header=TRUE )\n";

print R "samplesmorethan <- dim(ud[ud\$Residual>$cu,])[1]\n";
print R "samplesmorethan\n";
print R "sampleslessthan <- dim(ud[ud\$Residual<$cu,])[1]\n";
print R "sampleslessthan\n";


# Print a figure with the chosen cutoff

print R '

ud$col <- ud$Prediction
ud[ud$col>1,]$col <- "red"  # CMP
ud[ud$col<2,]$col  <- "blue" # HSC
ud[grep("bulk",ud$Celltype),]$col <- "black"
#ud[grep("HSC",ud$Celltype),]$col <- "red"
#ud[grep("CMP",ud$Celltype),]$col <- "blue"
';

print R "ud[ud\$Residual>$cu,]\$col <- \"grey\"\n";

print R 'ud$pch <- ud$col
ud[ud$pch=="blue",]$pch <- 1
ud[ud$pch=="red",]$pch <- 1
ud[ud$pch=="grey",]$pch <- 20
ud[grep("HSC",ud$Celltype),]$pch <- 17
ud[grep("CMP",ud$Celltype),]$pch <- 17
ud[grep("bulk",ud$Celltype),]$pch <- 17

ud[ud$col=="red",]$col <- rgb(1,0,0,0.3)  # CMP
ud[ud$col=="blue",]$col  <- rgb(0,0,1,0.3) # HSC
ud[ud$col=="grey",]$col  <- rgb(0.3,0.3,0.3,0.3) # HSC
ud[grep("HSC",ud$Celltype),]$col <- "red"
ud[grep("CMP",ud$Celltype),]$col <- "blue"


ud <- ud[sample(nrow(ud)),]

#ud <- ud[order(ud$Mean),]

#ud <- ud[order(ud$Prediction),]
hsc <- paste("HSC classified n=",table(ud$col)[[3]], sep="")
cmp <- paste("CMP classified n=",table(ud$col)[[1]], sep="")
und <- paste("Undefined n=",table(ud$col)[[2]], sep="")
ud3 <- ud[order(ud$Prediction),]
ud3$Mostmean<- apply(cbind(ud3$Mean,ud3$Mean.1),1,max)

';

print R "fn <- paste(\"$eset.$cu\",\".class.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R '
plot(c(ud3$Mostmean), col=ud3$col, pch=as.numeric(ud3$pch), ylab="HSC prediction certainty", xlab="Classified patients (n)")
#plot(c(ud$Mean), col=ud$col, pch=as.numeric(ud$pch), ylab="HSC prediction certainty", xlab="Classified patients (n)")
legend("right", legend = c(hsc,cmp,und),col =c("red","blue","grey"), pch=c(1,1,20), bg="white")
table(ud$Prediction,ud$col)
';

print R "ud<-ud[ud\$Residual<$cu,]\ndim(ud)\n";

# Do survival with a reduced dataset

print R 'library(survival)
library(survcomp)
library(RColorBrewer)
';

# read in survival data

print R "Survi <- read.table( \"Surviv.txt\", header=TRUE, sep =\"\\t\" )\n";
print R "rownames(Survi) <- Survi\$SampleGEO\n";


# get a subset of design that matches data

print R "Surviv <- Survi[rownames(ud),]\n";

#dchosen <- rownames(Survi)  %in%  rownames(ass.heat_DE.v.GENENORM)
#Surviv <- Survi[rownames(fir),]

# Just chech that it is all right
print R "all(rownames(ud)==rownames(Surviv))\n";


print R "cbbPalette <- c( \"#0072B2\", \"#D55E00\",\"#00EE76\" )\n";
print R "colfunc <- colorRampPalette(cbbPalette)\n";


#print R "Surviv\$Class <- residuls[,(e-1)] \n";
print R "Surviv\$Class <- as.vector(as.data.frame(ud)\$Prediction)\n";

print R "Surviv\$Class[Surviv\$Class<2]  <- \"CMP\"\n";
print R "Surviv\$Class[Surviv\$Class<3 ]  <- \"HSC\"\n";
print R "Surviv\$Class[Surviv\$Class<4]  <- \"MPP\"\n";
# as function of celltype -prediction (make a sensible cutoff and classification)
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviv\$Class), data = Surviv)\n";
print R "S.km\n";
print R "summary(S.km)\n";
print R "fn <- paste(\"$eset.$cu\",\".3surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(3) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviv\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(3) )\n";
print R "dev.off()\n";

print R "cbbPalette <- c( \"#0072B2\", \"#D55E00\")\n";
print R "colfunc <- colorRampPalette(cbbPalette)\n";

print R "Surviva<-rbind(Surviv[Surviv\$Class==\"HSC\",],Surviv[Surviv\$Class==\"CMP\",])\n";
print R "survdiff(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km\n";
print R "summary(S.km)\n";
print R "fn <- paste(\"$eset.$cu\",\".2surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(2) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviva\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(2) )\n";
print R "dev.off()\n";


#print R "fn <- paste(\"$eset.$cu\",\".RData\", sep=\"\")\n";
#print R "ls <- list(ud,ir,varsel_LOOCV,best_size,best_decay,nbgenes,res,preds,residuls,Surviva)\n";
#print R "save(ls, file = fn, envir = .GlobalEnv)\n";


## survdiff(Surv(OSmon, Termin)~as.vector(Surviv$Class), data = Surviv)

print "qsub -l h_vmem=1G  -pe mpislots 1 -b y  -V -cwd  -N $eset.$cu \"R CMD BATCH $eset.$cu.R > $eset.$cu.Rout\"\n";

exit;


