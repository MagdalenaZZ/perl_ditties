#!/usr/bin/perl -w

use strict;




my $largest = 0;
my $contig = '';


if (@ARGV < 3) {
	print "Usage: fastq_retrieve_subsets.pl fastq list 1/2 \n\n" ;

    print " mz3 script for retriveing fastq-files if their headers are in a list\n";
    print "1/2 says if it is forward or reverse read\n\n";

	exit ;
}



my $filenameA = shift;
my $contig_name = shift;
my $fr = shift;

my %reads = () ;

open (OUT, ">$filenameA.in_list_$fr.fastq") or die "oops!\n" ;
open (OUT2, ">$filenameA.not_in_list_$fr.fastq") or die "oops!\n" ;


# read in list

open (IN, "$contig_name") or die "oops!\n" ;

while (<IN>) {
	chomp ;
	my @line = split /\s+/ , $_ ;
	$reads{$line[0]}++ ;
    #print "Line:$line[0]:\n";
}


close(IN) ;

open (IN, "$filenameA") or die "oops2!\n" ;

while (<IN>) {
    chomp;
    #print "$_\n" ;

    if ($_=~/^\@\w+\_\w+:\d+:\d+:\d+:\d+/) {

	my $seq_name = $_;
    $seq_name=~s/\@//;
    $seq_name=~s/\/1//;
    $seq_name=~s/\/2//;

	my $seq = <IN> ;
	chomp($seq) ;
	my $plus = <IN> ;
	chomp($plus) ;
	my $qual = <IN> ;
	chomp($qual) ;

    #print "SEQname:$seq_name:\n";	

	if ($reads{$seq_name} ) {
			print OUT "\@$seq_name\/$fr\n";
			print OUT "$seq\n";
			print OUT "$plus\n";
			print OUT "$qual\n";


	}
    else {
			print OUT2 "\@$seq_name\/$fr\n";
			print OUT2 "$seq\n";
			print OUT2 "$plus\n";
			print OUT2 "$qual\n";

    }


    }
	
    
    #last;


}

close (OUT);
close (OUT2);

exit;
#print "\#\#the largest length is: $contig with $largest bp \n" ;
#
#
#
#cat 9887_3#10_2.fastq.gz.fastq | grep -A 3 -e  HS18_09887:3:1101:10018:68213#7
#
#
#cat 9887_3#7_1.fastq.gz.fastq | grep -A 3 -e  HS18_09887:3:1101:10018:68213#7 -e HS18_09887:3:1101:10046:88010#10 -e HS18_09887:3:1101:10089:6631#10
#
#
#
#cat *fastq.gz.fastq.in_list_2.fastq > pathogen_EgG_scaffold_0001_2.fastq &
#cat *fastq.gz.fastq.in_list_1.fastq > pathogen_EgG_scaffold_0001_1.fastq &


