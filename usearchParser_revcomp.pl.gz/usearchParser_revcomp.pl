#!/usr/bin/perl
use strict;
use My::ReadFasta;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  usearchParser.pl  uc original.fasta


Takes the output from usearch and calls consensus


';

}

my $uc = shift;
my $fas = shift;

my %fas;
my %clus;




###  parse cluster file  ####

open (CLU, "<$uc") || die "Cant find file $uc";

my $ind = "A";
my %h;

while (<CLU>) {
    #print "$ind\n";
    chomp;
    my @arr = split(/\t/, $_);

    if ($arr[0]=~/^H$/) {

        my $arr8 = $arr[8];
        my $arr9 = $arr[9];

        $arr[8]=~s/revcomp_//;
        $arr[9]=~s/revcomp_//;
        
        my $found8 = 0;
        my $found9 = 0;

        # go through and see if you can find it
        foreach my $key (keys %h) {
            if ( exists $h{$key}{$arr[8]}  ) {
                $found8 = $key;
            }
            if ( exists $h{$key}{$arr[9]}  ) {
                $found9 = $key;
            }
        }

        ## now deal with that 
        #print "RES  $arr[8]\t$arr[9]\t$found8\t$found9\n";
        
        # if doesn't exist, make new
        if ($found8 =~/^0$/ and $found9 =~/^0$/  ) {
            #print "make new $ind $arr[8] $arr[9]\n";
            $h{$ind}{ $arr[8] }{ "$arr8\t$arr9" } = 1 ;
            $h{$ind}{ $arr[9] }{ "$arr8\t$arr9" } = 1 ;
            $ind++;
        }
        # if one exists, attach the other one, overwrite previous orientation
        elsif ( $found8 !~/^0$/ and $found9 =~/^0$/  ) {
            #print "found $arr[8] attaching $arr[9]\n";
            $h{$found8}{ $arr[8] }{ "$arr8\t$arr9" } = 1 ;
            $h{$found8}{ $arr[9] }{ "$arr8\t$arr9" } = 1 ;
        }
        # if one exists, attach the other one, overwrite previous orientation
        elsif ( $found9 !~/^0$/  and $found8 =~/^0$/ ) {
            #print "found $arr[9] attaching $arr[8]\n";
            $h{$found9}{ $arr[8] }{ "$arr8\t$arr9" } = 1 ;
            $h{$found9}{ $arr[9] }{ "$arr8\t$arr9" } = 1 ;
        }
        # in this case both exist and in the same set already
        elsif ( $found9 =~/^$found8$/ and $found8 =~/^$found9$/   ) {
            #print "both  $arr[9] and $arr[8] in same set $found8  $found9  \n";
            # no need to do anything
        }
        # in this case both exist, and I have to merge them
        else {
            #print "both $arr[8] and $arr[9] exist make $ind\n";
            # copy vales to new key
           foreach my $key2 ( keys %{$h{$found8}} )  {
               #print "$key2\n";
               $h{$ind}{ $key2 }{ "$arr8\t$arr9" } = 1 ;
               #print "HASH $ind\t$key2\t$arr8\t$arr9\n";
           }

            # copy vales to new key
           foreach my $key2 ( keys %{$h{$found9}} )  {
               $h{$ind}{ $key2 }{ "$arr8\t$arr9" } = 1 ;
               #print "HASH $ind\t$key2\t$arr8\t$arr9\n";
           }
           # delete the old key
           delete $h{$found8};
           delete $h{$found9};
           # print "deleting $found8 and $found9\n";
           $ind++;
        }
    }
}

close (CLU);



my %res;

my %res2;
# now get the sequences ordered

#=pod

foreach my $key (sort keys %h) {
    #print "$key\n";
#    my $first = 0;
    foreach my $key2 (sort keys %{$h{$key}}) {
        #print "$key\t$key2\n";

        foreach my $key3 (sort keys %{$h{$key}{$key2}}) {
            #print "$key\t$key3\n";
            $key3=~s/revcomp_//g;
        my @key3 = split(/\t/,$key3);
            $res2{$key}{$key3[0]}=1;
            $res2{$key}{$key3[1]}=1;
        }

    }
}

foreach my $key (sort keys %res2) {
    foreach my $key2 (sort keys %{$res2{$key}}) {

        print "$key\t$key2\n";
    }
}


##################################
__END__
#=cut

my %h2;


foreach my $key (sort keys %h) {
    #print "$key\n";
    my $first = 0;
    foreach my $key2 (sort keys %{$h{$key}}) {
        #print "$key\t$key2\n";


        my $len = scalar keys  %{$h{$key}};
        # set the first key to forward
        if ($first=~/^0$/) {
            #print "\n$key First seq $key2 gets orientation forward $len\n";
            
            $first = $key2;
            $first =~s/revcomp_//;
            $res{$key}{$key2}= "F";
        }
        

        # set all other keys that you can to 
        foreach my $key3 (keys %{$h{$key}{$key2}}) {
            chomp $key3;
            #print "$key\t$key2\t#\t$key3\n";
            my @key3 = split(/\t/,$key3);
            
            # find out if it has first in it
            

            my $pos = 0 ;
            # 0 key is first
            if ($key3[0]=~/$first/) {
                $pos = 1 ;
                #print "Has 1 in it, first pos\n";
                # check their orientations 
                if ($key3[0]=~/revcomp_/ and $key3[1]=~/revcomp_/  ) {
                    #print "both are revcomp\n";
                    my $second = $key3[1];
                    $second =~s/revcomp_//;
                    $res{$key}{$second}= "F";   
                }
                elsif ($key3[0]=~/revcomp_/  ) {
                    #print "main is revcomp\n";
                    my $second = "revcomp_" . $key3[1];
                    $res{$key}{$second}= "F";
                }
                elsif ($key3[1]=~/revcomp_/  ) {
                    #print "sub is revcomp\n";
                    my $second = $key3[1];
                    $second =~s/revcomp_//;
                    $res{$key}{$second}= "F";
                }
                else {
                    #print "is not revcomp\n";
                    $res{$key}{$key3[1]}= "F";

                }

            }
            # 1 key is first
            elsif ($key3[1]=~/$first/) {
                $pos = 2 ;
                #print "Has 1 in it, second pos\n"
                # check their orientations 
                if ($key3[0]=~/revcomp_/ and $key3[1]=~/revcomp_/  ) {
                    #print "both are revcomp\n";
                    my $second = $key3[0];
                    $second =~s/revcomp_//;
                    $res{$key}{$second}= "F";
                }
                elsif ($key3[0]=~/revcomp_/  ) {
                    #print "sub is revcomp\n";
                    my $second = $key3[0];
                    $second =~s/revcomp_//;
                    $res{$key}{$second}= "F";
                }
                elsif ($key3[1]=~/revcomp_/  ) {
                    #print "main is revcomp\n";
                    my $second = "revcomp_" . $key3[0];
                    $res{$key}{$second}= "F";
                }
                else {
                    #print "is not revcomp\n";
                    $res{$key}{$key3[1]}= "F";
                }
            }
            else {
                # do nothing
                #print "$first doesnt have it $key3[0]\t$key3[1]\n";
                #check all the other keys in res

                my $has = 0;

                foreach my $oldkey (keys $res{$key}) {
                    print "$oldkey\n";
                    my $rev_oldkey = "revcomp_" . $oldkey;


                    if ( $oldkey=~/$key3[0]/ || $rev_oldkey=~/$key3[0]/  ) {
                        $has = 1;
                    }
                    elsif ( $oldkey=~/$key3[1]/ || $rev_oldkey=~/$key3[1]/ ) {
                        $has = 1;
                    }
                    else {
                        #print "doesnt have it $key3[0]\t$key3[1]\n";
                    }

                }
                if ($has =~/0/) {
                    print "doesnt have it $key3[0]\t$key3[1]\n";
                    $h2{$key}{$key2}="$key3[0]\t$key3[1]";

                }

            }

        }
          
    }

}







###  parse fasta file  ####

open (FAS, "<$fas") || die "Cant find file $fas";

my %fas;


#my @fasta = readfas(@fas);
local $/ = ">";
while (my $line = <FAS>)  {

  chomp($line);
    #print "$line\n";
    my ($head, $seq) = split (/\s+/, $line);
    #print "HEAD $head\nSEQ $seq\n";
    if ($head=~/\w+/ and $seq=~/\w+/ ) {
        $fas{$head}=$seq;
        
    }
}


$/ = "\n";


# write an output with all sequences orientated right direction and run consensus_caller on that


my %files;
if (-e "$uc\_fas") {
    die "Folder $uc\_fas already exists, remove and try again";
}

mkdir "$uc\_fas";


#open (OUT2, ">$uc.fas");
open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";
open (FAS3, ">$fas.unclustered2") || die;


foreach my $st (sort keys %res) {

   
    my $len = scalar(keys %{$res{$st}});
    
    #print "AAAA $st $len\n";

    # if there is only one sequence
    if ($len < 2 ) {
        foreach my $ori (sort keys %{$res{$st}}) {
            print FAS3 ">$st\t$ori\t$res{$st}{$ori}\n";
            print FAS3 "$fas{$ori}\n";
        }
    }
    # if there is more than one sequence
    else {
        open (OUT, ">>$uc\_fas/$st.fas") || die "Cant open file $uc\_fas/$st.fas ";
        $files{"$st.fas"}=1;

        foreach my $ori (sort keys %{$res{$st}}) {
            print OUT ">$ori\t$res{$st}{$ori}\n";
            #print ">$ori\t$res{$st}{$ori}\n";
            print OUT "$fas{$ori}\n";
        }
    }
    close (OUT);
}

chdir "$uc\_fas";


# calculating consensus

foreach my $key (keys %files) {

#    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
#    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
#    system "perl  ~/bin/perl/consensus_caller.pl  $key.mfa 10";wait;

}

chdir "..";


##################
#foreach my $file (@files) {
    
#    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $file > $file.clu");wait;
#    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $file > $file.mfa");wait;
#    system "perl  ~/bin/perl/consensus_caller.pl  $file.mfa 10";wait;

#}
#################
__END__


# marry up clusters and sequences, and make a separete fasta, and align it


# printing all fasta-files

mkdir "$uc\_fas";

open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";

open (FAS3, ">$fas.unclustered2") || die;

foreach my $key (sort keys %clus) {    


    open (FH, ">$uc\_fas/$key.fas") || die "Cant open file $uc\_fas/$key.fas ";
    
    $files{ "$key.fas" } = 1;

    #print OT "\n$key\t";
    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
        
        if (exists $fas{$key2} ) {
            #print "NORMAL: $key\t$key2\t$clus{$key}{$key2}\t$fas{$key2}\n";

            # check if sequence should be reversed, and if so, reverse it

            if ($clus{$key}{$key2} =~/1/) {
                  $fas{$key2} = reverse($fas{$key2});
                  $fas{$key2} =~ tr/ACGTacgt/TGCAtgca/;
            }

            print OT "$key\t$key2\t$clus{$key}{$key2}\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }



        else {
            print "Warning - no sequence for $key2 in file $fas\n";
        }
    }

    close (FH);
}

close (OT);



chdir "$uc\_fas";


# calculating consensus

foreach my $key (keys %files) {

    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
    system "perl  ~/bin/perl/consensus_caller.pl  $key.mfa 10";wait;

}

chdir "..";

# now go back and retrieve those sequences that are not in a cluster 


open (FAS2, ">$fas.unclustered") || die;


foreach my $key (sort keys %fas) {
    unless ($key =~/revcomp_/) {
        #print "KEY $key\n";
        print FAS2 ">$key\n$fas{$key}\n";
    }
}

close (FAS2);

# now go and retrieve the consensi, and the rejected sequences

#sleep(10);

system "cat $uc\_fas/\*consensus.fa > $fas.consensus ";wait;
system "cat $uc\_fas/\*rejected > $fas.rejected ";wait;
system "cat $uc\_fas/\*accepted  > $fas.clustered ";wait;
system "cat $fas.consensus $fas.unclustered $fas.rejected > $fas.merged.fas  ";wait;


exit;













__END__

        my $arr8 = $arr[8];
        my $arr9 = $arr[9];

        # check orientation, only save ff and fr
        $arr[8]=~s/revcomp_//;
        $arr[9]=~s/revcomp_//;
        my $rc = 0;

        if ($arr9=~/revcomp_/) {
            $rc +=1;
        }


        #print "\n$arr[0]\t$arr8\t$arr9\t$rc\n";
        # deal with revcomp
        if ($arr8=~/revcomp_/) {
            #print "Line will be ignored";

        }
        # deal with initial
        elsif (scalar %clus < 1 ) {
                $clus{$arr[8]}{ $arr[8] } = 0;
                $clus{$arr[8]}{ $arr[9] } = $rc;
                #print "First $arr[8]\t$arr[9]\t$rc\n";
        }
        # deal with the following
        else {
            
            my $second = 0;

            # check if exists as first key
                if (exists $clus{$arr[8]} ) {
                    print "exists 1 $arr[8] \t$rc\n";
                    print "Some error 1\n";
                    die;
                }
                # check if exists as second key
                elsif (exists $clus{$arr[9]} ) {

                        #print "exists 2 $arr[9] \t$rc\n";
                        $clus{$arr[9]}{ $arr[8] } = $rc;
                        $clus{$arr[9]}{ $arr[9] } = 0;
                        #print "added $arr[9] \t $arr[8]\n";
                    }

                # or - check if exists as member of another cluster
                else {
                    #print "Now checking secondary keys\n";
                    
                    for my $ke ( keys %clus ) {
                        #print "KE $ke\n";

                        # first element is secondary key
                        if (exists $clus{$ke}{$arr[8]} ) {
                            #print "exists 8 $arr[8]\t $clus{$ke}{$arr[8]}\t$rc; added $ke $arr[8] 0 $arr[9]  $rc\n";
                            #$clus{$ke}{ $arr[9] } = $rc;
                            #$second = 1;
                            #print "Some error 2\n";
                            #die;
                            
                            # check if it is forward or reverse

                            # it is forward match and Im forward
                            if ( $clus{$ke}{$arr[8]}=~/0/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[9] } = $rc;
                                $second = 1;
                            }
                            # it is forward match and Im reverse
                            elsif ( $clus{$ke}{$arr[8]}=~/0/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[9] } = $rc;
                                $second = 1;
                            }
                            # it is reverse match and Im forward
                            elsif ( $clus{$ke}{$arr[8]}=~/1/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[9] } = 1;
                                $second = 1;
                            }
                            # it is reverse match and Im reverse
                            elsif ( $clus{$ke}{$arr[8]}=~/1/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[9] } = 0;
                                $second = 1;
                            }
                            else {
                                print "Some error 2\n";
                                die;
                            }
                            

                        }

                        elsif (exists $clus{$ke}{$arr[9]} ) {
                            #print "exists 9 $arr[9] \t $clus{$ke}{$arr[9]}\t$rc; added $ke $arr[8] \n";

                            # check if it is forward or reverse

                            # it is forward match and Im forward
                            if ( $clus{$ke}{$arr[9]}=~/0/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[8] } = $rc;
                                $second = 1;
                            }
                            # it is forward match and Im reverse
                            elsif ( $clus{$ke}{$arr[9]}=~/0/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[8] } = $rc;
                                $second = 1;
                            }
                            # it is reverse match and Im forward
                            elsif ( $clus{$ke}{$arr[9]}=~/1/ and $rc=~/0/ ) {
                                $clus{$ke}{ $arr[8] } = 1;
                                $second = 1;
                            }
                            # it is reverse match and Im reverse
                            elsif ( $clus{$ke}{$arr[9]}=~/1/ and $rc=~/1/ ) {
                                $clus{$ke}{ $arr[8] } = 0;
                                $second = 1;
                            }
                            else {
                                print "Some error 3\n";
                                die;
                            }

                        }
                        else {
                            #print "Did not exist $arr[8] $arr[9] \n";
                        }

                    }

                    if ($second=~/0/) {
                        #print "Did not exist anywhere, have to do new $arr[8] \t$arr[9] \t\n";
                            $clus{$arr[8]}{ $arr[8] } = 0;
                            $clus{$arr[8]}{ $arr[9] } = $rc;
                            #print "Making $arr[8]\t$arr[9]\t$rc\n";
                    }

                }
        }
    }
}


close (CLU);




###  parse fasta file  ####

open (FAS, "<$fas") || die "Cant find file $fas";


while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head} = $seq;
        
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}



close (FAS);




# marry up clusters and sequences, and make a separete fasta, and align it


# printing all fasta-files

mkdir "$uc\_fas";

open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";

my %files;


open (FAS3, ">$fas.unclustered2") || die;


foreach my $key (sort keys %clus) {
    #print "$key\n";
    #if ($key =~/revcomp_/) {
        #print "next\n";
        #next;
        #}

    


    open (FH, ">$uc\_fas/$key.fas") || die "Cant open file $uc\_fas/$key.fas ";
    
    $files{ "$key.fas" } = 1;

=pod
    my $sca = scalar keys %{$clus{$key}} ;
    #print "$sca\t$key\n";

    if ($sca > 1) {
        $files{ "$key.fas" } = 1;
    }
    else {
        print FAS3 "SINGLE\t$sca\t$key\n";
    }
=cut
    #print OT "\n$key\t";
    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
        
        if (exists $fas{$key2} ) {
            #print "NORMAL: $key\t$key2\t$clus{$key}{$key2}\t$fas{$key2}\n";

            # check if sequence should be reversed, and if so, reverse it

            if ($clus{$key}{$key2} =~/1/) {
                  $fas{$key2} = reverse($fas{$key2});
                  $fas{$key2} =~ tr/ACGTacgt/TGCAtgca/;
            }

            print OT "$key\t$key2\t$clus{$key}{$key2}\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }



        else {
            print "Warning - no sequence for $key2 in file $fas\n";
        }
    }

    close (FH);
}

close (OT);


#__END__

chdir "$uc\_fas";


# calculating consensus

foreach my $key (keys %files) {

    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
    system "perl  ~/bin/perl/consensus_caller.pl  $key.mfa 10";wait;

}

chdir "..";



# now go back and retrieve those sequences that are not in a cluster 


open (FAS2, ">$fas.unclustered") || die;


foreach my $key (sort keys %fas) {
    unless ($key =~/revcomp_/) {
        #print "KEY $key\n";
        print FAS2 ">$key\n$fas{$key}\n";
    }
}

close (FAS2);

# now go and retrieve the consensi, and the rejected sequences

#sleep(10);

system "cat $uc\_fas/\*consensus.fa > $fas.consensus ";wait;
system "cat $uc\_fas/\*rejected > $fas.rejected ";wait;
system "cat $uc\_fas/\*accepted  > $fas.clustered ";wait;
system "cat $fas.consensus $fas.unclustered $fas.rejected > $fas.merged.fas  ";wait;


exit;


# exonerate --model est2genome --bestn 1 --minintron 10 --showtargetgff true --showcigar true ../unc_velvet_70.59.fa ../pathogen_HYM_scaffold_70.sl.fas




__END__





