#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLATparser.pl blast-out


'
}


	my $blat = shift;
	open (IN, "$blat") || die "I can't open $blat\n";
	my @blat = <IN>;
	close (IN);

#print "$blat[0]\n";
shift @blat;
shift @blat;
shift @blat;
shift @blat;
shift @blat;
#print "$blat[0]\n";

my $old_qseqid=0;
my $old_sseqid=0;


foreach my $line (@blat) {
my @res = split (/\t/, $line);

my $match = $res[0];
my $mismatch = $res[1];
my $repmatch = $res[2];
my $Ns = $res[3];
my $QgapCount = $res[4];
my $QgapBases = $res[5];
my $TgapCount = $res[6];
my $TgapBases = $res[7];
my $strand = $res[8];
my $Qname = $res[9];
my $Qsize = $res[10]; # Qsize
my $Qstart = $res[11];
my $Qend = $res[12];
my $Tname = $res[13];
my $Tsize = $res[14]; # Tsize
my $Tstart = $res[15];
my $Tend = $res[16];
my $block = $res[17];
my $blockSizes= $res[18];
my $Qstarts= $res[19];
my $Tstarts= $res[20];

my $length = $match;
#print "Res20 $res[20]\n";
#print "Block $res[17]\n";
#print "Name $Qname\n";
#print "Size $Qsize\n";
my $Qhit_length = ($Qend- $Qstart);
#print "Qhit  $Qhit_length bp\n";
my $pident = 100*(($match-($mismatch+$repmatch+$Ns))/$match) ;
my $hitlength= 100*($match/$Qsize) ;  # the length of the hit on the query
#my $length = $match;



if ($Qname=~/$old_qseqid/) {
	if ($Qname=~/$Tname/ && $Tname=~/$Qname/) {
#	print "Self-match $Qname vs $Tname\n";
	}
	else {
#	print "$pident and  $length\n";
		if ($pident > 95 and $hitlength > 80) {
#	print "SIGNIFICANT: $pident and  $length\n";
			if ($old_sseqid=~/$Tname/){
				print  "Identity $pident and length $length Query $Qsize  Hitlength  $hitlength\n";
			}
			else {
				print  "$Qname vs $Tname\n";
				print  "Identity $pident and length $length Query $Qsize Hitlength $hitlength\n";
			}
		}
	}
}

=pod

else {
#start anew for each new query sequence
# filter lines where there is a new query
		if ($pident > 95 and $hitlength > 80) {
#	print "SIGNIFICANT: $pident and  $length\n";
#			if ($old_sseqid =~/$Tname/){
				print  "$Qname vs $Tname\n";
				print  "Identity $pident and length $length start $Tstart end $Tend Hitlength  $hitlength\n";
			}


# print "$Qname is not $old_qseqid\n";
# print "Identity $pident and length $length\n";
		}
=cut

$old_qseqid=$Qname;
$old_sseqid=$Tname;

}