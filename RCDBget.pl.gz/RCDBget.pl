#!/usr/bin/perl -w


use strict;
use Cwd;
use File::Slurp;

if (@ARGV < 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: RCDBget.pl RCDBlist  

Takes a list of RCDB-numbers and associates them with the UniProt entry for them




What can possibly go wrong...  :-)



'
}

my $in = shift;


        open (IN, "<$in") || die "I can't open $in\n";
    	my @in= <IN>;
    	close (IN);

my %KOs;
# my %genes;

# Make a list of KOs

foreach my $line (@in) {
    chomp $line;

    my @arr = split (/\s+/,  $line);
    push (@arr, " ");
#    if ( $arr[1] =~/\w+/) {
#        print "$arr[1]\n";
        $KOs{$arr[0]}=1;
#    }

}
open (OUT, ">$in.ids") || die "I can't open $in.ids\n";


# wget them

system "rm -fr RCDBs_$in";
mkdir "RCDBs_$in";

chdir "RCDBs_$in";

foreach my $elem (keys %KOs) {
# print  "wget \"http://www.rcsb.org/pdb/explore.do?structureId=$elem\" \n";

system "wget \"http://www.rcsb.org/pdb/explore.do?structureId=$elem\" ";
sleep(1);

}

print "\n\n\n\n";



# read in each resulting file, and parse it
my $cwd = cwd();

my @files = read_dir( "$cwd", prefix => 1 ) ;

my %keg;

foreach my $file (@files) {


        open (IN2, "<$file") || die "I can't open $file\n";
#    	my @in2= <IN2>;
#    	close (IN2);

        $file=~s/explore\.do\?structureId=//;
        print OUT  "\n$file\t";

        my $def2;

        while (<IN2>) {
        chomp $_;
            if ($_=~/UpAccessionIdQuery/) {
                my $def = $_;
                chomp $def;
                my @arr2 = split(/accessionIdList=/, $def);
                my @arr3 = split( /\>/, $arr2[-1]);
                $arr3[0]=~s/"//;
                $arr3[0]=~s/<\/a>//;

                print OUT "$arr3[0]";
                $def2=$arr3[0];
                $keg{$file}{$def2}{"0"}=1;
            }
#            elsif ($_=~/show_pathway/ and $_=~/align/  ) {
#                my $met = $_;
#                my @arr4 = split (/show_pathway\?/, $met);
#                my @arr5 = split (/\+/,$arr4[1] );
#                print "PATH:$arr5[0]\n";
#                my @arr6 = split (/"left">/,$arr4[1] );
#                my @arr7 = split (/</,$arr6[1] );
#                print "PATH_DEF:$arr7[0]\n";
                #print "MET:$met\n";
#                $keg{$file}{$def2}{ "$arr5[0]\t$arr7[0]"} = 1;
                #}
        }
        close (IN2);


}


 print OUT "\n";


close (OUT);

print "Finished now\n";
exit;



__END__
# report output



my %kg;

foreach my $koval (keys %keg) {

    if (exists $KOs{$koval} ) {
#        print "Exists\n";
        foreach my $gene ( keys %{ $KOs{$koval} } ) {
            foreach my $defi ( keys %{ $keg{$koval} } ) {
                foreach my $path ( keys %{ $keg{$koval}{$defi} } ) {
#                    unless ($path =~/^0$/) {
                        print OUT "$gene\t$koval\t$defi\t$path\n";
                        $kg{$gene}{ "$koval\t$defi\t$path" }=1;
#                    }
                }
            }
        }
    }
    else {
#        print "Dont exist\n";

    }

}

chdir "..";

#__END__


# filter the domains to only those relevant
my %gen;
my %gen2;

my $in4 = shift;

        open (IN4, "<$in4") || die "I can't open $in4\n";
    	my @in4= <IN4>;
    	close (IN4);

        foreach my $lin4 ( @in4) {
            chomp $lin4;
                if ( $lin4=~/\w+/ ) {
                    $gen{$lin4}{0}=1;
                }
            
        }
=pod
        foreach my $lin4 ( @in4) {
            chomp $lin4;
            if ($lin4=~/^>/) {
                $lin4=~s/\>//;
                if ( $lin4=~/\w+/ ) {
                    $gen{$arr[0]}{0}=1;
                }
            }
        }

=cut

print "Successfully read in list of domains\n";
# get the list of domains in those genes



my $in3 = shift;

        open (IN3, "<$in3") || die "I can't open $in3\n";
    	my @in3= <IN3>;
    	close (IN3);

foreach my $lin (@in3 ) {
chomp $lin;

    my @arr =split(/\s+/, $lin);
#    print "$lin\n";
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");

    if ( exists $gen{$arr[6]} ) {
        $gen2{$arr[0]}{$arr[6]}=1;
    }

}

# now I have a HoH of $gen { domain } { gene }

# compare it to the genes I've got info for, so I know which domains go in which pathway

open (OUT2, ">$in.kosdom") || die "I can't open $in.kosdom\n";


foreach my $gn2 ( keys  %gen2 ) {
    
    if (exists $kg{$gn2}) {

        foreach my $dom3 ( keys %{ $gen2{$gn2} } ) {
            foreach my $pah ( keys %{ $kg{$gn2} } ) {

                print OUT2 "$dom3\t$gn2\t$pah\n";
            }
        }
    }



}












