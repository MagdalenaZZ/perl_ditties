#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: orthomcl_out2table.pl outfile

assumes that infile is "all_orthomcl.out"



'
}


## parse infile

my $infile = "all_orthomcl.out";
# my $prefix= shift;
my $outfile = shift;
 
open (IN, "<$infile");
my @in = <IN>;

open (OUT, ">$outfile");

my @stats;

my %h;
my %xs;

foreach my $line (@in) {
    chomp $line;
    my ($head, $genes) = split(/\t/, $line);
#    print "$head\n";
    my ($cluster, $stats) = split (/\(/, $head);
    push (@stats, $head);
    my @arr = split(/\s+/, $genes);
    foreach my $elem (@arr) {
        if ( $elem=~m/\w+/) {
            $cluster=~s/ORTHOMCL/omcl_/;
#            $elem=~s/\(EMU\)//;
            my @arr2 = split(/\(/, $elem);
            $arr2[1]=~s/\)//;
#            print "$cluster\t$arr2[0]\t$arr2[1]\n";
            $h{$cluster}{$arr2[1]}{$arr2[0]} +=1;
            $xs{$arr2[1]} = 1;
        }
    }

}

# print headers
open (OUT, ">$outfile") || die "I can't open $outfile\n";
#print "\t";
foreach my $group (sort keys %xs) {
    print OUT "\t#$group\t$group";
}
print OUT"\n";

foreach my $omc (sort keys %h) {
#    foreach my 
print OUT "\n$omc\t";

    foreach my $gro (sort keys %xs) {

        if (exists $h{$omc}{$gro}) {
            my $count = keys %{  $h{$omc}{$gro}  } ;
            print OUT "$count\t";
            foreach my $gene (sort keys %{  $h{$omc}{$gro}  }) {
                print OUT "$gene,";
            }
            print OUT "\t";
        }
        else {
            print OUT  "\t\t";

        }
        

    }
}

print OUT "\n";

close (OUT);
