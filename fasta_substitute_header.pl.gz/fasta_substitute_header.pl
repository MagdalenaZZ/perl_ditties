#!/usr/local/bin/perl -w

use strict;


sub USAGE {
die '

Perl-program for changing headers of sequences

Usage <fasta> <input-file> <output-filename> 

Written by: mz3@sanger.ac.uk


The input-file is a file where the first line up to "/" is the same as the original fasta-header



'
}

unless (@ARGV == 3) {
        &USAGE;
}

    my $in  = shift;
    my $in2  = shift;
    my $out =shift;



open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;
close (IN);

open (IN2, "<$in2") || die "I can't open $in2\n";
my @in2 = <IN2>;
close (IN2);

open (OUT, ">$out") || die "I can't open $out\n";

my %hash;

# read in all substitution-names
foreach my $elem (@in2) {
chomp $elem;
	my @arr= split(/\//, $elem);
	$hash{$arr[0]}=$elem;
#	print "ARR1:$arr[0]:\n";
}

# read in all fasta-headers
foreach my $line (@in) {
chomp $line;

	if ($line=~/^\>/) {
#		print "LINE:$line:\n";
		if (exists $hash{$line}) {
#		print "Line:$line:substituted with:$hash{$line}:\n";
		print OUT "$hash{$line}\n";
		}
		else {
		print "Not substituted $line\n";
		print OUT "$line\n";
		}


	}
	else {
		print OUT "$line\n";
	}


}




close (OUT);
