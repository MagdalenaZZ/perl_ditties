#!/usr/bin/perl
use strict;
use Clone qw(clone);

unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/SAM_extract_cover.pl bam-file genome.fasta   <anchor length>

This script takes a BAM-file, and returns to coordinates of the sections of the genome covered by overlapping paired-end reads.

Warning, you have to produce the BAM-file returning only the single best mapping position for the read. i.e.

  tophat -g 1 


<anchor length>  is the shortest achor length you think is plausible




';

}


my $in = shift;
my $fas = shift;
my $men = shift;
my $maximi = shift;

unless (-s "$in.properpairs.sam") {
    system "samtools view  -o $in.properpairs.sam -f 2 $in";
    print "Calculating proper pairs\n";
}

open (IN, "<$in.properpairs.sam") || die "I can't open $in.properpairs.sam\n";
open (TMP, ">$in.tmp") || die "I can't open $in.tmp\n";


my %h;

# store the coordinates in a hash

while (<IN>) {
    chomp;
    # catch gapped alignment
    my @arr=split(/\s+/,$_);
    #print "$_\n"; 
    #print "START $arr[0]\t$arr[5]\t$arr[3]\n";
    $h{"$arr[0]"}{"$arr[3]\t$arr[5]\t$arr[2]\t$arr[7]"}=1;
}


#print "hash\n";

my @res;

# go through the hash and pick mates

foreach my $rp ( keys %h) {
    
    my $len = scalar (keys %{$h{$rp}} );

    # single mapping
#    if ( $len=~/^2$/ ) {
#    }

    # multi mapping
    if ( $len =~/^2$/ ) {

        my @pair;
        
        foreach my $read ( keys %{$h{$rp}} ) {
            push (@pair, $read);
        }
        my @sort = sort {$a<=>$b} keys %{$h{$rp}} ;

        # Get the starting point min
        my ($min, $ref, $sca,$pos) = split(/\t/,$sort[0]);

        # Get the end point sum
        my ($max, $ref2, $sca2,$pos2) = split(/\t/,$sort[1]);
        my $cigar = $ref2;
        my @cign = split (/\D+/, $cigar );
        my @cigt = split (/\d+/, $cigar );
        my $cign = join(" ", @cign);
        my $cigt = join(" ", @cigt);

        if ($cigt eq " M") {
            my $sum=$max;
            $sum += $_ for @cign;
            #my $i=0;
            if (  ($sum - $min ) < $maximi ) {
                push (@res, "$sca\t$min\t$sum\n");
            }
            else {
                print "ELSE\t$sort[0]\t$sort[1]\t:$min\t$max\t$sum:\n";
            }
        }
        elsif ($cigt eq " M N M" and $cign[0]>="$men" and $cign[2]>="$men") {
            my $sum=$max;
            $sum += $_ for @cign;
            #my $i=0;
            push (@res, "$sca\t$min\t$sum\n");
        }
        elsif ($cigt eq " M N M N M"   and $cign[0]>="$men" and $cign[2]>="$men" and $cign[4]>="$men" ) {
            my $sum=$max;
            $sum += $_ for @cign;
            #my $i=0;
            push (@res, "$sca\t$min\t$sum\n");
        }
        
        else {
            #print "ELSE\t$sort[0]\t$sort[1]\t:$cigt:\n";
            }
    }
        

=pod
            # remove insertions from sum

            foreach my $elem ( @cigt) {

                if ($elem=~/I/) {
                    #print "$ref2\t$sum\n";
                    $sum = $sum - @cign[ ($i-1) ];
                    #print "$ref2\t$sum\n";
                }
                $i++;
            }
=cut

            #$sca=~s/\s+//g;
            
    else {
    
        foreach my $read ( keys %{$h{$rp}} ) {
            print "Skipped\t$len\t$rp\t$read\n";
            #die  "\nThe BAM-file contains multi-mapping reads, please re-do your mapping\n\n" ;
        }
    
    
    }
}


my @sorted = sort @res;

foreach my $elem (@sorted) {
    chomp $elem;
    print TMP  "$elem\n";
}

system "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas"; wait;
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -i $in.tmp -bga -g $fas.genome  > $in.genomeCoverageBed.tmp";  wait;
system "perl ~/bin/perl/coverage2feature.pl $in.genomeCoverageBed.tmp BED 5";  wait;


#system "~jit/bin/BEDTools-Version-2.12.0/bin/mergeBed -i $in.tmp > $in.cov.bed";

exit;



