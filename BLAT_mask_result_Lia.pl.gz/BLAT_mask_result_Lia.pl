#!/usr/bin/perl -w

use strict;

unless (@ARGV > 2) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_result.pl blatout.psl file_1.fastq file_2.fastq 

Takes a blat-output, and retrieves the hits from a fastq file.

Then masks the hits with low-quality Ns and outputs new balanced fastq-files





Warning: psl-files should have no header


' . "\n";
}


my $blat = shift;
my $fastq1 = shift;
my $fastq2 = shift;
my $type = "Lia";


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


# reading in the hits and filter bad ones

while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        # an alignment length of at least 12 nucleotides and one or no mismatches
        if ($arr[0]> 11 and $arr[1] < 2 and $arr[5] < 2 and $arr[7] < 2   ) {
        #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max\t$arr[8]" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]\t$arr[8]" ;
                #print "$arr[9]\t$arr[11]\t$arr[12]\n";                
                # make a hit-match - hit just has the read, not forward or rev info
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}

print "\n\nFinished reading BLAT results ....\n";


#=pod


# read the fastq-files line by line, and print the reads with a match to another file


if ($fastq1 =~ /\.gz$/) {
    open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";
}
else {
    open(FAS1, $fastq1) || die "can't open $fastq1";
}

if ($fastq2 =~ /\.gz$/) {
    open(FAS2, "gunzip -c $fastq2 |") || die "can't open pipe to $fastq2";
}
else {
    open(FAS2, $fastq2) || die "can't open $fastq2";
}

open (OUT1, ">$fastq1.chosen.fastq")|| die;
open (OUT2, ">$fastq2.chosen.fastq")|| die;
open (OUT3, ">$fastq1.not_chosen.fastq")|| die;
open (OUT4, ">$fastq2.not_chosen.fastq")|| die;

#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";
        my $seq = <FAS1>;
        my $mid = <FAS1>;
        my $qual = <FAS1>;

        if (exists $hits{$head}) {
            #print "$_";

            print OUT1 "$_$seq$mid$qual";
        }
        else {
            print OUT3  "$_$seq$mid$qual";
        }

    }
}


while (<FAS2>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/2$//;
        chomp $head;
        #print "match $head\n";
        my $seq = <FAS2>;
        my $mid = <FAS2>;
        my $qual = <FAS2>;

        if (exists $hits{$head}) {
            #print "$_";
            print OUT2 "$_$seq$mid$qual";
        }
        else {
            print OUT4  "$_$seq$mid$qual";
        }

    }
}

close (FAS1);
close (FAS2);
close (OUT1);
close (OUT2);

#=cut


# read in the temp-fastqs, and trim them according to the best BLAT-hit


open (IN1, "<$fastq1.chosen.fastq")|| die;
open (IN2, "<$fastq2.chosen.fastq")|| die;

my %final;
my %rev;
my %fwd;
my %discarded;

while (<IN1>) {

    #print "$_";
    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1 =~s/\/1$//;
        #print "match $head\t$head1\n";

        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $ori_seq = $seq;
            my $ori_qual = $qual;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $new_qual = substr($qual, $min, $len, $polyN );

            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);
            my $out_qual1 = substr($ori_qual, 0, $min);
            my $out_qual2 = substr($ori_qual, $max, -1);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
                #$new_qual =reverse($new_qual);
            }


            # now choose if this is a primer

                # this is reverse
                if ($new_seq =~/GAGTACTT/i or $new_seq =~/GTGTACTT/i ) {
                    #print "$ori_seq\n$new_seq\n$out_seq1\n$out_seq2\n";
                    #print "$ori_qual\n$new_qual\n$out_qual1\n$out_qual2\n";
                    #print "$_$out_seq2\n$mid$out_qual2\n";
                    $rev{$_}=1;
                    #$final{$head1}{$head}="$_$seq$mid$qual";
                    if ( (length($out_seq2) > length($out_seq1))  and (length($out_seq2)>5 ) and $out_seq2=~/\w{5}/  ) {
                        $final{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                        $rev{$head1}=1;
                        #print "1\t$head\n";
                    }

                    # the primer is on the wrong end of the read, so ignored
                    else {
                        $discarded{$head1}=1;
                        $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                        #print "$out_seq1\t$new_seq\t$out_seq2\n";
                        #print "2\t$head\n";
                    }

                    
                }
                # this is forward
                elsif ($new_seq =~/GAGTACGG/i or $new_seq =~/GAGTACATG/i ) {
                    #print "$ori_seq\n$new_seq\n$out_seq1\n$out_seq2\n";
                    #print "$ori_qual\n$new_qual\n$out_qual1\n$out_qual2\n";
                    if ( (length($out_seq2) > length($out_seq1))  and (length($out_seq2)>5 ) and $out_seq2=~/\w{5}/  ) {
                        $final{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                        $fwd{$head1}=1;
                        #print "3\t$head\n";

                    }

                    # the primer is on the wrong end of the read, so ignored
                    else {
                        $discarded{$head1}=1;
                        $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                        #print "$out_seq1\t$new_seq\t$out_seq2\n";
                    }                    
                    #
                }
                else {
                    $discarded{$head1}=1;
                    #print "This is not a real primer $new_seq \n";
                    $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                }
        }
        else {
            # just store mate without hit
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            $final{$head1}{$head}="$_$seq$mid$qual";
        }


    
    }
}




while (<IN2>) {

    #print "$_";
    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1 =~s/\/2$//;
        #print "match $head\n";


        if (exists $blat{$head}) {

            #print "$_";
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $ori_seq = $seq;
            my $ori_qual = $qual;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $new_qual = substr($qual, $min, $len, $polyN );

            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);
            my $out_qual1 = substr($ori_qual, 0, $min);
            my $out_qual2 = substr($ori_qual, $max, -1);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
                #$new_qual =reverse($new_qual);
            }
            # now choose if this is a primer

                # this is reverse
                if ($new_seq =~/GAGTACTT/i or $new_seq =~/GTGTACTT/i  ) {
                    #print "$ori_seq\n$new_seq\n$out_seq1\n$out_seq2\n";
                    #print "$ori_qual\n$new_qual\n$out_qual1\n$out_qual2\n";
                    #print "$_$out_seq2\n$mid$out_qual2\n";
                    $rev{$_}=1;
                    #$final{$head1}{$head}="$_$seq$mid$qual";
                    #print length($out_seq2) . "\n";
                    if ( (length($out_seq2) > length($out_seq1))  and (length($out_seq2)>5 ) and $out_seq2=~/\w{5}/ ) {
                        $final{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                        $rev{$head1}=1;
                        #print "4\t$head\n";
                    }
                    # the primer is on the wrong end of the read, so ignored
                    else {
                        $discarded{$head1}=1;
                        $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                        #print "$out_seq1\t$new_seq\t$out_seq2\n";
                        #print "5\t$head\n";

                    } 
                }
                # this is forward
                elsif ($new_seq =~/GAGTACGG/i or $new_seq =~/GAGTACATG/i  ) {
                    #print "$ori_seq\n$new_seq\n$out_seq1\n$out_seq2\n";
                    #print "$ori_qual\n$new_qual\n$out_qual1\n$out_qual2\n";
                    if (  (length($out_seq2) > length($out_seq1)) and (length($out_seq2)>5 ) and $out_seq2=~/\w{5}/ ) {
                        $final{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                        $fwd{$head1}=1;
                        #print "6\t$head\n";
                    }

                    # the primer is on the wrong end of the read, so ignored
                    else {
                        $discarded{$head1}=1;
                        $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                        #print "$out_seq1\t$new_seq\t$out_seq2\n";
                        #print "7\t$head\n";
                    }                    
                    #
                }
                else {
                    $discarded{$head1}=1;
                    #print "This is not a real primer $new_seq \n";
                    $final{$head1}{$head}="$_$ori_seq$mid$ori_qual";
                    #print "8\t$head\n";
                    #print "$_$ori_seq$mid$ori_qual";
                }

        }
        else {
            # just store mate without hit
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            $final{$head1}{$head}="$_$seq$mid$qual";
        }
    }
    
}




close (IN1);
close (IN2);






# now finally report the paired full output


open (OUT1, ">$fastq1.rev_trimmed.fastq")|| die;
open (OUT2, ">$fastq2.rev_trimmed.fastq")|| die;
open (OUT3, ">$fastq1.not_trimmed.fastq")|| die;
open (OUT4, ">$fastq1.fwd_trimmed.fastq")|| die;
open (OUT5, ">$fastq2.fwd_trimmed.fastq")|| die;
open (OUT6, ">$fastq2.not_trimmed.fastq")|| die;

#foreach my $key (sort keys %rev) {
#    print "REV :$key:\n";
#}



foreach my $key (sort keys %final) {
    #print ":$key:\n";
    my $sca = scalar  keys %{$final{$key}};
    #print "$sca\n";
    
    # This sequence is paired
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";


        # now check if it is forward, reverse or discarded

        if (exists $fwd{$key} and exists $rev{$key} ) {
            print OUT4 "$final{$key}{$first}";
            print OUT5 "$final{$key}{$second}";
            print OUT1 "$final{$key}{$first}";
            print OUT2 "$final{$key}{$second}";
            print "$key is both forward and reverse\n";
        }
        elsif (exists $fwd{$key}) {
            print OUT4 "$final{$key}{$first}";
            print OUT5 "$final{$key}{$second}";
        }
        elsif (exists $rev{$key}) {
            print OUT1 "$final{$key}{$first}";
            print OUT2 "$final{$key}{$second}";
        }
        else {
            print OUT3 "$final{$key}{$first}";
            print OUT6 "$final{$key}{$second}";
        }

    }

    # This is a single sequence
    else {
        print "Warning: single sequence $sca\t$key\n";
    }
}


close (OUT1);
close (OUT2);
close (OUT3);

# system "rm -f $fastq1.chosen.fastq $fastq2.chosen.fastq ";

__END__


