#!/usr/local/bin/perl -w

# 

use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: RPM_from_reads.pl merged.reads 




'
}

my $file = shift;
my $cut = shift;



my %h;

# read all domain architectures into a hash
#
	open (IN, "<$file") || die "I can't open $file\n";
	open (OUT, ">$file.rpm") || die "I can't open $file.rpm\n";

    my @in = <IN>;
	close (IN);


print OUT "$in[0]";

my @arr2 = split(/\t/, $in[0] );
shift @in;

# make sums array
my @sums = @arr2;
foreach my $el (@sums) {
    $el = 0;
    
}


#print OUT "Gene\tCondition\t999999 Max RPKM\tSum of RPKMs\n";

# go through and add to sum
foreach my $s (@in) {
    chomp $s;
    my @arr = split(/\t/,$s);
    my $i = 0;

    foreach my $ele (@arr) {
        if ($ele=~/^\d+\.\d+$/ or $ele=~/^\d+$/  ) {
            $sums[$i]= $sums[$i] + $ele;
            #print "$sums[$i]\t$ele\n";
            $i++;
        }
        else {
            $i++;
        }
    }

}



# go through and calculate and print RPM

my @scaling;

$sums[0]=1;

foreach my $el (@sums) {
    my $mil = 1000000/$el;
    #print "$el\t$mil\n";
    push (@scaling, $mil);
}


foreach my $s (@in) {
    chomp $s;
    my @arr = split(/\t/,$s);
    my $i = 0;

    print OUT "$arr[0]\t";
    foreach my $ele (@arr) {
        if ($ele=~/^\d+\.\d+$/ or $ele=~/^\d+$/  ) {
            my $res = $ele*$scaling[$i];
            print OUT "$res\t";
            $i++;
        }
        else {
            $i++;
        }
    }
    print OUT "\n";


}





close (OUT);
exit;






