#!/usr/bin/perl -w


use strict;
#use Set::Object;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: in out

Give a list of gene-names and product description
This program filters the list and rationalises gene-names to give the most popular name


'
}


	my $in = shift;

	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">$out.unique") || die "I can't open $out.unique\n";

    my %genes;
    my %scores;



foreach my $line (@in) {
#    print "IN:$line\n";
    chomp $line;
    my @line = split (/\//, $line);
    $line[1]=~s/product="//;
    $line[1]=~s/"//;
    $line[1]=~s/_/ /g;
    $line[1]=~s/mz3/hypothetical protein/;
    chomp $line[1];
    $line[1]=~s/ $//;
    $line[1]=~s/  / /;
#    print "LINE1:48:$line[1]\n";

    # Make a hash of gene-names 
#    $genes{$line[0]} = $line[1];
    push (@{$genes{$line[0]}},  $line[1]);

    my @bits = split (/[ ,:]/, $line[1]);
#    $scores{$line[0]} = $line[1];
        foreach my $elem (@bits) {
            chomp $elem;
            $elem=~s/\)//g;
            $elem=~s/\(//g;
            $elem=~s/ //g;
            $elem=~s/\[//g;
            $elem=~s/\]//g;
            $elem=~s/\+//g;
            $elem=~s/\-//g;
            $elem=~s/\:/ /g;
            $elem=~s/\'//g;
            $elem=~s/\t//g;
            $elem=~s/\'//g;
            $elem=~s/\,//;
            $elem=~s/ $//;

            push (@{$scores{$line[0]}}, $elem);
            
#            push (@{$scores{$line[0]}{$line[1]}},  $elem );

    }


}



# compare the two arrays, and give a score to each name
# Loop through and add scores to each name

my %new;

foreach my $key (keys %genes) {
          my $count = 0;
    foreach my $elem (@{$genes{$key}}) {
#    print "GENE:$key\tPIECE:$elem\n";
          my $count = 0;
        foreach my $i (0..$#{$scores{$key}}) {
            if ( $elem=~m/${$scores{$key}}[$i]/i) {
                if (${$scores{$key}}[$i] =~/^\d+$/) {
                    $count= $count + 0 ;
                }
                elsif (${$scores{$key}}[$i] =~/^\w$/) {
                    $count= $count + 0.20 ;
                }
                elsif ( ${$scores{$key}}[$i] =~/^alpha$/  ) {
                    $count= $count + 0.21 ;
                }
                elsif (${$scores{$key}}[$i] =~/^beta$/ || ${$scores{$key}}[$i] =~/^delta$/ || ${$scores{$key}}[$i] =~/^zeta$/ || ${$scores{$key}}[$i] =~/^iota$/  ) {
                    $count= $count + 0.20 ;
                }
                elsif (${$scores{$key}}[$i] =~/^subunit$/) {
                    $count= $count + 0.73 ;
                }
                elsif (${$scores{$key}}[$i] =~/^protein$/) {
                    $count= $count + 0.56 ;
                }
                elsif (${$scores{$key}}[$i] =~/^likely$/ || ${$scores{$key}}[$i] =~/thrombospondin/ ||  ${$scores{$key}}[$i] =~/^lc$/ ) {
                    $count= $count + 0.03 ;
                }
                elsif (${$scores{$key}}[$i] =~/^isoform$/) {
                    $count= $count + 0.74 ;
                }
                elsif (${$scores{$key}}[$i] =~/^homeodomain$/) {
                    $count= $count + 1.02 ;
                }


                else {
                    $count++;
                }
#                print "MATCH: GENE:$key\tPROD:$elem\tCOUNT:$count\tBIT:${$scores{$key}}[$i] \n";
            }
            else {
#                print "NO:    GENE:$key\tPROD:$elem\tCOUNT:$count\tBIT:${$scores{$key}}[$i] \n";
            }


        }
        
        $new{$key}{$elem}+= $count;
#        $score{$key}{$elem}+= $count;
        print "$key\t$elem\t$count\n";
    }
#    print "\n";
}



__END__



# Empty the new array with the chosen name
#
my $ct = 1;
my $max = 0;
my %best;

foreach my $gene (sort keys %new) {

my @highest;

    foreach my $prod (sort keys %{$new{$gene}}) {
        my $count = $new{$gene}{$prod} ;
        $prod=~s/ $//;
  
# LOWER HYPOTHETICAL PRODUCT SCORES
        if ($prod =~/hypothetical/) {
            $count = $count * 0.17 ;
        }
        if ($prod =~/\./) {
            $count = $count * 0.17 ;
        }
#            my $ncount = $count + 0.9 ;
#            my $max =  $max + 1;

            

        if ($count >= $max) {
#            unshift (@highest, "$gene\t$prod\t$count");
                $max = $count;
        }
#        else {
            push (@highest, "$gene\t$prod\t$count");
#        }
    }
    
    foreach my $val (@highest) {
        $val=~s/\t\t/\t/g;
        $val=~s/\t\t/\t/g;
    my @arr = split(/\t/,$val);
#        print "VAL:$val:\n";
            if ($arr[2] !~/\d+/ ) {
                print "WARNING2:$val:\n";
                next;
            }
=pod            
if ($max =~ /^[+-]?\d+$/ ) {
    print "max Is a number\n";
} else {
    print "max Is not a number\n";
}

if ($arr[2] =~ /^[+-]?\d+$/ ) {
    print "Is a number\n";
} else {
    print "Is not a number\n";
}
=cut
            my $nnum = $arr[2] - 0.9 ;
            my $nmax =  $max - 1;
#           print "ARR:$arr[2]:\tMAX:$max:\n";

#           print "NMAX:$nnum:\tMAX:$nmax:\n";

        if ( $nnum >= $nmax) {
            print OUT "BEST1:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
#            print "BEST1:\t$arr[0]\t\/product=\"$arr[1]\"\t:$arr[2]:\n";

            push ( @{$best{$arr[0]}},  $arr[1]) ;
        }
        else {
#            print "MAX:$max:\n";
            print OUT "WORSE1:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
#            print "WORSE1:\t$arr[0]\t\/product=\"$arr[1]\"\t:$arr[2]:\n";
        }

    }

    $max=0;   
}

print OUT "############## ROUND 1 ################\n";



#choose amongest the best ones by ignoring CAPS
#
my %bbest;

foreach my $gene (keys %best) {

    my $uniq = 

    my $length =  scalar(@{$best{$gene}});
    #print "CAPS:$gene\t$length\n";
    
    if ($length == 1) {
        print OUT2 "$gene\t\/product=\"${$best{$gene}}[0]\"\n";
    }
    else {
        foreach my $prod ( @{$best{$gene}}) {
            $prod=~s/ $//;
            my $prodo= $prod;
            $prod =~tr/[A-Z]/[a-z]/;
            $prod =~s/,/ /;
            $prod =~s/  / /;

            # catch the protein FAMs
            if ($prod=~/^protein fam\d+/i) {
                $prod=~s/fam/FAM/;
#                my @art = split(/\d+/, $prod);
                my $new = substr( $prod,0,14);
#                print "$gene\t\/product=\"$new\"\n";
                 $bbest{$gene}{$new}+= $ct ;                
            }

#            if (exists $bbest{$gene}{$prod} ) {

#            }
#            print "PROD220:$gene\t\/product=\"$prod\"\n";
             $bbest{$gene}{$prod}+= $ct ;
#            print "$gene\t\/product=\"$new\"\n";

        }
    }

}


# Then choose the best again

my %bbbest;

foreach my $gene (sort keys %bbest) {

my @highest;
my $max = "-1";

    foreach my $prod (sort keys %{$bbest{$gene}}) {
            $prod=~s/ $//;

        my $count = $bbest{$gene}{$prod} ;
#       print "BB:$gene\t$prod\t$count\n";       
# LOWER HYPOTHETICAL PRODUCT SCORES
        if ($prod =~/hypothetical/) {
            $count = $count * 0.17 ;
        }

        if ($count >= $max) {
            unshift (@highest, "$gene\t$prod\t$count");
            $max = $count;
        }
        else {
            push (@highest, "$gene\t$prod\t$count");
        }
    }
    
    foreach my $val (@highest) {
        $val=~s/\t\t/\t/g;
        $val=~s/\t\t/\t/g;
    my @arr = split(/\t/,$val);
#    print "VAL:$val:\n";
            if ($arr[2] !~/\d+/ ) {

                print "WARNING3:$val:\n";
                next;
            }


        if ($arr[2] >= $max) {
            print OUT "BEST2:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
            push ( @{$bbbest{$arr[0]}},  $arr[1]) ;
        }
        else {
            print OUT "WORSE2:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
        }

    }

    
}


print OUT "############## ROUND 2 ################\n";



#choose amongest the best ones by cutting the last baseb (unless already 1)

my %nbest;

foreach my $gene (keys %bbbest) {
    my $length =  scalar(@{$bbbest{$gene}});
#    print "\n";
#    print "f:$gene\t$length\n";
    
    if ($length == 1) {
        print OUT2 "$gene\t\/product=\"${$bbbest{$gene}}[0]\"\n";
    }
    elsif ($length ==2 ) {
#            print "elsif\n";

        my $prod1 =  @{$bbbest{$gene}}[0];
        my $prod2 =  @{$bbbest{$gene}}[1];

        if ($prod1=~/\Q$prod2\E/) {
            $nbest{$gene}{$prod2}+= $ct ;            
        }
        elsif ($prod2=~/\Q$prod1\E/) {
            $nbest{$gene}{$prod1}+= $ct  ;            
        }

        else {
#           print "else2\n";
            foreach my $prod ( @{$bbbest{$gene}}) {
#                    print "Length:$prod:\n";
                    $prod=~s/ $//;
                    $prod=~s/  / /;
#                    print "Length2:$prod:\n";
                    my @len =split(/ /, $prod);
                    my $len = scalar(@len);
#                    print "Length $len\n";
                    if ($len < 2) {
                        $nbest{$gene}{$prod}+= $ct  ;
                    }
                    else {
                        $prod=~s/\,//g;
                        $prod=~s/\d+//g;
                        $prod=~s/ $//g;
                        $prod=~s/  / /g;
                        #print "g:$gene\t\/product=\"$prod\"\n";
                        my @arr = split (/ /, $prod);
                        #print "0$arr[0]\n";
                        #print "1$arr[1]\n";
                        #print "2$arr[2]\n";
                        # pop @arr;
                        my $new = join(" ", @arr );
                        $nbest{$gene}{$new}+= $ct  ;
                        #print "h:$gene\t\/product=\"$new\"\n";
                    }
                    

            }
        }

        
        

    }

    else {
#            print "else\n";
                foreach my $prod ( @{$bbbest{$gene}}) {
#                    print "Length:$prod:\n";
                    $prod=~s/ $//;
                    $prod=~s/  / /g;
                    $prod=~s/\, / /g;
                    $prod=~s/ \d+//g;
                    #$prod=~s/ $//g;
#                    print "Length2:$prod:\n";
                    my @len =split(/ /, $prod);
                    my $len = scalar(@len);
                     if ($len < 2) {
                        $nbest{$gene}{$prod}+= $ct  ;
                     }
                    else {
                        #print "i:$gene\t\/product=\"$prod\"\n";
                        my @arr = split (/ /, $prod);
                        #pop @arr;
                        my $new = join(" ", @arr );
                        $nbest{$gene}{$new}+= $ct  ;
                        #print "j:$gene\t\/product=\"$new\"\n";
                     }
            }

    }


}




# Then choose the best again2

my %nnbest;

foreach my $gene (sort keys %nbest) {

my @highest;
my $max = "-1";

    foreach my $prod (sort keys %{$nbest{$gene}}) {
#        $prod=~s/  / /g;
#        $prod=~s/  / /g;
#        $prod=~s/ $//;
        my $count = $nbest{$gene}{$prod} ;
        #print "BB:$gene\t$prod\t$count\n";       
# LOWER HYPOTHETICAL PRODUCT SCORES
        if ($prod =~/hypothetical/) {
            $count = $count * 0.17;
        }

        if ($prod !~/\w+/) {
            # print "400:$gene\t$prod\n";
        }
        


        if ($count >= $max) {
            unshift (@highest, "$gene\t$prod\t$count");
            $max = $count;
        }
        else {
            push (@highest, "$gene\t$prod\t$count");
        }
    }
    
    foreach my $val (@highest) {
        $val=~s/\t\t/\t/g;
        $val=~s/\t\t/\t/g;
    my @arr = split(/\t/,$val);
#        print "VAL418:$val:\n";
            if ($arr[2] !~/\d+/ ) {

                print "WARNING4:$val:\n";
                next;
            }


        if ($arr[2] >= $max) {
            print OUT "BEST3:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
            push ( @{$nnbest{$arr[0]}},  $arr[1]) ;
        }
        else {
            print OUT "WORSE3:\t$arr[0]\t\/product=\"$arr[1]\"\t$arr[2]\n";
        }

    }

    
}


print OUT "############## ROUND 3 ################\n";




#concatenate the remaining best ones #

my %tbest;
#my $ct = 1;

foreach my $gene (keys %nnbest) {
    my $length =  scalar(@{$nnbest{$gene}});
#    print "$gene\t$length\n";
    
    if ($length == 1) {
        print OUT2 "$gene\t\/product=\"${$nnbest{$gene}}[0]\"\n";
    }
    elsif  ($length == 2) {

        my $prod1 =  @{$nnbest{$gene}}[0];
        my $prod2 =  @{$nnbest{$gene}}[1];

        my @arr1 = split(/ /, $prod1);
        my @arr2 = split(/ /, $prod2);

        foreach my $elem (@arr1) {
            $elem=~s/^\w$/ /;
            $elem=~s/^\d$/ /;
            
        }
        $prod1 = join(" ", @arr1);
        $prod1 =~s/  / /g;
        $prod1 =~s/  / /g;
        $prod1 =~s/:/ /g;
        $prod1 =~s/ $//g;
        $prod1 =~s/^ //g;


        foreach my $elem (@arr2) {
            $elem=~s/^\w$/ /;
            $elem=~s/^\d$/ /;
            
        }
        $prod2 = join(" ", @arr2);
        $prod2 =~s/  / /g;
        $prod1 =~s/  / /g;
        $prod2 =~s/:/ /g;
        $prod2 =~s/ $//g;
        $prod2 =~s/^ //g;

        my @arr3 = reverse(@arr2);
        my $prod3 = join(" ", @arr3);
        $prod3 =~s/  / /g;
        $prod3 =~s/  / /g;
        $prod3 =~s/:/ /g;
        $prod3 =~s/ $//g;
        $prod3 =~s/^ //g;

        my @arr4 = @arr2;
        my $prod4 = join(" ", @arr4);
        $prod4 =~s/  / /g;
        $prod4 =~s/  / /g;
        $prod4 =~s/:/ /g;
        $prod4 =~s/ $//g;
        $prod4 =~s/^ //g;


        if ($prod1=~/\Q$prod2\E/) {
             print OUT2  "$gene\t\/product=\"$prod2\"\n";

#            $nnnbest{$gene}{$prod2}+= $ct ;            
        }
        elsif ($prod2=~/\Q$prod1\E/) {
#            $nnnbest{$gene}{$prod1}+= $ct  ; 
             print OUT2  "$gene\t\/product=\"$prod1\"\n";
            
        }
        elsif ($prod1=~/\Q$prod3\E/) {
             print OUT2  "$gene\t\/product=\"$prod3\"\n";
        }
        elsif ($prod1=~/\Q$prod4\E/) {
             print OUT2  "$gene\t\/product=\"$prod4\"\n";
        }

        else {
           
             print  "X1:$gene\t\/product=\"$prod1\"\n";
             print  "X2:$gene\t\/product=\"$prod2\"\n";
             print  "\n";

            my $new2 = $prod1 . "\; " . $prod2 ;    
             print OUT2 "$gene\t\/product=\"$new2\"\n";


#            print "else2\n";
#            foreach my $prod ( @{$nnbest{$gene}}) {
                #print "Length:$prod:\n";
#                    print "h:$gene\t\/product=\"$prod\"\n";
#                    }
                    

            }
            #}


    }
    else {
        my $new2 = join ("\; ", @{$nnbest{$gene}} );    
             print OUT2 "$gene\t\/product=\"$new2\"\n";

    }

}







close (OUT);



__END__



