#!/usr/bin/perl
use strict;

unless (@ARGV >1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/scatterplot_in_R.pl in.rLogMat.txt colours colour.legend


infile has this structure:
        Cond1.1   Cond1.2   Cond1.2   Cond2.2
Gene1   val1  val2  val3    val4
Gene2   val1  val2  val3    val4



';

}

my $in = shift;
#my $in2 = shift;
#my $in3 = shift;

my $col = shift;
my $leg = shift;


my @inr=split(/\//,$in);
my @colr=split(/\//,$col);


open (R, ">$inr[-1].$colr[-1].R") || die "Cannot print to file $inr[-1].$colr[-1].R\n";


# Read in data

print R "CountTable = read.table( \"$in\", header=TRUE, row.names=1 )\n";  

=pod
print R "design =  read.table( \"$in2\", header=TRUE, row.names=1 )\n";
print R "dds<-DESeqDataSetFromMatrix(countData= CountTable,colData= design,design=$in3)\n";

# Do DE test ????
#print R "dds <-DESeq(dds, betaPrior=FALSE)

# Log-transform the values
print R "rld<-rlog(dds, blind=TRUE) \n";

# Make transformation
print R "rlogMat<-assay(rld)\n";

=cut

# Read in colours
print R "Cols = read.table( \"$col\", row.names=1 )\n";
print R 'colnames(Cols) <-c("Colour","Gene")';
print R "\n";

# Read in legend
print R "legend = read.table( \"$leg\" )\n";
print R 'colnames(legend) <-c("Colour","Gene")';
print R "\n";


# Merge Colours and data by row.names
print R "r <-merge(Cols,CountTable,bx=0,by=0, sort=F)\n";

# Rename columns
#print R 'colnames(r) <- c("Row.names", "C1","Colour" )\n';
print R 'colnames(r)';
print R "\n";
# create averages
#print R "r$LSKWTnormal <- (r$LSKWTnormal1 + r$LSKWTnormal2)/2\n";
#print R "r$GMPWTnormal <- (r$GMPWTnormal1 + r$GMPWTnormal2)/2\n";
#print R "r$LSKWTMLLENL <- (r$LSKWTMLLENL1 + r$LSKWTMLLENL2)/2\n";
#print R "r$LSKWTMLLENL <- (r$GMPWTMLLENL1 + r$GMPWTMLLENL2)/2\n";


# Make legend-colours
#print R "legend1 <-levels(r\$Colour)\n";
#print R "legend1\n";
#print R "legend2 <-levels(r\$Gene)\n";
#print R "legend2\n";

# [1] "antiquewhite2"  "aquamarine1"    "azure3"         "azure4"         "blue1"         
# [6] "brown2"         "chocolate4"     "coral1"         "cornflowerblue" "cornsilk3"     
#[11] "cyan1"          "cyan2"          "cyan3"          "darkkhaki"      "darkorange"    
#[16] "darkorchid"     "darkred"        "red"           


# plot dots and legend
print R "pdf(\"$inr[-1].$colr[-1].1.pdf\", useDingbats=FALSE)\n";
print R "par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)\n";
print R "plot(r\$LSKWTnormal,r\$GMPWTnormal, col=as.character(r\$Colour), bty='L')\n";
print R "legend(20,20,as.vector(legend\$Gene),col=as.vector(legend\$Colour), pch=1)\n";
print R " par(xpd=FALSE) \nabline(a=0,b=1)\n";
print R "dev.off()\n";

# plot dots and legend
print R "pdf(\"$inr[-1].$colr[-1].2.pdf\", useDingbats=FALSE)\n";
print R "par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)\n";
print R "plot(r\$LSKWTMLLENL,r\$GMPWTMLLENL, col=as.character(r\$Colour), bty='L')\n";
print R "legend(20,20,as.vector(legend\$Gene),col=as.vector(legend\$Colour), pch=1)\n";
print R " par(xpd=FALSE) \nabline(a=0,b=1)\n";
print R "dev.off()\n";


system "R CMD BATCH $inr[-1].$colr[-1].R";


exit;

 




__END__





