#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  usearchParser.pl  uc original.fasta


Takes the output from usearch and calls consensus


';

}

my $uc = shift;
my $fas = shift;

my %fas;
my %clus;




###  parse cluster file  ####

open (CLU, "<$uc") || die;

while (<CLU>) {
    chomp;
    my @arr = split(/\t/, $_);
    if ($arr[0]=~/^H$/) {
        #print "$arr[0]\t$arr[8]\t$arr[9]\n";
        $clus{$arr[9]}{ $arr[8] } = 1;
        $clus{$arr[9]}{ $arr[9] } = 1;
    }
}


close (CLU);


###  parse fasta file  ####

open (FAS, "<$fas") || die;


while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head} = $seq;
        
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}



close (FAS);




# marry up clusters and sequences, and make a separete fasta, and align it


# printing all fasta-files

mkdir "$uc\_fas";

open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";

my %files;

foreach my $key (sort keys %clus) {
    print "$key\n";
    $key=~s/revcomp_//;

    open (FH, ">$uc\_fas/$key.fas") || die "Cant open file $uc\_fas/$key.fas ";
    $files{ "$key.fas" } = 1;

    #print OT "\n$key\t";
    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
        if (exists $fas{$key2} ) {
            #print "$key\t$key2\t$fas{$key2}\n";
            print OT "$key\t$key2\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }
        elsif (exists $fas{$key2} ) {
            #print "$key\t$key2\t$fas{$key2}\n";
            print OT "$key\t$key2\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }

        else {
            print "Warning - no sequence for $key2 in file $fas\n";
        }
    }

    close (FH);
}

close (OT);

#__END__



chdir "$uc\_fas";

# calculating consensus

foreach my $key (keys %files) {

    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
    system ("/software/pubseq/bin/mafft --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
    system "perl  ~/bin/perl/consensus_caller.pl  $key.mfa 10";wait;

}

chdir "..";



# now go back and retrieve those sequences that are not in a cluster 


open (FAS2, ">$fas.unclustered") || die;


foreach my $key (sort keys %fas) {
    print FAS2 ">$key\n$fas{$key}\n";
}

close (FAS2);

# now go and retrieve the consensi, and the rejected sequences

#sleep(10);

system "cat $uc\_fas/\*consensus.fa > $fas.consensus ";wait;
system "cat $uc\_fas/\*rejected > $fas.rejected ";wait;
system "cat $uc\_fas/\*accepted  > $fas.clustered ";wait;
system "cat $fas.consensus $fas.unclustered $fas.rejected > $fas.merged.fas  ";wait;


exit;


# exonerate --model est2genome --bestn 1 --minintron 10 --showtargetgff true --showcigar true ../unc_velvet_70.59.fa ../pathogen_HYM_scaffold_70.sl.fas




__END__

 1192300
271241 * 3


  1121883
  254299 * 3

