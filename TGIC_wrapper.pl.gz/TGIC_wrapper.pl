#!/usr/bin/perl
use strict;


unless (@ARGV > 0 ) {
        &USAGE;
}



sub USAGE {

die ' 

This is a wrapper for the progam TGIC which clusters large numbers of transcriptome assemblies/ESTs


Usage: perl ~mz3/bin/perl/TGIC_wrapper.pl myseq.fasta <options>

Example: perl ~/bin/perl/TGIC_wrapper.pl ../TGIC_test/Trinity.fasta -p 50 -l 20


The options for TGIC are the following:

     -F <fasta_db> the EST file in fasta format.
     -c : use the specified number of CPUs on local machine
         (default 1) or a list of PVM nodes in <PVM_nodefile>

  Clustering phase options:
     -d do not perform all-vs-all search, but search <fasta_db> against 
        <refDb> instead; exit after the pairwise hits are generated
     -n number of sequences in a clustering search slice (default 1000)
     -p minimum percent identity for overlaps <PID> (default 94)
     -l miminum overlap length (default 40)
     -G store gap information for all pairwise alignments
     -v maximum length of unmatched overhangs (default 30)
     -M ignore lower-case masking in <fasta_db> sequences
     -W use custom script <pairwise_script.psx> for the distributed 
        pairwise searches instead of the default: tgicl_cluster.psx
     -Z only run the distributed pairwise searches and exit -- 
       (no sorting of the pairwise overlaps and no clusters generated)
     -Y only run the distributed pairwise searches 
        and the sorted & compressed *_hits.Z file
     -L performs more restrictive, layout-based clustering
        instead of simple transitive closure
     -I do not rebuild database indices
     -s attempt to split clusters larger than <maxsize> based on 
        seeded clustering (only works if there are \'et|\' 
        or \'np|\'-prefixed entries provided in the input file)
     -O use given \'cap3_options\' instead of the default ones
        ($cap3opt)
     -u skip the mgblast searches (assumed done) but restrict 
        further clustering analysis to only the sequences in <seq_list>
     -C (TIGR sequences only) always put in the same cluster all reads 
        from the same clone
     -t use <clone_list> file to put in the same cluster all sequence names
        on the same line
     -a assemble clusters from file <cluster_file>
       (do not perform any pairwise clustering)
     -f keep only sequence names with prefix <prefix>
     -K skip the pairwise searches, only recreate the clusters
        by reprocessing the previously obtained overlaps
     -X do not perform assembly, only generate the cluster file
     -A use custom script as the slice assembly script 
        (instead of tgicl_asm.psx)
     -P pass the <param_file> as the custom parameter file 
        to the assembly program <asmprog.psx>
     -b use a backend database. username, password, server name and driver
          need to be provided.
     -R generate HTML reports at the end of the build.



';

}


# Prepare job

use Cwd;
my $cwd = cwd();
my $fas = shift;
system "cp $fas Input.fas"; 
print "cp $fas Input.fas \n";

unless (-e "Input.fas") {
    die "$!";
}


# chdir "~" ;
#
open (IN, "</nfs/users/nfs_m/mz3/bin/TGICL-2.1/conf/ori_tgicl.cfg") or die "$!";
open (OUT, ">/nfs/users/nfs_m/mz3/tgicl.cfg") or die "$!";

my @cfg = <IN>;

foreach my $line (@cfg) {

    $line =~s/DB_FILE =/DB_FILE =  $cwd\/Input.fas /;
    print OUT "$line";
}


#system "cat ~mz3/bin/TGICL-2.1/conf/ori_tgicl.cfg | sed 's/DB_FILE = /DB_FILE = $cwd\/$fas /g' > ~/tgicl.cfg ";
#print "cat ~mz3/bin/TGICL-2.1/conf/ori_tgicl.cfg | sed 's/DB_FILE = /DB_FILE = $cwd\/$fas /g' > ~/tgicl.cfg \n ";

my $com = join(" ", @ARGV);

print "Executes ~mz3/bin/TGICL-2.1/bin/tgicl -M -F Input.fas $com\n";
print "Your output is *.fasta_cl_clusters and Result.fas \n\n";


system "~mz3/bin/TGICL-2.1/bin/tgicl -M -F Input.fas $com";

system "rm -f formatdb.log masked.lst *.Z *.log";

system "rm -f ~/tgicl.cfg Input.fas.n* ";

# print "cdbyank Input.fas.cidx < Input.fas.singletons > Singles.fas\n";
system "cdbyank Input.fas.cidx < Input.fas.singletons > Singles.fas";
system "cat asm_1/contigs  > Assembled.fas";
system "cat Assembled.fas Singles.fas > Result.fas";
print "\nstats Input.fas\n";
print "stats Result.fas\n\n";
system "rm -fr asm*";




