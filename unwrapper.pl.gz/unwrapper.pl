#!/usr/local/bin/perl -w

use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV == 1 ) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: unwrapper.pl alignment-file 

This script takes an alignment file with several lines, and merges them to one


'
}

    my $in = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

    	open (OUT, ">$in.unwrapped.aln") || die "I can't open $in.unwrapped.aln\n";


my %gene;

foreach my $line (@input) {
    chomp $line;

    if ($line=~/\w/) {
        my (@arr)= split (/\s+/, $line);
#        print "ARR0:$arr[0]\n";
        if (exists $gene{$arr[0]}) {
            $gene{$arr[0]} = $gene{$arr[0]} . $arr[1];
#            print "ADDED: $arr[0]\t$gene{$arr[0]}XXX$arr[1]\n";
        }
        elsif ($arr[0]=~/\w+/) {
            $gene{$arr[0]} = $arr[1];
#            print "STARTED: $arr[0]\t$gene{$arr[0]}\n";
        }
        else  {
#            $gene{$arr[0]} = $arr[1];
#            print "STARTED: $gene{$arr[0]}\n";
        }
    }

}


foreach my $taxa (keys %gene) {
#    print "$taxa\n";

    print OUT "$taxa\t$gene{$taxa}\n";

}
