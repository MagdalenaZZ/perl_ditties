#!/usr/bin/perl -w


use strict;

if (@ARGV < 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: DEXSeq_prepare_gff.pl  

Get a gff file from here:
http://ftp.ensembl.org/pub/release-82/gtf




'
}

my $in = shift;

system "source activate py2.7";

# run prepare

system "python ~/bin/R-packages/DEXSeq/python_scripts/dexseq_prepare_annotation.py  $in  $in.gff";


#system "python ~/bin/R-packages/DEXSeq/python_scripts/dexseq_count.py  -p yes -r pos -s yes -f bam $in.gff $in2 $in2.DEXcounts";



exit;

