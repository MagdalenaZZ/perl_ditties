#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLASTparser.pl blast-out


'
}

# Get pairs with long overlaps

	my $blast = shift;
	open (IN, "$blast") || die "I can't open $blast\n";
	my @blast = <IN>;
	close (IN);

foreach my $line (@blast) {
	my ($first, $second) = split (/\s+/,$line);

#	print "$first\n";

	my ($stem, $scaf , $contig)= split (/_/,$first);
	my ($stem2, $scaf2 , $contig2)= split (/_/,$second);
	if ($contig <  $contig2 ) {
		if ($scaf == $scaf2 ) {
		#these are on same contig
#		print "$first\n";
		my $contig3 = ($contig +1 );
#find contigs next to each other
			if ($contig3 == $contig2 ) {
		# search for the sequence lengths in the new_scaffolds.txt.fasta.agp file

				my $first_info = `cat /lustre/scratch101/sanger/mz3/GARM/fixed/new_scaffolds.txt.fasta.agp | grep $first`;
				my $second_info = `cat /lustre/scratch101/sanger/mz3/GARM/fixed/new_scaffolds.txt.fasta.agp | grep $second`;
				print "$first_info\n";
				print "$second_info\n";
			}
			else {
#			print "$first and $second are not next to each other\n";
			}
#		print "$first_info\n";
		}
		else {
		# these are on different contigs
#		print "$first and $second are a weird match\n";
		}
	}
	elsif ($contig == $contig2) {
#	print "$first and $second have same contig\n";
	}
	elsif ($contig >  $contig2) {
	#filtered reciprocal hits
#	print "$first and $second are reciprocal\n";
	}
	else {
#	print "$first and $second dont fit\n";
		}


}

__END__
/lustre/scratch101/sanger/mz3/GARM/454vel/scaffolding/new_new_scaffolds.txt

/lustre/scratch101/sanger/mz3/GARM/fixed/new_scaffolds.txt.fasta.agp


