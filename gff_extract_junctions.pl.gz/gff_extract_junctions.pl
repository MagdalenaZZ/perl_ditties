#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=3) {
        &USAGE;
}


sub USAGE {

die 'Usage: sam_extract_junctions.pl input.sam input.gff 

Takes a gff-file and makes a raw junction-file


'
}

# format

	my $ref = shift;
	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

    my %gff

# read in gff CDS in a hash

foreach my $line (@gff) {
    chomp $line;
    my @arr = split(/\s+/, $line);
    if ($arr[2]=~/CDS/) {
        print "$arr[3]\t$arr[4]\t$arr[8]\n";
    }
}

# write juncions from hash    

# <chrom> <left> <right> <+/->




__END__

Supplying your own transcript annotation data:

The options below allow you validate your own list of known transcripts or junctions with your RNA-Seq data. Note that the chromosome names in the files provided with the options below must match the names in the Bowtie index. These names are case-senstitive.

	
-j/--raw-juncs <.juncs file> 	

Supply TopHat with a list of raw junctions. Junctions are specified one per line, in a tab-delimited format. Records look like:

<chrom> <left> <right> <+/->

left and right are zero-based coordinates, and specify the last character of the left sequenced to be spliced to the first character of the right sequence, inclusive. That is, the last and the first positions of the flanking exons. Users can convert junctions.bed (one of the TopHat outputs) to this format using bed_to_juncs < junctions.bed > new_list.juncs where bed_to_juncs can be found under the same folder as tophat

