#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~/bin/perl/gff2art.pl gff

Makes a gzipped index of the gff-file, suitable for Artemis


';

}


my $gff = shift;


system " (grep ^\"#\" $gff; grep -v ^\"#\" $gff | sort -k1,1 -k4,4n) | bgzip > $gff.gz";wait;
system "tabix -p gff -f $gff.gz";


exit;



