#!/usr/bin/perl -w
# mz3 script for changing genepredictor output to Artemis or BEDtools files

use strict;

use Getopt::Std;
use Getopt::Long;


# checking input values

my %opts;

unless (@ARGV) {
        &USAGE;
}

getopts('hi:o:p:f:d:', \%opts);

&USAGE if $opts{h};

######################
my $path = "";

if ($opts{d}) {

	$path = $opts{d}; 
	# print "$path\n";
	# my $path = "/nfs/users/nfs_m/mz3/bin/perl";
}

######################

my %programs;
$programs{snap} = "$path/snap2gff.pl";  ## works -start-end sorting not done
$programs{glimmer} = "$path/glimmer2gff.pl";  ## sub doesnt exist
$programs{cufflinks} = "$path/cufflinks2gff.pl";
$programs{augustus} = "$path/augustus2gff.pl"; ## works -start-end sorting not done
$programs{blast} = "$path/BLAST2gff.pl";  ## works -start-end sorting not done
$programs{jigsaw} = "$path/jigsaw2gff.pl"; ## sub doesnt exist


########################### IOs #################################################


# make sure there is input, and make sure it is a gff file
if ($opts{i}) {
	VALIDATE($opts{i});
} else {
	print "Please give me an input file\n";
	&USAGE;
}


#  give a reasonable output name and check output valid
my $out = "";
my $outname = "output.art.gff";

if ($opts{p}) {
	my $preval = $opts{p};
	if ( $programs{$preval} ) {
		$out = TRANSLATOR($opts{p}, $opts{i});
	} else {
		die "Invalid output format\n";
		&USAGE;
	}
}


## need to add something here to change the outputs


my %outputformat;
$outputformat{art} = "art";
$outputformat{bed} = "bed"; 


if ($opts{o} and $opts{f}) {

#	if ($opts{f}) {
		my $format = $opts{f};
	
		if ( $outputformat{$format} eq "art" ) {
			$outname = "$opts{o}.art.gff";
		} 
		elsif ( $outputformat{$format} eq "bed" ) {
			$outname = "$opts{o}.bed.gff";
		}
#	}
}

elsif ($opts{o}) {
	print "No output format specified. Your result will go to output.art.gff\n";
}

elsif ($opts{f}) {
	
	
	print "No output prefix specified. Your result will go to output.$opts{f}.gff\n";	
}

 else {
	print "No output format specified. Your result will go to output.art.gff\n";
}



=pod
# check output exists
if ($out) {
	if ($opts{b} and $opts{o} ) {
		$outname = "$opts{o}.bed.gff";
	} 
	elsif ($opts{a} and $opts{o}) {
		$outname = "$opts{o}.art.gff";
	}
	
	else {
		$outname = "output.gff";
	}
	
=cut

	open OUTFILE, ">$outname";
	print OUTFILE "$out";
	close OUTFILE;



################################### subs #############################################




sub TRANSLATOR {
# sub translator calls modules for different predictors

my $pred = shift;  #grabs the first value of arguments for the sub
my $input = shift; #grabs the 2nd value of arguments for the sub
my $outsub = "";

if ($programs{$pred}) {  # double check that the value of -f exists in $programs
	my $cmd = "$programs{$pred} $input"; 
	$outsub = `$cmd`;
} else {
	die "something wierd...";
}

return $outsub;

}





sub VALIDATE {
# sub validate checks that there is an inputfile and that it is gff format

	my $name = shift;
	open (IN, "$name") || die "I can't open $name\n";
	my $whatever = <IN>;
	close (IN);

#check if gff is correct or no
}



sub USAGE {

die 'Usage: name.pl -p <predictor> -f <output> -i infile.gff -o output_prefix 
	-i: gene-predictor output.gff
	-o: output file name
	-p: predictor 
		snap
		glimmerHMM
		cufflinks
		augustus
		blast (tabular format)
		jigsaw
	-f: output format
		art  Artemis format (default)
		bed  BEDtools format
'
}

