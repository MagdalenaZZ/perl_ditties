#!/usr/local/bin/perl -w

use strict;
unless (@ARGV) {
	&USAGE;
}



sub USAGE {
	die "\nUsage: my_minimus3.pl </path_to/ref_genome> </path_to/add_genome> <min_length> <max-substs> <prefix_output>\n
    
    
    
    warning - this is not a script!!!!!!!\n\n";
}






