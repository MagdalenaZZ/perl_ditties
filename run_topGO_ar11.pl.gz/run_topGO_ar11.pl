#!/usr/local/bin/perl -w

use strict;

my $p_cut = 0.01;

my $node_size = 3;

my($clust, $go, $type, $outfile) = @ARGV;

if(!defined $go)
{
	print "USAGE: clust, go, type\n";
	exit;
}

$type = 'BP' unless defined $type;

open(CL, "<$clust") or die "$!";

my $clust_num = 1;

my @vecs = ();
my @ids = ();

while(<CL>)
{
	chomp;

	#my(@a) = split /\t/;

	push @ids, $_;

	#$a = join "\",\"", @a;

	#$a = '"'.$a.'"';

	#push @vecs, $a;
}
close CL;

my $ids = join "\",\"", @ids;
$ids = '"'.$ids.'"';
push @vecs, $ids;

my ($r_file, $outfiles) = r_code(\@vecs);

`R-2.15 --no-save < $r_file`;


my @header = ();
my %data = ();	

foreach my $file (@$outfiles)
{
	open(FILE, "<$file") or die "$!: $file";
	
	while(<FILE>)
	{
		chomp;
		
		if(/\[\d+\] (.*)/)
		{
			my(@ids) = split /\t/, $1;
		}
		elsif(/^"\d/)
		{
			my($row, $id, $term, $ann, $sig, $exp, $p) = split /\t/;
		
			$p =~ s/\"//g;
			$id =~ s/\"//g;
			$term =~ s/\"//g;
		
			next unless $p <= $p_cut;
		
			print "$file\t$id\t$term\t$p\n";
		}
	}
	close FILE
}

sub r_code
{
	my $vec = shift;

	my @files = ();

	my $out_file = 'temp.R';

	my $clust_num = 1;

	open(OUT, ">$out_file") or die "$!";

	print OUT <<RCODE;

	library(topGO, lib.loc="~ar11/R/library")

	ref=read.table (file="$go", stringsAsFactors=FALSE)
	names(ref) = c('id', 'go')
	ref.vec = strsplit(ref\$go, split=',', fixed=T)
	names(ref.vec) <- ref\$id
	all.ids <- ref\$id

RCODE

	foreach my $row (@$vec)
	{
		print OUT <<RCODE;
		vec<-c($row)

		scores <- rep(0, nrow(ref)) # list of scores
		names(scores) <- ref\$id
		scores[ref\$id \%in\% vec] <- 1

		geneSelectionFun <- function(score){
		  return(score >= 1)
		}

		GOdata <- new("topGOdata",  ontology = '$type', allGenes = scores, annot = annFUN.gene2GO, gene2GO = ref.vec, geneSelectionFun = geneSelectionFun, nodeSize = $node_size, description = '')
	
		#resultFisher <- runTest(GOdata,algorithm="classic",statistic="Fisher")
		resultTopgo <- runTest(GOdata,algorithm="weight01",statistic="Fisher")
		#resultElim <- runTest(GOdata,algorithm="elim",statistic="Fisher")

		res<-GenTable( GOdata, topGO = resultTopgo, orderBy = "topGO", ranksOf = "fisher", topNodes = 50)

		sink("genes_in_term$clust_num")
		genesInTerm(GOdata)

		sink("clust$clust_num")
		print(vec)

		write.table(res, sep = "\t")

RCODE

		push @files, "clust$clust_num";
		$clust_num++;
	}
	close OUT;

	return ($out_file, \@files);
}
