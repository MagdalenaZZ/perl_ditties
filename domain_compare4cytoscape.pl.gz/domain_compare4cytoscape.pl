#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: domain_compare.pl domain-file

Takes one file with domain-architectures - Pfam-style format, and compares the domain contents of it

'
}



my $dom1 = shift;

# read all domain architectures into a hash
#
	open (IN, "<$dom1") || die "I can't open $dom1\n";
	my @doms = <IN>;
	close (IN);

    open (OUT, ">$dom1.out.cyt") || die "I can't open $dom1.out.cyt\n";

my %ddom;
my %h;

foreach my $lin (@doms) {
    chomp $lin;
    my @arr2 = split(/\s+/, $lin);

    if ($arr2[6] =~/\w+/ ) {
    $arr2[6]=~s/ //g;
    $arr2[6]=~s/\t//g;
        $h{$arr2[0]}{$arr2[6]} += 1;
#        print "$arr2[0]\t$arr2[6]\t$h{$arr2[0]}{$arr2[6]}\n";
    }
}


# compare all genes against each other

my %h2 = %h;
my %comp;


# check if two domains are in the same gene
my %res;

foreach my $gen (keys %h) {

#    print "GENE: $gen\n";
    my @spe = split (/_/, $gen);

    foreach my $dom ( keys %{$h{$gen}} ) {
         foreach my $dom2 ( keys %{$h{$gen}} ) {
            my @arr = sort {$a cmp $b} ( $dom, $dom2 ) ;
            my $cat=0;
            if ($arr[0] =~/^MZ\d+/ and $arr[1] =~/^MZ\d+/ ) {
                $cat = "MZ_MZ";
            }
            elsif ($arr[0] =~/^MZ\d+/ and $arr[1] =~/^Pfam-B\d+/ ) {
                $cat = "MZ_Pfam-B";
            }
            elsif ($arr[0] =~/^Pfam-B\d+/ and $arr[1] =~/^Pfam-B\d+/ ) {
                $cat = "Pfam-B_Pfam-B";
            }
            elsif ($arr[0] =~/^Pfam-B\d+/ and $arr[1] =~/^\w+/ ) {
                $cat = "Pfam-B_PfamA";
            }
            elsif ($arr[0] =~/^\w+/ and $arr[1] =~/^Pfam-B/ ) {
                $cat = "PfamA_Pfam-B";
            }
            elsif ($arr[0] =~/^MZ\d+/ and $arr[1] =~/^\w+/ ) {
                $cat = "MZ_PfamA";
            }
            elsif ($arr[0] =~/^\w+/ and $arr[1] =~/^MZ/ ) {
                $cat = "PfamA_MZ";
            }
            elsif ($arr[0] =~/^\w+/ and $arr[1] =~/^\w+/ ) {
                $cat = "PfamA_PfamA";
            }

            my $result = "$arr[0]\t$spe[0]\t$arr[1]\t$cat";
            $res { $result } =1;
        }
    }

}


foreach my $elem (keys %res) {
    print OUT "$elem\n";
}


	close (OUT);

__END__


foreach my $gen (keys %h) {
    foreach my $gen2 (keys %h2) {
        foreach my $dom ( %{$h{$gen}} ) {
            # sort genes
#            print "U:$gen\t$gen2\n";
            my @array = sort {$a cmp $b} ( $gen, $gen2 ) ;
#            my  (sort { $a cmp $b } ($gen, $gen2))[-1];
#            print "S:$gen\t$gen2\n";
#            print "S:$array[0]\t$array[1]\n";
            unless (exists $comp{$array[0]}{$array[1]}  ) {
                $comp{$array[0]}{$array[1]} = 0 ;
            }
#            print "$dom\n";
                if ($dom =~/^\d+$/) {                
#                    print "DOM1: $dom\n";
                }
                else {
                    if (exists $h2{$gen2}{$dom} ) {
#                       print "SHARED:$gen\t$gen2\t$dom\t$comp{$gen}{$gen2}\n";

                    }
                    else {
#                        $comp{$gen}{$gen2} -= 1 ;
                         $comp{$array[0]}{$array[1]} -= 1 ;

#                        print "MISSING:$gen\t$gen2\t$dom\t$comp{$gen}{$gen2}\n";

                    }
                }

        }

    }
}

## merge 1-2 and 2-1
#my %comp3 

foreach my $gens (keys %comp) {
    foreach my $gens2 (keys %{$comp{$gens}} ) {
        print OUT "$gens\t$gens2\t$comp{$gens}{$gens2}\n";
#        if (exists $comp{$gens2}{$gens1} ) {

#        }
    }
}




