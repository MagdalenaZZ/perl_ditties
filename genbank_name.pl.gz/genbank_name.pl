#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}

sub USAGE {

die 'Usage: genbank_name.pl in



'
}

	my $in = shift;
	my $out = "$in.renamed";
	open (IN, "<$in") || die "I can't open $in\n";
    	open (OUT, ">$out") || die "I can't open $out\n";

## read the fastas
my %fasta;

while (<IN>) {
	if ( $_ =~m/^>/) {
		my $name = $_ ;
        chomp ($name);
#        print "$name\n"; <STDIN>;
		my $seq = <IN> ;
		chomp($seq) ;

        #########

# translate the names nicely
        my @nam = split(/\|/, $name);
        $name= $nam[3] . " " . $nam[4];

        if ( $name =~/Echinococcus granulosus/ ) {
            $name= "Eg"  . $name;
        }
        elsif ( $name =~/Echinococcus multilocularis/ ) {
            $name= "Em"  . $name;
        }
        elsif ( $name =~/Hymenolepis microstoma/ ) {
            $name= "Hm"  . $name;
        }
        elsif ( $name =~/Taenia solium/ ) {
            $name= "Ts"  . $name;
        }
        elsif ( $name =~/Taenia/ ) {
            $name= "Tx"  . $name;
        }
        elsif ( $name =~/Echinococcus/ ) {
            $name= "Ex"  . $name;
        }
        elsif ( $name =~/Hymenolepis/ ) {
            $name= "Hx"  . $name;
        }


        $name = ">O_" . $name; 

        ########
    		$fasta{$name} = $seq ;
#        print "$name\t$seq\n";
 	}
    else {
    }
}


# print the output

foreach my $gene (keys %fasta) {

    print OUT "$gene\n$fasta{$gene}\n";
}




