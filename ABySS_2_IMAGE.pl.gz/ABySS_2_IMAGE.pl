#!/usr/local/bin/perl -w
# mz3 script for generating read.placed.original and contigs.fa.original files from ABySS -> scaff_split.pl output

use strict;



unless (@ARGV) {
        &USAGE;
}


my $file_name = shift @ARGV;
my $count=1;

open (IN, "$file_name") or die "Cant find file $file_name\n" ;
open (OUT, ">reads.placed.original") or die "Cant write to file reads.placed.original \n" ;

while (<IN>) {
	chomp ;

	if ($_=~'>') {
	s/^.//;
	my @line = split /\_/ , $_ ;
	print OUT "$_", "\t", "scaf$line[0]","\n";
#	$reads{$line[0]}
	$count++ ;

	}
}
close(IN) ;
close(OUT) ;



sub USAGE {

die 'Usage: ABySS_2_IMAGE.pl <infile>

'
}

