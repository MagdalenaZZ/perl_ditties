#!/usr/bin/perl -w


use strict;

if (@ARGV < 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: DEseq_me.pl  merged.reads conditions.table <no_conditions>

Takes a list of genes and reads and does DEseq stuff on them 


conditions.table is a list of the experimental design
For each condition, make a row, like this:

ID    condition libType
untreated1 untreated single-end
untreated2 untreated single-end
untreated3 untreated paired-end
untreated4 untreated paired-end
treated1 treated single-end
treated2 treated paired-end
treated3 treated paired-end



IN PROGRESS


'
}


# read in reads data
my $in = shift;
open (IN, "<$in") || die "I can't open $in\n";
my @in= <IN>;
close (IN);


# read in conditions data
my $in2 = shift;
open (IN2, "<$in2") || die "I can't open $in2\n";
my @in2= <IN2>;
close (IN2);

my @c0;
my @c1;
my @c2;
my @c3;
my @c4;
my @c5;
my @c6;
my @c7;

my %c;

#my %c1;
#my %c2;
#my %c3;
#my %c4;
#my %c5;
#my %c6;
#my %c7;





foreach my $line (@in2) {
    chomp $line;
    my @arr = split(/\t/,$line);
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");

    push (@c0, $arr[0]);
    push (@c1, $arr[1]);
    push (@c2, $arr[2]);
    push (@c3, $arr[3]);
    push (@c4, $arr[4]);

    $c{"c0"}{$arr[0]}=1;
    $c{"c1"}{$arr[1]}=1;
    $c{"c2"}{$arr[2]}=1;
    $c{"c3"}{$arr[3]}=1;
    $c{"c4"}{$arr[4]}=1;
    $c{"c5"}{$arr[5]}=1;

}


my @designs;


shift @c0;
my $c0 = join("\"\, \"", @c0); 
$c0= "\"" . $c0 . "\"";
print "$c0\n";

shift @c1;
my $c1 = join("\"\, \"", @c1); 
$c1= "\"" . $c1 . "\"";
print "$c1\n";

#if ($c1 =~/\d+/) {
#    push (@designs, $c1);
#}

shift @c2;
my $c2 = join("\"\, \"", @c2); 
$c2= "\"" . $c2 . "\"";
print "$c2\n";
#if ($c2 =~/\w+/) {
#    push (@designs, $c2);
#}

shift @c3;
my $c3 = join("\"\, \"", @c3); 
$c3= "\"" . $c3 . "\"";
print "$c3\n";
if ($c3 =~/\d+/) {
    push (@designs, $c3);
}


shift @c4;
my $c4 = join("\"\, \"", @c4); 
$c4= "\"" . $c4 . "\"";
print "$c4\n";
if ($c4 =~/\d+/) {
    push (@designs, $c4);
}



open (R, ">$in.R") || die "I can't open $in.R\n";

# read in data
#print R "datafile = system.file( \"$in\", package=\"pasilla\" \n)";

print R "$in\_CountTable = read.table( \"$in\", header=TRUE, row.names=1 )\nhead( $in\_CountTable )\n";



# make a design

print R "#####  design #########\n";
print R "$in\_Design = data.frame(\nrow.names = colnames( $in\_CountTable ),\n";

# make dataframe
print R "libType= c($c1),\n";

print R "condition = c($c2),\n";

print R "condition2 = c($c3)\n";

# make dataframe
foreach my $des (@designs) {
    print R "$in\_condition = c($des)\n";
}

print R ")\n";

print R "##############\n";


# get parired samples
print R " $in\_pairedSamples = $in\_Design\$libType == \"paired-end\"\n";
print R " $in\_countTable = $in\_CountTable[ , $in\_pairedSamples ]\n";
print R " $in\_condition = $in\_Design\$condition[ $in\_pairedSamples ]\n";



print R "library( \"DESeq\" )\n$in\_cds = newCountDataSet( $in\_CountTable, $in\_condition )\n";

# estimate size factors - this is done for each library individually
print R "$in\_cds = estimateSizeFactors( $in\_cds )\nsizeFactors( $in\_cds )\n";



# print the normalised data to a file

print R " write.table(  counts( $in\_cds, normalized=TRUE )  , file=\"$in.norm\", row.names=TRUE, col.names=TRUE) \n";


# now estimate dispersion

print R "$in\_cds = estimateDispersions( $in\_cds )\n";

# plot the dispersion
# png("data.png",
print R "png (\"$in\_cds.png\" , height=700, width=700 )\nplotDispEsts( $in\_cds )\ndev.off()\n";



#print R "$in\_cds = estimateDispersions( $in\_cds, method==\"pooled\" )\n";


#cds2 = estimateDispersions( cds2, method = c("pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled", "pooled"))

=pod
Description:

     This function obtains dispersion estimates for a count data set.
     For each condition (or collectively for all conditions, see
     'method' argument below) it first computes for each gene an
     empirical dispersion value (a.k.a. a raw SCV value), then fits by
     regression a dispersion-mean relationship and finally chooses for
     each gene a dispersion parameter that will be used in subsequent
     tests from the empirical and the fitted value according to the
     'sharingMode' argument.

Usage:

     ## S4 method for signature 'CountDataSet'
     estimateDispersions( object,
        method = c( "pooled", "pooled-CR", "per-condition", "blind" ),
        sharingMode = c( "maximum", "fit-only", "gene-est-only" ),
        fitType = c("parametric", "local"),
        locfit_extra_args=list(), lp_extra_args=list(),
        modelFrame = NULL, modelFormula = count ~ condition, ... )

Arguments:

  object: a ‘CountDataSet’ with size factors.

  method: There are three ways how the empirical dispersion can be
          computed:

            • ‘pooled’ - Use the samples from all conditions with
              replicates to estimate a single pooled empirical
              dispersion value, called "pooled", and assign it to all
              samples.

            • ‘pooled-CR’ - Fit models according to ‘modelFormula’ and
              estimate the dispersion by maximizing a Cox-Reid adjusted
              profile likelihood (CR-APL). This method is much slower
              than ‘method=="pooled"’ but works also with crossed
              factors (as may occur, e.g., in designs with paired
              samples).  Usually, you will need to specify the model
              formula, which should be the same as the one used later
              in the call to ‘nbinomFitGLMs’ for fitting the full
              model.

              Note: The method of using CR-APL maximization for this
              application has been developed by McCarthy, Chen and
              Smyth [Nucl. Acid Res., 2012 and been first implemented
=cut


#print R "$in\_cds = estimateDispersions( $in\_cds )\n";
#




foreach my $key (keys %c) {
    #print "$key\t\n";

    foreach my $key2 (keys %{$c{$key}}) {

        if ($key=~/c2/) {
            print "$key\t$key2\n";

        }
    }

}

#__END__

print R "$in\_resMCvivoMCvitro = nbinomTest( $in\_cds, \"MCvivo\", \"MCvitro\" )\n";
print R "$in\_resPCPS = nbinomTest( $in\_cds2, \"PC\", \"PS\" )\n";


print R "write.table($in\_resMCvivoMCvitro , \"$in\_resMCvivoMCvitro.scores.dat\")\n";



print R "png (\"$in.MA.png\" , height=700, width=700 )\nplotMA($in\_resMCvivoMCvitro)\ndev.off()\n";


print R "png(\"$in.ma_cons.png\")\nplot($in\_resMCvivoMCvitro\$baseMean, $in\_resMCvivoMCvitro\$log2FoldChange, log=\"x\", col=ifelse(res\$padj < 1e-20, \"red\", \"black\"))\n";
print R "png(\"$in.ma_lib.png\")\nplot($in\_resMCvivoMCvitro\$baseMean, $in\_resMCvivoMCvitro\$log2FoldChange, log=\"x\", col=ifelse(res\$padj < 1e-05, \"red\", \"black\"))\ndev.off()\n";




# now with GLM full


print R "$in\_cdsFull = newCountDataSet( $in\_countTable, $in\_Design )\n";
print R "$in\_cdsFull = estimateSizeFactors( $in\_cdsFull )\n";
print R "$in\_cdsFull = estimateDispersions( $in\_cdsFull )\n";
print R "$in\_fit0full = fitNbinomGLMs( $in\_cdsFull, count ~ condition  )\n";
print R "$in\_fit1full = fitNbinomGLMs( $in\_cdsFull, count ~ condition2  )\n";
print R "$in\_pvalsGLMfull = nbinomGLMTest( $in\_fit1full, $in\_fit0full )\n";
print R "$in\_padjGLMfull = p.adjust( $in\_pvalsGLMfull, method=\"BH\" )\n";
print R "write.table($in\_fit0full , \"$in\_fit0full.scores.dat\")\n";


#The benefit fromfiltering relies on property 2, and we will explore it further in Section 5.2. Its statistical validity relies
#on properties 1 and 3. We refer to [7] for further discussion on the mathematical and conceptual background.
print R "$in\_rs = rowSums ( counts ( $in\_cdsFull ))\n";
print R "theta = 0.4\n";
print R "$in\_use = ($in\_rs > quantile($in\_rs, probs=theta))\n";
print R "table($in\_use)\n";


print R "$in\_cdsFilt = $in\_cdsFull[ $in\_use, ]\n";


print R "$in\_cdsFilt = estimateSizeFactors( $in\_cdsFilt )\n";
print R "$in\_cdsFilt = estimateDispersions( $in\_cdsFilt )\n";

print R "$in\_fit0filt = fitNbinomGLMs( $in\_cdsFilt, count ~ condition  )\n";
print R "$in\_fit1filt = fitNbinomGLMs( $in\_cdsFilt, count ~ condition2  )\n";

print R "$in\_pvalsGLMfilt = nbinomGLMTest( $in\_fit1filt, $in\_fit0filt )\n";
print R "$in\_padjGLMfilt = p.adjust( $in\_pvalsGLMfilt, method=\"BH\" )\n";

print R "write.table($in\_fit0filt , \"$in\_fit0filt.scores.dat\")\n";

print R "padjFiltForComparison = rep(+Inf, length($in\_padjGLMfull))\n";
print R "padjFiltForComparison[use] = $in\_padjGLMFilt\n";
print R "tab3 = table( `no filtering` = padjGLMfull < .1, `with filtering` = padjFiltForComparison < .1 )\n";
print R "addmargins(tab3)\n";
