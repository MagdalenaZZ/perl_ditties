#!/usr/local/bin/perl -w
#
use strict;

my($file) = @ARGV;

open(F, "<$file") or die "$!";

my $gene_name = '';
my %cds;
my $previous_str = '';
my $count = 0;
my $previous_score = 0;

while(<F>)
{
	next if /^#/;

	my($seq, $method, $element, $start, $end, $score, $str, $frame, $att, $comments) = split /\t/;

	$score = 1 if $score eq '.';

	if($element eq 'transcript')
	{
		my $el_count = 0;

		my @sorted_cds = ();

		@sorted_cds = sort {$a<=>$b} keys %cds;

		foreach my $begin (@sorted_cds)
		{
			my $type = '';

			if($count > 0)
			{
				if(scalar keys %cds == 1)
				{
					$type = 'single';
				}
				elsif(($el_count == 0 && $previous_str eq '+') || ($el_count == (scalar keys %cds) -1 && $previous_str eq '-'))
				{
					$type = 'initial';
				}
				elsif(($el_count == (scalar keys %cds) -1 && $previous_str eq '+') || ($el_count == 0 && $previous_str eq '-'))
				{
					$type = 'terminal';
				}
				else
				{
					$type = 'internal';
				}
	
				if($previous_str eq '-')
				{
					print "$count $type $cds{$begin} $begin $previous_score\n";
				}
				else
				{
					print "$count $type $begin $cds{$begin} $previous_score\n";
				}
			}

			$el_count++;
		}

		$gene_name = $att;
		%cds = ();
		$count++;
	}
	if($element eq 'exon')
	{
		$cds{$start} = $end;
		$previous_str = $str;
		$previous_score = $score;
	}
}
close F;

if(scalar keys %cds > 0)
{
	my $el_count = 0;

	my @sorted_cds = ();

	@sorted_cds = sort {$a<=>$b} keys %cds;

	 foreach my $begin (@sorted_cds)
	 {
		my $type = '';

		if($count > 0)
		{
			if(scalar keys %cds == 1)
			{
				$type = 'single';
			}
			elsif(($el_count == 0 && $previous_str eq '+') || ($el_count == (scalar keys %cds) -1 && $previous_str eq '-'))
			{
				$type = 'initial';
			}
			elsif(($el_count == (scalar keys %cds) -1 && $previous_str eq '+') || ($el_count == 0 && $previous_str eq '-'))
			{
				$type = 'terminal';
			}
			else
			{
				$type = 'internal';
			}

			if($previous_str eq '-')
			{
				print "$count $type $cds{$begin} $begin $previous_score\n";
			}
			else
			{
				print "$count $type $begin $cds{$begin} $previous_score\n";
			}
		}

		$el_count++;
	 }
}
