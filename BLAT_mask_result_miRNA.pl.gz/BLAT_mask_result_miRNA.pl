#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_result.pl blatout.psl file_1.fastq file_2.fastq

Takes a blat-output, and retrieves the hits from a fastq file.

Then masks the hits with low-quality Ns and outputs new balanced fastq-files


Warning: psl-files should have no header


' . "\n";
}


my $blat = shift;
my $fastq1 = shift;
my $fastq2 = shift;


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {

        # an alignment length of at least 12 nucleotides and <7 mismatches
        if ($arr[0]> 11 and $arr[1] < 7 and $arr[5] < 9 and $arr[7] < 9   ) {
            #print "ALN $arr[9]\t$arr[11]\t$arr[12]\n";
            
            
            # if I've already seen the hit- update it
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max\t$arr[8]" ;

            }

            # otherwise make a new one
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]\t$arr[8]" ;
                #print "$arr[9]\t$arr[11]\t$arr[12]\n";                
                
                # make a hit-match - hit just has the read-ID, not forward or rev info
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print ":$arr[9]:\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}


#__END__

# read the fastq-files line by line, and print the reads with a match to another file


if ($fastq1 =~ /\.gz$/) {
    open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";
}
else {
    open(FAS1, $fastq1) || die "can't open $fastq1";
}

if ($fastq2 =~ /\.gz$/) {
    open(FAS2, "gunzip -c $fastq2 |") || die "can't open pipe to $fastq2";
}
else {
    open(FAS2, $fastq2) || die "can't open $fastq2";
}

open (OUT1, ">$fastq1.chosen.fastq")|| die;
open (OUT2, ">$fastq2.chosen.fastq")|| die;

#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "HIT1 :$_:\n";
            my $seq = <FAS1>;
            my $mid = <FAS1>;
            my $qual = <FAS1>;
            print OUT1 "$_$seq$mid$qual";
        }

    }
}


while (<FAS2>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/2$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "HIT1 :$_:\n";
            my $seq = <FAS2>;
            my $mid = <FAS2>;
            my $qual = <FAS2>;
            print OUT2 "$_$seq$mid$qual";
        }

    }
}

close (FAS1);
close (FAS2);
close (OUT1);
close (OUT2);




# read in the temp-fastqs, and trim them according to the best BLAT-hit


open (IN1, "<$fastq1.chosen.fastq")|| die;
open (IN2, "<$fastq2.chosen.fastq")|| die;
open (OUT5, ">$fastq1.primer.fastq")|| die;
open (OUT6, ">$fastq2.primer.fastq")|| die;



my %final;
my %final2;

while (<IN1>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1 =~s/\/1$//;
        #print "File1:$head:$head1:\n";
        if (exists $blat{$head}) {
            #print "EXISTS 1 $_";
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            my $ori_qual = $qual;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);
            my $out_qual1 =substr($ori_qual, 0, $min);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }

            # now choose if the read had indeed a splice-leader in it by looking at the out-take

            # or choose a primer if this is miRNAs with the NEB protocol
            if ( $new_seq =~/^AGATCGG/i ) {
                my $new_qual = substr($qual, $min, $len, $polyI );
                #$final{$head1}{$head}="$_$seq$mid$qual";
                $final{$head1}{$head}="$_$out_seq1\n$mid$out_qual1\n";
                $final2{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                print OUT5 "$_$new_seq\n$mid$new_qual\n";
                #print "$head1\t$head\t$_$out_seq1\n$mid$out_qual1\n";
            }
            else {
                print "This is not a real primer $new_seq \n";
            }
        }
        else {
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print "ELSE $_$seq$mid$qual";
        }

    }
}




while (<IN2>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1=~s/\/2$//;
        #print "File2:$head:$head1:\n";
        if (exists $blat{$head}) {
            #print "EXISTS 2 $_";
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            my $ori_qual = $qual;

            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);
            my $out_qual1 =substr($ori_qual, 0, $min);


            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }

            # now choose if the read had indeed a splice-leader in it by looking at the out-take

            # or choose a primer if this is miRNAs with the NEB protocol
            if ( $new_seq =~/^AGATCGG/i ) {
                my $new_qual = substr($qual, $min, $len, $polyI );
                #$final{$head1}{$head}="$_$seq$mid$qual";
                $final{$head1}{$head}="$_$out_seq1\n$mid$out_qual1\n";
                $final2{$head1}{$head}="$_$out_seq2\n$mid$out_qual2\n";
                print OUT6 "$_$new_seq\n$mid$new_qual\n";

                #print "$head1\t$head\t$_$out_seq1\n$mid$out_qual1\n";
            }
            else {
                print "This is not a real primer $new_seq \n";
            }
        }
        else {
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print "$_$seq$mid$qual";
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print OUT2 "$_$seq$mid$qual";
        }
        

    }
}



# now finally report the paired full output


open (OUT1, ">$fastq1.trimmed.fastq")|| die;
open (OUT2, ">$fastq2.trimmed.fastq")|| die;
open (OUT3, ">$fastq1.rubbished.fastq")|| die;
open (OUT4, ">$fastq2.rubbished.fastq")|| die;

foreach my $key (sort keys %final) {
    #print "$key\n";
    my $sca = scalar  keys %{$final{$key}};
    #print "$sca\n";
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";
        print OUT1 "$final{$key}{$first}";
        print OUT2 "$final{$key}{$second}";

    }
}


foreach my $key (sort keys %final2) {
    #print "$key\n";
    my $sca = scalar  keys %{$final2{$key}};
    #print "$sca\n";
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";
        print OUT3 "$final2{$key}{$first}";
        print OUT4 "$final2{$key}{$second}";

    }
}




close (IN1);
close (IN2);
close (OUT1);
close (OUT2);
close (OUT3);
close (OUT4);
close (OUT5);
close (OUT6);

#system "rm -f $fastq1.chosen.fastq $fastq2.chosen.fastq ";

__END__

TGCAGCTCAGGCTCTGCCTACGAGC
ACTCCTTCGAACACCA

TGGTGTTCGAAGGAGT
ACTCCTTCGAACACCA


>Emu.SL2c
GTTACCGATA
AATCGGTCCT
TACCTGCACT
TTTGTATGGT
GAGTATC

>SL
GATGCAGCTCAGGCTCTG CCTACGAG

CTGACAGTATTTGGCTGGTCCGACGAGGGCC


CGAAGATGTA
CTCGGCCTCG
TAGGCCTGCA
TCACTCCCGT
CCAGTTAGGC
CATGTCCAGC
CACTGGATTG
GTGTTCGAAG
GAGTACAGAA
AAACCTGACT

>SL
GATGCAGCTC  AGGCTCTG CCTACGAG

>fw reversed
GATGCAGG             CCTACGAG


>fw
       CTCGTAGGCCTGCA TC

>rev
TGGTGTTCGAAGGA GT

AC TCCTTCGAACACCA

