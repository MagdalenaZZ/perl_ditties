#!/usr/bin/perl -w

use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: alternative_splice-forms.pl gff-file file.junc read_cutoff

'}

my $genes = shift;
my $file = shift;
my $cutoff = shift;

print "perl ~mz3/bin/perl/junctions2introns.pl $file $cutoff\n";
print "perl ~mz3/bin/perl/gff_overlap_finder.pl $file.gff\n";
print "perl ~mz3/bin/perl/gff_make_all_splice_forms.pl $genes $file.gff.stats\n";










