#!/usr/bin/perl -w
use strict;
use Getopt::Std;
use Getopt::Long;

my %opts;

unless (@ARGV) {
        &USAGE;
}
 getopts('hi:o:', \%opts);

&USAGE if $opts{h};
my $name = "";
my $out = "";
if ($opts{i}) {
	$name = $opts{i};
	open IN, "$name" || die "I can't open $name\n";
} else {
	die "No input\n";
}
if ($opts{o}) {
	$out = $opts{o};
	if (-e "$out") {
		die "$out already exists!!!\n";
	} else {
		open OUT, ">$out" || die "I can't write to $out\n";
	}
} else {
	die "No output file defined\n";
}

sub USAGE {

die 'Usage: Illumina2abyss.pl -i infile.fastq -o output.fastq
	-i: Illumina fastq file
	-o: output file
'
}

#my $name = "$ARGV[1]";
#my $name = $opts{i};
# print "$name and $nameother"; <STDIN>;
my @name2 = split (/[\_\.]/, $name);
# print "$name2[0]\n";<STDIN>;
# print "$name2[2]\n";<STDIN>;
my $count =1;
while (<IN>) {
        chomp;
s/^\@IL42_/aby/;

if ($name2[2] == 1 ) {

if ($_ =~m/(^aby\d*1)/) {
# print $_; <STDIN>;
tr/:/1/;
tr/\//1/;
s/^aby\d+/aby$count\_F/g;
$count++;
# print "mine\n";
}
}

elsif ($name2[2] == 2 ) {
if ($_ =~m/(^aby\d*1)/) {
# print $_; <STDIN>;
tr/:/1/;
tr/\//1/;
s/^aby\d+/aby$count\_R/g;
$count++;
# print "thine\n";
}

}
s/^aby/\@$name2[0]x/;

 print OUT;
 print OUT "\n";
 }

close (IN);
close (OUT);

 __END__

