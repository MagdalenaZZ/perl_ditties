#!/usr/local/bin/perl -w

# mz3 script for correcting prot4EST nucleotide output file

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

my $fasta = shift;

system "fasta2singleLine.py $fasta $fasta.sl "; wait;

open (IN, "<$fasta.sl" );

#my @fasta = <IN>;
my %fas;
#my $head;

while  ( <IN> ) {

# filter headers

	if ($_ =~ m/>/) {
        my $head = $_;
        my $seq = <IN> ;
        chomp $head;
        chomp $seq;
        #       print "$head\t$seq\n";
        $fas{$head} = "$seq";
    }
	else {
        print "WARN: unparsed line $_";
	}

}

close (IN);
open (OUT, ">$fasta.protcoding.fas");
open (OUT2, ">$fasta.noncoding.fas");



foreach my $key (keys %fas) {
#    print "$key\n";

    $fas{$key} =~ tr/X/N/;

#    Determine if the sequence is coding or non-coding and take out weird text
    my $line = $fas{$key};
    	$line =~ tr/GgCcAaTtNnXx/ /;
#    print "$line\n";
    if ($line=~/\w/) {
#        print "Has word: $line\n";
        my @arr = split (/Nodefinitionlinefound/,$fas{$key});
#        print "$arr[0]\t$arr[1]\n";

        print OUT2 "$key\n$arr[1]\n";
    }
    else {
#        print "No word: $line\n";
        print OUT "$key\n$fas{$key}\n";        
    }
    


}

close (OUT);
close (OUT2);




