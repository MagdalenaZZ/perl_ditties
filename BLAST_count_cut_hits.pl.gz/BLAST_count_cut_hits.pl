#!/usr/bin/perl -w

use strict;


unless (@ARGV == 2) {
        &USAGE;
}



sub USAGE {

die 'Usage: BLAST_count_cut_hits.pl BLASTinput outputname

Takes a set of BLAST-scores and retrieves interesting information



'
}


# Read in a BLAST-file
	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);
	open (OUT, ">$out") || die "I can't open $out\n";

my %hash;
my %hashu;
my $index=0;
# Make a hash with {gene}{hit}{number}

foreach my $line (@in) {
	chomp $line;
	my @arr=split(/\s+/, $line);
	my $query = $arr[0];
	shift @arr;
	my $hit = $arr[0];
	shift @arr;
		my $arr2=join("\t",@arr);
	$hash{$query}{$hit}{$arr2}=1;
#	print "$query\n";
	unless (exists $hashu{$query}) {
		$hashu{$query}="$hit\t$arr2";
	}

$index++;	
}


my $hits = 0;

$hits= scalar keys %hash;  # method 1: explicit scalar context

foreach my $query (keys %hash) {
	my $count = scalar keys %{$hash{$query}};
#	 print "$query\t$count\n";

}

foreach my $query (keys %hashu) {
#	my $count = scalar keys %{$hash{$query}};
	 print OUT "$query\t$hashu{$query}\n";

}


print "There are a total of $index BLAST-hits\n";
print "There are a total of :  " . keys(%hash) . " sequences which have a BLAST-hit\n";
print "There are a total of :  " . $hits .  " hits\n";

# scalar();

# I want to be able to pick the no1 best hit from each search
# write that to a new file:


close (OUT);