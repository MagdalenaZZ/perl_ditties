#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 1 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: transcript_bundler.pl <transcripts.fa>

Takes a file with alternative transcripts, bundles all belonging to the same locus; i.e. Locus_X.1 Locus_X.2 ...

Writes a new fasta-file for each one, and does alignemnt on that

'
}


my $fasta = shift;

# Read fasta in and put in hash

my %h;
my %hsing;


    open (FAS, "<$fasta") || die "I can't open $fasta\n";
    
    
    while (<FAS>) {
            chomp $_;
            if ($_=~m/\>/) {
                $_=~s/\>//;
                my $head = $_;
                my $seq = <FAS>;
                chomp $seq;

                my @arr = split(/_/, $head);

#                print "$arr[0]_$arr[1]\t$head\t$seq\n";
                my $key1 =  "$arr[0]_$arr[1]"; 
#                chomp $key1;
                my @arr2 = split(/_/, $head);
                
#                print join(" ", @arr2);
#                $head = "$arr2[3]_$arr2[7]_$arr2[5]";
                $head = "$arr2[3]_$arr2[5]";
#                print "\n";

    if ( $arr2[3] =~/^1\/1$/ ) {
                $hsing{ $key1 }{ $head } = $seq;
#                print "Im single: $key1\n";
            }

    else {
                $h{ $key1 }{ $head } = $seq;
    }

            }
        }

#__END__

# Print each locus-file

mkdir "Locus_$fasta";
chdir "Locus_$fasta";

my @files;

foreach my $key ( keys %h ) {

#    print "$key\n";

     open (FH, ">$key.fas") || die "I can't open $key.fas\n";

    push (@files, "$key.fas");

    foreach my $head (sort keys %{$h{$key}} ) {
        print FH ">$head\n$h{$key}{$head}\n";
    }

    close (FH);

}



# Align each locus-file

foreach my $infile ( @files ) {

    print "perl ~mz3/bin/perl/phylogenize_me.pl $infile nuc aln\n";

    system "perl ~mz3/bin/perl/phylogenize_me.pl $infile nuc aln";

}


