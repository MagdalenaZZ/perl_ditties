#!/usr/local/bin/perl -w

use strict;

### THE INPUT ###
#Hym_2000largest artemis CDS     60777175        60777465        .       +	0       ID=KOG0935.62
#Hym_2000largest artemis CDS     60777499        60777636        .       +	0       ID=KOG0935.62
#Hym_2000largest artemis CDS     60777688        60777732        .       +	0       ID=KOG0935.62
#Hym_2000largest artemis CDS     1257244 1257606 .       -       0       ID=KOG0373.3
#Hym_2000largest artemis CDS     1256906 1257199 .       -       0       ID=KOG0373.3
#Hym_2000largest artemis CDS     1255571 1255831 .       -       0       ID=KOG0373.3
my %cds;
my $prevkey = "";
my $count = 1;
my $file = $ARGV[0];
chomp $file;
my $tags = `awk '{print \$9}' $file | uniq`;
#print $tags; <STDIN>;
my @order = split (/\n/, $tags);
while (<>) {
	chomp;
	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $key = $line[8];
	($start, $end) = sort {$a <=> $b} ($start, $end);
	my $newline = "$name\t$method\tCDS\t$start\t$end\t$score\t$strand";
	push (@{$cds{$key}}, $newline);
}

foreach my $key (keys %cds) {
	#print "i'm in key $key"; <STDIN>;
	my @recoverline = split (/\s+/, ${$cds{$key}}[0]);
	my $strand = $recoverline[6];
	my @newarray;
	if ($strand eq "-") {
		@{$cds{$key}} = reverse @{$cds{$key}};
	}
}

foreach my $again (@order) {
	if ($again =~ /ID=/) {
		my $lastelem = (scalar @{$cds{$again}})-1;
		my $name = (split /\s+/, ${$cds{$again}}[0])[0];
		my $strand = (split /\s+/, ${$cds{$again}}[0])[6];
		my $method = (split /\s+/, ${$cds{$again}}[0])[1];
		my $first = (split /\s+/, ${$cds{$again}}[0])[3];
		my $last = (split /\s+/, ${$cds{$again}}[$lastelem])[4];
		my $range = "$first\t$last";
		print "$name\t$method\tgene\t$range\t.\t$strand\t.\t$again;\n"; #<STDIN>;
		my $tag = (split /\=/, $again)[1];
		print "$name\t$method\tmRNA\t$range\t.\t$strand\t.\tID=$tag.1;Parent=$tag;\n"; #<STDIN>;
		my $count = 1;
		foreach my $lines (@{$cds{$again}}) {
			print "$lines\t.\tID=$tag.1:exon:$count;Parent=$tag;\n"; #<STDIN>;
			$count++;
		}
	} else {
		print "weird tag $again\n";
	}
}

