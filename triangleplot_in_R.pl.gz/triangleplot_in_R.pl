#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: triangleplot_in_R.pl file


This program takes a file with a column with numbers and draws a triangle plot


Example file:
ID	Test1	Test2	Test3	Levels
Gene1	12	12	14	A
Gene2	10	23	32.3	B
Gene3	1	1	1	A
Gene4	10	10	16	B




    ' . "\n";
}

my $pch = 14;


my $file = shift;

open (R, ">$file.R") || die "I can't open $file.R\n";
#open (OUT, ">$files[0].out") || die "I can't open $files[0].out\n";



# make the file to print to

#print R "file = \"$files[0]\.histo\.pdf\"";
print R "pdf(\"$file\.triangle\.pdf\", useDingbats=FALSE)\n";

print R '
mfrow = c(1,1)
';

print R '
require("vcd")
';

print R "read.table(\"$file\", header=TRUE)->simresult \n";  #This loads our data from a tab delimited file
print R "attach(simresult)\ncolors <- as.numeric(Levels)\n";

print R '
pch <- rep(20,nlevels(Levels))               # making pch

ternaryplot(                                                  #This is the actual plotting of our data
  simresult[,2:4],                                          #Here I provide the file and columns to plot
  pch = 20,                                                     #This is choosing the shape of data points (simple circl here)
  cex = .5,                                                       #This is the size of the data points
  col = colors,               #Telling it to color the points
  main = "3-State Model"                  #Provides a title for the graph
  )
  #  colors
  grid_legend(0.8, 0.9, pch , palette(), levels(Levels))
  dev.off()
';


close(R);









