#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

#unless (@ARGV==1) {
#        &USAGE;
#}


sub USAGE {

die 'Usage: gff_sorter.pl

'
}



my $table =[

["aa", "cc", "b"],
["cc", "dd", "ye"],
["dd", "cc", "hoho"],
["dd", "aa", "tq"],
["aa", "cc", "a"]
];


#	my $in = shift;

#	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;
#	close (IN);


    my(@AoA, @tmp);
    while (@in) {
        @tmp = split;
        push @AoA, [ @tmp ];
    }


__END__

 my @sorted_table = sort tableSorter @$table;

 print Dumper(@sorted_table);


#########################################

 sub tableSorter ($$) {
     my($row1, $row2) = @_;
     
     my $column1comparison = $row1->[2] cmp $row2->[2];
     if($column1comparison != 0){
         return $column1comparison;
     }
     
     my $column2comparison = $row1->[1] cmp $row2->[1];
     if($column2comparison != 0){
         return $column2comparison;
     }
  
     return $row1->[0] cmp $row2->[0];
 }