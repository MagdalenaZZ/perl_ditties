#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

    die '


Usage: velvet_transcriptome_align.pl transcripts.fa prefix

    
    ' . "\n";
}


my $fasta = shift;

my $prefix = shift;

mkdir "$prefix";

system "fasta2singleLine.py $fasta $fasta.sl";

open (IN, "<$fasta.sl");


my %h;

while (<IN>) {
chomp;

    if ($_=~'>') {
	my $head = $_;
    my $seq = <IN>;
    my @arr = split(/\_/,$head);
    $arr[0]=~s/\>//;
    $head=~s/_Transcript//;
    #print "$arr[0]_$arr[1]\n";
    #print "$head\t$seq\n";
    $h{ "$arr[0]_$arr[1]" }{$head} = $seq;
	}

}

# write output files
chdir  "$prefix";

open (OUT2, ">$prefix.singles.sl");

foreach my $locus (sort keys %h) {
    print "$locus\t"; 
    print scalar(keys %{$h{$locus}}) . "\n"; 
    if ( scalar(keys %{$h{$locus}}) > 1 ) { 
        #print "IF\n";
        open (OUT, ">$prefix.$locus.sl");
        foreach my $trans (sort keys %{$h{$locus}}) {
            print OUT "$trans\n$h{$locus}{$trans}";
        }
    }
    else {
        #print "ELSE\n";
        foreach my $trans (sort keys %{$h{$locus}}) {
            print OUT2 "$trans\n$h{$locus}{$trans}";
        }
        
    }

    close OUT;
    # do phylogeny

}

close OUT2;

exit;



