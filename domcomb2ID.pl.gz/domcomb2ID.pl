#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: domcomb2ID.pl dom-comb.tab  product-names.nm

Takes a list like this:

dom1,dom2,dom4   <TAB>   species1_0004   <TAB>   species2_0002  <TAB>   species5_0006 
dom1,dom2  <TAB>   species1_0001   <TAB>   species1_0002 

and a list of product names for those genes:


ID=species1_0004   <TAB>   /product="kinase"
ID=species2_0002   <TAB>   /product="ubiquitin"


And retrieves them all and chooses a best composite name for that domain-combinations

Such lists can be made using domain_combination_cluster.pl followed by tab_list_co-ordinator.pl


'
}

# Take the infile and get all the IDs


my $table = shift;
my $prod = shift;


        open (IN, "<$table") || die "I can't open $table\n";
    	my @table= <IN>;
    	close (IN);
        
        open (IN3, "<$prod") || die "I can't open $prod\n";
    	my @prods= <IN3>;
    	close (IN3);

# put the dom-combs in a hash

my %h;

foreach my $line (@table) {
chomp $line;

    my @arr = split (/\t/,$line);
    my $doms = shift(@arr);

    foreach my $elem (@arr) {
        if ($elem=~/\w+_\w+/ ) {
            my @arr4= split(/\,/, $elem);
            foreach my $lin4 ( @arr4) {
                if ($lin4=~/\w+_\w+/) {
                    $lin4=~s/,//;
                    $lin4=~s/\.\d+\.\.pep//;
                    $lin4=~s/.1.\{pep\}//;
                    $h{$doms}{$lin4}{"0"}=1;
                    # print "DOMS:$lin4\n";
                }
            }
        }
    }
}


print "Finished reading in domain-combinations\n";

# add the products to genes that have them

open (OUT, ">$table.prod") || die "I can't open $table.prod\n";
open (OUT2, ">$table.err") || die "I can't open $table.err\n";


print "Reading products\n";


foreach my $lin2 (@prods) {
    chomp $lin2;
   my @arr2 = split (/\t/, $lin2);
   $arr2[0]=~s/^ID=//;
   push (@arr2, " ");
   my $test = 0;
#    print "LIN2:$lin2\n";
   foreach my $key ( keys %h) {
        if ( exists $h{$key}{$arr2[0]} and $arr2[1]=~/\w+/ ) {
            print OUT "$key\t$arr2[0]\t$arr2[1]\n";
                $h{$key}{$arr2[0]}{$arr2[1]}+=1;
                $test++;
        }
        else {
        }
   }
   if ($test=~/^0$/) {
        print OUT2 "No match for: $lin2\n";
   }
}

close (OUT);
close (OUT2);

my %dh;

# split results into domains

foreach my $dc ( %h ) {
    my @arr5 = split (/\,/, $dc);

    foreach my $ele (@arr5) {
        foreach my $key ( keys %{$h{$dc}}  ) {
            foreach my $key2 ( keys %{ $h{$dc}{$key}  } ) {
                $dh{$ele}{ "$dc\t$key"}{$key2}+=1;
            }    
        }
    }
}

# print output

open (OUT3, ">$table.doms") || die "I can't open $table.doms\n";

foreach my $doms1 ( keys %dh ) {
    foreach my $doms2 ( keys %{$dh{$doms1}} ) {
        foreach my $doms3 ( keys %{$dh{$doms1}{$doms2}} ) {
                print OUT3 "$doms1\t$doms2\t$doms3\t$dh{$doms1}{$doms2}{$doms3}\n";
        }
    }  
}






close (OUT3);


__END__

# print output
#
foreach my $domco ( sort keys %h) {

    foreach my $domco ( sort keys %h) {
            foreach my $domco ( sort keys %h) {
        }

    }


}


