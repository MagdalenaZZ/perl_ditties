#!/usr/local/bin/perl -w
#
# Take biological replicates for each of two conditions and determine differentially
# expressed genes. Allows normalise within conditions and use of different expression
# metrics.
#
use strict;
use Getopt::Long;

my $help;
my $outdir = 'out';
#my $analyse_express_script = '/nfs/users/nfs_a/ar11/scripts/analyse_express.pl';
my $analyse_express_script = '~mz3/bin/perl/analyse_express.pl';

my $r_prog = "R-3.0.0";

# Genes must be at least this unique to enter analysis
# q-value cutoffs for DE results
#my $lib_cut = 1e-5;
my $lib_cut = 0.05;

my $cons_cut = 1e-20;
my $top_exp_cut = 20;

my $use_read_counts = 1;
my $use_rpkm = 0;
my $use_lennorm_read_counts = 0;

my $ann_file = '';

my $normalise_reps = 0;

GetOptions
(
	"h|help"	=> \$help,
	"o|outdir:s"	=> \$outdir,
	"a|ann:s"	=> \$ann_file,
	"n"		=> \$normalise_reps,	
	"r|use_rpkm"	=> \$use_rpkm,
	"l|use_lennorm"	=> \$use_lennorm_read_counts,
	"lib_cut:f"	=> \$lib_cut,
	"cons_cut:f"	=> \$cons_cut,
	"t|top:i"	=> \$top_exp_cut
);

if($help)
{
	print_usage();
	exit;
}

my($a_files, $b_files, $cond1, $cond2) = @ARGV;

if(!defined $cond2)
{
	print_usage("Missing arguments!\n");
	exit;
}
else
{
	print STDERR "Running with: $a_files, $b_files, $cond1, $cond2\n";
}

my $f = 0.1;
my $input_file = 'input.dat';
my $logged_file = 'logged_input.dat';
my $basevar_plot = 'basevar_plot.png';
my $ma_plot_cons = 'ma_cons.png';
my $ma_plot_lib = 'ma_lib.png';
my $deseq_scores = 'scores.dat';
my $cons_dat = 'cons.dat';
my $lib_dat = 'lib.dat';
my $norm1_png = $cond1.'_norm.png';
my $norm2_png = $cond2.'_norm.png';
my $deseq_input = 'deseq.input';
my $html_out = 'out.html';
my $log_file = 'log.txt';
my $top_exp_file = 'top_exp.dat';

my $ma_file = 'ma.dat';

if(!-e $outdir)
{
	mkdir $outdir;
}

open(LOG, ">$outdir/$log_file") or die "$!";

# Get annotation (Not working at the moment)
my ($desc, $go);

if(defined $ann_file && $ann_file ne '')
{
	($desc, $go) = get_ann($ann_file);
}

# Extract data from expression files
my($exp_dat, $all_exp) = get_exp($a_files, $b_files);

# Create tabular file of expression values
open(OUT, ">$outdir/$input_file") or die "$!";
print "creating file $outdir/$input_file\n";

my @a_files = split ',', $a_files;
my @b_files = split ',', $b_files;

# Do we have reps of both? If not, can't do ecdf plot
my $full_reps = 0;
if(@a_files >= 2 && @b_files >=2)
{
	$full_reps = 1;
    print "We have full replicates\n";
}

my $file_head = join "\t", (@a_files, @b_files);

print OUT "gene\t$file_head\n";
print "gene\t$file_head\n";

my @a_dat;
my @b_dat;

my $c = 0;

my @conds = ();

for(0..scalar @a_files - 1)
{
	push @a_dat, $exp_dat->[$c];

	push @conds, $cond1;

	$c++;
}
for(0..scalar @b_files - 1)
{
	push @b_dat, $exp_dat->[$c];

	push @conds, $cond2;

	$c++;
}

foreach my $id (sort keys %$all_exp)
{
	foreach my $dat (@a_dat)
	{
		$dat->{$id} = 0 if !exists $dat->{$id};
	}
	foreach my $dat (@b_dat)
	{
		$dat->{$id} = 0 if !exists $dat->{$id};
	}

	my @vals = ();
	foreach (@a_dat)
	{
		push @vals, $_->{$id};
	}
	foreach (@b_dat)
	{
		push @vals, $_->{$id};
	}
	
	my $vals = join "\t", @vals;

	print OUT "$id\t$vals\n";
}
close OUT;

# Log input data for drawing plots and normalisation
log_data("$outdir/$input_file", "$outdir/$logged_file");

# Plot all pairwise correlations
#pairwise_cor("$outdir/$logged_file", @a_files, @b_files);

if($normalise_reps)
{
	# Normalise the first replicates
	my $old_plot = get_cols("$outdir/$input_file", 2, 3);
	my $ma = generate_ma_data($old_plot);
	my $norm = normalise($ma);
	my($lowess_x, $lowess_y) = get_lowess_line($old_plot);
	plot_norm($old_plot, $norm, $lowess_x, $lowess_y, $norm1_png);
	my $first_file = 'round1.out';
	print_new("$outdir/$input_file", "$outdir/$first_file", $norm, 2, 3);


	# Normalise second replicates
	$old_plot = get_cols("$outdir/$input_file", 4, 5);
	$ma = generate_ma_data($old_plot);
	$norm = normalise($ma);
	($lowess_x, $lowess_y) = get_lowess_line($old_plot);
	plot_norm($old_plot, $norm, $lowess_x, $lowess_y, $norm2_png);
	my $second_file = 'round2.out';
	print_new("$outdir/$first_file", "$outdir/$second_file", $norm, 4, 5);

	delog("$outdir/$second_file", "$outdir/$deseq_input");
}
else
{
	system("cp $outdir/$input_file $outdir/$deseq_input") == 0 or die "$!";
}

runDESeq("$outdir/$deseq_input", \@conds);

analyseDESeq();

printHTML("$outdir/$html_out");

close LOG;

sub printHTML
{
	my($outfile) = shift;

	my $cor_file = $logged_file.'_cor.png';

	open(OUT, ">$outfile") or die "$!";

	print OUT <<HTML;

<table border="0">

<tr>
<td><img src="$cor_file"/></td>
</tr>

<tr>
<table>
<tr>
<td><img src="$norm1_png"/></td>
<td><img src="$norm2_png"/></td>
</tr>
</table>
</tr>

<tr>
<table>
<tr>
<td><img src="$ma_plot_cons"/></td>
<td><img src="$ma_plot_lib"/></td>
</tr>
</table>
</tr>
</table>

HTML

}

sub analyseDESeq
{
	open(IN, "<$outdir/$deseq_scores") or die "Havent written file $outdir/$deseq_scores $!";

	my $up_cons = 0;
	my $down_cons = 0;
	my $up_lib = 0;
	my $down_lib = 0;

	while(<IN>)
	{
		chomp;

		next if /^\"id/;

		my($row, $fields) = split /\" \"/;

		my($id, $rest) = split /\" /, $fields;

		my @fields = split " ", $rest;
		
		@fields = ($id, @fields);

		$fields[0] =~ s/\"//;
		$fields[-1] =~ s/\"//;

		next if !defined $fields[7] || $fields[7] eq 'NA';

		if($fields[7] <= $cons_cut)
		{
			if($fields[4] < 1)
			{
				$down_lib++;
				$down_cons++;
			}
			if($fields[4] >= 1)
			{
				$up_lib++;
				$up_cons++;
			}
		}
		elsif($fields[7] <= $lib_cut)
		{
			if($fields[4] < 1)
			{
				$down_lib++;
			}
			if($fields[4] >= 1)
			{
				$up_lib++;
			}
		}
	}
	close IN;

	print LOG "Conservative cut $cons_cut: $up_cons UP, $down_cons DOWN\nLiberal cut $lib_cut: $up_lib UP, $down_lib DOWN\n";

	if($ann_file && $ann_file ne '')
	{
        system("$analyse_express_script $outdir/$deseq_scores $ann_file $cons_cut > $outdir/$cons_dat") == 0 or die "$!";
		system("$analyse_express_script $outdir/$deseq_scores $ann_file $lib_cut > $outdir/$lib_dat") == 0 or die "$!";
	}
}

sub runDESeq
{
	my($dat_file, $conds) = @_;

	my $cond_string = join "\",\"", @$conds;

	# Need to set this if there are no replicates
	my $pool_string = '';

	if(scalar @$conds == 2)
	{
		$pool_string = ',method="blind", sharingMode="fit-only"';
	}

	open(OUT, ">$outdir/temp.R") or die "$!";

	print OUT <<R_CODE;

    #library(DESeq, lib.loc="~ar11/R/library/")
    library(DESeq)
	countsTable <- read.delim("$dat_file", header=TRUE, stringsAsFactors=TRUE)
	rownames(countsTable) <- countsTable\$gene
	countsTable <- countsTable[ , -1]
	conds <- c("$cond_string")
	cds <- newCountDataSet(countsTable, conds)

    cds <- estimateSizeFactors(cds)


	sizeFactors(cds)
    cds <- estimateDispersions(cds $pool_string, fitType="local")
    cds <- estimateDispersions(cds $pool_string)

R_CODE

	#if($full_reps)
	#{
#
#		print OUT "png(\"$outdir/$ecdf_plot\", width=900, height=450)\n" .
#			  "par(mfrow=c(1,2))\n" .
#			 "residualsEcdfPlot(cds, \"$cond1\")\n" .
#			  "residualsEcdfPlot(cds, \"$cond2\")\n";
#	}

	print OUT <<R_CODE;

	res <- nbinomTest(cds, "$cond1", "$cond2")
	write.table(res, "$outdir/$deseq_scores")
	png("$outdir/$ma_plot_cons")
	plot(res\$baseMean, res\$log2FoldChange, log="x", col=ifelse(res\$padj < $cons_cut, "red", "black"))
	png("$outdir/$ma_plot_lib")
	plot(res\$baseMean, res\$log2FoldChange, log="x", col=ifelse(res\$padj < $lib_cut, "red", "black"))

R_CODE

	close OUT;

	my @result = `$r_prog --no-save < $outdir/temp.R`;

	# Print replative library sizes to log
	my $print_flag = 0;

	print LOG "Size Factors:\n";
	
	foreach my $line (@result)
	{
		if($print_flag == 1 && $line =~ /^>/)
		{
			last;
		}
		elsif($line =~ /sizeFactors\(cds\)/)
		{
			$print_flag = 1;
		}
		elsif($print_flag == 1)
		{
			print LOG "$line";
		}
	}
	print LOG "\n";
}

sub get_ann
{
	my($file) = @_;

	my %desc = ();
	my %go = ();

	open(F, "<$file") or die "Cant find annotation file $file $!";

	while(<F>)
	{
		chomp;

		my($gene, $desc, @go) = split /\t/;

		$desc{$gene} = $desc;

		if(defined $go[0])
		{
			$go{$gene} = \@go;
		}
	}
	close F;

	return(\%desc, \%go);
}

# Get normalised values in original format from normalised log values
sub delog
{
	my($file, $out_file) = @_;

	open(F, "<$file") or die "$!";

	open(OUT, ">$out_file") or die "$!";

	while(<F>)
	{
		chomp;
		my($id, @cols) = split /\t/;

		if($id eq 'gene')
		{
			my $heads = join "\t", @cols;
			print OUT "gene\t$heads\n"
		}
		else
		{
			my @new_cols = ();

			foreach my $col (@cols)
			{
				# Get exponent of logarithm (e.g. normalised RPKM)
				my $rpkm = int(2**$col);

				push @new_cols, $rpkm;
			}

			my $cols = join "\t", @new_cols;
			print OUT "$id\t$cols\n";
		}
	}
	close OUT;
	close F;
}

sub log_data
{
	my($file_in, $file_out) = @_;

	open(IN, "<$file_in") or die "$!";
	open(OUT, ">$file_out") or die "$!";

	while(<IN>)
	{
		chomp;
		my($id, @cols) = split /\t/;

		my @new_cols = ();

		if($id eq 'gene')
		{
		          print OUT "$_\n";
		}
		else
		{
			foreach my $col (@cols)
			{
				$col = log2($col + 1);

				push @new_cols, $col;
			}

			my $row = join "\t", @new_cols;
			print OUT "$id\t$row\n";
		}

	}

	close IN;
}

sub take_means
{
	my($file_in, $file_out) = @_;

	open(IN, "<$file_in") or die "Cant open infile $file_out $!";
	open(OUT, ">$file_out") or die "Cant open outfile $file_out $!";

	while(<IN>)
	{
		chomp;
		my($id, @cols) = split /\t/;

		my @means = ();

		if($id eq 'gene')
		{
			print OUT "gene\tCond1\tCond2\n";
		}
		else
		{
			for(my $i=0;$i<scalar @cols;$i+=2)
			{
				my $mean = ($cols[$i] + $cols[$i+1]) / 2;
				push @means, $mean;
			}

			my $cols = join "\t", @means;
			print OUT "$id\t$cols\n";
		}
	}
	close OUT;
	close IN;
}

sub print_new
{
	my($old_file, $new_file, $new_cols, $c1, $c2) = @_;

	open(OLD, "<$old_file") or die "$!";

	open(NEW, ">$new_file") or die "$!";

	while(<OLD>)
	{
		chomp;

		my($id, @cols) = split /\t/;

		my @new_cols = ();

		for(my $i=0;$i<scalar @cols;$i++)
		{
			if($i == ($c1 - 2))
			{
				push @new_cols, $new_cols->{$id}->[0];
			}
			elsif($i == ($c2 - 2))
			{
				push @new_cols, $new_cols->{$id}->[1];
			}
			else
			{
				push @new_cols, $cols[$i];
			}
		}

		my $dat = join "\t", @new_cols;
		print NEW "$id\t$dat\n";
	}
	close NEW;
	close OLD;
}

sub get_cols
{
	my($file, $c1, $c2) = @_;

	open(IN, "<$file") or die "$!";

	my %dat = ();

	while(<IN>)
	{
		chomp;

		#next if /^gene\s+/;

		my($id, @cols) = split /\t/;

		$dat{$id} = [$cols[$c1-2], $cols[$c2-2]];
	}
	close IN;

	return \%dat;
}

sub generate_ma_data
{
	my($dat) = @_;

	my %ma = ();

	foreach my $id (sort keys %$dat)
	{
		if($id eq 'gene')
		{
			$ma{$id} = [$dat->{$id}->[0], $dat->{$id}->[1]];
			next;
		}

		my $m = log2($dat->{$id}->[0] + 1) - log2($dat->{$id}->[1] + 1);
		my $a = ( log2($dat->{$id}->[0] + 1) + log2($dat->{$id}->[1] + 1)) / 2;

		$ma{$id} = [$m, $a];
	}
	return \%ma;
}

sub get_lowess_line
{
	my ($dat) = @_;

	open(OUT, ">$outdir/temp.dat") or die "$!";

	foreach my $id (sort keys %$dat)
	{
		next if $id eq 'gene';
		my $a1 = log2($dat->{$id}->[0] + 1);
		my $a2 = log2($dat->{$id}->[1] + 1);
		print OUT "$id\t$a1\t$a2\n";
	}
	close OUT;

	my $res = runR("temp  <- read.table(\"$outdir/temp.dat\", header=TRUE);lowess(temp[,2],temp[,3], f=$f);");

	my ($x, $y) = parse_R_twocol($res);

	return($x, $y);
}

sub normalise
{
	my ($ma) = @_;

	my %rpkm_norm = ();

	open(OUT, ">$outdir/$ma_file") or die "$!";

	foreach my $id (sort keys %$ma)
	{
		next if $id eq 'gene';

		print OUT "$id\t$ma->{$id}->[1]\t$ma->{$id}->[0]\n";
	}
	close OUT;

	my $res = runR("before <- read.table(\"$outdir/$ma_file\", header=FALSE);lowess(before[,2],before[,3], f=$f);");

	#print "$res\n";

	my($x, $y) = parse_R_twocol($res);

	foreach my $id (sort keys %$ma)
	{
		if($id eq 'gene')
		{
			$rpkm_norm{$id} = [$ma->{$id}->[0], $ma->{$id}->[1]];

			#print "$id\t$ma->{$id}->[0]\t$ma->{$id}->[1]\n";
		}
		else
		{
			my($M, $A) = @{$ma->{$id}};

			my $best_diff = 100;
			my $best_i = 0;

			for(my $i=0;$i<scalar @$x;$i++)
			{
				#print "$x->[$i]\t$y->[$i]\n";

				my $diff = abs($A - $x->[$i]);
	
				if($diff < $best_diff)
				{
					$best_diff = $diff;
					$best_i = $i;
				}
			}
	
			my $new_y = $M - $y->[$best_i];
	
			# Get normalised original values from logged, normalised values
			my $e1_val = ((2*$A) + $new_y) / 2;
			my $e2_val = ((2*$A) - $new_y) / 2;

			#print "$id\t$M\t$A\t$best_diff\t$best_i\t$new_y\t$e1_val\t$e2_val\n";

			$rpkm_norm{$id} = [$e1_val, $e2_val];
		}
	}

	return \%rpkm_norm;
}

sub plot_norm
{
	my($old_dat, $new_dat, $lowess_x, $lowess_y, $pngfile) = @_;

	my $normal_x = "-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15";

	open(OLD, ">$outdir/old.temp") or die "$!";
	foreach my $id (sort keys %$old_dat)
	{
		next if $id =~ /^gene/;

		my $a1 = log2($old_dat->{$id}->[0] + 1);
		my $a2 = log2($old_dat->{$id}->[1] + 1);
		print OLD "$id\t$a1\t$a2\n";
	}
	close OLD;

	open(NEW, ">$outdir/new.temp") or die "$!";
	foreach my $id (sort keys %$new_dat)
	{
		next if $id =~ /^gene/;

		print NEW "$id\t$new_dat->{$id}->[0]\t$new_dat->{$id}->[1]\n";
	}
	close NEW;

	if(defined $lowess_y)
	{
		open(LOW, ">$outdir/lowess.dat") or die "$!";

		for(my $i=0;$i<@$lowess_x;$i++)
		{
			print LOW "$lowess_x->[$i]\t$lowess_y->[$i]\n";
		}
		close LOW;
	}

	my $r_code = "before<-read.table(\"$outdir/old.temp\", header = TRUE);" .
	"after<-read.table(\"$outdir/new.temp\", header=TRUE);" .
	"normalx <- c($normal_x);" .
	"png(file=\"$outdir/$pngfile\");" .
	"plot(before[,2],before[,3],col=\"black\", xlab=\"Rep1\", ylab=\"Rep2\", xlim=c(0,20),ylim=c(0,20));" .
	"title(main=\"Lowess normalisation between replicates\");" .
	"par(new=T);" .
	"plot(after[,2],after[,3],col=\"red\", xlab=\"\", ylab=\"\", xlim=c(0,20),ylim=c(0,20));" .
	"par(new=T);" .
	"lines(normalx, normalx, col=\"yellow\", xlab=\"\", ylab=\"\",xlim=c(0,20),ylim=c(0,20));";

	if(defined $lowess_y)
	{
		$r_code .= "lowess<-read.table(\"$outdir/lowess.dat\");" .
		"par(new=T);" .
		"lines(lowess[,1],lowess[,2], col=\"green\", xlab=\"\", ylab=\"\", xlim=c(0,20),ylim=c(0,20));";
	}

	runR($r_code);

}

sub runR
{
	my $code = shift;

	 print STDERR "Running R with $code\n";

	open(R, ">$outdir/r.temp") or die "$!";

	print R $code;
	close R;

	my $res = `R --no-save < $outdir/r.temp`;

	#unlink "$outdir/r.temp";

	return $res;
}

sub get_exp
{
	my ($a, $b) = @_;

	my @results = ();

	my $c = 0;
	my %all = ();

	my @a_files = split ',', $a;
	my @b_files = split ',', $b;

	my @exp_files = (@a_files, @b_files);

	foreach my $file (@exp_files)
	{
		open(FILE, "<$file") or die "Cant find file $file\t $!";
        print "opening file $file\n";
		while(<FILE>)
		{
			chomp;
			next if /^Gene/;
            #print "US2 $_\n";	
			my(@a) = split /\t/;

			# Add 1 to all values so they can be logged
            #print "Us $a[0]\t$a[1]\n";
            $results[$c]->{$a[0]} = $a[1];

            $all{$a[0]} = 1;
		}
		close FILE;

		$c++;
	}

	return (\@results, \%all);
}

sub log2
{
	return log($_[0])/log(2);
}

sub pairwise_cor
{
	my($dataset, @dat) = @_;

	my $normal_x = "-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15";
	my $normal_y = "-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15";

	my $r_code = 
		"png(file=\"$dataset" . "_cor.png\");" .
		"par(mfrow=c(2,3));" .
		"x<-read.table(\"$dataset\", header=TRUE);" .
		"normalx <- c($normal_x);";

	my $j_max = scalar @dat+1;

	for(my $i=1;$i<scalar @dat;$i++)
	{
		for(my $j=$i+1;$j<$j_max;$j++)
		{
			my $label_index_x = $i - 2;
			my $label_index_y = $j - 2;

			$r_code .= "plot(x[,$i], x[,$j], xlab=\"$dat[$label_index_x]\", ylab=\"$dat[$label_index_y]\");";
	
			$r_code .= "lines(normalx, normalx, col=\"yellow\");";
		}
	}

	runR($r_code);
}

# Parse two-column R output
sub parse_R_twocol
{
	my $res = shift;

	my @res = split /\n/, $res;

	my $old_index = 0;
	my $y_flag = 0;

	my @x = ();
	my @y = ();

	#my $out_file = "norm_";

	#open(OUT, ">$out_file") or die "$!";

	foreach my $res (@res)
	{
		chomp $res;
		next unless $res =~ /\[(\d+)\] (.*)/;
		
		my $index = $1;
		my $vals = $2;
		
		if($index < $old_index)
		{
			$y_flag = 1;
		}

		my @vals = split /\s+/, $vals;

		foreach my $val (@vals)
		{
			next if $val =~ /^$/;

			if($y_flag)
			{
				push @y, $val;
			}
			else
			{
				push @x, $val;
			}
		}
	
		$old_index = $index;
	}

	return(\@x, \@y);
}

sub print_usage
{
	my $err_msg = shift;

	print <<USAGE;

	USAGE: [options] <A1,A2,..> <B1,B2,..> <cond1 label> <cond2 label>

	-h | -help		print this message
	-o | -outdir <s>	output directory [out]
###	-a | -ann <s>		Annotation file (ID<tab>Description<tab>GOtermid | GOtermtype | GOtermdesc)
	-n			normalise reps [F]	
	-r | -use_rpkm		use rpkm [raw read counts]
	-l | -use_lennorm	use lengh-normalised read counts [raw read counts]
	-lib_cut <f>		liberal DESeq q-value cutoff [1e-5]
	-cons_cut <f>		conservative DESeq-value cutoff [1e-20]
	-t | -top <i>		Record top n expressed genes in each condition

USAGE

	print "$err_msg\n" if defined $err_msg;
}
