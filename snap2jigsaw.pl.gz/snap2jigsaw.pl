#!/usr/local/bin/perl -w
#
use strict;

my($file) = @ARGV;

open(F, "<$file") or die "$!";

my $gene_name = '';
my %cds;
my $previous_str = '';
my $count = 0;

while(<F>)
{
	next if /^#/;

	my($element, $start, $end, $str, $score, $x, $y, $z, $att) = split /\t/;

	if($element eq 'Esngl')
	{
		if($str eq '-')
		{
			print "$count single $end $start $score\n";
		}
		else
		{
			print "$count single $start $end $score\n";
		}

		$count++;
	}
	if($element eq 'Eterm')
	{
		$cds{$start} = $end;

		my $el_count = 0;

		my @sorted_cds = ();

		@sorted_cds = sort {$a<=>$b} keys %cds;

		foreach my $begin (@sorted_cds)
		{
			my $type = '';

			if(($el_count == 0 && $previous_str eq '+') || ($el_count == (scalar keys %cds) -1 && $previous_str eq '-'))
			{
				$type = 'initial';
			}
			elsif(($el_count == (scalar keys %cds) -1 && $previous_str eq '+') || ($el_count == 0 && $previous_str eq '-'))
			{
				$type = 'terminal';
			}
			else
			{
				$type = 'internal';
			}

			if($previous_str eq '-')
			{
				print "$count $type $cds{$begin} $begin $score\n";
			}
			else
			{
				print "$count $type $begin $cds{$begin} $score\n";
			}

			$el_count++;
		}

		$gene_name = $att;
		%cds = ();
		$count++;
	}
	elsif($element eq 'Exon' || $element eq 'Einit')
	{
		$cds{$start} = $end;
		$previous_str = $str;
	}
}
close F;
