#!/usr/local/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: uniprot_retrieve.pl blast-output 

Assumes uniprot accessions in column 2


'
}


my $in = shift;

#=pod
open (IN, "<$in") || die;
my @ids = <IN>;

# http://www.uniprot.org/uniprot/Q6GZX4.fasta

if (-d "$in\_fas") {
    die "Folder $in\_fas exists, I wont over-write. Remove it and restart the job\n\n rm -fr  $in\_fas \n\n ";
}

mkdir "$in\_fas";
chdir   "$in\_fas";


my %up;
my %uid;

# link gene and uniprot ID 

foreach my $id (@ids) {
    my @arr = split(/\s+/, $id);
    $id = $arr[1];
    chomp $id;
    my @first = split(/\./, $id);
    $up{$arr[0]}{$first[0]}=1;
    $uid{$first[0]}=1;
}

# now get the unique sequences and merge them

foreach my $i (keys %uid) {
    system " wget \"http://www.uniprot.org/uniprot/$i.fasta\"";
    #print " wget \"http://www.uniprot.org/uniprot/$i.fasta\"\n";
    sleep (0.5);
}

#=cut




system "cat *.fasta > $in.all.fas";
#system "rm -f *.fasta";


# parse the output

open (FAS, "<$in.all.fas") || die;

my %pro;

while (<FAS>) {
    
    if ($_=~/^>/) {
        my @arr = split(/OS=/, $_);
        $arr[0] =~s/ /|/;
        my @arr2 = split(/\|/, $arr[0]);
        $arr2[3]=~s/ $//;
        my $prod = "$arr2[1]\t\"$arr2[3]\"";
        $pro{$arr2[1]}="\"$arr2[3]\"";   
    }
}
chdir  "..";


# print output

open (OUT, ">$in.prod") || die;

foreach my $gene (sort keys  %up ) {
    foreach my $pr (sort keys  %{$up{$gene}} ) {

        print OUT "$gene\t$pro{$pr}\n";
    }
}

close (OUT);






__END__


###### using the java api ###################

# Getting entries for a list of accession numbers
# It is also possible to supply a list of protein identifiers.
  
print '

    // Create UniProt query service
    UniProtQueryService uniProtQueryService = UniProtJAPI.factory.getUniProtQueryService();
    
    //Create a list of accession numbers (both primary and seconday are acceptable)
    List<String> accList = new ArrayList<String>();
'


foreach my $id ($ids) {
#    accList.add("O60243");
#    accList.add("Q8IZP7");
#    accList.add("P02070");
    print "accList.add("$id");";
}

print '
    //Isoform IDs are acceptable as well 
    accList.add("Q4R572-1");
    //as well as entry IDs 
    accList.add("14310_ARATH");
    
    Query query = UniProtQueryBuilder.buildIDListQuery(accList);
    
    EntryIterator<UniProtEntry> entries = uniProtQueryService.getEntryIterator(query);
    for (UniProtEntry entry : entries) {
        System.out.println("entry.getUniProtId() = " + entry.getUniProtId());
    }
    

'


