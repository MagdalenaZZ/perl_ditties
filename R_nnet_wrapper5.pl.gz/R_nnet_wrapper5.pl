#!/usr/bin/perl -w
#
#
#if (@ARGV < 2 ) {
#    print "\nUsage: R_nnet_wrapper.pl Eset signal training-set Size-range Decay-range\n\n\n" ;
#
#        print "\nExample: R_nnet_wrapper.pl myv_COMBAT tmpsig 1412:1442 20,30,5 20:3  \n\n\n" ;
#            #print "\nExample: R_nnet_wrapper.pl myv_COMBAT tmpsig Celltype~. 1412:1442 20,30,5 20:3  \n\n\n" ;
#
#                print "\nEset = an R expressionset object e.g. es.RData only type es. The name of the es is expected to be the same as \n" ;
#                    print "\nsignal = a list with gene names of genes that should be used (same as in eset) \n" ;
#                        print "\nTraining set columns in data set (the others are expected to be the test-set)\n\n\n" ;
#                            print "\nNeural network optimisation paramenters\n" ;
#                                print "\nSize-range is from 20 to 30, in intervals of 5 \n\n\n" ;
#                                    print "\nDecay-range is from 2^-20 to 2^-3 \n\n\n" ;
#
#                                            exit;
#                                            }
#
#
#
#
#                                            # Input
#                                            #
#                                            my $eset= shift; # Expression set
#                                            my $signal=shift; # List of signal genes
#                                            #$model=shift;
#                                            my $tt=shift;
#                                            my $sr=shift;
#                                            my $sr2=$sr;
#                                            $sr=~s/\,/_/g;
#                                            my $dr= shift;
#
#                                            #$ts=shift; # Training set
#                                            #$num= shift;
#
#                                            open (R, ">$eset.$signal.$sr.$dr.R") || die "I can't open $eset.$signal.$sr.$dr.R\n";
#
