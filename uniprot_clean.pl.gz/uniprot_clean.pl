#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: in out

Give a list of gene-names and product description
This program filters the list


'
}


	my $in = shift;

	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">filtered.out2") || die "I can't open filtered.out2\n";

foreach my $line (@in) {
chomp $line;
my @line = split (/\t/, $line);

    $line[1]=~s/ /_/g;
    $line[1]=~s/"//g;

#	print ":$line[0]:\t\t:$line[1]:\n";

	$line[1] =~ s/_\(Fragment\)//;
	$line[1] =~ s/,_putative//;
	$line[1] =~ s/Putative_uncharacterized_protein_//;
	$line[1] =~ s/Putative_uncharacterized_protein_//;
	$line[1] =~ s/Putative_//i;
	$line[1] =~ s/-like_protein//i;
	$line[1] =~ s/,_X-linked//i;

#	$line[1] =~ s/similar_to_//i;
#	$line[1] =~ s/Similar_to_//;
#	$line[1] =~ s/Similarity_to_//;
#


	$line[1] =~ s/Putative_uncharacterized_protein/ / ; 

	if ($line[1] =~/[A-Z]+_[A-Z]+_[A-Z]+/) {
		$line[1] =~ tr/A-Z/a-z/;
		$line[1] =~ s/low_quality_protein:_//; 
	}

	if ($line[1] =~/^Uncharacterized_protein/i) {
		if ($line[1] =~/involved/) {
			print OUT "$line[0]\t/product=\"$line[1]\"\n";
		}
		else {
			print OUT2 "mz3:Uncharacterized_protein:\t\t\t$line[1]\n";
			print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
            next;

		}
	}
	elsif ($line[1] =~/^Putative_uncharacterized_protein$/) {
		print OUT2 "mz3:pup2:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
        next;

	}
	elsif ($line[1] =~/^ $/) {
		print OUT2 "mz3:blank:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
        next;
	}

#save some genes
	elsif ($line[1] =~/^VP\d+/) {
		print OUT "$line[0]\t/product=\"$line[1]\"\n";
	}
	elsif ($line[1] =~/^AC\d+$/) {
		print OUT "$line[0]\t/product=\"adenylyl_cyclase_($line[1])\"\n";
	}
	elsif ($line[1] =~/^RAG\d+$/) {
		print OUT "$line[0]\t/product=\"recombination_activating_gene($line[1])\"\n";	
	}
	elsif ($line[1] =~/^P\d+$/) {
		print OUT "$line[0]\t/product=\"$line[1]\"\n";
	}
	elsif ($line[1] =~/^Gp\d+$/) {
		print OUT "$line[0]\t/product=\"Glycoprotein_$line[1]\"\n";
	}
#remove others

	elsif ($line[1] =~/^hypothetical_protein$/) {
		print OUT2 "mz3:MGF:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/domain/) {
		print OUT2 "mz3:domain:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/^Similar_to/) {
		print OUT2 "mz3:sim1:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ( $line[1] =~/^similar_to/ ) {
		print OUT2 "mz3:sim2:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ( $line[1] =~/^Similarity_to/ ) {
		print OUT2 "mz3:sim3:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/^Similarities_with_/     ) {
		print OUT2 "mz3:sim4:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ( $line[1] =~/^Similarity:/ ) {
		print OUT2 "mz3:sim5:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/^Novel_protein_similar_to_/    ) {
		print OUT2 "mz3:sim6:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/highly_similar_to/ ) {
		print OUT2 "mz3:sim7:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/^Novel_protein_similar_to_/    ) {
		print OUT2 "mz3:sim8:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/similar_to/ ) {
		print OUT2 "mz3:sim9:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
        next;
	}
    elsif ($line[1] =~/Protein_similar_to/  ) {
		print OUT2 "mz3:sim10:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

    elsif ($line[1] =~/Contains_similarity_to_/  ) {
		print OUT2 "mz3:sim11:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

    elsif ($line[1] =~/Simila_to_/ ) {
		print OUT2 "mz3:sim11:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
    elsif ($line[1] =~/^cDNA_/i ) {
		print OUT2 "mz3:cdna:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

    elsif ($line[1] =~/clone/i ) {
		print OUT2 "mz3:clone:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

    elsif ($line[1] =~/uniprot/ ) {
		print OUT2 "mz3:sim:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

	elsif ($line[1] =~/SJCHG\w+_protein/) {
		print OUT2 "mz3:sjap:\t\t\t$line[1]\n";
        #print OUT "$line[0]\tSimilar_to_Schistosoma_japonicum_$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Protein_MGF/) {
		print OUT2 "mz3:MGF:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+$/) {
		print OUT2 "mz3:number:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] !~/[a-z]+[a-z]+/) {
		print OUT2 "mz3:not_lower:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Protein_\db$/) {
		print OUT2 "mz3:Protein_b:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+[LR]$/) {
		print OUT2 "mz3:LR:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+kd$/) {
		print OUT2 "mz3:kd1:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+_kDa_protein$/) {
		print OUT2 "mz3:kd2:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kDa_protein$/) {
		print OUT2 "mz3:kd3:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kd_protein$/) {
		print OUT2 "mz3:kd34:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+K_protein$/) {
		print OUT2 "mz3:kd5:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^\d+\_protein$/) {
		print OUT2 "mz3:protein:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Putative_uncharacterized_protein/) {
		print OUT2 "mz3:pup:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/PREDICTED:_hypothetical_protein/) {
		print OUT2 "mz3:PHP:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Predicted_protein$/) {
		print OUT2 "mz3:pp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Conserved_domain_protein/) {
		print OUT2 "mz3:cdp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Putative_membrane_protein$/) {
		print OUT2 "mz3:Pmp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Membrane_protein$/) {
		print OUT2 "mz3:Mp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Putative_Membrane_protein$/) {
		print OUT2 "mz3:Mp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
#	elsif ($line[1] =~/Polyprotein/) {
#		print OUT2 "mz3:pop:\t\t\t$line[1]\n";
#		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
#	}
	elsif ($line[1] =~/predicted_protein/) {
		print OUT2 "mz3:pp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Secreted_protein$/) {
		print OUT2 "mz3:sp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Predicted_membrane_protein$/) {
		print OUT2 "mz3:pmp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Novel_protein$/) {
		print OUT2 "mz3:np:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Putative_transporter$/) {
		print OUT2 "mz3:ptp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Uncharacterized_conserved_protein$/) {
		print OUT2 "mz3:ucp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Genome_polyprotein/) {
		print OUT2 "mz3:Gp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}	
	elsif ($line[1] =~/^Lipoprotein$/) {
		print OUT2 "mz3:Lp:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Genome$/) {
		print OUT2 "mz3:gen:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/whole_genome_shotgun_sequence/) {
		print OUT2 "mz3:wgs:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_sequence/) {
		print OUT2 "mz3:wgs:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_assembly/) {
		print OUT2 "mz3:wga:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Os0\w+00_protein$/) {
		print OUT2 "mz3:os:\t\t\t$line[1]\n";
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_FG/) {
		print OUT2 "mz3:fg:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_LOC/) {
		print OUT2 "mz3:hlc:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/hypothetical_protein,_partial/) {
		print OUT2 "mz3:hypp:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/UPI\w+_related_cluster/) {
		print OUT2 "mz3:UPI:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Zgc:\d+/) {
		print OUT2 "mz3:zg:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^LOC\d+_protein/ or $line[1] =~/^LOC\d+_transcript/) {
		print OUT2 "mz3:LOC:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/^Smp_\d+/) {
		print OUT2 "mz3:Smp:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/project/) {
		print OUT2 "mz3:project:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}
	elsif ($line[1] =~/E\.coli/i) {
		print OUT2 "mz3:ecoli:\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}



    else {
		print OUT "$line[0]\t/product=\"$line[1]\"\n";
	}

}

	close (OUT);
	close (OUT2);

#system "cat $out | sed \'s/mz3/hypothetical_transcript/\' | awk -F\'\t\' \'{print \$1\"\t\/product=\"\"\$2\"}\' > $out.cleaned ";



__END__

	elsif ($line[1] =~//) {
		print OUT2 "mz3::\t\t\t$line[1]\n";		
		print OUT "$line[0]\t/product=\"hypothetical_transcript\"\n";
	}

		print OUT "$line[0]\\t/product="hypothetical_transcript"\n";
