#!/usr/bin/perl
use strict;

#Phylogenomic pipeline, generates alignments for every gene that exists in an OrthoMCL cluster as one copy in the organism of interest.
#A RAXML tree is generate from the output.

unless (@ARGV ==3) {
        &USAGE;
}

sub USAGE {

die 'Usage: orthoMCL_2_fasta.pl orthofile fasta-file prot/nuc/NO

1. OrthoMCL output
2. Fasta-file with all sequences
3. Is the sequences proteins or nucleotides?
    If you just want stats, instead type NO

This program takes the ortho-MCL result, produces a stats-file
    and a folder with for each cluster:
    fasta
    alignments
    phylogeny

    
'
}

my $orthofile=shift;
my $pepfile=shift;
my $prot = shift;

open (ORTHO, $orthofile);
open (PEP, $pepfile);

my @ortho = <ORTHO>;
chomp @ortho;
#print "$ortho[0]\n";

#@pep = <PEP>;
#chomp (@pep);
#print "$pep[0]\n";
my @stats;
my %genes;

foreach my $line (@ortho) {
#    chomp $line;
    my ($head, $genes) = split(/\t/, $line);
#    print "$head\n";
    my ($cluster, $stats) = split (/\(/, $head);
    push (@stats, $head . ",\t" . $genes);
    my @arr = split(/\s+/, $genes);
    foreach my $elem (@arr) {
            if ($elem=~m/\w/ and $cluster=~m/\w/ ) {
                $cluster=~s/ORTHOMCL/omcl_/;
                $elem=~s/\(\D+\)//;
#                print "$cluster\t$elem\n";
                $genes{$cluster}{$elem} = 1;
            }
            else {
            }
        
    }

}

my %stat;

foreach my $elem (@stats) {
    chomp $elem;
#    print "$elem\n";
    my @arry =split( /\t/, $elem);    
    my @arr =split( /[\,\(]/, $arry[0]);
    $arr[0]=~s/ORTHOMCL//;
    $arr[1]=~s/ genes//;
    $arr[2]=~s/taxa\)\://;
    my @arrx =  split(/\s+/, $arry[1]);
    foreach my $elem2 (@arrx) {
#        print "$elem2\n";
#        my @arr2 = split (/[\s+]/, $elem2);
#        unless ($arr2[0]=~/\)/) {
            my @arr3 = split (/\_/, $elem2);
#            print "$arr3[0]\n";
            if ($arr3[0]=~/\w+/) {
                $stat{ "$arr[0]\t$arr[1]\t$arr[2]" }{$arr3[0]}++ ; 
#                print "$arr[0]\t$arr[1]\t$arr[2]\t$arr3[0]\n";
            }
#        }
    }


}

open (OUT, ">$orthofile.stat");


print OUT "SPECIES\tGENES\tTAXA";

# pad up missing values
my %spe;

foreach my $ort ( sort {$a<=>$b} keys %stat) {
#    print OUT "\n\northo_$ort\t";

    foreach my $species2 (keys %{$stat{$ort}} ) {
        $spe{$species2}=1;
    }
    foreach my $species3 (keys %spe) {
        unless (exists $stat{$ort}{$species3}) {
            $stat{$ort}{$species3} = 0;
#            print "Make $ort\t$species3\t0\n";
        }
    }
}

foreach my $ort ( sort {$a<=>$b} keys %stat) {
    print OUT "\n\northo_$ort\t";

    foreach my $species (sort keys %{$stat{$ort}} ) {
        print OUT "$species=$stat{$ort}{$species}\t";
    }



#    print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\n";

}

if ($prot =~/NO/i) {
    exit;
}
#__END__
#=pod
while (<PEP>) {
    chomp $_;

        if ($_=~/^>/) {
            my $gene = $_;
            $gene =~s/\>//;
            my $seq = <PEP>;
            chomp ($seq);
#            print "$gene\n";
            # assign sequences to genes
            foreach my $omcl (keys %genes) {
                if (exists $genes{$omcl}{$gene}) {
                    $genes{$omcl}{$gene} = $seq;
#                    print "$gene\n$seq\n";
                }
            
            }
        }
        else {
            print "Line is weird: $_\n";
        }
}

#=cut

if (-d "$orthofile.fastas") {
    die 'There already exists a folder called fastas.
    I dont want to overwrite it so I will die
    
    ';
}
else {
        mkdir "$orthofile.fastas";
}
chdir "$orthofile.fastas";

foreach my $clu (keys %genes) {

    my $ln = scalar(keys %{$genes{$clu}});
#    print "$clu\t$ln\n";
    open (FAS, ">>$clu.$ln.fas");

    foreach my $gen (keys %{$genes{$clu}}) {

#       print "$clu\t$gen\n$genes{$clu}{$gen}\n";

        unless ($genes{$clu}{$gen} =~m/^1$/ ) { 
            print FAS ">$gen\n$genes{$clu}{$gen}\n";
        }
        else {
#            print "$gen\n$genes{$clu}{$gen}\n";
        }

    }
    close (FAS);
    system "bsub.py 2 $clu.$ln  perl ~mz3/bin/perl/phylogenize_me.pl $clu.$ln.fas $prot";

}

chdir "..";

exit;

__END__

$orthojoin=join ('', @ortho);
$pepjoin=join ('', @pep);

@ortho=split /ORTHO/, $orthojoin;
@pep=split /\>/, $pepjoin;

foreach $cluster (@ortho){
	@group=split /\s+/, $cluster;
	@group=sort @group;
	$egu=0;
	$emuv2=0;
	$hym=0;
	$macl=0;
	$sjap=0;
	$sman=0;
	$smed=0;
	$taes=0;
	foreach $gene (@group){
		if ($gene=~/egu/) {$egu++};
		if ($gene=~/emuv2/) {$emuv2++};
		if ($gene=~/hym/) {$hym++};
		if ($gene=~/macl/) {$macl++};
		if ($gene=~/sjap/) {$sjap++};
		if ($gene=~/sman/) {$sman++};
		if ($gene=~/smed/) {$smed++};
		if ($gene=~/taes/) {$taes++};
		}
	if (($egu==1)&&($emuv2==1)&&($hym==1)&&($macl==1)&&($sjap==1)&&($sman==1)&&($smed==1)&&($taes==1)){
		push @singles, $cluster;
		}
	}
	
#print "$count clusters of one gene each!";

foreach $line (@singles){
	$line=~s/\(egu\)//;
	$line=~s/\(emuv2\)//;
	$line=~s/\(hym\)//;
	$line=~s/\(macl\)//;
	$line=~s/\(sjap\)//;
	$line=~s/\(sman\)//;
	$line=~s/\(smed\)//;
	$line=~s/\(taes\)//;
	@taxa=split /\:/, $line;
	@taxa=split /\s+/, $taxa[1];
	@taxa=sort @taxa;
	$count++;
	$filename="file".$count;
	open (OUTFILE, ">$filename");
#	if ($taxa[4]!~/LmxM/) {print "WTF $line!!";}
	#print "$taxa[1] | $taxa[2] | $taxa[3] | $taxa[4] | $taxa[5]\n";
	foreach $species (@taxa){
		#print "$species\n";
		foreach $entry (@pep){
				if ($entry=~/$species/){
				$contents= ">"."$entry";
				push @align, $contents;
			}	
		}
}
unless ($count>6000){
	$alignjoin=join ('', @align);
	print OUTFILE $alignjoin;
	close OUTFILE;
	system "clustalw -OUTORDER=INPUT -OUTPUT=PHYLIP -INFILE=$filename";
	@align='';
}
}

system "cat *.phy > all.phy";
system "perl ~/Scripts/Magdalenaphylos/phylipcleanerall.pl all.phy > allclean.phy";
system "perl ~/Scripts/Magdalenaphylos/phyliptofasta.pl allclean.phy > all.fa";
system "Gblocks all.fa";

