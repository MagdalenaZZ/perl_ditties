#!/usr/bin/perl -w


# use strict;

use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_gff_cleanup.pl folder out-prefix
# From a folder, it gathers all gff-files in the directories, merges them, flags up mistakes, and makes a cleaned-up version


First run the writedb_entries.py script 


'
}


# Unzip the files in all folders and cat them

my $folder = shift;
my $prefix = shift;

#=pod

#chdir "$folder";
my $cwd = cwd();
print "CWD: $cwd\n";

my $dir = cwd();
my @dirs ;


my @paths = read_dir( "$cwd/$folder", prefix => 1 ) ;


foreach my $elem (@paths) {
    if ($elem=~m/\.gz$/) {

        #print "gunzip -r $cwd/$folder/$elem\n";
        system "gunzip  $cwd/$folder/$elem";
        $elem=~s/\.gz//;
        push (@dirs, "$cwd/$folder/$elem");
        #print "$cwd/$folder/$elem\n";        

    }
    else {
        push (@dirs, "$cwd/$folder/$elem");
        #print "$cwd/$folder/$elem\n"; 
    }
}

=pod


#Make sure the folder has the right path - if not a path - assume that it is in this folder

if ($folder =~m/\//) {	
	if (-d "$folder") {
        print "If: $folder\n";
		foreach my $elem (@dirs) {
            $elem = "$folder\/$elem";
            print "`gunzip -r $elem\n";
            system `gunzip -r $elem `;
			print "Unzipping of $elem finished\n";

            unless (-z  "$elem.gff" ){
                system  `cat $elem/*.gff > $elem.gff `;
            }
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
		print "Else: $cwd\/$folder\n";
		foreach my $elem (@dirs) {
			$elem = "$cwd\/$folder\/$elem";
			print "`gunzip -r $elem\n";
#            system `gunzip -r $elem `;
            print "Unzipping of $elem finished\n";

            unless (-z  "$elem.gff" ){
                system  `cat $elem/*.gff > $elem.gff `;
            }
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
=cut


print "Fishished reading files\n";

#__END__

# Concatenate all files

my $nothing = " ";
push (@dirs, $nothing);
#open (EXC, ">exception.list") || die "I can't open exception.list\n";
my $filelist = join( " ", @dirs); 

# print "List:$filelist:\n";

unless (-z "$prefix.all.originals.gff") {
system `cat $filelist > $prefix.all.originals.gff`;
#print "cat $filelist > $prefix.all.originals.gff`\n";
}



# Read in the concatenated file
#
	open (IN, "<$prefix.all.originals.gff") || die "I can't open $prefix.all.originals.gff\n";
	my @in = <IN>;
	close (IN);

my @gff;
my @no_genes;

# sort out which contigs have and do not have genes
foreach my $line (@in){
    chomp $line;
    if ($line=~m/\tchado\t/){
        #print "$line\n";
        push (@gff, $line);
    }
    elsif ($line=~m/\>/) {
        push (@no_genes, $line);
    }
}

# Print a list of contigs with no genes
	open (OUT, ">$prefix.contigs.list") || die "I can't open $prefix.contigs.list\n";

foreach my $line (@no_genes) {
    print OUT "$line\n";
}

	close (OUT);

my %h;



# Create a hash like this hash{contig}{gene}{genepart}{gff-line}
#
my $contig_no=0;
my $gene_no=0;
my $mrna_no=0;
my $poly_no=0;
my $cds_no=0;
my $pseudo_no=0;
my $cont_no=0;
my $gap_no=0;

# Print a list of contigs with no genes
	open (OUT2, ">$prefix.raw.gff") || die "I can't open $prefix.raw.gff\n";


foreach my $line (@gff) {
    chomp $line;
    print OUT2 "$line\n";

    my @arr = split(/\s+/, $line);
#    print "ARR8:$arr[8]\n";
    #   my $sign = "$arr[8]";
    my @id =  split(/\;/, $arr[8]);

        if ($arr[2]=~m/^gene$/){
#            print "gene:$arr[2]\n";                
            my $gene_id = $id[0] ;
                $h{$arr[0]}{$gene_id}{$arr[2]} = $line;
#                print "$arr[0]\t$gene_id\t$arr[2]\n";
                 $gene_no++;
        }
        elsif ($arr[2]=~m/^mRNA$/){
#            print "mRNA:$arr[2]\n";
                my @gene_id = split(/\./,$id[0]);
                my $gene_id = $gene_id[0];
                $h{$arr[0]}{$gene_id}{$arr[2]} = $line;
#                print "$arr[0]\t$gene_id\t$arr[2]\n"; 
                 $mrna_no++;
        }
        elsif ($arr[2]=~m/^CDS$/){
#            print "CDS:$arr[2]\n";
                my @gene_id = split(/\./,$id[0]);
                my $gene_id = $gene_id[0];
                $h{$arr[0]}{$gene_id}{$arr[2]} = $line;
#                print "$arr[0]\t$gene_id\t$arr[2]\n";       
                 $cds_no++;
        }
        elsif ($arr[2]=~m/^polypeptide$/){
#            print "pep:$arr[2]\n";
                my @gene_id = split(/\./,$id[0]);
                my $gene_id = $gene_id[0];
                $h{$arr[0]}{$gene_id}{$arr[2]} = $line;
#                print "$arr[0]\t$gene_id\t$arr[2]\n";       
                 $poly_no++;
        }
        elsif ($arr[2]=~m/^pseudogene/){
#            print "pseudogene:$arr[2]\n";
                 $pseudo_no++;
              }
        elsif ($arr[2]=~m/^pseudogen/){
#            print "pseudo:$arr[2]\n";
              }
        elsif ($arr[2]=~m/^gap$/){
#            print "gap:$arr[2]\n";
                 $gap_no++;
              }
        elsif ($arr[2]=~m/^contig$/){
#            print "contig:$arr[2]\n";
                 $cont_no++;
              }

        else {
            print "OTHER: $arr[2]\t$id[0]\n";
        }

}


print "Finished reading in all data\n";

# Print some stats


my $contigs = 0;
$contigs += scalar keys %h;

print "There are $contigs contigs/scaffolds with genes in them\n";
print "These consist of $cont_no contigs and $gap_no gaps\n\n";
#print "There are $contigs contigs/scaffolds with genes in them\n\n";
print "There are $gene_no genes in the file\n";
print "There are $pseudo_no pseudo-genes in the file\n";
print "There are $mrna_no mRNAs in the file\n";
print "There are $poly_no polypeptides in the file\n";



close (OUT2);


system "perl ~/bin/perl/chado_gff_correct.pl $prefix.raw.gff ";

