#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_rename_scaffolds.pl input.gff list out-prefix

Takes a gff-file and a list, and changes the scaffold-names, just like fasta_rename.pl

'
}


	my $in = shift;
    my $list = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);
	open (LIST, "<$list") || die "I can't open $list\n";
	my @list = <LIST>;
	close (LIST);

	open (OUT, ">$out.renamed") || die "I can't open $out.renamed\n";
	open (OUT2, ">$out.kept") || die "I can't open $out.kept\n";

my %names; 

foreach my $line (@list) {
    chomp $line;
    my ($ori, $new) = split(/\s+/,$line);
    $names{$ori}= $new;
}


foreach my $line (@in) {
    chomp $line;
    my @arr = split(/\s+/,$line);
    if (exists $names{$arr[0]}) {
        $arr[0]=$names{$arr[0]};
        my $new_line = join("\t", @arr);
        print OUT "$new_line\n";
    }
    else {
        print "Missing contig  $arr[0] from the list\n";
        print OUT2 "$line\n";

    }
}



	close (OUT);
