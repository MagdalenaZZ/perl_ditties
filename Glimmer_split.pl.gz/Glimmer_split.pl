#!/usr/local/bin/perl -w
# mz3 script for making augustus hint-s-file from RNAseq
# do one .psl file at a time

use strict;

unless (@ARGV == 3) {
        &USAGE;
}



sub USAGE {

die 'Usage: perl augustus_BLAT2hints.pl <genome-file> <RNAseq-file.fasta> <prefix>

All files need to be real - no softlinks 

RNAseq-file needs to contain both forward and reverse reads in fasta-format.

Once you\'ve done all of the files, you can concatenate all files using

cat hints.introns.gff hints.ep.gff  [hints2.gff, hints3.gff]  > hints.gff

No need to bsub - it bsubs itself

'
}

__END__
