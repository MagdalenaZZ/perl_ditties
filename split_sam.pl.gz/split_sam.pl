#!/usr/local/bin/perl -w
# mz3 script for creating a folder structure and splitting a bam/sam-file

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage:  split_fasta_to_dirs.pl infile.bam

Infile - bam/sam -file


'
}

my $file = shift;
my @infiles = $file;

# Get all headers

my @ins = `samtools view -H $file`;


#print "$ins[0]";
my @folders;

foreach my $line (@ins) {
    if ($line =~/^\@SQ/) {
        my @arr = split(/\s+/, $line);
        $arr[1] =~s/SN://;
#        print "$arr[1]\n";
#        system "mkdir $arr[1]";
        push (@folders, $arr[1]);
    }
}


print "Finished part 1\n";
#__END__

#my $first_file = $infiles[0];
my $first_file = @ins;

#system "head $first_file | grep @ | sed s/TopHat/ID:TopHat/ > header.sam";

foreach my $scaffold (@folders) {
    chomp $scaffold;
 
    open (OUT, ">./$scaffold/all.sam") || die "I can't open all.sam\n";
    print OUT `samtools view -H $file`;
    #print "@ins";

    system ("mkdir $scaffold") unless (-d $scaffold);
	my $scaffold2 = '"'.'>'."$scaffold".'"';
	
#=pod
    foreach my $file (@infiles) {

        if ($file=~/\.bam$/) {
    	    open (IN, "samtools view $file |") || die "I can't open $file\n";
            #open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";        
        }
        else {
    	    open (IN, "<$file") || die "I can't open $file\n";

        }
		
        while (<IN>) {
            my $line = $_;
            my @arr = split(/\s+/, $line);
            #print  "$arr[2] $scaffold\n";

            if ($arr[2]=~/^$scaffold$/) {

                print OUT "$line";
                #print  "$line";

                #print "$scaffold2\n";
                #print ("cat $infile | grep $scaffold2 -w -A 1 > ./$scaffold/$scaffold.fasta") ;

                #system ("cat $file | grep $scaffold2 -w -A 1 > ./$scaffold/$scaffold.fasta") 
                #unless (-e  "./$scaffold/$scaffold.fasta" );

            }
        }

    }
#=cut

    close (OUT);
    system "samtools view -bS $scaffold/all.sam > $scaffold/$scaffold.bam ";
}
