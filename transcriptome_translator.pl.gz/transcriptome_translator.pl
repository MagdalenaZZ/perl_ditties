#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: transcriptome_translator.pl <species> transcriptome.fasta 

This program takes a transcriptome and translates it using augustus

<species> is the name of species augustus is using


    ' . "\n";
}

my $species = shift;
my $fas = shift;


# run augustus
system "augustus --species=$species --genemodel=partial --noInFrameStop=true --codingseq=yes --protein=on --alternatives-from-sampling=false --outfile=$fas.gtf $fas";

# export amino acids

system " ~/bin/augustus.2.5.5/scripts/getAnnoFasta.pl $fas.gtf";

# clean up
#system "rm -f $fas.gtf";

print "perl ~mz3/bin/perl/augustus2gff_pipe.pl $fas.gtf \n";
print "perl ~mz3/bin/perl/augustus_fix_gff-coords.pl $fas.gff $fas.aa $fas.codingseq \n";



print "\n\nYour result is  $fas.aa \n\n";




