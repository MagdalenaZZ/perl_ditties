#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: fasta_trim_alignment.pl fasta.fas  L<INT> R<INT>

Takes one fasta-file, and then trims the edges of it

Exampe:

fasta_trim_alignment.pl fasta.fas  L50 R10

Trims 0bp to the left and 10 to the right



'
}


my $dom1 = shift;
my $left = shift;
my $right = shift;

# Check left and right are okay

if ($left=~/^L\d+$/) {
    print "$left in right format\n";
    $left=~s/L//;
    
}
else {
    print "$left not in right format, it should be written like L<INT>;  L10 L0  L43\n";
    exit;
}

if ($right=~/^R\d+$/) {
    print "$right in right format\n";
    $right=~s/R//;

}
else {
    print "$right not in right format, it should be written like R<INT>;  R10 R0  R43\n";
    exit;
}




my $rhead;
my $rseq;
my $rlen=0;


# make sure all names are uniq

system "perl ~mz3/bin/perl/fasta_uniq.pl $dom1 ";


system "rm -f $dom1.not_uniq $dom1.uniq";


# read all fastas to a hash
	open (IN, "<$dom1.all_uniq") || die "I can't open $dom1.all_uniq\n";
#	my @doms = <IN>;
#
my $i=1;

my %h;

    while (<IN>) {
        chomp $_;
        if ($_ =~/^>/) {
            my $head = $_;
            #$head =~s/.1..pep//;
            #$head =~s/.2..pep//;
            #$head =~s/.3..pep//;
            $head =~s/>//;
            my $seq = <IN>;
            chomp $seq;

            if ($head =~/\w+/ and $seq =~/\w+/) {
                $h{$head} = $seq;

                #print "$i\t$head\t$seq\n";
                $i++;
            }
            else {
                print "Escaped $_\n";
            }

        }
        else {
                print "Escaped $_\n";
        }
    }

close (IN);






if (-s "$dom1.trimL$left\R$right" ) {
    die "Output file already exists\n";
}

open (OUT, ">$dom1.trimL$left\R$right") || die "I can't open $dom1.trimL$left\R$right\n";

#__END__

$i=1;

foreach my $gene1 (keys %h){ 

            


            # make new trimmed sequence
            # first trim right
            # then trim left
            my $len = length($h{$gene1});
            my $offset = $len - $right;
            #print "$left\t$right\t$len\t$offset\n";
            my $new_seq = substr($h{$gene1}, 0, $offset );
            $new_seq =substr($new_seq, $left  );

            # then check there is sequence left
            print OUT ">$gene1\n$new_seq\n";
            #print "$i\t$gene1\n$new_seq\n";
            # print out
            $i++;


}




close(OUT);

exit;



