#!/usr/bin/perl -w
use strict;

my %hash;

while (<>) {
	chomp;
tr/=/ /;

	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $note = $line[8];
	($start, $end) = sort {$a <=> $b}($start,$end);
	#print "$start, $end"; <STDIN>;
	my $phase = 0;
	
	my $newline =  "$name\t$method\t$tag\t$start\t$end\t.\t$strand\t$phase";
	# counter
	push (@{$hash{$note}}, $newline); 
	
}
foreach my $key (keys %hash) {
	my $elem = scalar(@{$hash{$key}});
#	print "I'm in $key with $elem"; <STDIN>;
	my $comment = "ID=$key;";
	my $mrna = "ID=Transcript.$key;Parent=$key;";
#	print "$\t$method\tgene\t$first\t$last\t.\t$strand\t.\t$comment\n"; #<STDIN>;
	my @array;
	my $count = 1;
	my $first = "";
	my $last = "";
	my $name = "";
	my $method = "";
	my $strand = "";
	foreach my $liner (@{$hash{$key}}) {
		my @line = split (/\s+/, $liner);
		$name = $line[0];
		$method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
		my $end = $line[4];
		my $score = $line[5];
		$strand = $line[6];
		($start, $end) = sort {$a <=> $b}($start,$end);
		if ($tag =~ /First/) {
			$first = $start;
		} elsif ($tag =~ /Terminal/) {
			$last = $end;
		} elsif ($tag =~ /Single/) {
			($first, $last) = ($start, $end);
		}
#		print "this is line\n$line"; <STDIN>;
		my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t0\tID=Exon.$count;Parent=Transcript.$key\n";
		push (@array, $newline);
		#print $newline; #<STDIN>;
		$count++;
	
	}
	my $conta = 0;
	foreach my $elem (sort {(split /\s+/, $a)[3] <=> (split /\s+/, $b)[3]} @array) {
		if ($conta == 0) {
			if (scalar @array == 1) {
				($first, $last) = ((split /\s+/, $elem)[3], (split /\s+/, $elem)[4])
			} else {
				$first = (split /\s+/, $elem)[3];
			}
		} elsif ($conta == (scalar @array)-1) {
			unless (scalar @array == 1) {
				$last = (split /\s+/, $elem)[4];
			}
		}
		print $elem;
		$conta++;
	}
	print "$name\t$method\tgene\t$first\t$last\t.\t$strand\t.\t$comment\n"; #<STDIN>;
	print "$name\t$method\tmRNA\t$first\t$last\t.\t$strand\t.\t$mrna\n"; #<STDIN>;
}
