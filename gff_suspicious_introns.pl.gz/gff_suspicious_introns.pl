#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_suspicious_introns.pl input.gff 

Takes a gff-file and checks the file integrity. Summary prints to STDOUT and detailed info prints to outfile


'
}

	my $in = shift;
	my $out = $in;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out.out") || die "I can't open $out.out\n";


my $gene=0;
my %genes;
my $last= "0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0";

foreach my $ele (@in) {
    chomp $ele;
    my @arr=split(/\t/,$ele);


    if ($arr[2]=~/gene/) {
        if ( $arr[8]=~/=/) {
            my @arr2=split( /=/,$arr[8]);
            $gene=$arr2[1];

        }
        else {
            $gene=$arr[8];
        }
    }
    elsif ( $arr[2]=~/CDS/ ) {
        #push( @{$genes{$gene}}, "$arr[3]\t$arr[4]");
        my @last=split( /\t/,$last);

        if ($last=~/$gene/ and $ele=~/$gene/) {
            #print "same gene $last[8]\t$arr[8]\n";

            if ($arr[3] - $last[4] >10000 ) {
                #print "$gene\t$last[4]\t$arr[3]\n";
                print OUT "$gene\n";
            }
        }


        $last=$ele;
    }
    elsif  ( $arr[2]=~/mRNA/ ) {
    }
    else {
        print "$ele\n";
    
    }



}


#foreach my $key (keys %genes) {
#    my @arr=@{$genes{$key}};
#}


close (OUT);





