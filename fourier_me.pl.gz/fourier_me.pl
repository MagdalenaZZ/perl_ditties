#!/usr/bin/perl
use strict;


unless (@ARGV > 2) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:
 
perl ~/bin/perl/fourier_me.pl   <file.rpkm>  <order>  <cut-off>


Example: 

perl ~/bin/perl/fourier_me.pl  HOMEO.emu.rpkm 3 10


    order - file with all the conditions ordered

    <cut-off> - fourier significance cut-off (typically betwen 0.2-0.5)


';

}




my $rpkm = shift;
my $order = shift;
my $cut = shift;

# sort out the order of conditions

my @ord;
my %seen;

open (ORD, "<$order" ) || die "$!";

while (<ORD>){
    chomp;
    #print "$_";
    
    my @arr = split(/\./, $_);

    if (exists $seen{$arr[0]}) {
        # do nothing
        $seen{$arr[0]}{$arr[1]}=1;
        #print "$arr[0]\t$arr[1]\n";
    }
    else {
        push (@ord, $arr[0]);
        $seen{$arr[0]}{$arr[1]}=1;
        #print "$arr[0]\t$arr[1]\n";
    }

}

my %lens;
my $reps;

foreach my $key (keys %seen ) {
    #print "$key\n";


    foreach my $rep (keys %{$seen{$key}} ) {
        my $len = scalar (keys %{$seen{$key}}  );
        #print "$len\n";
        $lens{$len}=1;
        $reps=$len;
    }


#    foreach my $rep (keys %{$seen{$key}} ) {
        #my $len = scalar (keys %{$seen{$key}}  );
        #print "$len\n";
#    }
}


my $totlen = scalar (keys %lens  );
unless ($totlen=~/1/) {
    die "Something is wrong with your order-file, please fix and re-start\n";
}



my $cond = scalar(@ord);
my $order = join("\,",@ord);



system " ~mz3/bin/Fourier_transform/find_periodicity  $rpkm $reps $cond";

system "perl ~mz3/bin/Fourier_transform/parse_fourier.pl Fourier_data.out $cut > $rpkm.$cut.ft_ordered.dat ";

system  "perl ~mz3/bin/Fourier_transform/mean_vals.pl $rpkm $order $rpkm.$cut.ft_ordered.dat $cut";

system "perl ~/bin/Fourier_transform/draw_plot.pl $rpkm.$cut.ordered.profiles.R  $order";



print "\n";


# make a circos input file




# make an R input file



open (RF, ">$rpkm.$cut.code.R") || die "$!";

print RF "

x<-read.table(\"$rpkm.$cut.ordered.profiles.R\", header=TRUE)
#x<-x[,-1]
row.names(x) 

x.m = data.matrix(x)

library(gplots)

pdf(\"$rpkm\.$cut\.pdf\")

heatmap.2(x.m,  Rowv=NA, Colv=NA, col=rev(redgreen(20)), margins=c(5,10), key=FALSE, symkey=FALSE, density.info=\"none\", trace=\"none\")

dev.off()

svg(\"$rpkm\.$cut\.svg\")

heatmap.2(x.m, Rowv=NA, Colv=NA, col=rev(redgreen(20)), margins=c(5,10), key=FALSE, symkey=FALSE, density.info=\"none\", trace=\"none\")

dev.off()



";


close(RF);

system  "R-3.0.0 CMD BATCH $rpkm.$cut.code.R\n ";

print "\n";


