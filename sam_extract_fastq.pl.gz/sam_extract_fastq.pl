#!/usr/bin/perl -w


# Read in SAM-file


# Go through fastq line by line to see if that sequence is present

    # translate all Ns to As



# retrive complete mate-pairs   



