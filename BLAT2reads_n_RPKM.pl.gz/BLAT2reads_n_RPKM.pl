#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLAT2reads_n_RPKM.pl output.blat.psl file.gff


Takes a BLAT output and count the reads for each CDS


NOT FINISHED!!!!



'
}


my $in = shift;
open (PSL, "<$in") || die "I can't open $in\n";
my $in2 = shift;
open (GFF, "<$in2") || die "I can't open $in2\n";


my %gff;


# read in the gff-file
while (<GFF>) {
    chomp;
    my @arr = split(/\t/,$_);
    if ($arr[2]=~/CDS/) {
        #print "$arr[0]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[8]\n";
        $gff{$arr[0]}="$arr[3]\t$arr[4]\t$arr[8]";
    }
}


# read in the psl file
while (<PSL>) {
    chomp;
    my @arr = split(/\t/,$_);

    print "$_\n";

}






# find out which reads overlap a feature


close (PSL);
close (GFF);



