#!/usr/local/bin/perl -w

use strict;
#use Text::ParseWords;

unless (@ARGV==3) {
        &USAGE;
}

sub USAGE {

die 'Usage: hmmer_chooser.pl in eval out

Give a hmmer-searh output-file 
The program will merge all hits, and then report the best hit from several different models, if their evalue is less than eval


'
}

	my $in = shift;
	my $eval = shift;
#    my $maxlen = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

    
my %genes;
my %res;
my $index = 1;
my %gff;

# make hmm output to gff
#
foreach my $line (@input) {

    unless ($line =~/^#/) {
my @var	= split(/\s+/, $line);

my $gene= $var[0];
my $acc = $var[1];
my $model = $var[2];
my $acc2 = $var[3];
$acc2 =~s/Group\.//;

my $full_eval = $var[6];
my $full_score = $var[5];
my $full_bias = $var[6];
my $best_eval = $var[7];
my $best_score = $var[8];
my $best_bias = $var[9];
my $dom_exp = $var[10];
my $dom_reg = $var[11];
my $dom_clu = $var[12];
my $dom_ov = $var[13];
my $dom_env = $var[14];
my $dom_dom = $var[15];
my $dom_rep = $var[16];
my $dom_inc = $var[17];
my $dom_desc = $var[18];

#print "Eval $var[6]\t$dom_dom\t$dom_rep\t$dom_clu\n";

        if ( $eval >= $dom_clu ) {
            $genes{$gene}{$full_eval}= $line;
            push (@{$gff{$gene}} , "$gene\t$dom_dom\t$dom_rep\t$dom_inc\t$dom_desc\t$dom_clu\t\+\t\.\tID\=$gene\.$acc2");
            $index++;
        }
    }

}

# sort arrays after co-ords



# MERGE OVERLAPPING HITS

my %merged;

foreach my $line (keys %gff) {
#    print "LINE:$line\n";

my @unsort = @{$gff{$line}} ;
my @ordered_users = sort { (split '\t', $a)[3] <=> (split '\t', $b)[3] || (split '\t', $a)[4] <=> (split '\t', $b)[4]    } @unsort ;    

my $i=2;
my $line2 = 0;
my $line3 = 0;

    foreach my $elem ( @ordered_users ) {
#        print "\nELEM:$elem\n";
        
        my @arr = split(/\t/, $elem);
        my $start = $arr[3];
        my $end = $arr[4];
        my $hstart = $arr[1];
        my $hend = $arr[2];

        if (exists $merged{$line} ) {
            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
#            my ($estart , $eend) = split (/\t/, $merged{$line});
            my @earr = split (/\t/, $merged{$line});
            my $estart = $earr[0];
            my $eend = $earr[1];
            my $ehstart = $earr[2];
            my $ehend = $earr[3];

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];

            # hmax
                my $hmax = ($hend, $ehend)[$hend < $ehend];
            # hmin
                my $hmin = ($hstart, $ehstart)[$hstart > $ehstart];


            my $new = "$min\t$max\t$hmin\t$hmax";
#            print "New: $new\n";
            
                $merged{$line} = "$min\t$max\t$hmin\t$hmax";                

            }

        elsif (exists $merged{$line2} ) {

            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
#            my ($estart , $eend) = split (/\t/, $merged{$line2});
            my @earr = split (/\t/, $merged{$line});
            my $estart = $earr[0];
            my $eend = $earr[1];
            my $ehstart = $earr[2];
            my $ehend = $earr[3];

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];
            # hmax
                my $hmax = ($hend, $ehend)[$hend < $ehend];
            # hmin
                my $hmin = ($hstart, $ehstart)[$hstart > $ehstart];

            my $new = "$min\t$max";
#            print "New: $new\n";
            
                $merged{$line2} = "$min\t$max\t$hmin\t$hmax"; 
            }
        }


        elsif (exists $merged{$line3} ) {

            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
#            my ($estart , $eend) = split (/\t/, $merged{$line3});
            my @earr = split (/\t/, $merged{$line});
            my $estart = $earr[0];
            my $eend = $earr[1];
            my $ehstart = $earr[2];
            my $ehend = $earr[3];

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];
            # hmax
                my $hmax = ($hend, $ehend)[$hend < $ehend];
            # hmin
                my $hmin = ($hstart, $ehstart)[$hstart > $ehstart];

            my $new = "$min\t$max";
#            print "New: $new\n";
            
                $merged{$line3} = "$min\t$max\t$hmin\t$hmax"; 
            }
        }



            # have to make a new one
            else {
                # dont overlap
                $line2 = $line . "#$i";
                $merged{$line2} = "$start\t$end\t$hstart\t$hend";
                $i++;

#                print "NEW: $line2\t$start\t$end\n";
            }



        }

# if it doesn't exist before, add the first one
        else {
            $merged{$line} = "$start\t$end\t$hstart\t$hend";
        }
        

    }

}



my %final;

foreach my $key (sort keys %merged) {

my @arr = split( /#/, $key);
push (@arr, 1);
#my @arr2 = split(/\:/, $arr[1]);

#print OUT "$arr[0]#$arr[1]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$key\n";
#print OUT "$arr[0]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$arr[0]\.$arr[1]\n";
#print "$arr[0]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$arr[0]\.$arr[1]\n";

# check if exists

if (exists $final{$arr[0]}) {
#    print "\nDOUBLE:\n$final{$arr[0]}\n$arr[0]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$arr[0]\.$arr[1]\n";

    # check if they are parts of the same hmm-model or different
    my @fina = split(/\t/, $final{$arr[0]}) ;

    my $fseqstart = $fina[3];
    my $fseqend = $fina[4];
    my $fhmmstart = $fina[5];
    my $fhmmend = $fina[6];

    my @merge = split(/\t/, $merged{$key}) ;

    my $seqstart = $merge[0];
    my $seqend = $merge[1];
    my $hmmstart = $merge[2];
    my $hmmend = $merge[3];

#    print "merged\t\t\t\t\t\t" . join("\t", @merge ) . "\n";
#    print "final\t" . join("\t", @fina ) . "\n";

    # check if hmmoverlap is less than 250 and sequence distance more than 50

#    print "$arr[0]\t$fhmmstart - $fhmmend\t$hmmstart - $hmmend\t$fseqstart - $fseqend\t$seqstart - $seqend\n";
#    print "$arr[0]\t" . ($fhmmend-$hmmstart) . "\t" . ($seqstart - $fseqend) . "\n";


    if ( ($fhmmend-$hmmstart) > 250 and ($seqstart-$fseqend) > 50 ) {
        # keep separate
#        print "SEPARATE\n";
        my $new = "$arr[0]#2";

        $fina[3] =  $seqstart ;
        $fina[4] =  $seqend ;
        my $newgff = join( "\t", @fina);
        $final{$new} = "$newgff\.2";
    
    }


    else {

            # max
               my $maxi = ($seqend, $fseqend)[$seqend < $fseqend];
            # min
                my $mini = ($seqstart, $fseqstart)[$seqstart > $fseqstart];
            # hmax
                my $hmaxi = ($hmmend, $fhmmend)[$hmmend < $fhmmend];
            # hmin
                my $hmini = ($hmmstart, $fhmmstart)[$hmmstart > $fhmmstart];

        $final{$arr[0]} = "$arr[0]\thmm\tCDS\t$mini\t$maxi\t$hmini\t$hmaxi\t.\t\+\t\.\tID\=$arr[0]\.merged";
#        print "MERGED:$arr[0]\thmm\tCDS\t$mini\t$maxi\t$hmini\t$hmaxi\t.\t\+\t\.\tID\=$arr[0]\.$arr[1]\n";
    }



}

else {
    $final{$arr[0]} = "$arr[0]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$arr[0]";
}




}

#########
# print output

foreach my $key (sort keys %final) {

my @arr = split( /#/, $key);
push (@arr, 1);
my @arr2 = split( /\t/, $final{$key});

#print "FIN:$final{$key}\n";


print OUT "$arr[0]\thmm\tCDS\t$arr2[3]\t$arr2[4]\t.\t\+\t\.\t$arr2[10]\n";


}




close (OUT);
