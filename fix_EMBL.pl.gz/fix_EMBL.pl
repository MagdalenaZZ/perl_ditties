#!/usr/bin/perl -w
# mz3 script for fixing EMBL to good names

use strict;

my $count = 1;



while (<>) {

	if (/codon_start=/) {
	my ($first, $second) = split (/:/, $_);
	print "FT                   /codon_start=1\n";
	print "FT                   /locus_tag=\"CEGMAgene_$count\"\n";
	$count++;
	}
	elsif (/timelastmodified/) {
	}
	elsif (/isObsolete/) {
	}
	elsif (/\/ID/) {
	}
	elsif (/Parent/) {
	}
	elsif (/Note/) {
	}
	elsif (/colour\=13/) {
	}	
	else {
	print "$_";
	}

}

=pod

/locus_tag="gene1"