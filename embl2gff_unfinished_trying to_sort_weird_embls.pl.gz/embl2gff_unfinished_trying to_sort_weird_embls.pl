#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: embl2gff.pl in.embl out.gff

After finished run fix_children4Artemis.pl

'
}


## parse infile

my $infile = shift;
my $outfile = shift;
 
open (IN, "<$infile");
my @embl = <IN>;

open (OUT, ">$outfile");

	my $name;
	my $method = "RATT";
	my $tag = "CDS";
	my $start = "0";
	my $end = "0";
	my $score = ".";
	my $strand;
#	my $id;
    my @arr2;

#    pop @embl;
#    pop @embl;

foreach my $line (@embl) {
chomp $line;


	my @arr=split(/\s+/, $line);
	if ($arr[0]=~/^ID/) {
		$name = $arr[1];
#		print "Name:$arr[1]\n"
	}
	elsif ($arr[0]=~/^FT/) {

        # if it is a CDS - catch the positions
		if ($arr[1] =~/CDS/) {
			if ($arr[2] =~/complement/) {
				$strand = "-";
				$arr[2] =~s/complement\(//g;
				$arr[2] =~s/join\(//g;
				$arr[2] =~s/\)\)//g;
				$arr[2] =~s/\)//g;
				$line =~s/\t/ /g;
				$line =~s/ //g;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
#				foreach my 
#				split(//,);
			}
			else {
				$strand = "+";
				$arr[2] =~s/join\(//;
				$arr[2] =~s/\)//;
				$line =~s/\t/ /g;
				$line =~s/ //g;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
			}
		}

        elsif ($line=~/\.\./ and $line!~/mRNA/ and  $line!~/source/ ) {
#            print "$line\n";

			if ($line =~/complement/) {
				$strand = "-";
				$line =~s/complement\(//g;
				$line =~s/join\(//g;
				$line =~s/\)\)//g;
				$line =~s/\)//g;
				$line =~s/\t/ /g;
				$line =~s/ //g;
				$line =~s/FT//g;
#                print ":$line:\n";
				my @arr3=split(/,/, $line);
                push (@arr2, @arr3);
            }
			else {
				$strand = "+";
				$line =~s/join\(//;
				$line =~s/\)//;
                $line =~s/\t/ /g;
				$line =~s/ //g;
                $line =~s/FT//g;
#                print ":$line:\n";
				my @arr3=split(/,/, $line);
                push (@arr2, @arr3);
			}


        }

        # if it has a gene - print all the positions of that gene
		elsif ($arr[1] =~/locus_tag/ or $arr[1] =~/gene/) {
			$arr[1]=~s/\/locus_tag="//;
			$arr[1]=~s/\/gene="//;
			$arr[1]=~s/\"//;
#			/locus_tag="KOG0450.57"
#			print "ID:$arr[1]\n";
			my $id = $arr[1];

            # sort and fix the array

            my @final;

			foreach my $pos (@arr2) {
#                print "POS1:$pos:\n";
                $pos =~s/\.\./\t/;
#                print "POS:$pos:\n";
            }

#            @arr2=sort { $a <=> $b } @arr2;

            foreach my $elem (@arr2) {
               ($start,$end)=split(/\t/, $elem);
               print OUT "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
            }

		}
        elsif ($line=~/\/\//) {
        }
#        elsif ($arr[1]=~/source/) {
#				print OUT "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#        }
#
		else {
#			print "Filter 2:$line\n";
		}
	
	}
	elsif ($arr[0]=~/\/\//) {
#		foreach my $pos (@arr2) {
#				($start,$end)=split(/\.\./, $pos);
#			print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#		}
	}
	else {
#		print "Filter 1:$line\n";
	}


# print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\n";

}



close (IN);
close (OUT);

