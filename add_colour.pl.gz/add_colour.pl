#!/usr/bin/perl -w
# mz3 script for reversing start and end positions

use strict;

# open (INFILE, @ARGV);
# my @_s = <INFILE>;

# my $a =0;
# my $b = 0;

while (<>) {

	my @line = split (/\s+/, $_);
# print $line;
		my $name = $line[0];
#		print "$name\n";
		my $method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
#		print "$start\n";
		my $end = $line[4];
		my $score = $line[5];
		my $strand = $line[6];
		my $trans = $line[7];
		my $note = $line[8];

	if ($tag eq "CDS") {
		my $newline = "$name\t$method\t$tag\t$newstart\t$newend\t.\t$strand\t.\t$note;colour=9\n";
		print "$newline\n";	
	}

	else {
		my $newline = "$name\t$method\t$tag\t$newstart\t$newend\t.\t$strand\t.\t$note\n";
		print "$newline\n";	
	}


}