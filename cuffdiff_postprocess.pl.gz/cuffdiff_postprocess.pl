#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: cuffdiff_postprocess.pl key-file

Parses output from cuffdiff

assumes that input has standard cuff-diff names

Needs key-file produced by cuffdiff_preprocess.pl

q1 <tab>  BAMfile_1
q2 <tab>  BAMfile_2
...


'
}

my $in = shift;

my $prefix = shift;

	open (DIFF, "<isoform_exp.diff") || die "I can't open isoform_exp.diff\n";
	my @diff = <DIFF>;
	close (DIFF);

    open (TRACK, "isoforms.fpkm_tracking") || die "I can't open isoforms.fpkm_tracking\n";
	my @track = <TRACK>;
	close (TRACK);


my %genes;


# determine how many BAM-files we have
my $head = shift(@track);
my @arr = split (/\s+/, $head);

my $len = scalar @arr - 9;
my $len2 = ( $len / 4 );

print "There are $len2 BAM-files here\n$head \n";

# read in track

foreach my $line (@track) {
    chomp $line;
    if ($line =~/\w+/) {
        my @arr =split (/\t/, $line);
        $genes{$arr[0]}{LINE} = $line ;
        $genes{$arr[0]}{COORD} = $arr[6] ;
#        $genes{$arr[0]}{TEST} = $arr[8] ;
        $genes{$arr[0]}{LEN} = $arr[7] ;

#        my $len2 = ( $len*4 );
        for ( my $count = 0; $count < $len ; $count+=4) {
            my $name = "q" . ($count/4 + 1) ;
            $genes{$arr[0]}{  $name } = "$arr[ 9 + $count ]\t$arr[ (9 + $count + 1) ]\t $arr[ (9 + $count + 2) ] \t $arr[ (9 + $count + 3) ] " ;
#                print "$arr[0]\t$len\t$count\t$arr[ 9 + $count ]\t $arr[ 9 + $count + 1 ]\t  $arr[ (9 + $count + 2) ] \t $arr[ (9 + $count + 3) ]\n"; # <STDIN>;
        }

    }
}

# read in diff

    foreach my $line (@diff) {
        chomp $line;
#        print "$line\n";
        my @ar =split (/\t/, $line);
        my $pos = "$ar[4]". "_v_"."$ar[5]";
        $genes{$ar[0]}{DIFF}{  $pos }{ $ar[11] } = " $ar[13]";
#        print "$ar[0]\t$pos\t$ar[11]\t$ar[13]\n";

    }



# print output
open (TMP, ">$prefix.tmp") || die "I can't open $prefix.tmp\n";

foreach my $gene ( keys %genes) {
    #           print "$gene\t$genes{$gene}\n";
my $marker =0;

    foreach my $key (sort keys %{$genes{$gene}}) {

        
        if ($key =~/LINE/) {
#            print "$gene\t$key\t$genes{$gene}{$key}\n";
        }
        elsif ($key =~/COORD/) {
#            print "$gene\t$key\t$genes{$gene}{$key}\n";
        }
        elsif ($key =~/^q/) {
            print TMP "$gene\t$key\t$genes{$gene}{$key}\t";
            $marker = 1;
        }

#        foreach my $elem ( sort keys %{$genes{$gene}{$key}} ) {
#            print "$gene\t$key\t$elem\t $genes{$gene}{$key}{$elem} \n";
#        }
    }

        if ($marker =~/1/) {
            foreach my $diff ( sort keys %{$genes{$gene}{DIFF}}  ) {
                foreach my $pval ( sort keys %{$genes{$gene}{DIFF}{$diff}} ) {
                     print TMP "$diff\t$pval\t$genes{$gene}{DIFF}{$diff}{$pval}\t";
                }
            }
            $marker = 0;
        }


    print TMP "\n";
}


# make pretty output

	open (IN, "<$prefix.tmp") || die "I can't open $prefix.tmp\n";
	my @res = <IN>;
	close (IN);

	open (IN2, "<$in") || die "I can't open $in\n";
	my @in = <IN2>;
	close (IN2);


# parse key

my %key;

foreach my $lin ( @in) {
    chomp $lin;
    my @arr = split(/\t/, $lin);

    if ($arr[1]=~/5477/ ) {
        $arr[1]="MetaVesicles_LateBC";
    }
    elsif ($arr[1]=~/5817_1/ ) {
        $arr[1]="EmAdultGravide";
    }
    elsif ($arr[1]=~/5817_2/ ) {
        $arr[1]="EmPreAWDog";
    }
    elsif ($arr[1]=~/7745_8_3/ ) {
        $arr[1]="MS10";
    }
    elsif ($arr[1]=~/7745_8_4/ ) {
        $arr[1]="MS10";
    }
    elsif ($arr[1]=~/7745_8_5/ ) {
        $arr[1]="G8065";
    }

    elsif ($arr[1]=~/7745_8_6/ ) {
        $arr[1]="PC";
    }
    elsif ($arr[1]=~/7745_8_7/ ) {
        $arr[1]="noBC";
    }
    elsif ($arr[1]=~/7745_8_8/ ) {
        $arr[1]="7745_8_8";
    }


    $key{$arr[0]}=$arr[1];

}

# process output

# make header


#print "\n\n\nGene_ID\t"; 

foreach my $linn (sort keys %key) {
    print "$key{$linn}\tstatus\t";
}

foreach my $linn (sort keys %key) {

    foreach my $linn2 (sort keys %key) {
        print "eval_$key{$linn}_v_$key{$linn2}\tsign\t";
    }

}

print "$len2\n\n"; 
my $ix = 2;

# make data

foreach my $lix (@res) {
chomp $lix;
my @ax = split (/\t/, $lix);



print "$ax[0]\t";
my $ix2=0;
# for ($count = 10; $count >= 1; $count--) {

for ( $ix =2 ; ($ix/6) < $len2 ; $ix=$ix+6 ) {
    my $one = $ix;
    my $two = ($ix+3);
#    print "O:$one:\tT:$two:\t";
    print "$ax[$one]\t$ax[$two]\t"; #$ax[8]\t$ax[11]\t$ax[14]\t$ax[17]\t";
    $ix2=$ix+5;
}

for ( $ix2=$ix2 ; $ix2 < ($len2*9) ; $ix2=$ix2+3 ) {
    my $three = $ix2;
    my $four = ($ix2+1);
    my $five;

    if ($four =~/no/) {
        $five = " ";
    }
    elsif ($four =~/yes/) {
        if ()
                $five = " ";

    }
    else {
        print "Warning, something wrong with $four\n";
    }

#    print "T:$three:\tF:$four:\t";
    print "$ax[$three]\t$ax[$four]\t";

#    print "$ax[19]\t$ax[20]\t$ax[22]\t$ax[23]\t$ax[25]\t$ax[26]\n";
}

print "\n";



}


