#!/usr/bin/perl
use strict;


unless (@ARGV >= 1) {
        &USAGE;
}


sub USAGE {

die ' 

This script will take your output from a velvet assembly, and cluster it.

The script will output a unified fasta-file

';

}


my $in = shift;

# do clustering

$in = "../Usearch2/ID.51609.MergedAssembly57.fa ";


system "~/bin/dnaclust_64bit/dnaclust -s 0.7 -i $in -l --no-overlap > $in.list";

# make hash of seqs

open (FAS, "<$in");

while (<FAS>) {
}


# get clusters
#
#
open (IN, "<$in.list");


foreach my $line



