#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/gff_overlapper.pl  ref.gff comparator.gff

Ex:

perl ~/bin/perl/gff_overlapper.pl  ../../Chado.HYM_scaffold_70.gff.gene unc_oases_trans.55.exo.gff.gene


Calculates advanced stats on how different two GFFs are and removes the overlapping ones too


';

}


my $in1 = shift;
my $in2 = shift;


# Make gene-only files
#

system "cat $in1 | grep -w gene > $in1.gene";
system "cat $in2 | grep -w gene > $in2.gene";


#print  "\n\nRunning overlapper on comparator...     perl ~/bin/perl/gff_overlap_finder.pl $in2.gene \n";
system  "perl ~/bin/perl/gff_overlap_finder.pl $in2.gene";
system  "perl ~/bin/perl/gff_overlap_finder.pl $in1.gene";


# Make overlap agp

# open (AGP, "<$in2.gene.stats") or die 'Cant find temp-file $in2.gene.stats';

#foreach my $lin (<AGP>) {
#    chomp $lin;
#    my @arr =split (/\s+/, $lin);
#}


# check overlaps



system "~jit/bin/BEDTools-Version-2.12.0/bin/intersectBed -b $in2.gene -a $in1.gene -wao > temp.$in2.wao";
#print "\n\nRunning overlapper to ref...  ~jit/bin/BEDTools-Version-2.12.0/bin/intersectBed -b $in2.gene.out -a $in1.gene -wao > temp.$in2.wao\n ";


#print  "\n\nParsing overlaps...  \n";


 open (IN, "<temp.$in2.wao") or die 'Cant find temp-file temp.$in2.wao - bedtools did not work';
 open (OUT, ">$in1\_VS\_$in2.res") or die 'Cant make file $in1\_VS\_$in2.res';

  my @in = <IN>;

print OUT  "Scaffold\tSource_1\tSource_2\tGene_1_start\tGene_1_end\tGene_2_start\tGene_2_end\tTot_length\tOverlap\t%\tGene_1\tGene_2\n";

foreach my $line (@in) {
    
    chomp $line;
    my @arr =split (/\t+/, $line);


    my $len1 = $arr[4]-$arr[3] ;
    my $len2 = $arr[13]-$arr[12] ;

    my $min2 = ( $arr[3] , $arr[12]  )[ $arr[3] > $arr[12] ];
    my $max2 = ($arr[4], $arr[13]  )[$arr[4] < $arr[13]];

    my $totlen = $max2 - $min2  ;
    my $ovl = $arr[18];
    my $ovlpro = sprintf( "%.2f" , (100*($ovl/$totlen))) ;



    unless ($arr[9]=~/\./ and $arr[10]=~/\./ ) {
        #print "$arr[8]\t$arr[17]\n";
        #print "$arr[9]\t$arr[10]\t$arr[11]\t$arr[12]\n";
        #print  "$arr[0]\t$arr[3]\t$arr[4]\t$arr[12]\t$arr[13]\t$totlen\t$ovl\t$ovlpro\n";


        print OUT "$arr[0]\t$arr[1]\t$arr[10]\t$arr[3]\t$arr[4]\t$arr[12]\t$arr[13]\t$totlen\t$ovl\t$ovlpro\t$arr[8]\t$arr[17]\n";
    #$pre_start\t$last_end\t$min\t$max\t$totlen\t$ovl\t$ovlpro\n";

    }

}


__END__

nucmer --maxmatch -c 40 -o unc_55 unc_oases_transcripts.55.fa.sl unc_oases_transcripts.55.fa.sl 

needle     -asequence aln1    -bsequence aln2 -gapopen 10.0 -gapextend 0.5 -outfile align 



