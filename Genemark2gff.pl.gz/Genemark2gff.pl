#!/usr/local/bin/perl -w
# mz3 script for changing raw Genemarkhmm-E output to Artemis-gff

use strict;
my @newlines= '';


unless (@ARGV) {
        &USAGE;
}

my $infile = shift;
my $outfile = shift;

open (INFILE, "$infile");
open (OUTFILE, ">$outfile");
open (TEMPFILE, ">tmp");

my @input = <INFILE>;
# chomp @input;

foreach my $line (@input) {


	
	if ($line=~"CDS") {
		my ($newline, $other, $other2 )= split(/;/, $line);
			$newline=~s/gene_id /ID=/;
			$newline=~s/"//g;
			print TEMPFILE "$newline\n"; #<STDIN>;
			push (@newlines, ($newline));
	}
	else {
#	print "not$line\n";	
	}


}

system "perl ~/bin/perl/fix_children_gff4Artemis.pl tmp >$outfile";

system "rm -f tmp";



close (OUTFILE);
close (INFILE);
close (TEMPFILE);

sub USAGE {

die 'Usage: Genemark2gff.pl infile outfile
'
}




