#!/usr/bin/perl -w

use strict;

#for my $num (1,2,4,8,16,32,64,2.5,1000) { 


for my $num (9.35851889791922,8.68869903695092,9.02628467425347,10.0858727680595,9.26291455737258,9.75978211371268,7.24607953947415,6.8446327124347,6.91497242130397) {

    my $exp2 = 2**($num);
    my $log2 = log($exp2)/log(2);

    #print "Log2 $num = " . (log($num) / log(2)) . " and back " . $log2 .  " $exp2 "   . "\n"; 
	print "$num is log2, in real numbers $exp2 and then turn it back to log2 $log2\n"; 

}






