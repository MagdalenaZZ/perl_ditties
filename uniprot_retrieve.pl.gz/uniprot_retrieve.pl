#!/usr/local/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: uniprot_retrieve.pl id-list

ID-list i.e.

A0BJQ8.1
A0JNB9.1
A2AI78.1
A2TGR4.1
A2TGR5.1
A3KNW7.1


'
}


my $in = shift;
open (IN, "<$in") || die;
my @ids = <IN>;

# http://www.uniprot.org/uniprot/Q6GZX4.fasta

if (-d "$in\_fas") {
    die "Folder $in\_fas exists, I wont over-write. Remove it and restart the job\n\n rm -fr  $in\_fas \n\n ";
}

mkdir "$in\_fas";
chdir   "$in\_fas";


foreach my $id (@ids) {
    chomp $id;
    my @first = split(/\./, $id);
    system " wget \"http://www.uniprot.org/uniprot/$first[0].fasta\"";
    #print " wget \"http://www.uniprot.org/uniprot/$first[0].fasta\"\n";

}

system "cat *.fasta > $in.all.fas";

open (FAS, "<$in.all.fas") || die;


while (<FAS>) {
    
    if ($_=~/^>/) {
        my @arr = split(/OS=/, $_);
        #print "$arr[0]\n";
        $arr[0] =~s/ /|/;
        
        #my @arr2 = split(/\s+/, $arr[0]);
        #my $prod = join( " ", @arr2);
        #$prod =~s/ /|/;
        my @arr2 = split(/\|/, $arr[0]);
        $arr2[3]=~s/ $//;
        my $prod = "$arr2[1]\t\"$arr2[3]\"";

        print "$prod\n";

    }
}



__END__


###### using the java api ###################

# Getting entries for a list of accession numbers
# It is also possible to supply a list of protein identifiers.
  
print '

    // Create UniProt query service
    UniProtQueryService uniProtQueryService = UniProtJAPI.factory.getUniProtQueryService();
    
    //Create a list of accession numbers (both primary and seconday are acceptable)
    List<String> accList = new ArrayList<String>();
'


foreach my $id ($ids) {
#    accList.add("O60243");
#    accList.add("Q8IZP7");
#    accList.add("P02070");
    print "accList.add("$id");";
}

print '
    //Isoform IDs are acceptable as well 
    accList.add("Q4R572-1");
    //as well as entry IDs 
    accList.add("14310_ARATH");
    
    Query query = UniProtQueryBuilder.buildIDListQuery(accList);
    
    EntryIterator<UniProtEntry> entries = uniProtQueryService.getEntryIterator(query);
    for (UniProtEntry entry : entries) {
        System.out.println("entry.getUniProtId() = " + entry.getUniProtId());
    }
    

'


