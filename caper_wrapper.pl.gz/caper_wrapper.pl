#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >1) {
        &USAGE;
}


sub USAGE {

die 'Usage: caper_wrapper.pl input.table input.phylogeny

Takes a table with values to correlate, and prints it


Like this:

<TAB>   Taxa1   Taxa2   Taxa3
Xaxis   1       1       3
Yaxis1  5       3       9
Yaxis2  1       7       8
Yaxis3  2       2       6

The values will be log-transformed so there must not be any 0-values
Weird characters in any labels may cause crashes
There must be no line with no variation in the characters


'
}

# format

my $in = shift;
my $phy = shift;
chomp $phy;

my $out = "$in" . ".R";
open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;

open (PHY, "<$phy") || die "I can't open $phy\n";
my @phy = <PHY>;
open (OUT, ">$out") || die "I can't open $out\n";





# Get all the value lines

# Print the header and the tree


print OUT '


library("caper")


myphy <- read.tree(text=\'';
print  OUT  @phy;
print   OUT  '\')   

';


# read in the data


# read in taxa header

my $h = shift(@in);
chomp $h;
$h=~s/\t/","/g;
$h=~s/Hcon_Schwarz/HconS/;
$h=~s/Hcon_Laing/HconL/;
$h=~s/Egra_Zheng/EgraZ/;
$h=~s/GO ID//;
$h=~s/","/Phylo.data <- data.frame(\ntaxa=c(\"/;
#print "$h\"),\n";

# read in x variable

my $x = shift(@in);
chomp $x;
$x=~s/GO:/GOXX/;


my @arrx = split(/\t/, $x);
$x=~s/\t/,/g;
$x=~s/,/=c(/;

#print "$x),\n";
#print "$x\n"; <STDIN>;

foreach my $line (@in) {
    chomp $line;
    my $y = $line;
    $y=~s/GO:/GOXX/;
    $y=~s/\-/zzzz/g;
    $y=~s/\_/qqq/g;
    my @arr = split(/\t/, $y);
    $y=~s/\t/,/g;
    $y=~s/,/=c(/;
    $y=~s/^/X/;

    # for binom
#    $y=~s/=c\(/=c("/;
#    $y=~s/,/","/g;
#    $y = $y . "\"";
    #print "$y\n";
    # for binom


    print  OUT  "$h\"),\n";
    print  OUT  "$x),\n";
    print  OUT "$y))\n";
    print  OUT "\n\n";

    $arr[0]= "X" . "$arr[0]";
        
    # Make a dataframe
    print  OUT "Phylo <- comparative.data(myphy, Phylo.data, taxa, vcv=TRUE, vcv.dim=3)\n";

    # now do the tests
    # without log
    #print  OUT " mod <- pgls( $arrx[0] ~ $arr[0] , Phylo  , lambda=\'ML\', kappa=\'ML\', delta=\'ML\') \n";

    # with log
    #
#    print  OUT " mod <- pgls($arrx[0] ~ log($arr[0]) , Phylo  , lambda=\'ML\', kappa=\'ML\', delta=\'ML\') \n";
#    print  OUT " mod <- pgls($arrx[0] ~ log($arr[0]) , Phylo ) \n";

#    print  OUT " mod <- pgls(log($arrx[0]) ~ log($arr[0]) , Phylo  , lambda=\'ML\', kappa=\'ML\', delta=\'ML\') \n";
#    print  OUT " mod <- pgls(log($arrx[0]) ~ log($arr[0]) , Phylo  , lambda=\'ML\', kappa=\'ML\') \n";

# to phylogeny
   print  OUT " mod <- pgls( log($arr[0]) ~ 1 , Phylo  , lambda=\'ML\', kappa=\'ML\', delta=\'ML\') \n";
#    print  OUT " mod <- pgls( $arr[0] ~ 1 , Phylo  , lambda=\'ML\', kappa=\'ML\', delta=\'ML\') \n";



#    For binary values
#    print  OUT "     perisso <- comparative.data(myphy, Phylo.data, taxa) \n";
#    print  OUT "     perisso  \n";
#    print  OUT "     mod <- brunch($arrx[0] ~ $arr[0], data=perisso, robust = Inf)\n";


    print  OUT "summary(mod)\n\n";
}


#__END__

system "R CMD BATCH  $in" . ".R"; wait;


close(IN);
close(OUT);

open (IN2, "<$in.Rout") || die "I can't open $in.Rout\n";
#my @in2 = <IN2>;
open (OUT2, ">$in.res") || die "I can't open $in.res\n";

print OUT2 "Intercept\tEstimate\tSDErr\tt-value\tPval\tCorrelation\tEstimate\tSDErr\tt-value\tPval\n";

while (<IN2>) {
    my $ele = $_;
    chomp $ele;
    $ele=~s/  / /g;
    $ele=~s/  / /g;
    $ele=~s/\<\s+/\</g;
    $ele=~s/\s+/\t/g;
    $ele=~s/\t\t/\t/g;
    $ele=~s/\t\t/\t/g;
    $ele=~s/\t\./\./g;
    $ele=~s/\t$//;

    if ($ele=~/pgls/) {
        # discard
    }
    elsif ($ele=~/\(Intercept\)/) {
        $ele=~s/ /\t/g;
        $ele=~s/\t\t/\t/g;
        $ele=~s/\t\t/\t/g;
        $ele=~s/\t\*/\*/g;
        $ele=~s/\t$//;
        $ele=~s/\t\./\./g;

        chomp $ele;
        print OUT2 "$ele\t";
        $ele = <IN2>;
        chomp $ele;
    #}
    #elsif ($ele=~/log\(\w+\)/) {
        $ele=~s/  / /g;
        $ele=~s/  / /g;
        $ele=~s/\<\s+/\</g;
        $ele=~s/log\(//;
        $ele=~s/\)//;
        $ele=~s/X//;
        $ele=~s/zzzz/\-/g;
        $ele=~s/qqq/\_/g;
        $ele=~s/GOXX/GO:/g;
        $ele=~s/ /\t/g;
        $ele=~s/\t\t/\t/g;
        $ele=~s/\t\t/\t/g;
        $ele=~s/\t\*/\*/g;
        $ele=~s/\<\t/\</g;
        $ele=~s/\<//g;
        $ele=~s/\t\./\./g;
        print OUT2 "$ele\n";
    }
    elsif ($ele=~/error/i and $ele!~/Residual/ and $ele!~/Estimate/) {
        print OUT2 "WARNING: $ele\n";
    }
    else {
        # discard
    }

}


exit;


