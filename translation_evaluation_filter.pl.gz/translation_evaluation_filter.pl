#!/usr/bin/perl
use strict;
use Data::Dumper;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl translation_evaluation.pl  query.fasta  db.fasta  blast-output-tabular <pid_cutoff>

Do a BLASTsearch, and then this program will count up the amount of similarity between those files.

It will output some key statistics, and a table of all the best hits

To filter blast results by percent id enter cut off, for no filter enter 0


';

}


# catch the 3 input arguments in variables

my $query = @ARGV [0];
my $db =  @ARGV [1];
my $blast = @ARGV [2];
my $pid_cut = @ARGV [3];

#Usage: faidx <in.fasta> [<reg> [...]]
# Make faidx files from the $query and the $db by system call to "samtools faidx"

system "samtools faidx $query";
system "samtools faidx $db";


# Read in the output from faidx, and store it in two hashes

###########entering in qry id and length from fai###########

my %q_lens;  #  $q_lens{ ID } = length
my %db_lens;  #  $db_lens{ ID } = length

#go through each line and make array split on tabs

unless (open (QRY, "$query.fai")) {
	print "Can't open $query.fai\n";
}

my @qry_fai = <QRY>;

foreach my $qry_fai (@qry_fai) {
	my @entry = split (/\t/, $qry_fai); 
	#array 0 goes to ID, 1 to length
	$q_lens { $entry[0] } = $entry[1];
}

close (QRY);

###########entering in db id and length from fai###########

unless (open (DB, "$db.fai")) {
	print "Can't open $db.fai\n";
}

my @db_fai = <DB>;

foreach my $db_fai (@db_fai) {
    chomp $db_fai ;
	my @entry = split (/\t/, $db_fai); 

	#array 0 goes to ID, 1 to length
	$db_lens { $entry[0] } = $entry[1];
}

close (DB);


# Parse the blast-output

    # make sure you only get the best hit and store in the hash

my %bla;
my %seen;

my $filt_entry = shift;
unless (open (BLAST, "$blast")) {
	print "Can't open $blast\n";
}
print "reading in blast_file\n";
my @b_out = <BLAST>;


foreach my $b_out (@b_out) {
    chomp $b_out;
    #print "$b_out\n";
    my @entry = split (/\t/, $b_out);
    if ( $entry[2] > $pid_cut) {

        # check if it has been seen before
        if (exists  $seen{"$entry[0]"}   ) {
            # has been seen before, check if it is right match
            if (exists $bla{ "$entry[0] $entry[1]"  }) {
                $bla{ "$entry[0] $entry[1]"  } { $b_out } = 1;
            }
            else {
                # this is a hit on a different gene so can be ignored
            }
        }
        # has not been seen, so first hit is added
        else {
            $bla{ "$entry[0] $entry[1]"  } { $b_out } = 1;
            $seen{"$entry[0]"} = 1;
        }

    }
}


my %bla2;

# Desciding the coverage of the hits

foreach my $key ( keys %bla) {

    foreach my $key2 ( keys %{$bla{$key}}) {
        #print "qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore\n$key2\n";
        my @arr = split( /\s+/ ,$key2 );
        my $qstart = $arr[6];
        my $qend = $arr[7] ;
        my $sstart = $arr[8];
        my $send = $arr[9];

        if (exists $bla2{ $arr[0]} ) {
            #print "Exists: $key\t$bla2{$key}\n";
            #my $max = ($x, $a)[$x < $a];
            my @arr2 = split( /\s+/ ,$bla2{$key}  );
            my $eqstart = $arr2[0];
            my $eqend = $arr2[1] ;
            my $esstart = $arr2[2];
            my $esend = $arr2[3];
            
            my $min_qs = ($qstart, $eqstart)[$qstart > $eqstart];
            #print "Min of $qstart and $eqstart is $min_qs \n  ";
            my $min_ss = ($sstart, $esstart)[$sstart > $esstart];
            #print "Min of $sstart and $esstart is $min_ss \n  ";
            my $max_qe = ($qend , $eqend)[$qend < $eqend];
            my $max_se = ($send , $esend)[ $send < $esend];
            #print "Max of $send  and $esend  is $max_se \n  ";
            $bla2{ $arr[0]} = "$min_qs\t$max_qe\t$min_ss\t$max_se";
        }
        else {
            #print "Making: $key\n";
            $bla2{ $arr[0] } = "$qstart\t$qend\t$sstart\t$send";
        }
    }


}





# comparing the coverage with the length of the reference 
foreach my $elem ( sort keys %bla2 ) {
    my @arr = split(/\s+/, $elem);
    my @arr2 = split(/\s+/, $bla2{$elem});

    #print "$arr[0]\t$arr[1]\t$bla2{$elem}\n";
    my $db_len = $db_lens { $arr[1] };
    my $q_len =	$q_lens { $arr[0] };


    my $db_hit = ($arr2[3] - $arr2[2]);
    my $q_hit = ($arr2[1] - $arr2[0]) ;
    #print "$db_len\t$q_len\t$db_hit\t$q_hit \n";
    
}

my $tot_len;
my $hit_len;

foreach my $elem ( keys %q_lens  ) {

    if (exists $bla2{$elem} ) {
        #print "Hit\n";
        my @arr2 = split(/\s+/, $bla2{$elem});
        $hit_len += ($arr2[1] - $arr2[0]);
        $tot_len +=	$q_lens{ $elem };
        #print "$hit_len\n";
        #print "$tot_len\n";
    }
    else {
        #print "No hit\n";
        $tot_len +=	$q_lens{ $elem };
        #print "$tot_len\n";
    }


}

my $ave =  ($hit_len/$tot_len)*100 ;


print "\n\nThe query is $tot_len bp/aa long, and the hits over $pid_cut cover $hit_len bp/aa\nAverage coverage is $ave % \n\n  ";




