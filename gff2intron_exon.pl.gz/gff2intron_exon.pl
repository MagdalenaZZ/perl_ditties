#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/gff2intron_exon.pl file.gff




';

}


my $in = shift;
my $out = $in . ".stats";

open (IN, "<$in") or die "Cant find infile $in\n" ;

my @in=<IN>;





my $ll_plus=0;
my $ll_minus=0;
my $le=0;

#push(@in,"gene\tgene\tgene\tgene\tgene\tgene");
my @introns;
my @intergenic;


foreach my $el (@in) {
	chomp $el;
    #tr/=/ /;
    #print "$el\n";

	my @arr = split (/\s+/, $el);

    #print "$arr[6]\n";
    if ($arr[2]=~/gene/) {
        if ($ll_plus>0 and $arr[6]=~/\+/) {
            my $intergen = $arr[3]-$ll_plus;
            push (@intergenic,$intergen);
            #print "IG plus $intergen\n";
            $ll_plus = $arr[4];
            $le=0;
        }
        elsif ($ll_minus>0 and $arr[6]=~/\-/) {
            my $intergen = $arr[3]-$ll_minus;
            push (@intergenic,$intergen);
            #print "IG minus $intergen\n";
            $ll_minus = $arr[4];
            $le=0;
        }


        else {
            if ($arr[6]=~/\+/) {
                $ll_plus = $arr[4];
            }
            elsif ($arr[6]=~/\-/) {
                $ll_minus = $arr[4];
            }
        }
    
    }
    elsif ($arr[2]=~/exon/ or $arr[2]=~/CDS/) {
        if ($le>0) {
            my $intron =  $arr[3]-$le;
            push (@introns,$intron);
            $le = $arr[4];
            #print "intron\n";


        }
        else {
            $le = $arr[4];
        }

        
        
    }
    else {
        #
    }


}




# fix last element

open (OUT, ">$out.introns") or die "Cant find infile $out.introns\n" ;


foreach my $ele (@introns) {
    unless ($ele=~/-/) {
        print OUT "intron\t$ele\n";
    }
}
close (OUT);

open (OUT, ">$out.intergenic") or die "Cant find infile $out.intergenic\n" ;


foreach my $ele (@intergenic) {
    unless ($ele=~/-/) {
        print OUT "intergenic\t$ele\n";
    }
}

close (IN);
close (OUT);


=pod

foreach my $ele (@res) {
    print OUT "$ele\n";
}
   
print "Exon count: $counter\n\n";
close (IN);
close (OUT);

=cut






