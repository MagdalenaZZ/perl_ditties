#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_sorter.pl infile.gff outfile

May cause problems with incorrectly formattted genes

Check that the file before and after sorting are exactly equal size



'
}


	my $in = shift;
	my $out = "temp2";
	my $out3 = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

### split the file in enough columns

    my(@AoA, @tmp);


foreach my $line (@in) {
chomp $line;

my @array=split(/\t/,$line);
$line = join ("\t",@array[0..8]);
$line =~s/_/\t/;
$line =~s/_/\t/;
$line =~s/_/\t/;
$line =~tr/=/\t/;
$line =~tr/\:/\t/;
$line =~tr/\;/\t/;

my $arrlength= ( scalar(@array) - 1) ;
my $line2 =  join ("_", @array[9..$arrlength] );
chomp $line2;
$line2=~s/ $//;
 print "$line\n";
 print "$line2\n";
$line = "$line"  . "\t" . "$line2";

my @tmp = split(/\t/, $line);

# move into an array
        push @AoA, [ @tmp ];
}

# change lines in the array
for (my $i = 0; $i < @AoA; $i++) {
	$AoA[$i][5] =~ s/gene/Agene/;
	$AoA[$i][5] =~ s/mRNA/BmRNA/;
	$AoA[$i][5] =~ s/transcript/Btrancript/;
}


# sort the array
 my @st = sort tableSorter @AoA;

# print Dumper(@sorted_table);
	open (TMP, ">temp") || die "I can't open temp\n";
#	my @final = <TMP>;

for (my $i = 0; $i < @st; $i++) {
# takes the whole a of a
     for (my $j = 0; $j < @{$st[$i]}; $j++) {
	print TMP $st[$i][$j]. "\t";
     }
print TMP "\n";
}

close (TMP);
__END__
################################################################

	open (TMP2, "<temp") || die "I can't open temp\n";
	my @fix = <TMP2>;

my @final;

foreach my $line (@fix) {

	my @arr = split(/\t/, $line);
	my $pathogen = $arr[0];
	my $EMU= $arr[1];
	my $cont= $arr[2];
	my $contno= $arr[3];
	my $method= $arr[4];
	my $gene= $arr[5];
	$gene =~s/Agene/gene/;
	$gene =~s/BmRNA/mRNA/;
	$gene =~s/Btranscript/transcript/;
	my $start= $arr[6];
	my $end= $arr[7];
	my $dot= $arr[8];
	my $ori= $arr[9];
	my $dot2= $arr[10];
	my $id= $arr[11];
	my $name= $arr[12];
	my $parent= $arr[13];
	my $newline=0;

    my $arrlength= ( scalar(@arr) - 1) ;
    #   print "ARR:$arrlength\n";
	if ($gene =~m/gene/) {
        if ($arrlength > 13) {
        my @subarr = @arr[13..$arrlength];
        my $annot = join(" ", @subarr);
        chomp $annot;
#        print "sub:$annot\n";
        $newline="$pathogen\_$EMU\_$cont\_$contno\t$method\t$gene\t$start\t$end\t$dot\t$ori\t$dot2\t$id\=$name\t$annot";
        }
        else {
		$newline="$pathogen\_$EMU\_$cont\_$contno\t$method\t$gene\t$start\t$end\t$dot\t$ori\t$dot2\t$id\=$name";
        }
	}
	if ($gene =~m/transcript|mRNA/) {
		$newline="$pathogen\_$EMU\_$cont\_$contno\t$method\t$gene\t$start\t$end\t$dot\t$ori\t$dot2\t$id\=$name\;$parent\=$arr[14]";
	}

	if ($gene =~m/CDS|exon/) {
		if ($name =~m/EmW/) {
		 $newline="$pathogen\_$EMU\_$cont\_$contno\t$method\t$gene\t$start\t$end\t$dot\t$ori\t$dot2\t$id\=$name\:$parent\:$arr[14]\;$arr[15]\=$arr[16]";
		}
		elsif ($name =~m/g/) {
		$newline="$pathogen\_$EMU\_$cont\_$contno\t$method\t$gene\t$start\t$end\t$dot\t$ori\t$dot2\t$id\=$name\:$parent\:$arr[14]\;$arr[15]\=$arr[16]";
		}
	}
	push ( @final,$newline);
}
	close (TMP2);

	open (OUT1, ">$out") || die "I can't open $out\n";

foreach my $elem (@final) {
    chomp $elem;
	print OUT1 "$elem\n";
}
	close (OUT1);

############################## sort the genes ################

	open (OUT2, "<$out") || die "I can't open $out\n";
	my @hashfix = <OUT2>;
	close (OUT2);

	open (OUT3, ">$out3") || die "I can't open $out3\n";

### make a hash with gene-names

my %hash;
my $last_line=0;
my $very_last_line=$hashfix[-1];

push (@hashfix, "END\tEND\tEND\tEND");

foreach my $line (@hashfix) {
	chomp $line;

	my @arr = split(/\t/, $line);
	my $lead = "$arr[3]";
#	unshift(@arr, "$lead"); 
	my $newline = "$lead\t$line";
	my @last_arr = split(/\t/, $last_line);
#	print "Arr $arr[0]\n";
#	print "Last $last_arr[0]\n";
	my $first_gene="START\tSTART\tSTART\tSTART";

# Test if we are still on the same contig
	if ($arr[0] =~/$last_arr[0]/) {
#		print "Match\n";
		my ($key, $oa, $ob, $oc, $od)= split(/([:;])/,$arr[8]);
#		print "Key $key\n";
#		unshift(@{$hash{$key}}, $lead);	

# Test if the first value already exists	
		if ($hash{$key}[0]) {
# Replace the value if there is a new lower value
			unless ($hash{$key}[0] <= $lead){
				$hash{$key}[0] = $lead;
			}
#			print "IF: Key1 $key \n" . "value1 $newline\n";		
		}
# or put a new value
		else {	
			push(@{$hash{$key}}, $lead);
#			print "ELSE: Key1 $key \n" . "value1 $lead\n";
		}

		push(@{$hash{$key}}, $newline);
#		print "Key2 $key \n" 
#		print "NEW:$newline\n";		
	}


# Now we are on a new contig - time to print everything we caught in the hash

	else {

	#Here I have to add the first value from the new contig
		unless ($line=~/END/) {
			my ($key2, $oa, $ob, $oc, $od)= split(/([:;])/,$arr[8]);
#			$key2=~s/ID=//;
#			push(@{$hash{$key2}}, $newline);
#			print "Key2: $key2\n";
#			print "Val: $newline\n";
			$first_gene=$newline;
		}
#	print "All well\n";

# FOREACH LOOP to sort the values
		foreach my $key (sort {$hash{$a}[0] <=> $hash{$b}[0] }  keys %hash) {
#	 		 print "Value $key $hash{$key}[0]\n";
			foreach my $i (@{$hash{$key}}) {
# here I have lost the first value	
                if ($i=~/w+/) {
                my @x =split(/\s+/, $i);
                # print "$x[3]\n";	
				    $x[3]=~s/gene/Age/;
				    $x[3]=~s/mRNA/BmR/;
				    $x[3]=~s/transcript/Btran/;
                     $i = join("\t", @x);
                     #  print "NEW:$x[3]\n";
                }
			}

				my @sort = sort {(split/\t/, $a)[0] <=> (split/\t/, $b)[0]} (@{$hash{$key}});
#					print ":$sort[0]:\t:$sort[1]:\n";
					shift @sort;
					my $scalar = scalar(@sort);
					my $first1 = $sort[0];
#					print "Scalar:$scalar:\t:$first1:\t:$sort[1]:\n";
					if ($sort[0]) {
						foreach my $line2 (@sort) {
							chomp $line2;
#							print "LINE2: $line2:\n";
							if ($line2=~/pathogen/) {
#								print "Line2: $line2:\n";
								my @final= split (/\t/, $line2);
								shift @final;
								$final[2]=~s/Age/gene/;
								$final[2] =~s/BmR/mRNA/;
								$final[2] =~s/Btran/transcript/;	
								my $final = join ("\t",@final);
                                $final=~s/ $//;
                                $final=~s/\"\_\//\"\t\//g;
								print OUT3 "$final\n";
#								print "Final: $final:\n";<STDIN>;
							}
						}
					}
					else {
						print "Funny line: $sort[0]\n:";
					}
		}

	# Empty the hash
		foreach my $key  (keys %hash) {
			delete $hash{$key};
		}	

	# Add the first value to the new hash
		unless ($first_gene=~/START/) {
#			print "First: $first_gene\n";
			my @first=split(/\t/, $first_gene);
#			print "First Key: $first[9]\n";
			push(@{$hash{$first[9]}}, $first[0]);
			push(@{$hash{$first[9]}}, $first_gene);
		}
	
	}

$last_line=$line;

}


close (OUT3);


 system "rm -f temp";
 system "rm -f temp2";


##################################################################################
##################################################################################


 sub tableSorter ($$) {
     my($row1, $row2) = @_;
     
     my $column1comparison = $row1->[2] cmp $row2->[2];
     if($column1comparison != 0){
         return $column1comparison;
     }
     
     my $column2comparison = $row1->[3] <=> $row2->[3];
     if($column2comparison != 0){
         return $column2comparison;
     }
  
       my $column6comparison = $row1->[6]  <=> $row2->[6];
     if($column6comparison != 0){
         return $column6comparison;
     }

       my $column12comparison = $row1->[12] cmp  $row2->[12];
     if($column12comparison != 0){
         return $column12comparison;
     }

       my $column5comparison = $row1->[5] cmp $row2->[5];
     if($column5comparison != 0){
         return $column5comparison;
     }


   return $row1->[0] cmp $row2->[0];
 }


__END__
