#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_primers.pl blatout.psl file.fasta

Takes a blat-output, and retrieves the hits from a fasta file.

Then moves the primers 


Warning: psl-files should have no header


' . "\n";
}


##
=pod
This is the "smartbell" adapter:

ATCTCTCTCTTTTCCTCCTCCTCCGTTGTTGTTGTTGAGAGAGAT
=cut
##

my $blat = shift;
my $fastq1 = shift;
my $fastq2 = shift;


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        if ($arr[0]> 11 and $arr[1] < 2 ) {
        #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]" ; 
                # make a hit-match
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}


#__END__
# read the fasta-files line by line, and print the reads with a match to another file


# remove low-complexity sequence
#
system " perl ~/bin/perl/fastn_trim_poly-A.pl 200 70  reads_of_insert.fasta.100";

open(FAS1, "$fastq1.200.70.no_polyA" ) || die "can't open $fastq1.200.70.no_polyA";



open (OUT, ">$fastq1.blat_chosen.fasta")|| die;
open (OUTC, ">$fastq1.no_blat_chosen.fasta")|| die;

#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/^>//;
        #$head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "$_";
            my $seq = <FAS1>;
            print OUT "$_$seq";
            #print "$_$seq";
        }
        else {
            my $seq = <FAS1>;
            #print "NOHIT $_$seq";
            print OUTC "$_$seq";
        }
    }
}


close (FAS1);
close (OUT);
close (OUTC);


#__END__

# read in the temp-fastqs, and trim them according to the best BLAT-hit


open (IN1, "<$fastq1.blat_chosen.fasta")|| die;
open (OUT1, ">$fastq1.trimmed.fasta")|| die;
open (OUT2, ">$fastq1.dunno.fasta")|| die;
open (OUT3, ">$fastq1.rejected.fasta")|| die;
open (OUT4, ">$fastq1.primers.fasta")|| die;


while (<IN1>) {

    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/^>//;
        #$head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";

        # a blast-hit exists for that seq
        if (exists $blat{$head}) {
            #print "hit $_";
            my $seq = <IN1>;
            chomp $seq;

            # split the seq
            my ($min,$max) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            my $seqlen = length($seq);
            my $new_seq1 = substr($seq, 0, $min);
            my $new_seq2 = substr($seq, $min, $len);
            my $new_seq3 = substr($seq, $max, -1);
            my $len1 = length($new_seq1);
            my $len2 = length($new_seq2);
            my $len3 = length($new_seq3);

            # Check which case it is





            if ($len3 < 100 and $len1 < 100 ) {
                #print "case1 - funnily enough there are two polyA tails\n";
                #print "1:$head\n$seq:\n";
                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                #print "3:$new_seq1\n:$new_seq2:\n:$new_seq3\n";

                # trim away both sides and output one orientation
                if ( $new_seq2=~/TTTT\w+AAAA/ ) {
                    my @arr=split(/TTTT/,$new_seq2);
                    shift @arr;
                    my $ns1 = join("TTTT", @arr);
                    #$ns1=~s/^TTTTTTTTTTT//g;
                    #$ns1=~s/^TTTTTTT//g;
                    #$ns1=~s/^TTTTT//g;
                    #$ns1=~s/^T//g;
                    $ns1=revcomp($ns1);
                    @arr=split(/TTTT/,$ns1);
                    shift @arr;
                    $ns1 = join("TTTT", @arr);
                    #$ns1=~s/^TTTTTTTTTTT//g;
                    #$ns1=~s/^TTTTTTT//g;
                    #$ns1=~s/^TTTT//g;
                    #$ns1=~s/^TT//g;
                    $ns1=revcomp($ns1);
                    print OUT1 ">$head\_1\n$ns1\n";
                    print OUT4  ">$head\_1\n$new_seq1\n";
                    print OUT4  ">$head\_1\n$new_seq3\n";
                }
                else {
                    print OUT4  ">$head\_1\n$new_seq2\n";
                    print OUT4  ">$head\_1\n$new_seq1\n";
                    print OUT4  ">$head\_1\n$new_seq3\n";

                }

            }
            elsif ($len3 < 10 ) {
                #print "case2 - forward strand\n";
                print OUT1 ">$head\_2_has_uncut_primer_start\n$new_seq1\n";
                    print OUT3  ">$head\_2\n$new_seq2\n";
                    print OUT3  ">$head\_2\n$new_seq3\n";
            }
            elsif ($len1 < 10 ) {
                #print "case3 - reverse strand\n";
                $new_seq3=revcomp($new_seq3);
                print OUT1 ">$head\_3_has_uncut_primer_start\n$new_seq3\n";
                print OUT3  ">$head\_3\n$new_seq1\n";
                print OUT3  ">$head\_3\n$new_seq2\n";

            }
            elsif ( ($len3+$len2) < $len1 ) {
                #print "case4 - forward 2\n";
                print OUT1 ">$head\_44_has_uncut_primer_start\n$new_seq1\n";
                print OUT3  ">$head\_4\n$new_seq2\n";
                print OUT3  ">$head\_4\n$new_seq3\n";

            }
            elsif ( ($len1+$len2) < $len3 ) {
                #print "case5 - reverse 2\n";
                $new_seq3=revcomp($new_seq3);
                print OUT1 ">$head\_5_has_uncut_primer_start\n$new_seq3\n";  
                print OUT3  ">$head\_5\n$new_seq1\n";
                print OUT3  ">$head\_5\n$new_seq2\n";

            }

            elsif ( $len2 < $len1  ) {
                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                #print "case6 - The poly-A tail is funnily enough in the middle\n";
                # the middle is the shortest bit
                #
                #print "1:$head\n$seq:\n";
                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                #print "3:\t$len1\t$len2\t$len3:\n";
                #print "4:$new_seq1\n:$new_seq2:\n:$new_seq3\n";
                #print "4:$new_seq2\n";
                my $primer_n_polyA = $new_seq2;
                # the primer can either have a polyA start, or a poly T finish
                # some have both
                if ($primer_n_polyA=~/^AAAAA/ and $primer_n_polyA=~/TTTTT$/ ) {
                    #print "Goes both ways - split\n";
                    $new_seq3=revcomp($new_seq3);
                    print OUT1 ">$head\_61\n$new_seq1\n";
                    print OUT1 ">$head\_62_has_uncut_primer_start\n$new_seq3\n";
                    print OUT3  ">$head\_6\n$new_seq2\n";
                }
                elsif ($primer_n_polyA=~/^AAAAA/ ) {
                    #print "Goes forward\n";
                    print  OUT1 ">$head\_63_has_uncut_primer_start\n$new_seq1\n";
                    print  OUT1 ">$head\_64_maybe_uncut_primer_start\n$new_seq3\n";
                    print OUT3  ">$head\_6\n$new_seq2\n";
                    #print OUT3  ">$head\_6\n$new_seq3\n";

                }
                elsif ( $primer_n_polyA=~/TTTTT$/ ) {
                    #print "Goes reverse\n";
                    $new_seq3=revcomp($new_seq3);
                    print  OUT1 ">$head\_65_maybe_uncut_primer_start\n$new_seq1\n";
                    print  OUT1 ">$head\_66_maybe_uncut_primer_start\n$new_seq3\n";
                    print OUT3  ">$head\_6\n$new_seq2\n";
                }
                else {
                    print OUT2  ">$head\_6\n$new_seq1\n";
                    print OUT2  ">$head\_6\n$new_seq3\n";
                    print OUT3  ">$head\_6\n$new_seq2\n";

                }

            }

            #elsif ( ($len1+$len3) < 100 ) {

            else  {
                  
                #print "case7 - all other weird things \n";
                #my $primer_n_polyA = $new_seq2;
                #print "1:$head\n$seq:\n";
                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                #print "3:\t$len1\t$len2\t$len3:\n";
                #print "4:$new_seq1\n:$new_seq2:\n:$new_seq3\n";
                
                print OUT2  ">$head\_71\n$new_seq1\n";
                print OUT2  ">$head\_72\n$new_seq2\n";
                print OUT2  ">$head\_73\n$new_seq3\n";
                
                

            }

            #else {

                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                ########## INSERT CODE  ################
                # the middle is longer    
                #print "case7 - The poly-A tail is funnily enough in the middle\n";
                #my $primer_n_polyA = $new_seq2;
                #print "1:$head\n$seq:\n";
                #print "2:\t$min\t$len\t$max\t$seqlen:\n";
                #print "3:\t$len1\t$len2\t$len3:\n";
                #print "4:$new_seq1\n:$new_seq2:\n:$new_seq3\n";
                #}

            #else {
            #    print "Else\n";
            #    print "2:\t$min\t$len\t$max\t$seqlen:\n";
            #    print "3:$new_seq1\n:$new_seq2:\n:$new_seq3\n";
            #    #print "$_$seq\n";
            #    }


        }
        # no blast hit exists
        else {
            my $seq = <IN1>;
            print "Else2 - Warning! Should not occur\n";
            print "$_$seq\n";
        }

    }
}






close (IN1);
close (OUT1);
close (OUT2);


# fix the outputs ?



exit;



sub revcomp {
  my $dna = shift;
  my $revcomp = reverse($dna);

  $revcomp =~ tr/ACGTacgt/TGCAtgca/;

  return $revcomp;
}



