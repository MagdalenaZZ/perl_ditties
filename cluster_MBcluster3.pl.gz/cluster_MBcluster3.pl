#!/usr/local/bin/perl -w
use strict;
use Getopt::Long;

my $clust_num = 20;
my $outfile = 'out';
my $treat = 0 ;

my $go_cut = 0.01;
my $skip_clustering = 0;
my $save = 0;

my @go_class = ('BP', 'MF', 'CC');

my($help, $cdata, $rpkms, $go_file, $go_res, $go_prod  ) = ();

GetOptions (
	"h|help"	=> \$help,
	"c|counts:s"	=> \$cdata,
	"r|rpkms:s"	=> \$rpkms,
	"g|go:s"	=> \$go_file,
	"p|product-list:s"	=> \$go_prod,
	"o|out:s"	=> \$go_res,
	"n|nclust:i"	=> \$clust_num,
	"t|gocut:f"	=> \$go_cut,
	"s|skip_clust"	=> \$skip_clustering,
	"d|own_treatment_definition:s" => \$treat,
	"save"		=> \$save,

);

if($help || !$cdata || !$rpkms || !$go_file) {
	print_usage();
	exit;
}



#if(!$go_res){
#	$go_res = "results.dat";
#}


if(!$go_res){
	$outfile = "results.dat";
}
else {
    $outfile=$go_res;
}

print "d $treat\t\t default 0\n";

print "RPKMs $rpkms\n";
print "nclust $clust_num\n";
print "s $skip_clustering \t\t default 0\n";
print "c $cdata \t\t default ''\n";
print "o $outfile \t\t default 'results.dat'\n";

#__END__

open(DAT, "<$cdata") or die "$!";

my @treatment = ();
my %treatments = ();
my %data = ();
my @ids = ();

my %samples = ();
my @samples = ();

# work with the data

# Read in the counts
while(<DAT>){
	chomp;

	my($id, @cols) = split(/\t/, $_);
	#print "ID\t $id\n";

	if($id=~/^id$/ || $id=~/^ID$/ ) {
		my $c = 1;
		my $col_num = 1;
		my %seen = ();
            	#print "ID\t $_\n";

		foreach my $col (@cols){
            #my @temp =~ split(/\./, $col);
            #$col=$temp[0];
            print "col\t $col\n";

			my $treatment = $col;
            		#print "T $treatment\n";
			$samples{$col_num} = $col;
			push @samples, $col;

			if(exists $seen{$treatment}) {
				push @treatment, $seen{$treatment};
			}
			else {
				$seen{$treatment} = $c;
				push @treatment, $seen{$treatment};

				$treatments{$c} = $treatment;
				$c++;
			}

			$col_num++;
		}
	}
	else
	{
		$data{$id} = \@cols;
		push @ids, $id;
	}
}
close DAT;

#__END__


# work with the rpkms
open(RPKM, "<$rpkms") or die "Cant find file $rpkms\n$!";

my %rpkms = ();

while(<RPKM>){
	chomp;

	next if ($_=~/^id$/ || $_=~/^ID$/ );

	my($id, @cols) = split /\t/;

	my $c = 0;

	my %collection = ();

	foreach my $col (@cols){
		#push @logs, (log($col + 1) / log(2));
		push @{$collection{$treatment[$c]}}, $col;
		$c++;
	}

	my @logs = ();
	my $log_sum = 0;
	my $treat_num = 0;

	foreach my $treatment (sort {$a<=>$b} keys %collection)
	{
		my $sum = 0;
		my $n = 0;

		foreach my $val (@{$collection{$treatment}}){
            if ($val=~/^\d+$/ or $val=~/^\d+\.\d+$/ ) {
			$sum += $val;
			$n++;
            }
            else {
                #print "not number $val\n";
            }
		}

        my $mean = 0;
        unless ($sum=~/^0$/ and $n=~/^0$/ ) {
		    $mean = $sum / $n;
        }

		my $log_mean = log($mean+1) / log(2);

		push @logs, $log_mean;

		$log_sum += $log_mean;
		$treat_num++;


		#print "$id\t$log_mean\n";
	}

	my $mean_of_logs = $log_sum / $treat_num;

	foreach my $log (@logs)
	{
		my $norm_log = $log - $mean_of_logs;

		#print "$log\t$mean_of_logs\t$norm_log\n";

		push @{$rpkms{$id}}, $norm_log;
	}

}
close RPKM;



# make my own treatment string

#print "@treatment\n";
my $treat_string = join ",", @treatment;

#print "Treatment $treat_string\t$treat\n";
unless ($treat=~/^0$/) {
    $treat_string = $treat;
    print "Updated Treatment to $treat_string \nwhich should look something like 1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8,9,9,9,10,10,10\n";
}





##__END__

# Do clustering

unless($skip_clustering)
{
	cluster($cdata, $treat_string, $clust_num, $outfile);
}

print "\nClustering completed\n\n";

close RES;


sub cluster {
	my ($dat, $treat_string, $clusters, $outfile) = @_;

	my $save_string = "";

	if($save)
	{
		$save_string = "save(cls2, file=\"cls.RData\")";
	}

	open(R_CODE, ">$cdata.$clust_num.clust.R") or die "$!";

	print R_CODE "

	library(MBCluster.Seq)

	MatVar <- function(x, dim = 1) {
	  if(dim == 1){
	    rowSums((x - rowMeans(x))^2)/(dim(x)[2] - 1)
	      } else if (dim == 2) {
	        rowSums((t(x) - colMeans(x))^2)/(dim(x)[1] - 1)
          } else stop(\"Please enter valid dimention\")
	}

	Count<-read.table(\"$dat\", header=TRUE, row.names=1)
	#rpkm<-read.table(\"$rpkms\", header=TRUE, row.names=1)
	#rpkm2 <- rpkm[MatVar(rpkm, 1)>5,]
	Count <- Count[MatVar(Count, 1)>5,]
	#GeneID=row.names(rpkm2)
	GeneID=row.names(Count)

	Treatment=c($treat_string)
    	warnings()
	Normalizer=rep(1,ncol(Count))
	mydata=RNASeq.Data(Count,Normalize=NULL,Treatment,GeneID)
	c0=KmeansPlus.RNASeq(mydata,nK=$clusters)\$centers
	cls2=Cluster.RNASeq(data=mydata,model=\"nbinom\",centers=c0,method=\"EM\")
	cls=cls2\$cluster
	cls3=as.data.frame(cls2\$cluster)
	row.names(cls3) <- GeneID
	$save_string
	tr=Hybrid.Tree(data=mydata,cluster=cls,model=\"nbinom\")
	pdf(\"$outfile\.clustering.pdf\", useDingbats=FALSE)
	plotHybrid.Tree(merge=tr,cluster=cls,logFC=mydata\$logFC,tree.title=NULL)
	dev.off()

	write.table(cls3, file=\"$outfile\",sep=\"\\t\")
	#write(cls3, file=\"$outfile\",sep=\"\\n\")
	#dev.off()
    	#q(save=\"yes\")\n
    ";


	print R_CODE '

library(plyr)
Count$Category <- cls3$`cls2$cluster`
nclu <- length(levels(factor(Count$Category)))
j=1

for (j in 1:nclu) {


# Get all genes that belong to a certain category
x1<- Count[Count$Category==j,]

ds <- as.data.frame(x1[,1])
row.names(ds) <- row.names(x1)
ds$`x1[, 1]` <- row.names(ds)
colnames(ds) <- "ID"


i=1

for (i in levels(factor(Treatment))) {

    vec <- x1[,Treatment==i]
    x.m <- as.vector(apply(x1[,Treatment==i],1,mean))
    d <- data.frame(row.names(vec), x.m,row.names=row.names(vec))
    colnames(d) <- c("ID",i)
    ds <-join(ds,d,by="ID")
}

row.names(ds) <- ds$ID
ds$ID <- NULL

x<-t(ds)

row.order <-c(1,2,4,5,6,7,8,3)
x2<-as.data.frame(x[row.order,])
colnames(x2) <- colnames(x) 
x <- x2
row.names(x) <- c("HSC.Normal","HSC.MLLx","CMP.Normal","CMP.MLLx","GMP.Normal","GMP.MLLx","LMPP.Normal","LMPP.MLLx")

x.sd1 <- apply(x,1, sd)
x.mean <- apply(x, 1, mean)
losd <- x.mean - x.sd1
hisd <-  x.mean + x.sd1
x.sd <- rbind(losd,hisd)
x.sd
';
print R_CODE "
fn <- paste(\"$cdata.$clust_num.\",j,\".clu.pdf\", sep=\"\")\n";


print R_CODE '
pdf(file=fn, useDingbats=FALSE)
plot(x=levels(factor(Treatment)),y=apply(x,1,mean),ylim=c(min(x),max(x)),type="n",xaxt="n",xlab="Lifecycle stage",ylab="Normalised log fold expression change")
axis(side=1, at=seq(1,length(row.order)),labels=row.names(x), las=1)
apply(x,2,function(x) { lines(x,lwd=1,col=sample(colours())) } )
polygon(x=c(1:length(row.order),length(row.order):1),y=c(x.sd[1,],rev(x.sd[2,])),col=rgb(0.1,0.1,0.1,0.1), border=NA)
lines(apply(x,1,mean), col = "black", lwd=4)
dev.off()

	';

print R_CODE "
fn <- paste(\"$cdata.$clust_num.\",j,\".clulog2.pdf\", sep=\"\")\n";


print R_CODE '

x <- apply(x, 2, log2)
x[x=="-Inf"]<-0
x.sd1 <- apply(x,1, sd)
x.mean <- apply(x, 1, mean)
losd <- x.mean - x.sd1
hisd <-  x.mean + x.sd1
x.sd <- rbind(losd,hisd)
x.sd

pdf(file=fn, useDingbats=FALSE)
plot(x=levels(factor(Treatment)),y=apply(x,1,mean),ylim=c(min(x),max(x)),type="n",xaxt="n",xlab="Group",ylab="Normalised log fold expression change")
axis(side=1, at=seq(1,length(row.order)),labels=row.names(x), las=1)
apply(x,2,function(x) { lines(x,lwd=1,col=sample(colours())) } )
polygon(x=c(1:length(row.order),length(row.order):1),y=c(x.sd[1,],rev(x.sd[2,])),col=rgb(0.1,0.1,0.1,0.1), border=NA)
lines(apply(x,1,mean), col = "black", lwd=4)
dev.off()

}
	';



	close (R_CODE);

      #system("R --no-save < $cdata.$clust_num.clust.R") == 0 or die "$!";
      system "R --no-save < $cdata.$clust_num.clust.R";
      print "\n R CMD BATCH $cdata.$clust_num.clust.R >  $cdata.$clust_num.clust.Rout\n\n";
      #exit;

}


sub print_usage 
{
	print <<USAGE;

	# cluster_expression.pl

	Mandatory:
	"c|counts:s"	Read counts for each gene (see below for format)
	"r|rpkms:s"	RPKMs for each gene (see below for format)
	"g|go:s"	GO annotations (see below for format)

	Optional:
	"h|help"	Help
	"o|out:s"	Outfile for cluster descriptions
	"n|clust:i"	Number of clusters (20)
	"t|gocut:f"	Cutoff q-value for go term enrichment (default: 0.05)
	"s|skip_clust"	Skip clustering
	"save"		Save clustering object as cls.RData

	# Read count/RPKM file format
	n.b. Header format for count/RPKM data should include timecourse/treatment
	info in the following format: <treatment>.<unique_id> e.g. J2.1234_1 where
	J2 is the treatment and 1234_1 is the lane id. So J2.1234_1 and J2.4321_1
	will be interpreted as biological replicates. this line should also begin
	"id" for the gene id column:

	id	J2.1234_1	J2.4321_1	J4.2345_2	J4.5432_1
	GeneA	12	43	1000	2000
	GeneB	45	90	3	1

	# Go annotation file format
	<Id>\t<go1,go2,go3,go4...>

USAGE

}


exit;


__END__


