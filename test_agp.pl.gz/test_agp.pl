#!/usr/local/bin/perl -w
# mz3 script for running GlimmerHMM on contigs in different folders


    my $agp_file =shift;
    my $input_fasta =shift;


open (AGP, "<$agp_file");
open (FASTA, "<$input_fasta");

my @mergers = <FASTA>;
my @agp = <AGP>;



close (FASTA);
close (AGP);

my $index=0;

foreach my $line (@agp) {


# for ($index=0, $index<scalar(@agp), $index++ ) {

if (scalar(@mergers)> 0) {

my ($scaffold1, $scaffold2, $merger) = split ( /\t/, $mergers[0]);
chomp $merger;
		if ($line=~/$scaffold1/) {
#		print $agp[$index+1];
			shift (@mergers);
			print "$line";
#			print "Match next_line:\t$agp[$index+1]";
			my $newline = $agp[$index+1];
			my ($s1, $s2, $s3, $s4, $s5, $s6, $s7, $s8)= split (/\s+/, $newline);
			my $newline2 = "$s1\t$s2\t$s3\t$s4\tW\t$merger\t1\t$s6\t+\n";
			print "$newline2";
			shift (@agp);
		}
		else {
#		print "Else:\t$line\n";
			print "$line";
		}



}

else {
#print "Else3\n";
print "$line";
}

$index++;
# print "$index\n";
}

=pod

perl ~/bin/perl/test_agp.pl scaffold00002.agp mergers.list


