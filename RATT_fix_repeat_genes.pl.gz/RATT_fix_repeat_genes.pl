#!/usr/local/bin/perl -w
# mz3 script 

use strict;
use Cwd;
use File::Slurp;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: RATT_fix_repeat_genes.pl folder 

Works on standard embl-files output by RATT

Give it the folder which contains all embl-files you want to fix


'
}


## parse infile

my $in = shift;
my $cwd = cwd();
my @paths = read_dir( "$in", prefix => 1 ) ;


my %seen;

foreach my $file (@paths) {

    #print "$file\n";
    open (IN, "<$file");
    my @embl = <IN>;

    if (scalar(@embl) < 1) {
        next;
    }
    open (OUT, ">$file.fixed.embl") || die "Cant open file $file.fixed.embl \n";


    foreach my $ele (@embl) {
        chomp $ele;
        #print "$ele\n";

        if ($ele=~/\/locus_tag=\"/) {

            # ignore the RNAs
            if ($ele=~/rfamscan/) {
                print OUT "$ele\n";
            }
            else {
                #print "LOC\t $ele\n";
                my $ori_ele=$ele;
                $ele=~s/\"//g;
                $ele=~s/\/locus_tag=//g;
                my ($prefix,$number) = split(/\_/, $ele);
                $prefix=~s/FT                   //;
                #print "LOC\t:$prefix\t$number\n";

                my $inc=0;
                for ( my $i=0; $i < 1000; $i++) {

                    # check if it exists and increase
                    if (exists $seen{$number}) {
                        $number++;
                        #print "$number increased\n";
                        $inc++;
                    }
                    # it doesnt exist, so use
                    else {
                        $i=1001;
                        $seen{$number}=1;
                        #print "$number confirmed\n";
                        #print "$ori_ele\n";

                        if ($inc > 0) {
                            $ori_ele=~s/locus_tag/previous_locus_tag/;
                            print OUT "FT                   \/locus_tag=\"$prefix\_$number\"\n";
                            print OUT "$ori_ele\n";
                            $inc=0;
                        }
                        else {
                            print OUT "FT                   \/locus_tag=\"$prefix\_$number\"\n";
                        }

                    }

                    #print "$ele\n";

                }


            }


        }
        else {
            print OUT "$ele\n";
        }
   
    }


    close(OUT);
    close(IN);
}


__END__


      5 LOC	 FT                   /locus_tag="HmN_000928000"
      4 LOC	 FT                   /locus_tag="HmN_000984700"
      4 LOC	 FT                   /locus_tag="HmN_000950200"





