#!/usr/bin/perl -w


use strict;
use Cwd;
use File::Slurp;

if (@ARGV < 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: KOget.pl KO_pathway_index gene_list 

Takes a list of genes and associates them with pathways


###KO_pathway_index### 
A file that looks like this:
GeneId <TAB> KOnumber  <TAB> pathway  <TAB> description

The pathway index can be constructed using KAAS and KOget.pl



NOT FISIHED !!!!


'
}

my $in = shift;
my $list = shift;




# read in the list of pathways, and unique instances of genes

open (IN, "<$in") || die "I can't open $in\n";
#    	my @in= <IN>;
#    	close (IN);

my %pws;

while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    push (@arr, "NA");
    if ($arr[2]=~/ko/) {
        $pws{"$arr[2]"}{$arr[0]}{"KO"}{$arr[1]}="$arr[3]";
        #print "$arr[0]\n";
    }
}

close (IN);

# read in the genes and associate them with pathways

open (IN2, "<$list") || die "I can't open $list\n";

my %gen;
my $tot = 0;

while (<IN2>) {
    chomp;
    #print "$_\n";
    foreach my $path (keys %pws) {
        #foreach my $path (keys %{$pws{$path}} ) {
        #print "$path\t$_\n";
            if (exists  $pws{$path}{$_}  ) {
                #print "Exists $_\n";
                $pws{$path}{$_}{"GENE"}{"$_"}="0";
                print "Assign $path\t$_ GENE\t$_\n";
            }
            #else {
                #}
            #}    
    }


 $tot++;



}

close (IN2);




# calculate overrepresented pathways observed/expected


my $pathways = scalar keys %pws;

print "There are $pathways  pathways\n";
print "There are $tot differentially expressed genes\n";

foreach my $path (keys %pws) {

    my $genes = scalar keys %{$pws{$path}};

    #print "There are $genes genes in pathway $path\n";
 
    my $spectot = 0;

    foreach my $cat (keys %{$pws{$path}} ) {

        #print "$cat\n";
        #if ( $cat=~/GENE/ ){
                
            my $specs = scalar keys %{$pws{$path}{$cat}{GENE}};
            $spectot = $spectot + $specs ;
            if ($specs > 0) {
                print "$cat is in pathway $path\n";
            }
            #}

    }

    print "In pathway $path there are $genes genes, of which  $spectot are differentially expressed\n";

}


#### NEED to recalculate the total number of genes in pathway from unique ko-numbers


