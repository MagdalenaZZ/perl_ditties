#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta_from_CDS_position.pl ref.fas input.gff  <offset>

Takes a gff-file and a fasta-file and makes fasta-file from it, with only the CDSs.


Example:
perl ~/bin/perl/fasta_from_CDS.pl genome.fa  file.gff 
perl ~/bin/perl/fasta_from_CDS.pl genome.fa  file.gff  10


# make sure the fasta is single-line

offset will add a set of bases to the start or the end of your sequence (it is optional, and should only be used when there are not CDS which should be cobbled together)


The ID is made from the contig name and position





'
}


	my $ref = shift;
	my $in = shift;
	my $out = $in;
	open (IN, "<$in") || die "I can't open $in\n";
	my @gff = <IN>;
	close (IN);

	open (OUT, ">$in.fas") || die "I can't open $in.fas\n";
	open (OUT2, ">$in.comb.fas") || die "I can't open $in.comb.fas\n";

    # read in fasta

open (FAS, "<$ref") || die "I can't open $ref\n";
my %fas;
while (<FAS>) {
    chomp;
    if (/^>(\S+)/) {
        my $seq_name = $_;
        $seq_name=~s/>//;
        my $seq = <FAS> ;
        chomp($seq) ;
        $fas{$seq_name}="$seq";
        #print "$seq_name\n";
    }	
}


close(FAS);

# keep order if gene is seen or not
my %seen;

foreach my $line (@gff) {

    chomp $line;
    my @arr= split(/\t/,$line);


    if (exists $fas{$arr[0]}) {
        my $len = $arr[4]-$arr[3]+1  ;
        my $seqlen = length($fas{$arr[0]});
        my $sub="0";
        # reverse is mising one on the start, forward is missing one on the end
        $arr[3] = $arr[3] -1;    

        # if positions are within sequence
        if (  $seqlen   >=  ( $arr[3] + $len)  ) {
             $sub = substr($fas{$arr[0]}, $arr[3], $len);
        }
        # if positions are outside the sequnece, go to the end of seq
        elsif (  $seqlen >=  $arr[3]  ) {
             $sub = substr($fas{$arr[0]}, $arr[3], -1);
             #print "$arr[0]\_$arr[3]\_$arr[4]\t$len\t$arr[3]\t$seqlen\t$sub\n";
             unless (defined $sub) {
                $sub="0";
             }
        }
        # if even the start is outside the sequence
        else {
             print "Warning : $arr[0] $arr[3] $arr[4] is outside sequence range $seqlen\t$sub\n";
             next;
        }



        if ($arr[6]=~/\-/) {
            #print "Reverse\n";
            #print "sub $sub\n";
            $sub=~tr/ACGTacgt/TGCAtgca/;
            $sub = reverse($sub);
            #print "rev $sub\n";

        }

        if ($arr[0]=~/\w+/ and $arr[3]=~/\w+/ and $arr[4]=~/\w+/ and $sub!~/^0$/   ) {
            print OUT ">$arr[0]\_$arr[3]\_$arr[4]\n$sub\n";
            #print OUT2 "$arr[8]\n$sub\n";

        }
        else {
            print  ">$arr[0]\_$arr[3]\_$arr[4]\n$sub\n";
        }


        if (exists $seen{$arr[8]}) {
            #print "Have seen $arr[8]\n";

                # if reverse
                if ($arr[6]=~/\-/) {
                    $seen{$arr[8]}= $sub . $seen{$arr[8]} ;
                    #print "$sub\n";
                }
                # if forward
                else {
                    $seen{$arr[8]}= $seen{$arr[8]} . $sub ;
                }
        }
        else {
            #print "Make new $arr[8]\n";
                # record seeing a gene
                $seen{$arr[8]}=$sub;
        }

    }
    else {
        print "Missing sequence $arr[0] in fasta-file\n";
    }

}


# now print second file


foreach my $key (sort keys %seen) {
    my $head = $key;
    $head=~s/^ID=//;
    print OUT2 ">$head\n$seen{$key}\n";
}



exit;

    
__END__


