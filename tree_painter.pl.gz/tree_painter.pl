#!/usr/bin/perl -w


use strict;


unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: tree_painter.pl input

This program paints a phylogeny according to a colour-scheme you descide
Takes an input a Newick-style phylogeny and a file





'
}

my $in = shift;
my $file ="/nfs/users/nfs_m/mz3/bin/perl/tree_painter.list";
#my $file ="/nfs/users/nfs_m/mz3/bin/perl/tree_painter.parasite.list";

        open (IN, "<$in") || die "I can't open $in\n";
    	my @in= <IN>;
    	close (IN);

        open (LIST, "<$file") || die "I can't open $file\n";
    	my @list= <LIST>;
    	close (LIST);

        open (OUT, ">$in.tre") || die "I can't open $in.tre\n";


my @taxa;
# Read in the tree
foreach my $line (@in){
    chomp $line;
    my @arr = split(/[:]/, $line);

    foreach my $elem (@arr){
    $elem=~s/\(/ /g;
    $elem=~s/\)/ /g;
    $elem=~s/\,/ /g;
    $elem=~s/;/ /g;
    $elem= $elem . "  .";
#    print "$elem\n";
    my @arr2 = split (/\s+/, $elem);
    if ($arr2[1]=~m/\w+/ and not $arr2[1]=~m/^\d+$/ and not $arr2[1]=~m/^\d+\.\d+$/  ) {
        push (@taxa, $arr2[1]);
        #print "$arr2[1]\n";
    }
    }
}
# Read in the colour-formatting list
my %col;

foreach my $line (@list) {
    chomp $line;
    if ($line =~/^\#/) {
    }
    elsif ($line=~m/\w+/) {
#    print "$line\n";
    my @arr=split(/\s+/, $line);

=pod
    $arr[1]=~s/emerald/[&!color=#-16751002]/;
    $arr[1]=~s/lgreen/[&!color=#-9967806]/;
    $arr[1]=~s/dgreen/[&!color=#-16751053]/;
    $arr[1]=~s/green/[&!color=#-16738048]/;

    $arr[1]=~s/yellow/[&!color=#-3355648]/;
    $arr[1]=~s/orange/[&!color=#-26368]/;
    $arr[1]=~s/fuschia/[&!color=#-3407719]/;
    $arr[1]=~s/red/[&!color=#-65536]/;
    $arr[1]=~s/purple/[&!color=#-10092340]/;
#    $arr[1]=~s/grey/[&!color=#-8355712]/;
    $arr[1]=~s/lblue/[&!color=#-9260811]/;
    $arr[1]=~s/dblue/[&!color=#-16776961]/;
    $arr[1]=~s/lbrown/[&!color=#-7707377]/;
    $arr[1]=~s/dbrown/[&!color=#-10077934]/;
    $arr[1]=~s/black/[&!color=#-16777216]/;
    $arr[1]=~s/emerald/[&!color=#-16751002]/; 

=cut
$arr[1]=~s/black/[&!color=#-16777216]/;
$arr[1]=~s/dblue/[&!color=#-13552386]/;
$arr[1]=~s/dbrown/[&!color=#-10404591]/;
$arr[1]=~s/dgreen/[&!color=#-10587641]/;
$arr[1]=~s/dred/[&!color=#-7731192]/;
$arr[1]=~s/pink/[&!color=#-3121712]/;
$arr[1]=~s/emerald/[&!color=#-16751002]/;
$arr[1]=~s/grey/[&!color=#-8092540]/;
$arr[1]=~s/lblue/[&!color=#-6699282]/;
$arr[1]=~s/lbrown/[&!color=#-8035304]/;
$arr[1]=~s/lgreen/[&!color=#-6684876]/;
$arr[1]=~s/orange/[&!color=#-32768]/;
$arr[1]=~s/purple/[&!color=#-10550092]/;
$arr[1]=~s/red/[&!color=#-2147839]/;
$arr[1]=~s/fuschia/[&!color=#-3407668]/;
$arr[1]=~s/turqoise/[&!color=#-12800558]/;
$arr[1]=~s/lilac/[&!color=#-7434543]/;
$arr[1]=~s/dirt/[&!color=#-11711950]/;
$arr[1]=~s/yellow/[&!color=#-4212206]/;



    # if it doesn't have a colour - make it grey
    unless ($arr[1]=~/color=/) {
        $arr[1]= $arr[1] . "[&!color=#-10066330]";
    }
    $col{$arr[0]}=$arr[1];
#    print "COL:$arr[0]\t$arr[1]\n";
    
    }
}

my $len=scalar(@taxa);


# Make the header-lines

print OUT "#NEXUS\nbegin taxa;\n\tdimensions ntax=$len;\n\ttaxlabels\n";

foreach my $line (@taxa){
    my $colour='';
    my @arr=split(/_/, $line);
    $arr[0]=~s/\.//g;
    if (exists $col{$arr[0]}){
        $colour=$col{$arr[0]};
        print OUT "\t$line$colour\n"; #red
    }
    else {
        print "$arr[0]\n";
         print OUT "\t$line$colour\n"; 
    }

}


print OUT ";\nend;\n\nbegin trees;\n
        tree tree_1 = [&R]\t$in[0]\n";

# Re-format the phylogeny
#
#print OUT "PHYLOGENY\n";

        # print end
        #

print OUT '
end;

begin figtree;
        set appearance.backgroundColorAttribute="User Selection";
        set appearance.backgroundColour=#-1;
        set appearance.branchColorAttribute="User Selection";
        set appearance.branchLineWidth=1.0;
        set appearance.foregroundColour=#-16777216;
        set appearance.selectionColour=#-2144520576;
        set branchLabels.colorAttribute="User Selection";
        set branchLabels.displayAttribute="Branch times";
        set branchLabels.fontName="sansserif";
        set branchLabels.fontSize=8;
        set branchLabels.fontStyle=0;
        set branchLabels.isShown=false;
        set branchLabels.significantDigits=4;
        set layout.expansion=0;
        set layout.layoutType="RADIAL";
        set layout.zoom=4100;
        set nodeBars.barWidth=4.0;
        set nodeLabels.colorAttribute="User Selection";
        set nodeLabels.displayAttribute="Node ages";
        set nodeLabels.fontName="sansserif";
        set nodeLabels.fontSize=8;
        set nodeLabels.fontStyle=0;
        set nodeLabels.isShown=false;
        set nodeLabels.significantDigits=4;
        set polarLayout.alignTipLabels=false;
        set polarLayout.angularRange=0;
        set polarLayout.rootAngle=0;
        set polarLayout.rootLength=100;
        set polarLayout.showRoot=true;
        set radialLayout.spread=20.0;
        set rectilinearLayout.alignTipLabels=false;
        set rectilinearLayout.curvature=0;
        set rectilinearLayout.rootLength=100;
        set scale.offsetAge=0.0;
        set scale.rootAge=1.0;
        set scale.scaleFactor=1.0;
        set scale.scaleRoot=false;
        set scaleAxis.automaticScale=true;
        set scaleAxis.fontSize=8.0;
        set scaleAxis.isShown=false;
        set scaleAxis.lineWidth=1.0;
        set scaleAxis.majorTicks=1.0;
        set scaleAxis.origin=0.0;
        set scaleAxis.reverseAxis=false;
        set scaleAxis.showGrid=true;
        set scaleAxis.significantDigits=4;
        set scaleBar.automaticScale=true;
        set scaleBar.fontSize=10.0;
        set scaleBar.isShown=true;
        set scaleBar.lineWidth=1.0;
        set scaleBar.scaleRange=0.0;
        set scaleBar.significantDigits=4;
        set tipLabels.colorAttribute="User Selection";
        set tipLabels.displayAttribute="Names";
        set tipLabels.fontName="sansserif";
        set tipLabels.fontSize=8;
        set tipLabels.fontStyle=0;
        set tipLabels.isShown=true;
        set tipLabels.significantDigits=4;
        set trees.order=false;
        set trees.orderType="increasing";
        set trees.rooting=false;
        set trees.rootingType="User Selection";
        set trees.transform=false;
        set trees.transformType="cladogram";
end;
';
print "\n";


    	close (OUT);
__END__

((((((SME_mk4_023451_00_02:1.8808724892,((TsM_000760700:0.3654827816,HmN_000378700:0.5000504841):0.4785352395,SME_mk4_001672_07_01:1.2223534979):0.4700930392):0.6902129695,(TsM_001098300:0.5176724547,HmN_000096400:0.6348063609):1.4365814414):0.2343947927,((((HSA_CCDS48194_1_Hs37_3_chrX:0.0000000206,HSA_CCDS44021_1_Hs37_3_chrX:0.0000000001):0.0000053684,MUS_CCDS41018_1_Mm37_2_chrX:0.0324046430):3.2369847507,(((Smp_020800_1:0.7087480737,(TsM_000620900:0.7335352357,(HmN_000290300:0.0141127600,HmN_000290200:0.1171238574):0.3685832411):0.2728408772):0.1391109337,(((((DRE_ENSDARG00000003973:0.2497547385,DRE_ENSDARG00000017067:0.1446876192):0.0645537822,((HSA_CCDS44705_1_Hs37_3_chr11:0.0032318904,HSA_CCDS8289_1_Hs37_3_chr11:0.0000000001):0.0257822029,MUS_CCDS22842_1_Mm37_2_chr9:0.0224898331):0.1817502912):0.2787570832,DRE_ENSDARG00000030176:0.5184028806):0.1768041482,(HSA_CCDS14411_1_Hs37_3_chrX:0.1379024320,MUS_CCDS41079_1_Mm37_2_chrX:0.0252315450):0.8593319902)
:0.0949307404,DME_FBpp0083939:0.9609789848):0.1453977185):0.0643223359,(RNA815_10946:0.7054570448,(SME_mk4_002953_01_01:1.1171554527,CEL_WBGene00000502:0.9522862323):0.1175334616):0.2060059819):0.3903009427):0.4244091507,(SME_mk4_000280_10_01:1.1290163701,(((Smp_010160_1:0.0075302652,Smp_168350_1:0.5259287724):0.5077988512,((HSA_CCDS45050_1_Hs37_3_chr13:0.0666751700,MUS_CCDS36988_1_Mm37_2_chr14:0.1187817525):0.1490795556,HSA_CCDS9436_1_Hs37_3_chr13:0.0695974609):1.0743153042):0.1732944049,(HmN_000162700:0.2881415253,TsM_000726800:0.1811577150):0.6033575282):0.1242231624):1.6113922139):0.3954806683):0.3660815481,(((HSA_CCDS55931_1_Hs37_3_chr14:1.2175907494,((HSA_CCDS55930_1_Hs37_3_chr14:0.1985251235,MUS_CCDS26042_1_Mm37_2_chr12:0.0546128752):0.0050532936,HSA_CCDS9821_1_Hs37_3_chr14:0.0000005456):1.0015854152):1.5506526635,(((TsM_000204800:0.5174550878,HmN_000338600:0.3818177661):0.5113253525,Smp_121810_1:0.7981415699):0.3567930616,(CEL_WBGene00021655:1.4733136387,((HSA_CCDS33788_1_Hs37_3_chr3:0.2476621509,MUS_CCDS39580_2_Mm37_2_chr6:0.2732364684):0.4917747634,DRE_ENSDARG00000058522:0.5169937057):0.4520304831):0.2650416204):1.9537331287):1.1240192118,(DRE_ENSDARG00000057353:99.9945682803,(((((RNA815_35833:3.4976833544,((Smp_103320_1:0.5311940326,((((HSA_CCDS292_1_Hs37_3_chr1:0.0536887993,MUS_CCDS18750_1_Mm37_2_chr4:0.0220671006):0.2877401682,(DME_FBpp0297079:0.0000000001,DME_FBpp0075087:0.0000000001):0.6094722448):0.0980667482,CEL_WBGene00003829:0.6321482088):0.1889429636,(SME_mk4_002934_08_01:0.0000000001,SME_mk4_009652_00_01:0.0000000001):0.4154468304):0.1215493883):0.1108419502,(TsM_000089200:0.3467380682,HmN_000392700:1.0417463613):0.0896590938):0.3462929475):0.2483630940,((((SME_mk4_009307_02_01:0.9623324742,Smp_128650_2:0.5027264565):0.2339066250,TsM_000813600:0.6806112993):0.3473105440,DME_FBpp0082917:1.1921440271):0.1621782413,((HSA_CCDS5490_2_Hs37_3_chr7:0.1003440417,MUS_CCDS24412_1_Mm37_2_chr11:0.0766510324):0.3839755824,DRE_ENSDARG00000006005:0.3397222350):0.6349964200):0.3466962738):1.0909154277,(RNA815_53495:3.4811346536,((DME_FBpp0081590:100.0000000000,(RNA815_4347:1.5609081261,((HSA_CCDS6312_1_Hs37_3_chr8:0.0526345348,MUS_CCDS27455_1_Mm37_2_chr15:0.0874361353):0.2391464734,DRE_ENSDARG00000036158:0.3641631367):0.6040213982):0.0417867467):0.8602417483,(Smp_020060_1:1.4957309365,(TsM_000552300:0.6168035650,HmN_000406600:0.1492524933):1.4464252023):0.3547828357):0.7206134117):0.4303558002):0.1773304926,(CEL_WBGene00018328:2.7549815867,(DME_FBpp0076203:1.5948714584,HSA_CCDS3849_1_Hs37_3_chr4:1.8491614776):1.3271811038):0.8105616506):0.0841212343,(RNA815_10393:1.8200831992,((DME_FBpp0080097:1.4610911256,((TsM_000465000:0.9902557896,Smp_121880_1:1.0528226455):0.4383445930,(HSA_CCDS45282_1_Hs37_3_chr15:0.0504854504,MUS_CCDS23284_1_Mm37_2_chr9:0.0484077358):1.9660246399):0.4943210137):0.4576153113,HmN_000378200:3.0948443676):0.3058432031):2.1125318621):0.0000055501):0.0000027841):0.1519098651):1.9538143856,(((((HSA_CCDS32244_1_Hs37_3_chr15:0.0398683216,HSA_CCDS32243_1_Hs37_3_chr15:0.1489159153):0.1741129750,HSA_CCDS10154_1_Hs37_3_chr15:0.0000004051):0.0996668469,(MUS_CCDS52854_1_Mm37_2_chr9:0.0851975192,MUS_CCDS23333_1_Mm37_2_chr9:0.0167153606):0.1566454787):0.2479231412,DRE_ENSDARG00000007792:0.4106167372):0.2821931752,TsM_000366600:0.8942808720):0.5525870167):1.1800819627,SME_mk4_022579_01_01:0.0067447734,SME_mk4_018552_00_01:0.0000023706);
