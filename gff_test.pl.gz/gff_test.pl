#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_test.pl input.gff detailed_output

Takes a gff-file and checks the file integrity. Summary prints to STDOUT and detailed info prints to outfile


'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

 print "Hi!\n";

## Basic stats 

my @contigs;
my @methods;
my @tags;
my @coords;
my @keys;
my @split_genes;
my @geness;

my $index = 1;

foreach my $line (@in) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

# Test contig name
unless  ( ($contig =~/^pathogen_\w+_contig_\d+$/) || ($contig =~/^pathogen_\w+_scaffold_\d+$/) ||  ($contig =~/^pathogen_HYM_scaffold_\d+$/) || ($contig =~/^pathogen_EMU_scaffold_\d+$/) ||   ($contig =~/^pathogens_Gpal_scaffold_\d+$/) || ($contig =~/^pathogens_\w+_scaffold_\d+$/) || ($contig =~/^pathogens_\w+_contig_\d+$/)   ) {
print "This contig name seems to be wrong:$contig:\n";
# print "Line $index:$line:\n";
next;
}

# Test method 
unless  ($method =~/^\w+$/ || $method=~/exonerate:est2genome/ ) {
print "This method seems to be wrong:$method:\n";
print "Line $index:$line:\n";
next;
}

# Test tag
unless (($tag =~/^CDS$/) || ($tag =~/^mRNA$/) || ($tag =~/^exon$/) || ($tag =~/^gene$/) || ($tag =~/^transcript$/) ) {
print "This tag seems to be wrong:$tag:\n";
print "Line $index:$line:\n";
next;
}

# Test start
unless ($start =~/^\d+$/) {
print "This start seems to be wrong:$start:\n";
print "Line $index:$line:\n";
next;
}

# Test end
unless ($end =~/^\d+$/) {
print "This end seems to be wrong:$end:\n";
print "Line $index:$line:\n";
next;
}

# Test score
unless (($score =~/^\.$/) || ($score =~/^\d+$/)) {
print "This score seems to be wrong:$score:\n";
print "Line $index:$line:\n";
next;
}

# Test strand
unless (($strand =~/^\+$/) || ($strand =~/^\-$/)   ) {
	if ( ($strand =~/^\.$/)) {
        print "This strand is dot: $index:$line:\n";

    }
    else {
        print "This strand seems wrong:$strand:\n";
        print "Line $index:$line:\n";
    }
next;
}

# Test dot
unless (($dot =~/^\.$/)) {
print "This dot seems to be not a dot:$dot:\n";
print "Line $index:$line:\n";
next;
}

# Test key
unless (($key =~/\w+/) ) {
print "This key seems to be wrong:$key:\n";
print "Line $index:$line:\n";
next;
}


my %gene_uniq = ();

push (@contigs, $contig);
push (@methods, $method);
if (($tag=~/CDS/) || ($tag=~/exon/) ) {


# declare that gene

# print "KEY:$key:\n";

push (@coords,  "$start\t$end\t$strand\t$contig\t$key" ); 

my @arr= split(/[:;]/, $key );
$arr[0]=~s/ID=//;
#print "KEY:$arr[0]:\n";
push (@split_genes, "$contig\t$arr[0]");

}






########### check if two genes are suspiciously close to each other ##############################################################




if ($tag=~/gene/)  {

    push (@geness, "$contig\t$start\t$end\t$key");

}

#################


push (@tags, $tag);
push (@keys, $key);


#push (@contigs, $contig);

my @methods;
my @tags;

$index++;

}

###### Report stats for tags #########
#@sort_tags = sort (@tags);


my %count = ();
#my @unique2 = ();
#my $CDS = 0;
#my $gene = 0;
#my $mRNA = 0;
#my $exon = 0;
#my $transcript = 0;


foreach my $elem (@tags) {
	$count{$elem}++;
#	push (@non_unique, $elem) if $tags{ $elem }++;
#	push (@unique2, $elem);
        }

foreach my $key (keys %count) {

print "There are $count{$key} $key" . "s \n";

}


####################### check if a gene is on several scaffolds ####################### 
 #

# check if this gene already exists on a different scaffold
#
my %seen   = ();
my %seen2   = ();
my @unique = ();
my @non_unique = ();
my @unique2 = ();
my @non_unique2 = ();
my %non_uniq = ();

# make a hash with all gene-names and scaffolds
foreach my $elem (@split_genes) {
# my @arr = split (/\t/, $elem);
# my $elem = "$arr[1]";
	push (@non_unique2, $elem)   if $seen{ $elem }++;    
	push (@unique2, $elem);
}

foreach my $ele (keys %seen) {
#    print "ELE:$ele:\n";
     my @arr = split (/\t/, $ele);
     my $elem = "$arr[1]";
	push (@non_unique, $elem)   if $seen2{ $elem }++;    
	push (@unique, $elem);

}


# check if there are any non-unique genes

if (exists $non_unique[0]) {

print "There are non-uniqe gene-names, so I will attempt to correct them and write to file $out.unique\n"; 
open (OUTU, ">$out.unique") || die "I can't open $out.unique\n";

foreach my $line (@non_unique) {
        my @arr = split( /=/, $line);
#        print "non-unique:$line\n";
        $non_uniq{$arr[0]}= 1;
}

foreach my $key (sort keys %non_uniq) {
    print "non-unique:$key\n";
}

 %seen   = ();

foreach my $line (@in) {
    chomp $line;
    my @arr = split (/\t/, $line);
    my @nme = split (/[:;]/, $arr[8]);
    $nme[0]=~s/ID=//;
#    print "GENE:$nme[0]:\n";
#    foreach my $key (keys %non_uniq ) {
        push (@arr, "\/product=\"hypothetical protein\"");
        $arr[9]=~s/_/ /g;
        if (exists $non_uniq{$nme[0]}) {
#        print "non-unique:$line\n";
            my $key = $nme[0];
            # if I've not seen this gene before, let go unless it is a cds
            if ($non_uniq{$key}=~m/^1$/ and $arr[2]=~/CDS/ ) {
                $non_uniq{$key}= $arr[0];
#                print "\nFirst spotted:$line\n";
#                my @art3 = split(/_/, $arr[8]);
#                $art3[1]++;
#                my $new_name = join ("_", @art3);
                    my @artt = split(/:/, $arr[8]); 
                    my @artt2 = split(/_/, $artt[0]);
                    my $old_name2 = $artt2[1];
                    $artt2[1]++;
#                    $old_name2--;
#                    my $new_name2 = join ("_", @artt2);
                    my $new_name2 = $artt2[1];                   
                    $new_name2=~s/ID=//;
                    $artt2[0]=~s/ID=//;

#                    print  OUTU "$line\t/comment=\"This gene is probably part of gene $new_name\"\n";

                    print OUTU "$arr[0]\t$arr[1]\tgene\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$artt2[0]_$old_name2\t$arr[9]\t/comment=\"This gene is probably part of gene $artt2[0]_$new_name2\"\n";
                    print  OUTU "$arr[0]\t$arr[1]\tmRNA\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$artt2[0]_$old_name2;Parent=$artt2[0]_$old_name2\n";
#                    $line=~s/$old_name2/$artt2[1]/g;
#                    $line=~s/$old_name/$art2[1]/g;

                    print  OUTU  "$line\n";

                    $non_uniq{$key}= 2;

            }
        
            # when I see another one (just re-name)

            elsif ($non_uniq{$key}=~m/^2$/ and $arr[2]=~/CDS/  ) {

                    my @art = split(/:/, $arr[8]); 
                    my @art2 = split(/_/, $art[0]);
                    my $old_name = $art2[1];
                    $art2[0]=~s/ID=//;
                    $art2[1]++;
                    my $new_name = join ("_", @art2);
#                    $line=~s/$old_name/$art2[1]/g;
                    print OUTU "$line\n";
#                    print  OUTU  "$line\n";
                    $non_uniq{$key}= 2;

            }

            elsif ($non_uniq{$key}=~m/^1$/ ) {
                $non_uniq{$key}= $arr[0];
#                print "\nFirst spotted:$line\n";
                my @art3 = split(/_/, $arr[8]);
                $art3[1]++;
                my $new_name = join ("_", @art3);

                if ($arr[2]=~m/gene/) {
                    print  OUTU "$line\t/comment=\"This gene is probably part of gene $new_name\"\n";
                }
                else {
#                    print OUTU "$line\n";
                }
            }
            elsif ($arr[0]=~/^$non_uniq{$key}$/ ) {
#                print "First instance:$line\n";
                print OUTU "$line\n";
            }
            # if I've seen this gene before give it a new gene and mRNA
            else {
                    
                # when I see another one (just re-name)
                if ($non_uniq{$key} =~m/^re/) {
                    my @art = split(/:/, $arr[8]); 
                    my @art2 = split(/_/, $art[0]);
                    my $old_name = $art2[1];
                    $art2[0]=~s/ID=//;
                    $art2[1]++;
                    my $new_name = join ("_", @art2);
                    $line=~s/$old_name/$art2[1]/g;

                    unless ($line=~/gene/ || $line=~/mRNA/ ) {
                        print OUTU "$line\n";
                     }
#                    print OUTU "333 $arr[0]\t$arr[1]\tgene\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$new_name\t $arr[9]\t/comment=\"This gene is probably part of gene $art2[0]_$old_name\"\n";
#                    print OUTU "334 $arr[0]\t$arr[1]\tmRNA\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$new_name;Parent=$new_name\n";


                }
                else {
                # when I've first seen it (make gene and mRNA)
#                    print "\n\nThis is the repeat:$line\n\n";
                    my @artt = split(/:/, $arr[8]); 
                    my @artt2 = split(/_/, $artt[0]);
                    my $old_name2 = $artt2[1];
                    $artt2[1]++;
                    my $new_name2 = join ("_", @artt2);
                    $artt2[0]=~s/ID=//;
                    $new_name2=~s/ID=//;
                    print OUTU "$arr[0]\t$arr[1]\tgene\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$new_name2\t$arr[9]\t/comment=\"This gene is probably part of gene $artt2[0]_$old_name2\"\n";
                    print OUTU "$arr[0]\t$arr[1]\tmRNA\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\tID=$new_name2;Parent=$new_name2\n";
                    $line=~s/$old_name2/$artt2[1]/g;

                    unless ($line=~/gene/ || $line=~/mRNA/ ) {
                    print OUTU "$line\n";
                     }

                    $non_uniq{$key}= "re" ."$arr[0]";
                }
            }
        }
        # this gene is not repeated, so just let go
        else {
             my @arr = split (/\t/, $line);
             $arr[9]=~s/_/ /g;
             $line = join("\t", @arr);
             print OUTU "$line\n";
        }
}

print "Finished printing $out.unique\n";
close (OUTU);
system "perl ~/bin/perl/gff_Artemis_orientation.pl all.gff2.err.unique all.gff2.err.unique.gff";

die "Fixed the gene and mRNA positions in $out.unique.gff! \n\n";
}


#foreach my $line ()


###### Check that there are no same gene-names #########

my @sort_keys = sort (@keys);

=pod
    You can also go through each element and skip the ones you’ve seen before. Use a hash to keep track. The first time the loop sees an element, that element has no key in %Seen. The "next" statement creates the key and immediately uses its value, which is "undef", so the loop continues to the "push" and increments the value for that key. The next time the loop sees that same element, its key exists in the hash and the value for that key is true (since it’s not 0 or undef), so the next skips that iteration and the loop goes to the next element.
=cut

 @unique = ();
 %seen   = ();
 @non_unique = ();

foreach my $elem ( @keys) {
	push (@non_unique, $elem) if $seen{ $elem }++;
	push (@unique, $elem);
        }

my $nonunique = scalar (@non_unique);

print "There are $nonunique non-unique gene-names in the file\n";

foreach my $elem (@non_unique) {
 print OUT "Non-unique gene-name $elem\n";
}

if (@non_unique) {

 print "Writing a new file for unique elements only: $out.unique\n";

# Make a corrected file
	open (IN, "<$in") || die "I can't open $in\n";
	my @in2 = <IN>;
	close (IN);

# my @in3;
# my $index = 0;
#my $stop = scalar(@in2);

my @unique2 = ();
my %seen2 =();

 #   my @r = ();
    foreach my $alt (@in2) {
	chomp $alt;
	my $alt2;
	if ($alt =~/\w+/) {
		$alt2=$alt;
#		$alt2=~s/\s+/X/g;
	}
#	print "ALT:$alt\n";	
        unless ($seen2{$alt2}) {
            push @unique2, $alt2;
            $seen2{$alt2} = 1;
#		print "ALTU:$alt2\n";		
        }
    }

open (OUTU, ">$out.unique") || die "I can't open $out.unique\n";

foreach my $line (@unique2) {
 print OUTU "$line\n";
}

print "Finished printing $out.unique\n";

close (OUTU);
}

#foreach my $line (@in2) {
#chomp $line;

#	for my $i

#    unless($line eq $unique[$i]) {
 #       push(@unique,$item);
#        $i++;
#	}


#}
 
 
 
 

####################### check that the start and end are in 1 - 2, 3 - 4, 5 -6 order

foreach my $elem (@coords)  {
my @arr = split (/\t/, $elem);
	if ( $arr[0] < $arr[1]) {
#		print "Forward order:$elem:\n";
	}
	elsif ($arr[0] > $arr[1]) {
		print "Warning: reverse order:$elem:\n";
	}
	else {
		print "Warning: Can\'t figure out the orientation of these coordinates:$elem:\n";
	}

}

my $last_elem = 0;
# check orientation of adjoining
foreach my $elem (@coords)  {
# print "Elem:$elem:\n";
	my @arr = split (/\t/, $elem);

	if ($last_elem =~/^0$/) {
#		next;
	}	

	else {
		my @last = split (/\t/, $last_elem);

# check if we are on the same contig
#
        my @last_gene = split(/\.t/, $last[4]);
        my @this_gene = split(/\.t/, $arr[4]);
#        print "Fourth:$arr[4]:$last[4]:\n";	
#        print "Fourth:$this_gene[0]:$last_gene[0]:\n";	

		if  ($last[3] =~/^$arr[3]$/) {
		# Test start order
			if (  $last[0] < $arr[0]  ) {
#				print "Start in forward order:$last_elem:$elem:\n";
			}
            # check for alternative transcripts of the same gene
            elsif  ( $last_gene[0]=~m/^$this_gene[0]$/)  {
#				if ( $last[0] =~m/^$arr[0]$/) {
#                    print "Okay:$last_elem:$elem:\n";
#                }
#                else {
#    				print "Warning: Same start of these genes:$last_elem:$elem:\n";
#                }
            }
			elsif ( $last[0] > $arr[0] ) {
				print "Warning: Start in reverse order:$last_elem:$elem:\n";
			}
			else {
				print "Warning: Can\'t figure out the orientation of these starts:$last_elem:$elem:\n";
			}
		# Test end order
			if (  $last[1] < $arr[1] ) {
#				print "End in forward order:$last_elem:$elem:\n";
            }
            elsif  ( $last_gene[0]=~m/^$this_gene[0]$/)  {
#                    print "Okay:$last_elem:$elem:\n";
            }
			elsif ( $last[1] > $arr[1] ) {
				print "Warning: End in reverse order:$last_elem:$elem:\n";
			}
			else {
				print "Warning: Can\'t figure out the orientation of these ends:$last_elem:$elem:\n";
			}


		
		}
		else  {
		# change contig
			next;	
		}

	}


$last_elem=$elem;
}

print "Finished checking order\n";


$last_elem = 0;
my $same = 0;
my $different = 0;
my $weird = 0;

# check orientation of adjoining 2

foreach my $elem (@coords)  {
chomp $elem;
# print "Elem:$elem:\n";
	my @arr = split (/\t/, $elem);
	my @last = split (/\t/, $last_elem);

	#filter change of strand
	if ($last_elem =~/^0$/) {
#		next;
	}
	elsif ($last[3] !~/$arr[3]/) {
#		next;
	}	

	else {
#		my @last = split (/\t/, $last_elem);

# check if we are on the same contig	# Test overlap
			if ( $last[1] > $arr[0] ) {
				if ($arr[2]=~/^\+$/ and $last[2]=~/^\-$/ ) {
					print OUT "Overlapping genes on different strands:\n$last_elem:\n$elem:\n";
					$different++;
				}
				elsif ($arr[2]=~/^\-$/ and $last[2]=~/^\+$/ ) {
					print OUT "Overlapping genes on different strands:\n$last_elem:\n$elem:\n";
					$different++;
				}
				elsif ($arr[2]=~/^\-$/ and $last[2]=~/^\-$/ ) {
					print OUT  "Overlapping genes on negative strand:\n$last_elem:\n$elem:\n";
					$same++;
				}
				elsif ($arr[2]=~/^\+$/ and $last[2]=~/^\+$/ ) {
					print OUT  "Overlapping genes on positive strand:\n$last_elem:\n$elem:\n";
					$same++;
				}
				else {
					print OUT "Something funny with the orientations and overlaps:\n$last_elem:\n$elem:\n";
					$weird++;
				}
			}
			elsif ( $last[1] == $arr[0] ) {
					print OUT "Something funny with the orientations and overlaps:\n$last_elem:\n$elem:\n";
					$weird++;
			}
			else {
#				print "Not overlapping:$last_elem:$elem:\n";
			}	


		}





$last_elem=$elem;
}


print "There are $same genes overlapping on the same strand\n";
print "There are $different genes overlapping on different strands\n";
print "There are $weird genes with weird overlaps. They are highlighted in the output as \"Something funny with the orientations and overlaps\" \n";


############### check that all genes are in triplets ####################
my %codon;
# Make a hash with the gene name as key value, and all CDS positions as an array
# push (@coords,  "$start\t$end\t$strand\t$contig\t$key" );
# coords only contains CDSs

foreach my $line (@coords) {
chomp $line;
#print "Line:$line:\n";
my @arr=split(/([=:\t])/, $line);
#$arr[10] =~s/://;
#print "Arr1\t$arr[10]\n";
#print "Arr0\t$arr[0]\n";
#print "Arr2\t$arr[2]\n";
my $sum= ($arr[2]-$arr[0]+1);
#  -tlrint OUT "Sum\t$sum\t$arr[10]\n";

$codon{$arr[10]}+=$sum;
#print "SUM:key $arr[10] value $codon{$arr[10]}\n";
}

# Work out the replacement

foreach my $key (keys %codon) {
	my $third = ($codon{$key}/3);
#	print "$key\t$codon{$key}\t$third\n";
	if ($third=~/333333/) {
#		$codon{$key}="-1";
	print "Warning: Gene $key has $codon{$key} bases, resulting in incomplete codon $third which needs to be adjusted by -1\n";
	}
	elsif ($third=~/666666/) {
#		$codon{$key}="-2";
	print "Warning: Gene $key has $codon{$key} bases, resulting in incomplete codon $third which needs to be adjusted by -2\n";
	}	
}



# Parse the original gff, and replace the co-ordinates with new coordinates as appropriate for genes mRNAs and CDSs
if (-e "$out.unique") {
	open (IN3,"<$out.unique");
	print "Opening $out.unique\n";
}
else {
	open (IN3,"<$in");
	print "Opening $in\n";
}


########### check if two genes are suspiciously close to each other ##############################################################


$last_elem = 0;
my $too_close = 0;

foreach my $elem (@geness) {

    my @an = split (/\t/, $elem);
    my @al = split (/\t/, $last_elem);

    if ($an[0]=~/$al[0]/ and $an[0]=~/$al[0]/ ) {
        my $diff = ( $an[1] - $al[2] ) ;
        if ($diff < 100) {
            print OUT "Genes are too close:$diff\t$last_elem\t$elem\n";
            $too_close++;
        }
    }


    $last_elem = $elem;
}

print "$too_close genes are too close (closer than 100 bp). They are marked in the error-file as; Genes are too close: \n";


############### check that mRNA, gene and CDSs add up ####################
#
my %gh;

foreach my $line (@in) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

#    print "ELEM:$line\n"; 



    if ($tag=~/^gene$/) {
#      print "$tag\t$key\t$start\t$end\n";
       push (@{$gh{$key}{$tag}} , $start);
       push (@{$gh{$key}{$tag}} , $end );
    }
       elsif ($tag=~/^mRNA$/) {
        my @keyarr=split(/;/, $key);
#       print "$tag\t$key\t$start\t$end\n";
       push (@{$gh{$keyarr[0]}{$tag}} , $start);
       push (@{$gh{$keyarr[0]}{$tag}} , $end );
    }
       elsif ($tag=~/^CDS$/) {
        my @keyarr=split(/:/, $key);
#       print "$tag\t$key\t$start\t$end\n";
       push (@{$gh{$keyarr[0]}{$tag}} , $start);
       push (@{$gh{$keyarr[0]}{$tag}} , $end );
    }
      
 
}

# test if gene and mRNAs have same coords 

my $right = 0;
my $wrong = 0;

foreach my $key (keys %gh) {
    my $genes = @{$gh{$key}{"gene"}}[0];
    my $genee = @{$gh{$key}{"gene"}}[1];
    my $mRNAs = @{$gh{$key}{"mRNA"}}[0];
    my $mRNAe = @{$gh{$key}{"mRNA"}}[1];
#    print "$key\n";
#    print "mRNAs:$mRNAs\n";
#    print "mRNAe:$mRNAe\n";
#    print "genes:$genes\n";
#    print "genee:$genee\n";

    my @CDSs = sort { $a <=> $b } @{$gh{$key}{"CDS"}};
#    print "CDSs $CDSs[0]\n";
#    print "CDSe $CDSs[-1]\n";
    
    if ($genes == $mRNAs and $mRNAs == $CDSs[0]) {
#           print "Gene $key has correct coords\n";
            $right++;
    }
    else {
           print OUT "Gene $key don\'t have correct coords\n"; 
           $wrong++;
    }
}

print "$right genes have correct coords, and $wrong genes have incorrect coordinates - for instance mRNA and gene boundaries don't match\n";
print "Erroneous genes are printed in the output, and tagged: Gene gene-name don\'t have correct coords\n";






#########################################################################



close (IN3);


close (OUT);

__END__

# check that the contigs were already in the right order

my @sorted = sort(@contigs);

foreach my $elem (@contigs) {

 	if (@sorted[0] =~/$elem/ ) {

	}

}


# check and count methods
 
