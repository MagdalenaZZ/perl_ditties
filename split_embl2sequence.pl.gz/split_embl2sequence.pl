#!/usr/local/bin/perl -w
# mz3 script 
use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: ## perl ~/bin/perl/augustus2embl.pl augustus-output 


Input needs top be an embl-file with only ID FT FH and SQ -lines



'
}

	my $gtf = shift;

system "cat $gtf | grep -w -i -e ID -e FH -e FT -e SQ > $gtf.all";


open (IN, "<$gtf.all") || die "I can't open $gtf.all\n";



my @list = <IN>;

open (OUT, ">tmp") || die "I can't open tmp\n";

# $\ = "ID";

foreach my $elem (@list) {

	unless ($elem=~/^ID/) {
	print OUT "$elem";
	}
	if ($elem=~/^ID/) {
		close (OUT);
		my @arr = split(/\s+/, $elem);
#		print "Arr1: $arr[1]\n";
#		my $length =length($arr[1]);
#		print "Length:  $length\n";
#		my $arr2 = $arr[1];
#		chomp $arr2;
		$arr[1]	=~ s/;//;
#		print "Arr2: $arr[1]\n";
		open (OUT, ">$arr[1].all.embl") || die "I can't open $arr[1].all.embl\n";
	
	}

}

