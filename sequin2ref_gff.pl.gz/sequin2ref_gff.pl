#!/usr/local/bin/perl -w
# mz3 script for taking sequin input on contig-position on a reference
# and changing a gff so that positions are relative to reference rather than contigs

use strict;





unless (@ARGV) {
        &USAGE;
}

############### getting position info from the sequin-file #######################################

my @fpositions= '';
my @seq= '';
my @start= '';
my @end= '';

my $infile = shift;
my $gffile = shift;

open (INFILE, "$infile");
my %hash_info;
my @input = <INFILE>;

my @info;
	my $start = "";
	my $end = "";
	my $other = "";
	my $other1 = "";
	my $other2= "";
	my $other3 = "";
	my $other4 = "";
	my $newseq = "";	
	
foreach my $line (@input) {
	chomp $line;


	if ($line=~"fasta_record") {
	($start, $end, my $record)= split(/\t/, $line);

	}
	if ($line=~"note") {
	($other1, $other2, $other3, $other4, $other, $newseq)= split(/\t/, $line);

	}
	if ($line=~"label") {	
	$hash_info{$other}="$start";
	}
	
}

use Data::Dumper;
# print Dumper @info;

#  print Dumper %hash_info;

close (INFILE);


######################### reading in the gff-file ################################

open (GFFFILE, "$gffile");

my @gff= <GFFFILE>;

my @hash_gff;


foreach my $gffline (@gff) {


	 my @line = split (/\t/, $gffline);
#	 print "@line";

		my $name = $line[0];		
		my $method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
		my $end = $line[4];
		my $score = $line[5];
		my $strand = $line[6];
		my $trans = $line[7];
		my $noten = $line[8];
		my ($note1, $note2) = split(/\s+/, $noten);

		push (@hash_gff, ("$method\t$tag\t$start\t$end\t.\t$strand\t$trans\t$note1"));

}

#  print keys %hash_gff, "\n";

#print Dumper @hash_gff;


close (GFFFILE);


#################### changing positions in the gff-file ####################################


my @common = ();


#Find keys from one hash that aren't in both and print to @common


my @result;
my @res;

foreach (@hash_gff) {
	my $key_gff = $_;
#	print "$key_gff\n";

	foreach (keys %hash_info) {  
		my $key_info = $_;
#		print "$key_info\n";
			if ($key_gff=~m/$key_info.*/)  {
				my $res = "$key_info\t$key_gff\t$hash_info{$key_info}"; 
				push (@res, ($res));			
			}		
	} 
}

foreach my $line (@res) {
	
		 my @line = split (/\t/, $line);
#		 print "@line";

		my $name = $line[0];		
		my $method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
		my $end = $line[4];
		my $score = $line[5];
		my $strand = $line[6];
		my $trans = $line[7];
		my $noten = $line[8];
		my $position = $line[9];
		my $newstart = ($start + $position-1);
		my $newend = ($end + $position-1);
		my $result = "$name\t$method\t$tag\t$newstart\t$newend\t$score\t$strand\t$trans\t$noten\n";
		push (@result, ($result));
}
# @result = sort @result[9];
 print @result;



sub USAGE {

die 'Usage: sequin2list.pl sequin-file gff-file

This program takes a sequin-file with contig positions and a gff-file with positions relative to contigs
It outputs a gff which has positions relative to the reference, instead of the contigs

'
}
