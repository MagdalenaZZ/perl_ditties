#!~/bin/perl-5.10.1/perl -w

# Script for determining whether a certain package is in your library

use strict;
use warnings;

print ("Which package do you want to test? \n");
chomp (my $name=<STDIN>);

use Bio;

print "Finished task: $name \n";
print "\n";

# doesn't work because it doesnt allow me to have a $parameter in the use syntax.
