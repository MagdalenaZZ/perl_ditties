#!/usr/local/bin/perl -w
# mz3 script for running GlimmerHMM on contigs in different folders

use strict;

my $trainingdir = shift;
my $prefix = shift;


unless (@ARGV == 2) {
        &USAGE;
}

# Get a list of folders

my $directories = `ls -d */`;

# print "$directories";

my @array = split(/\n/, $directories);
# Run GlimmerHMM in the contig in all folders

# print "+++$array[2]\n"; <STDIN>;

foreach my $line2 (@array) {
#chomp $line2;
#print $line2; <STDIN>;
my $line = (split /\//, $line2)[0];
#print "----$line-----\n"; <STDIN>;
#run glimmer

print "glimmerhmm_x86_64 $line/$line.fasta -d $trainingdir -o $line/$line.$prefix.gff -g -f && perl ~/bin/perl/" , "/n";

}


sub USAGE {

die 'Usage: split_Glimmer_2_contigs.pl <glimmer_training_dir> <prefix>

glimmer_training_dir = full path to Glimmer training directory. Ex: /lustre/glimmerHMM/TrainGlimmM2011-02-16D15:14:39
prefix = prefix for the output filename


'
}



__END__


perl ~/bin/perl/split_Glimmer_2_contigs.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU2/glimmerHMM/TrainGlimmM2011-02-16D15:14:39 test