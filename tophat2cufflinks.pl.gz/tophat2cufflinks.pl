#!/usr/local/bin/perl -w

# mz3 script for taking tophat output accepted_hits.sam and turning it into cufflinks-ready file


use strict;

unless (@ARGV == 1) {
        &USAGE;
}

my $ref = shift;

print "Reference sequence: $ref \n";


# my @in2 = < all.sam >;

# if there is not an all.ssam file already - make one
unless (-e "all.sam") {

my @infiles = < *accepted_hits.sam >;


# make a header file and
#change   @PG TopHat VN:1.0.130 
#to	 @PG ID:TopHat VN:1.0.13

my $first_file = $infiles[0];

# print "I am firstfile $first_file\n";

# system `head $first_file | grep @ | sed s/TopHat/ID:TopHat/ > header.sam`;


# take each file and strip header 

foreach my $file (@infiles) {

print "Reading infile $file\n";

#my ($prefix, $other, $other2) = split (/\./, $file);

# print "I am prefix $prefix \n";

# system `cat $file | grep -v @ > $prefix.nohead.sam`;

}

}

my $step0 = "cat *accepted_hits.sam | grep -v -e @ -e M1N > all.nohead.sam; cat *accepted_hits.sam | grep @ | sed s/TopHat/ID:TopHat/ > header.sam";

my $step1 = "echo \"running Step1 concatenate sam-files\n\" ;  head -2 header.sam > 2header.sam ; cat 2header.sam *.nohead.sam > all.sam";

# my $step1 = "echo \"running Step1 concatenate sam-files\n\" ;  cat header.sam *.nohead.sam > all.sam";

my $step2 = "echo \"running Step2 make faidx\n\" ; samtools faidx $ref ";

my $step3 = "echo \"running Step3 make alignment \n\" ; samtools view -bt $ref.fai all.sam > aln.bam";

my $step4 = "echo \"running Step4 make sorted file \n\" ; samtools sort aln.bam aln-sorted";

 my $step5 = "echo \"Running Step5 remove temporary files \n\" ; cp 2header.sam old_header.sam; rm -f 2header.sam header.sam; rm -fr *nohead*; rm -fr all.sam; rm -fr aln.bam";

my $step6 = "echo \"Skipping Step2 make faidx - using existing file $ref.fai \n\" ";

my $step7 = "rm -f t2c.e";

open CMD, ">tophat2cufflinks.sh";
# test if a .fai already exists

############ if there is already an all.sam file #########################################

if (-e "all.sam") {

    print CMD "$step2 && $step3 && $step4 && $step7 \n";

}


#####################################################
else {
    if (-e "$ref.fai") {
        print CMD "$step0 && $step1 && $step6 && $step3 && $step4 && $step5 && $step7 \n";
    }
    else {
        print CMD "$step0 && $step1 && $step2 && $step3 && $step4 && $step5 && $step7 \n";
    }
}
close CMD;


system ("team133-bsub.pl basement 10 t2c.o t2c.e t2c sh tophat2cufflinks.sh");

sub USAGE {

die 'Usage: tophat2cufflinks.pl <reference-genome.fas> &

Put files or softlinks to all .sam files you want to include in the working directory. The prefix given to them will be whatever is before the first  .  (dot)

The out-file is called aln-sorted.bam and this is the input for cufflinks

Do not bsub - it bsubs itself 



'
}
__END__

