#!/usr/bin/perl -w


use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: 






'
}

# Take the infile 

my $table = shift;
my $prod = shift;


        open (IN, "<$table") || die "I can't open $table\n";
    	my @table= <IN>;
    	close (IN);
        
        open (IN3, "<$prod") || die "I can't open $prod\n";
    	my @prods= <IN3>;
    	close (IN3);
