#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: augustus_train_fixGBfromArtemis.pl input.fa chosen.txt int

input.fa is a fasta-file with one sequence/line
chosen.txt is a file with each line:
contigname	start	end

int is the length of sequence you want to include before and after

'
}


	my $in = shift;
	my $chosen = shift;
	my $extra = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	open (OUT, ">$in.chosen.fas") || die "I can't open $in.chosen.fas\n";

	open (TAB, "<$chosen") || die "I can't open $in\n";


my @sequences;

# read in sequences and put in array

while (<IN>) {

	if ($_ =~/^>/) {
    	$_ =~s/>//;
        chomp $_;
        my $seq = <IN> ;
        chomp $seq;
    	push (@sequences, "$_\t$seq");
#        my $sub = substr($seq,0,10) ;
#        print "$_\t$sub\n";
	}
}
close (IN);


# read in coords

my %coo; 


while (<TAB>) {

	if ($_ =~/\w+/) {
        chomp $_;
    	my @tab =split (/\s+/,$_);
        $coo{$tab[0]}{ "$tab[1]\t$tab[2]" } = 1;
#        print "$_\n";
	}
}
close (TAB);



# go through sequences and look for coords

foreach my $lin (@sequences) {
    my ($head, $seq) = split(/\t/, $lin);

    if (exists $coo{$head}) {

        foreach my $key (sort keys  %{$coo{$head}} ) {
#          print "Match $head\n";
           # find out total length of string
            my $len = length($seq);
#          print "LEN:$len\t$coo{$head}\n";
            my ($start, $end) = split(/\t/, $key);
            my $ext = $end-$start;
            my $new_seq = substr($seq,$start,$ext) ;
            print OUT ">$head-$start-$end\n$new_seq\n";
        
        # 
        }
        delete $coo{$head};
    }
    else {
#        print "No match $head\n";
    }

               


}


 foreach my $el (sort keys %coo ) {
     print "$el was left over\n";
 }


