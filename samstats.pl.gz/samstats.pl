#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

    die '


Usage: samstats.pl file.sam

Gives back a frequency-file and an average insert length

WARNING: insert sizes smaller than 1, and longer than 10000 are disregarded.
Normally your data should not contain these types of values, but if you think it does,
figure out another way of calculating average and median.


' . "\n";
}


print "\n";

my $sam = shift;




open (IN, "<$sam");
open (OUT, ">$sam.freq");


my %h;

while (<IN>) {


    my @arr = split(/\s+/,$_);

    if (  $arr[1]=~/^99$/ || $arr[1]=~/^163$/  ) {
        if (exists $arr[8] and $arr[8] > 1 and $arr[8]=~/^\d+$/ ) {
            $h { $arr[8] } += 1 ;
        }
#        else {
            #print "$_";
#        }
    }


}


foreach my $key (sort {$a <=> $b} keys %h) {
    print OUT "$key\t$h{$key}\n";
}


my $first = 1;
my $last = 10000;

my @goodkeys = grep exists $h{$_}, $first .. $last;

my $vals = 0;
my $tot = 0;

# calculate average
foreach my $key (sort {$a <=> $b} keys %h) {

        $vals = $vals + $h{$key};
        $tot = $tot + ($key * $h{$key} );

}

# calculate median

my $med = 0;
my $val2 = $vals/2 ;

foreach my $key (sort {$a <=> $b} keys %h) {

    $med = $med + $h{$key};
    if ($med > $val2 ) {
        print "APPR MEDIAN INSERT LENGTH $key\n";
        last;
    }
}




my $ave = ($tot/$vals);

print "AVERAGE INSERT LENGTH\t$ave\n";

print "\n";


exit;


__END__



