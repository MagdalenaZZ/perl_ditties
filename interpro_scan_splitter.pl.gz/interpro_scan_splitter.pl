#!/usr/local/bin/perl -w
# mz3 script for splitting a protein-file to several pfamscan jobs

use strict;

unless (@ARGV == 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: interproscan_splitter.pl <input.fa> <prefix> <int>
prefix = prefix for the output filename
<int>  is the approximate number of bytes you want the file to be 

The original fasta will be split in several files, each of which will be bsubbed to the farm
For nucelotides you have to add some options that this wrapper has disabled.


'
}

### this is the splitter-part of the script ####

my $in = shift;
my $out = shift;
my $size = shift;


open (IN, "<$in");
#my @in = <IN>;
my @files;
#my $length = scalar(@in);

#my $targetsize = 50*1024*1024;
my $targetsize = $size;
my $fileprefix = $out;
my $outfile = 0;
my $outsize = 0;
#my $outfh= "$fileprefix\_$outfile";
my $outfh;

my $temp='';

local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
  #print "LINE:$line:\n";
  next unless $line;
  # discard initial empty chunk
#  if($line =~ /^\$\$$/ || $outfile == 0){
#  if($line =~m/\_/ || $outfile == 0){
  if($line =~m/\w+/ || $outfile == 0){
    $line=~s/\*/X/g;
    $line=~s/\+/X/g;
    $line=~s/#/X/g;

        $outsize += length($temp);
        #print "SIZE:$outsize:\n";
        if ( $outfile == 0 || ($outsize - $targetsize) > 0)  {
              ++$outfile;
              if($outfh) {close($outfh);}
              my $inf = "$fileprefix\_$outfile";
              open ($outfh,  ">$inf");
              push (@files,  "$fileprefix\_$outfile" );
#              print "$outfh\t$fileprefix\_$outfile\n";
              $outsize = 0;
        }
        $temp='';
    }
  $temp = $temp.$line;
  print $outfh "\>$line";
}


######################
#
#
#
# make a shell-file
foreach my $file (@files) {
# my $format = "summary";
# print "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam\n";
#

print "bash /software/pathogen/external/apps/usr/local/iprscan-5.0.6/interproscan.sh -appl jobPanther-7.2,jobProDom-2006.1,jobSMART-6.2,jobPrositeProfiles-20.89,jobSignalP-EUK-4.0,jobPfamA-26.0,jobPrositePatterns-20.89,jobPRINTS-42.0,jobSuperFamily-1.75,jobGene3d-3.5.0,jobPIRSF-2.83,jobPhobius-1.01,jobTMHMM-2.0c,jobHAMAP-201302.26,jobCoils-2.2 -goterms -b $file.ipr -i $file \n" ;

# system "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -pfamB -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam";
}




