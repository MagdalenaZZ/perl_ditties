


# Remove some poor peaks using CCAT

../bin/CCAT ES_CTCF_chr19.bed ES_GFP_chr19.bed genome_length_mm8_chr19.txt config_TF.txt ES_CTCF_chr19 > ES_CTCF_chr19.log


# Find the exact binding site using SISSRs (Site Identification from Short Sequence Reads)

perl ~groupso/bin/sissrs.pl


# Filter out blacklisted regions

ask Claire


