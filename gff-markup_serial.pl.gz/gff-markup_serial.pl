#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff-markup_serial.pl products.training.out outputfile


Give the products.training.out and chosen output name


'
}


	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";



foreach my $line (@in) {
	chomp $line;
	my @arr = split (/\t/, $line);
	$arr[0] = "/locus_tag=\"$arr[0]\"";
	$arr[1] =~ s/related/putative/;
	$arr[1] = "/product=\"$arr[1]\"";
	$arr[1] =~s/PREDICTED:_//;
#	$arr[2] =~ s/Annotation/annotation/ ;
	my $product = $arr[1];

	if ($arr[1]=~/hypothetical protein/) {
		print OUT "$arr[0]\t$product\n";
	}
	else {
		$arr[2] =~ s/Annotation/annotation/ ;
		$arr[2] = "/note=\"Product $arr[2]\"";
		my $note =$arr[2];
		print OUT "$arr[0]\t$product\t$note\n";
	}
}


	close (OUT);