#!/usr/bin/perl -w

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

    die '


Usage: file_replace_value.pl file replace-values  


Takes a file, and replaces all instances of one value with another.

File replcae-values:

New <TAB> Old
New2 <TAB> Old2






' . "\n";
}


my $in = shift;
my $out = $in . "\.rep";

my $rep = shift;


# read in rep into a hash 

open (REP, "<$rep")|| die;

my %hits;


while (<REP>) {
    chomp;

    my @arr = split(/\t/, $_);

    $hits{$arr[1]}="$arr[0]";
    #print ":$arr[1]:\t:$arr[0]:\n";
}


open (IN, "<$in")|| die;
open (OUT, ">$out")|| die;


while (<IN>) {
    chomp;
    $_=~s/\;/\t/g;
    my @arr = split(/\t/, $_);

    foreach my $val (@arr) {
        #print ":$val:\n"; 
        if (exists $hits{$val}) {
            $val = $hits{$val};
            print "Replace $val\n";
        }
    }

    
    my $arr= join("\t", @arr);
    print OUT "$arr\n";
}






exit;


