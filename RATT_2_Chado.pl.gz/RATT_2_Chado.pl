#!/usr/local/bin/perl -w

# mz3 script for converting RATT-file to something else


    my $input_file = shift;
#    my $output = shift;
#    my $number =shift;	

my (@arr) = split ( /_/, $input_file);

my $cont = $arr[2];
# print "$arr[3]\n";
my ($number, $left, $left2) = split ( /.f/, $arr[3]); 
# print "$number\n";
# print "$left\n";
# print "$left2\n";
my $output ="pathogen_EMU_$cont"."_$number.final.embl";

 my $output_file ="pathogen_EMU_$cont"."_$number.final.embl.temp";

system `cat $input_file | grep -i -e ID -e FH -e FT > $output_file`;

open (IN, "<$output_file");
open (OUT, ">$output");

my @list = <IN>;

foreach my $entry (@list) {

if ($entry=~m/ID/ and $entry=~m/$number/) {

$entry =~s/tot.//;
$entry =~s/.final//;
print OUT $entry;
# ID                   tot.pathogen_EMU_scaffold_008000.final ; ; ; ; ; 3282496 BP.
}
else {
print OUT $entry;
}

}

system `perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl $output $output.temp.embl`;
system "echo perl ~/bin/perl/make_EMU_gene-names_EMBLfiles.pl $output.temp.embl $output.temp2.embl";


# system `cat $output_file | grep ID | grep $number `;