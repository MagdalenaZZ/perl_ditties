#!/usr/local/bin/perl -w

# mz3 script for calculating gc-content


use strict;

unless (@ARGV == 2) {
        &USAGE;
}

my $fasta = shift;
my $fq = shift;

open (IN, "<$fasta") || die;
open (OUT, ">$fasta.gc") || die;

#my @fasta = <IN>;
my $final_X = 0;
my $final_N = 0;
my $final_AT = 0;
my $final_GC = 0;
my @contam;

my $fastq=0;

if ($fq=~/\w+/) {
	$fastq="fastq";
}

while ( <IN>) {

# filter headers

	if ($_ =~/^>/ and $fastq=~/0/ ) {
#	print "Header: $line";
        my $line = <IN>;
        my $N_count = $line =~ tr/Nn//;
        my $X_count = $line =~ tr/Xx//;
        my $AT_count = $line =~ tr/AaTt//;
        my $GC_count = $line =~ tr/GgCc//;
        $line =~ tr/GgCcAaTtNnXx/\t/;
        my $others = $line;
        push (@contam, $others);
            $final_X =$final_X +$X_count;
        $final_N =$final_N +$N_count;
        $final_AT =$final_AT + $AT_count;
        $final_GC =$final_GC +$GC_count;
	}
    elsif ($_ =~/^@/) {
        $fastq=1;
        my $line = <IN>;
        my $red1 = <IN>;
        my $red2 = <IN>;

        #print "$_\t$line\n";
	my $len = length($line);
        my $N_count = $line =~ tr/Nn//;
        my $X_count = $line =~ tr/Xx//;
        my $AT_count = $line =~ tr/AaTt//;
        my $GC_count = $line =~ tr/GgCc//;
        $line =~ tr/GgCcAaTtNnXx/\t/;
        my $others = $line;
        #print "others $others\n";
        push (@contam, $others);
            $final_X =$final_X +$X_count;
        $final_N =$final_N +$N_count;
        $final_AT =$final_AT + $AT_count;
        $final_GC =$final_GC +$GC_count;
	print "$GC_count". " " ."$len" . " " . $GC_count/$len . "\n";
    }
    else {
    }

}
print  OUT "$fasta\tTotal X:\t$final_X\n";
print	OUT "$fasta\tTotal N:\t$final_N\n";
print	OUT "$fasta\tTotal AT:\t$final_AT\n";
print	OUT "$fasta\tTotal GC:\t$final_GC\n";

my $all = $final_AT + $final_GC;
my $gc_content = $final_GC/$all;

print OUT	"$fasta\tFinal GC content:\t$gc_content\n";

foreach my $line (@contam) {
$line =~ s/\t//g;
$line =~ s/ /space=" "  /g;
if ($line =~m/./ ){
print OUT "$fasta\tother characters:\t$line";


}
}

print "\n\n Results in file  $fasta.gc \n\n";


sub USAGE {

die '
Usage: 
perl ~/bin/perl/gc_content.pl fasta <fasta/fastq>

mz3 script for checking gc-content in a fasta, and checking all bases are right

<fasta/fastq> - wether your file is fastq or fasta
 

'
}


exit;

