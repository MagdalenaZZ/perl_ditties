#!/usr/loca/bin/perl -w
# as9 simple script for changing gff to gene-predictor input (maybe SNAP) 

use strict;

print ">pathogen_EMU_scaffold_1\n";

while (<>) {
	my @line = split (/\s+/,$_);
	if ($line[3] eq "-") {
		print "$line[0]\t$line[2]\t$line[1]\t$line[4]\n";
	} else {
		print "$line[0]\t$line[1]\t$line[2]\t$line[4]\n";
	}
}
