#!/usr/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die '
Usage: gff_fix_codingseq_output.pl augustus.codingseq



'
}


my $cs = shift;


	open (CS, "<$cs") || die "I can't open $cs\n";
	my @cs = <CS>;
	close (CS);

	open (OUT, ">$cs.fixed") || die "I can't open $cs.fixed\n";

foreach my $line (@cs) {
chomp $line;
	if ($line=~/^>/) {
		my @arr=split(/\./, $line);
#		print "Arr0:$arr[0]\n";
#		print "Arr1:$arr[1]\n";
#		print "Arr2:$arr[2]\n";
#		print "Arr3:$arr[3]\n";
#		print "Arr4:$arr[4]\n";
		my $new_name = "$arr[0]\.$arr[2]\.$arr[3]";
		print OUT "$new_name\n";
	}
	else {
		print OUT "$line\n";
	}
}


	close (OUT);

