#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die '
Usage: perl ~/bin/perl/augustus_fix_gff.pl input.gff 


NOT A SCRIPT!!!!!


'
}

my $gff = shift;





