#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}



# housekeeping

my $rand = substr( rand, 2, 5);
my @jobs;
open (OUT, ">>wrapper.velvet.sh");




# read and reformat the command

# print "$com\n";


my @command = @ARGV;

my $com = join (" ",@command);

print "\nCommand:$com\n\n";

my ($veh, $veg) = split("velvetg", $com);


# fix the velvetg command
my @vegarr = split(/ /, $veg);
shift @vegarr;
my $keep = shift @vegarr;
if ($keep=~/-\w+/) {
    unshift (@vegarr, $keep);
}
$veg = join (" ",@vegarr);
$veg =~s/ -read_trkg yes / /;

#print "VEG:$veg\n";

# fix the velveth command

$veh =~s/velveth/ /;
$veh =~s/  / /g;
$veh =~s/  / /g;


# check if there is binary data

my $bin = "0";

if ($veh=~/create_binary/) {
    $bin="1";
}


# count number of kmers to be tested

my @nos;

foreach my $line (@command) {

    if ($line =~m/\,/) {
        push (@nos, $line);
    }

}

my $no = scalar(@nos);

# print "NO::$no\n";
my @kmers;
my @outs;



# determine if there is one job or many to do, and prepare the shell scripts for them

# ALTERNATIVE 1 - weird command
if ( $no > 1) {
    print "Im a bit stupid and don't understand your input, try removing unessecary commas\n";
}

# ALTERNATIVE 2 - submit several jobs

elsif ( $no == 1) {
    print "submitting several jobs\n";

    my @jobs = split (/\,/ , $nos[0]);
    
    my $kmer =  $jobs[0];

        if ( -e "$kmer.velvet.sh" ) {
            print "File $kmer.velvet.sh already exists\n";
            exit;
        }

        # now do velveth hashes

    open (FH1, ">>prep.velvet.sh");
    my @ar1 = split ( / /, $veh);
    shift(@ar1);
    shift(@ar1);
    shift(@ar1);
    my $vep = join( " ", @ar1);

    # check if you have the binary option

    if ($bin=~/0/) {
        print FH1 " velveth o_Seq 31 -noHash $vep;\n ln -s o_Seq/Sequences;\n"; 
    }
    elsif ($bin=~/1/) {
        print FH1 " velveth o_Seq 31 -noHash $vep;\n ln -s o_Seq/CnyUnifiedSeq;\nln -s o_Seq/CnyUnifiedSeq.names;\n"; 
    }
    else {
        print "Error with the binary option\n";
        die;
    }

# MAKE the precomputing file

    print "bsub.py -q yesterday 10 prep.vel_$rand sh prep.velvet.sh\n"; 
    print OUT "bsub.py -q yesterday 10 prep.vel_$rand sh prep.velvet.sh\n";
    # system "bsub.py 10 prep.vel sh prep.velvet.sh\n"; 

    close (FH1);

    # Now make sh-files for each of the kmers

    while ( ($jobs[1] ) >= $kmer  ) {

        open (FH, ">>$kmer.velvet.sh");

#           print "KMER:$kmer:\n";
                push (@kmers, $kmer);
                my @velopt = split (/$nos[0]/, $veh );
                print FH "mkdir vel_$kmer;wait;\n";
                print FH "cd vel_$kmer;wait;\n";
                
                if ($bin=~/0/) {
                   print FH "ln -s ../Sequences;wait;\n";
                }
                else {
                   print FH "ln -s ../CnyUnifiedSeq;wait;\n";
                   print FH "ln -s ../CnyUnifiedSeq.names;wait;\n";
                }

                print FH "cd ..;wait;\n";
                print FH "velveth vel_$kmer $kmer -reuse_Sequences $velopt[1];wait;\n";
                print FH "velvetg  vel_$kmer -read_trkg yes $veg;\n\n";

                close (FH);
                
                print "bsub.py --dep=prep.vel_$rand -q hugemem 80 vel_$kmer.$rand sh $kmer.velvet.sh\n"; 
                print OUT "bsub.py --dep=prep.vel_$rand -q hugemem 80 vel_$kmer.$rand sh $kmer.velvet.sh\n";

                push (@outs, "vel_$kmer.$rand" );
                push (@jobs, "vel_$kmer.$rand" );
#                print "JOB: vel$kmer\n";
                $kmer = ($kmer + $jobs[2]) ;           
    }
 
}

# ALTERNATIVE 3 - submit one job - Untested!
elsif ( $no == 0) {
    print "submitting only one job\n";
    print "$veh\n";
    print "velvetg $veg\n\n";
}

# ALTERNATIVE 4 - major meltdown
else {
    print "Im really stupid and don't understand your input, try removing unessecary commas\n";

}


# WRITE A MERGING-FILE
# write a shell-script file
# bsub that shellscript
# Assume we want to create a merged assembly in a folder called MergedAssembly.


open (FH2, ">>merge.velvet.sh");

print "\nWhen all merged jobs have finished - do merging\n";
print FH2 "velveth MergedAssembly53 53 -long vel_*/contigs.fa\n";
print FH2  "velvetg MergedAssembly53 -read_trkg yes -conserveLong yes \n";

print FH2 "velveth MergedAssembly55 55 -long vel_*/contigs.fa\n";
print FH2  "velvetg MergedAssembly55 -read_trkg yes -conserveLong yes \n";

print FH2 "velveth MergedAssembly57 57 -long vel_*/contigs.fa\n";
print FH2  "velvetg MergedAssembly57 -read_trkg yes -conserveLong yes \n";

print FH2 "velveth MergedAssembly59 59 -long vel_*/contigs.fa\n";
print FH2  "velvetg MergedAssembly59 -read_trkg yes -conserveLong yes \n";


# print "oases MergedAssembly/ -merge \n";

my $jobx = join(" ", @outs);
# print "NNN:$jobx\n";
print "bsub.py --dep=\"$jobx\" -q normal 1 merge.vel_$rand sh merge.velvet.sh \n";
#
print OUT "bsub.py --dep=\"$jobx\" -q normal 1 merge.vel_$rand sh merge.velvet.sh; \n";



# do oases

 print "oases directory -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes \n";
 print OUT "# oases directory -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes\n";


close (FH2);
close (OUT);

print "\nHave printed a file wrapper.velvet.sh which contains all the jobs you need to sumit. Edit as you want, and then submit by:\n\nsh wrapper.velvet.sh\n\n";


sub USAGE {

die ' 

Write your job as "velveth options velvetg options", and this script will read it all in and rationalise it a bit
For example write: velveth out 25,57,2 -fastq -shortPaired -separate 3967_1_1.fastq 3967_1_2.fastq velvetg read_trkg yes -ins_length 383 -unused_reads yes -min_contig_lgth 200 -clean yes

The script will then make a unified Sequence file, and then give you shell-script files to submit.
';

}


# bsub.py -q hugemem 60 3224 python ~/bin/oases_0.2.08/scripts/oases_pipeline.py --data="-fastq -shortPaired -separate 3224_1.CORR31_3_1.fastq 3224_1.CORR31_3_2.fastq -short 3224_1.CORR31_3SE.fastq" --options="-ins_length 205 -unused_reads yes " --clean --kmin=19 --kmax=31 --kstep=2 --merge=27 --output=3224_merge27

# bsub.py -q hugemem 100 veltestg23_100 velvetg out19-37_23 -cov_cutoff auto -long_cov_cutoff auto -exp_cov auto -ins_length 3026 -ins_length2 4050 -ins_length_long 8850  -min_contig_lgth 300 -read_trkg yes -unused_reads yes 
#7305345

# bsub.py -q basement 30 veltesth4 velveth out19-37 19,37,2 -create_binary -fastq  -separate -shortPaired F6Q05Q20_1.shortP.fq F6Q05Q20_2.shortP.fq  -separate -shortPaired2 GDGEG_1.shortP2.fq GDGEG_2.shortP2.fq  -separate -longPaired GLA9HR30_1.longP.fq GLA9HR30_2.longP.fq  -separate -shortPaired3 4189_4637_7330_1.shortP3.fq 4189_4637_7330_2.shortP3.fq -short 4962.SE.fq

__END__
