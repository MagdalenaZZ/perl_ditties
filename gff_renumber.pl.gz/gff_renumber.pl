#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_renumber.pl gff



Takes a gff-file which has been done on a fasta-file which is a sub-file of a genome fasta, and positions are reported as:

pathogen_EmW_Chr_01_4341542_4342511
means that the fasta BLASTed fits on the position 4341542 - 4342511 on pathogen_EmW_Chr_01


Very specific script and unlikely to be of much use to anyone except me


'
}

my $in = shift;



open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\t/, $line);


    #print "$line\n";
    my @head = split(/\_/, $arr[0]);
    my @tail = split(/\_/, $arr[8]);   
    
    #print "@head\n";

    # check if it is forward or reverse
    # forward
    if ($arr[4]-$arr[3] > 0 or $arr[6]=~/\+/) {
        #print "positive $arr[3]\t$arr[4]\n";        
        my $adjusted_start = $head[4]+$arr[3];
        my $adjusted_end = $head[4]+$arr[4];
        #print "$head[0]\_$head[1]\_$head[2]\_$head[3]\tBLAST\tCDS\t$adjusted_start\t$adjusted_end\t\.\t\+\t\.\t$tail[0]\_$tail[1]\_$tail[2]\_$tail[3]\_$tail[4]\_$tail[5]\n";
        print "$head[0]\_$head[1]\_$head[2]\_$head[3]\tBLAST\tCDS\t$adjusted_start\t$adjusted_end\t\.\t\+\t\.\t$tail[0]\_$tail[1]\_$tail[2]\_$tail[3]\_$tail[4]\n";

    
    }
    else {
        #print "negative $arr[3]\t$arr[4]\n";
        my $adjusted_start = $head[4]+$arr[4];
        my $adjusted_end = $head[4]+$arr[3];
        print "$head[0]\_$head[1]\_$head[2]\_$head[3]\tBLAST\tCDS\t$adjusted_start\t$adjusted_end\t\.\t\-\t\.\t$tail[0]\_$tail[1]\_$tail[2]\_$tail[3]\_$tail[4]\_$tail[5]\n";
    }

}


