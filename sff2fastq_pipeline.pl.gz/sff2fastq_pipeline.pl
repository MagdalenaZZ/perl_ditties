#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: sff2fastq_pipeline.pl input.sff insertsize insertdev




'
}

	my $in = shift;
	my $insize = shift;
	my $indev = shift;
	open (IN, "$in") || die "I can't open $in\n";
#	my @in = <IN>;

	close (IN);

my ($prefix, $bin )= split(/.sff/, $in);

print "$prefix\n";

__END__

system " ~/bin/wgs-6.1/Linux-amd64/bin/sffToCA -insertsize $insize $indev -clear 454 -trim chop -linker titanium -libraryname $prefix -output $prefix $in";

my $CMD2 = "toAmos -o $prefix.afg -f $prefix.frg";

my $CMD3 = "amos2sq -i $prefix.afg -o $prefix.fas";

my $CMD4 = "

