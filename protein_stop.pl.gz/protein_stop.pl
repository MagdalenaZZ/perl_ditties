#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: protein_stop.pl input.fa

input.fa is a (protein) fasta-file with one sequence/line

'
}


	my $in = shift;

	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;
#	close (IN);

	open (OUT, ">$in.nostop") || die "I can't open $in.nostop\n";

my @sequences;

while (<IN>) {
    chomp;
    my $line = $_;

	if ($line =~/>/) {
	$line =~s/\.\.pep//;
    my $seq = <IN> ;

        if ($seq =~/[#*+]/) {
            print "$line has stops\n";
        }
        elsif ($seq =~/\w+/)  {
#            print "$line is good\n$seq\n";
        	push (@sequences, $line);
        	push (@sequences, $seq);
        }
        else {
#           print "WEIRD:$line\n";
        }

	}
}

foreach my $elem (@sequences) {
    chomp $elem;
    print OUT "$elem\n";
}





	close (OUT);

