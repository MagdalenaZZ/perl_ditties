#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}



# housekeeping
my $in = shift;
open (IN, "<$in");


while (<IN>) {
    chomp;
    if ($_=~/^AS/) {
    }
    elsif ($_=~/^CO/) {
    }
    elsif ($_=~/\w+/) {
    }
    else {
        # do nothing
    }
}


sub USAGE {

die ' 

Makes a SAM from an ACE file

';

}

