#!/usr/local/bin/perl -w

use strict;
use File::Slurp;
use Cwd;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: sam_from_gff.pl mapped.sam/bam  input.gff file.fasta  <offset>

Takes a gff-file and makes a new BAM-file from it, and new fastas, just covering the genes + offset.


offset will add a set of bases to the start or the end of your sequence (it is optional, and should only be used when there are not CDS which should be cobbled together)



'
}

print "\n1. Starting...\n";

my $in = shift;
my $gff = shift;
my $fas = "0";
$fas = shift;
my $off ="0";
$off = shift;
my $sam;

# read in BAM or SAM  ###

my $file = `file $in`;
my $file2 = `head -1 $in`;


# print ":$file:\n";

if ($file=~/gzip/) {

    # check if there is a sam-file to use already
    if (-e  "$in.sam") {
        open (IN, "<$in.sam") || die "I can't open $in.sam\n";
        print "\nInput $in read as a BAM-file, no new SAM required, as I'm using file $in.sam\n";
        $sam = "sambam";
    }
    # or make one
    else {
        system "samtools view $in > $in.sam";
        #system "samtools view -H $in > $in.head";
        open (IN, "<$in.sam") || die "I can't open $in.sam\n";
        print "\nInput $in read as a BAM-file and written to file $in.sam\n";
        $sam = "sambam";
    }

}
elsif ($file2!~/^@/) {
    #system "samtools view -S $in -o $in.sam";   
	open (IN, "<$in") || die "I can't open $in\n";
    print "\nInput $in read as a SAM-file without header\n";
    $sam = "sam no head";
}

# if file is samfile
elsif ($file=~/ASCII/) {
    system "samtools view -S $in -o $in.sam";   
	open (IN, "<$in.sam") || die "I can't open $in.sam\n";
    print "\nInput $in read as a SAM-file\n";
    $sam = "sam";
}
else {
    print "\nI dont know if your infile is SAM or BAM\n";
    die;
}



#__END__

print "2. SAM file created\n";

# run fasta_from_gff
system "perl /nfs/users/nfs_m/mz3/bin/perl/fasta_from_gff_gene.pl $fas $gff $off ";

print "3. Fasta file created\n";


# read in gff and get coordinates

open (GFF, "<$gff") || die "I can't open $gff\n";
my @gff = <GFF>;


my %gff;
my $gene;

foreach my $ele (@gff) {
    chomp $ele;
    my @arr = split(/\t/, $ele);
    if ($arr[2]=~/gene/) {

        my $start = $arr[3] - $off;
        my $adjust = $arr[3]  - $off+1;
        my $len = ($arr[4] - $arr[3]   + $off );


        $gff{$arr[0]}{"$arr[3]\t$arr[4]\t$arr[6]"}{"GENE"}="$ele";
        $gene ="$arr[3]\t$arr[4]\t$arr[6]";


        #my $adjust = $start - $off+1;
        #$arr[3]
        #$gff{$arr[0]}{"$arr[3]\t$arr[4]\t$arr[6]"}{"SAM"}="$arr[0]\_$arr[3]\-$arr[4]\-$len";


    }
    else {
        push( @{$gff{$arr[0]}{$gene}{"CDS"}}, "$ele") ;

    }
}


print "4. GFF parsed\n";

# go through the gff, and get SAM-entries which overlap with the gene
my $first = <IN>;
my @ar = split(/\t/, $first);

print "I think reads are " . length($ar[9]) . " bp long, applied to entire SAM-file\n";


=pod
# check if outfiles exist

my $cwd = cwd();
my @paths = read_dir( "$cwd", prefix => 1 ) ;
my @files;

print "Files that will be overwritten:\n";

foreach my $elem (@paths) {
    #print "$elem\n";
    if ($elem=~/\w+\_\d+\-\d+\-\d+\.sam/) {
        print " $elem\n";
    }
}

print "\n";
=cut

# open sam outfile
if (-e "$in.fas.sam") {
    system "rm -f $in.fas.sam";
    print "Removed old file $in.fas.sam\n";
}
open (TMP, ">>$in.fas.sam") || die "I can't open $in.fas.sam\n";

#__END__

my %SQ;

#=pod

while (<IN>) {

    chomp;
    #print "$_\n";

    my @arr = split(/\t/, $_);

    if ($arr[0]=~/^@/) {
        # ignore header line
    }

    elsif (exists $gff{$arr[2]} ) {

        #print "Exists $arr[2]\n";

        # get the gene coordinates from the fasta

        foreach my $gen (sort keys %{$gff{$arr[2]}} ) {
            
            # now get the SAM entry covering that gene
            my ($start,$end,$ori)=split(/\t/, $gen );
            #my @ge = split(/\t/,$gff{$arr[2]}{$gen}{GENE} );
            my $adjust = $start - $off+1;

            #$start = ($start-$adjust);
            #$end = ($end-$adjust);

            #print "$arr[2]\t$gen\t:$start:$end:$ori:\t$gen\t$gff{$arr[2]}{$gen}{GENE}\n";

            my $sstart = $arr[3]; 
            my $cigar = $arr[5];
            my @cign = split (/\D+/, $cigar );
            my @cigt = split (/\d+/, $cigar );
            my $cign2 = join(" ", @cign);
            my $slen = $off;
            $slen += $_ for @cign;
            my $send = $sstart + $slen;
            #print "N:$cign2:$sstart:$send:$slen:\n";
             

            # now test if they overlap

            #print "$start\t$end\t$sstart\t$send\n";
            # read is outside gene
            if ( $end  <= $sstart  or $send <= $start) {
                #print "OUT\t$start\t$end\t$sstart\t$send\n";

            } 
            # read is inside gene
            elsif ( $start <= $sstart  and $send <= $end) {
                #print "IN\t$start\t$end\t$sstart\t$send\n";
                #print "$gff{$arr[2]}{$gen}{GENE}\n";

                # recalculate all coords
                my $len = ($end - $start + $off + $off);
                $start = $start - $off;
                my $end = $end + $off;
                #print "$ge[0]\_$start\-$end\-$len\n"; 
                $arr[2]= "$arr[2]\_$start\-$end\-$len";
                $arr[3]=$arr[3]-$adjust+1;
                my $read =join("\t", @arr);
                $SQ{"SN:$arr[2]"}="LN:$len";
                #print "SQLINE $arr[2]\t$len\n";

                #open (TMP,">>$ge[0]\_$start\-$end\-$len\.sam") || die "Cant open file $ge[0]\_$start\-$end\-$len\.sam";
                print TMP "$read\n";
            } 
            # read is spanning the gene
            elsif ( $sstart <= $start and $end  <= $send ) {
                #print "SPA\t$start\t$end\t$sstart\t$send\n";

            } 

            # read is overlapping gene to the left
            elsif ( $start <=  $send  and $sstart <= $start ) {
                #print "LOVL\t$start\t$end\t$sstart\t$send\n";

            } 
            # read is overlapping gene to the right
            elsif ( $sstart <= $end and $end  <=  $send ) {
                #print "ROVL\t$start\t$end\t$sstart\t$send\n";

            } 
            # odd
            else {
                print "Warning:\tundetermined location of read on gene $start\t$end\t$sstart\t$send\n";
            }

        
        }
    }
    else {
        #print "Warning no gene on this scaffold $arr[2]\n";
    }


}




#=cut

close (TMP);

print "5. SAM splitted\n";

# make BAM-header

open (OUT, ">$in.head") || die "Cant open file $in.head\n";
#print "here\n";



# get HD ang PG lines

my $hd;
my $pg;


if ($sam =~/^sam$/) {

    print "SAM-file with header $in\n";
    $hd = `cat $in | grep -e \@HD | head -1 `;
    $pg = `cat $in | grep -e \@PG | head -1 `;

}
elsif ($sam =~/^sambam$/) {

    print "BAM-file with header $in\n";
    $hd = `samtools view -H $in | grep -e \@HD | head -1`;
    $pg = `samtools view -H $in | grep -e \@PG | head -1`;

}
else {

    print "SAM-file no header\n";

    $hd = '@HD	VN:1.0	SO:coordinate' . "\n"; 
    $pg = '@PG	ID:TopHat	VN:2.0.6	CL:/software/pathogen/external/bin/tophat -unknown commands' . "\n";

}




# if there is only a SAM-file without header



print OUT "$hd";
#print  "$hd";

foreach my $sq (sort keys %SQ) {
    print OUT "\@SQ\t$sq\t$SQ{$sq}\n";
    #print  "\@SQ\t$sq\t$SQ{$sq}\n";

}

print OUT "$pg";
#print "$pg";

close (OUT);

print "cat $in.head $in.fas.sam > $in.fas.tmp.sam\n";
system "cat $in.head $in.fas.sam > $in.fas.tmp.sam";

print "samtools view -S -b $in.fas.tmp.sam > $in.fas.bam\n";
system "samtools view -S -b $in.fas.tmp.sam > $in.fas.bam";

print "samtools sort $in.fas.bam $in.fas.sorted\n";
system "samtools sort $in.fas.bam $in.fas.sorted";

print "samtools index  $in.fas.sorted.bam\n";
system "samtools index  $in.fas.sorted.bam";

print "6. Finished!!!!\n";
exit;
    

__END__

# read in sam and get reads

my @gene;
my @files;

foreach my $line (@gff) {
    chomp $line;

    if ($line=~/gene/) {
        @gene = split(/\t/,$line);

        # chekc it is a gene
        if ($gene[2]=~/gene/) {
            #print "$gene[0]\t$gene[3]\t$gene[4]\n";

            if ($off=~/\w+/) {
               #print "offset :$off:\n";
                $gene[3]=($gene[3]-$off);
                $gene[4]=($gene[4]+$off); 
                #}
                #else {
                #print "No offset\n";
            }
        
	        open (TMP, "> $gff.tmp.bed") || die "I can't open $gff.tmp.bed\n";
            print TMP "$gene[0]\t$gene[3]\t$gene[4]\n";
            print "Processing gene $gene[3] - $gene[4]\n";
            system "samtools view -L $gff.tmp.bed $in > $in.$gene[3].$gene[4].sam";
            push(@files, "$in.$gene[3].$gene[4].sam" );
            close (TMP);


            # fix coordinates

            open (TMP2, "< $in.$gene[3].$gene[4].sam") || die "I can't open $in.$gene[3].$gene[4].sam\n";
    
            my @sam = <TMP2>;
            close(TMP2);
            
            my $len = $gene[4] -$gene[3];
            open (TMP3, "> $in.$gene[3].$gene[4].sam") || die "I can't open $in.$gene[3].$gene[4].sam\n";
            print TMP3 "@HD\tVN:1.0\tSO:coordinate\n";
            print TMP3 "@SQ\tSN:$in.$gene[3].$gene[4]\tLN:$len\n";


            foreach my $l (@sam) { 
                    my @arr = split(/\s+/,$l);
                    $arr[3]=($gene[3]-$off);
                    my $newl =join("\t", @arr);
                    print TMP3 "$newl\n";
            }

            close(TMP3);

        }

    }
    else {
        # ignore line
    }


}












