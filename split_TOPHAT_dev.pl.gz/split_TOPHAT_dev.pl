#!/usr/local/bin/perl -w
# mz3 script for creating a folder structure for Tim's web-view Artemis for the incubator

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

## parse infile

my $infile = shift;
#my $infile2 = shift;
my $prefix = shift;
my $samfile = shift;
 
open (IN, "$infile");
my @list = <IN>;

if (-e "$prefix.split_tophat.sh") {
print "Warning: overwrote old file $prefix.split_tophat.sh ";
system `rm -f $prefix.split_tophat.sh`;
}


foreach my $scaffold (@list) {
chomp $scaffold;

# make a directory with scaffold name, unless it already exists
system ("mkdir $scaffold") unless (-d $scaffold);

#my $scaffold2 = '>'."$scaffold";
#system ("cat $infile2 | grep $scaffold2 -w -A 1 > ./$scaffold/$scaffold.fasta") unless (-d  #"./$scaffold/$scaffold.fasta" );

# make a faidx index and Print only the part of the file for that scaffold

# unless ("-e ./$scaffold/$scaffold.fasta.fai") 

my $step0 = "echo \"running Step0 making multiline fasta \n\"; /nfs/helminths/users/mz3/mh12/python/fasta2multiline.py ./$scaffold/$scaffold.fasta ./$scaffold/$scaffold.m.fasta 1000";

my $step1 = "echo \"running Step1 creating faidx \n\"; samtools faidx ./$scaffold/$scaffold.m.fasta";

# Make  a .sam file to print to
open (OUT, ">$scaffold/$scaffold.$prefix.tophat.sam");

# change header in SAM
my $step2 = "echo \"running Step2 $scaffold changing header \n\"; cat $samfile | head -2 | sed 's/TopHat/ID:TopHat/' > ./$scaffold/$scaffold.$prefix.tophat.sam ";

# make one sam for each scaffold
my $step3 = "echo \"running Step3 $scaffold making scaffold-only sam\n\"; cat $samfile | grep $scaffold >> ./$scaffold/$scaffold.$prefix.tophat.sam";

# make one bam from sam for each scaffold
my $step4 = "echo \"running Step4 $scaffold making bam\n\"; samtools view -bt ./$scaffold/$scaffold.m.fasta.fai ./$scaffold/$scaffold.$prefix.tophat.sam > ./$scaffold/$scaffold.$prefix.sorted.tophat.bam";
 
# make am-index
my $step5 = "echo \"running Step5 $scaffold making bam-index\n\"; samtools index ./$scaffold/$scaffold.$prefix.sorted.tophat.bam ./$scaffold/$scaffold.$prefix.sorted.tophat.bam.bai";

my $step6 = "rm -fr ./$scaffold/$scaffold.$prefix.tophat.sam";

close (OUT);

open CMD, ">>$prefix.split_tophat.sh";


print CMD "$step0 && $step1 && $step2 && $step3 && $step4 && $step5 && $step6\n";
close CMD;

}

system ("team133-bsub.pl long 5 $prefix.split_tophat.o $prefix.split_tophat.e $prefix.split_tophat sh $prefix.split_tophat.sh");


# system "rm $prefix.split_tophat.sh";


sub USAGE {

die 'Usage: split_TOPHAT.pl file prefix samfile

file = tab delimited file with names of contigs or scaffolds being mapped

Ex:
pathogen_EMU_contig_2361
pathogen_EMU_contig_2362
pathogen_EMU_contig_2367
pathogen_EMU_contig_2372
pathogen_EMU_contig_2375

cat file.fasta | grep > |tr -d > > file

prefix = your chosen prefix - maybe the name of the RNAseq run?
samfile= accepted_hits.sam file

Warning: use full path unless the file is in . 
Warning2: make sure to run the script from the folder in which all the scaffold-folders are
Warning3: Make sure to run multifas2singlefas2.pl first

'
}

__END__

=pod
For contigs:



perl ~/bin/perl/split_TOPHAT.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado/head_list_scaffolds_file.txt 5817_1 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/tophat/EMUtophat5817_1/accepted_hits.sam

perl ~/bin/perl/split_TOPHAT.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado/list_scaffolds_file.txt 5477_3 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/tophat/EMUtophat5477/accepted_hits.sam

perl ~/bin/perl/split_TOPHAT.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado/list_scaffolds_file.txt 5817_2 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/tophat/EMUtophat5817_2/accepted_hits.sam



perl ~/bin/perl/split_TOPHAT_dev.pl large.tab EMU2_tophat_5477_3 /nfs/helminths/users/mz3/EMU/EMUv2/tophat/EMUtophat5477/accepted_hits.sam

perl ~/bin/perl/split_TOPHAT_dev.pl EMUcontigs.tab EMU2_tophat_5477_3 /nfs/helminths/users/mz3/EMU/EMUv2/tophat/EMUtophat5477/accepted_hits.sam

perl ~/bin/perl/split_TOPHAT_dev.pl EMUcontigs.tab EMU2_tophat_5817_1 /nfs/helminths/users/mz3/EMU/EMUv2/tophat/EMUtophat5817_1/accepted_hits.sam

perl ~/bin/perl/split_TOPHAT_dev.pl EMUcontigs.tab EMU2_tophat_5817_2 /nfs/helminths/users/mz3/EMU/EMUv2/tophat/EMUtophat5817_2/accepted_hits.sam