#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: fasta_change_A2N.pl <length> fasta

<length> is the length of polyA or polyT you want to replace with Ns


' . "\n";
}


my $str = shift;
my $fas = shift;

my $polyA = "A" x $str;
my $polyT ="T" x $str;
my $polyN ="N" x $str;


open (OUT, ">$fas.N.fas");

system "fasta2singleLine.py $fas $fas.sl";

#system "cat $fas.sl | sed 's/$polyA/$polyN/g' |  sed 's/$polyT/$polyN/g'  > $fas.sl2  ";


open (IN, "<$fas.sl");

while (<IN>) {
chomp;

    if ($_=~'^>') {
        my $head = $_;
        my $seq = <IN>;
        $seq = uc($seq);
        #my $length = length($seq);
        #print "BEFORE: $head\n$seq\n";

	    if ($seq =~ /A{$str,}/ || $seq =~ /T{$str,}/) {
            $seq =~s/$polyA/$polyN/gi;
            $seq =~s/$polyT/$polyN/gi; 
            my $length = $str;

            for (; $length > 0 ; $length--) {
                $seq =~s/NA/NN/gi;
                $seq =~s/NT/NN/gi;
            }
        }

        #print " AFTER: $head\t$seq\n";
        print OUT "$head\n$seq";

    }

}

close OUT;

exit;





