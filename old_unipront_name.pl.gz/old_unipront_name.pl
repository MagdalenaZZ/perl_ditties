#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}

sub USAGE {

die 'Usage: uniprot_name.pl in

Give it a fasta-file with uniprot, and get a fasta with nice cleaned up names


'
}



	my $in = shift;


    system "fasta2singleLine.py $in $in.sl"; wait;

	my $out = "$in.renamed";
	open (IN, "<$in.sl") || die "I can't open $in.sl\n";
    	open (OUT, ">$out") || die "I can't open $out\n";



## read the fastas
my %fasta;

while (<IN>) {
	if ( $_ =~m/^>/) {
		my $name = $_ ;
        chomp ($name);
#        print "$name\n"; <STDIN>;
		my $seq = <IN> ;
		chomp($seq) ;

        #########

# translate the names nicely
        my @nam = split(/\|/, $name);

        $name= $nam[2] ;

        if ( $name =~/Echinococcus granulosus/ ) {
            $name= "Eg"  . $name;
        }
        elsif ( $name =~/Echinococcus multilocularis/ ) {
            $name= "Em"  . $name;
        }
        elsif ( $name =~/Hymenolepis microstoma/ ) {
            $name= "Hm"  . $name;
        }
        elsif ( $name =~/Taenia solium/ ) {
            $name= "Ts"  . $name;
        }
        elsif ( $name =~/Taenia/ ) {
            $name= "Tx"  . $name;
        }
        elsif ( $name =~/Echinococcus/ ) {
            $name= "Ex"  . $name;
        }
        elsif ( $name =~/Hymenolepis/ ) {
            $name= "Hx"  . $name;
        }

        my @nam2 = split(/OS=/, $name);
        $name = $nam2[0];
	if ( $name =~/HUMAN/) {
        $name = ">O_" . $name;
	}
	elsif ( $name =~/MOUSE/) {
        $name = ">U_" . $name;
	}	
	elsif ( $name =~/CAEEL/) {
        $name = ">C_" . $name;
	}
	elsif ( $name =~/DANRE/) {
        $name = ">R_" . $name;
	}
	elsif ( $name =~/DROME/) {
        $name = ">D_" . $name;
	}		
	else {
        $name = ">X_" . $name;
	}
        ########
    		$fasta{$name} = $seq ;
#        print "$name\t$seq\n";
 	}
    else {
    }
}


# print the output

foreach my $gene (keys %fasta) {

    print OUT "$gene\n$fasta{$gene}\n";
}




