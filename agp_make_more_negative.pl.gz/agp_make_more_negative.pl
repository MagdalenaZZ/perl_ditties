#!/usr/bin/perl -w


use strict;


unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: agp_make_more_negative.pl agp-file cutoff


cut-off is the boundary under which you want a gap to be negative


'
}



	my $in = shift;
	my $cut = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	my $out = $in . "\.mod\.agp";
	open (OUT, ">$out") || die "I can't open $$out\n";
#	my @in = <OUT>;
#	close (OUT);   

foreach my $line (@in) {

	if ($line =~/fragment/) {
		my @arr=split(/\s+/, $line);
		my $contig = $arr[0];
		my $start = $arr[1];
		my $end = $arr[2];
		my $no = $arr[3];
		my $n = $arr[4];
		my $length = $arr[5];
		my $frag = $arr[6];
		my $yes = $arr[7];

		if ($length > $cut) {
			print  OUT $line;
		}
		else {
			my $newlength = ($length - $cut -1 );
			print OUT "$contig\t$start\t$end\t$no\t$n\t$newlength\t$frag\t$yes";
		}
	}
	else {
		print  OUT "$line";
	}


}




	close (OUT);