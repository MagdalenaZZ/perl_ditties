#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >3 ) {
        &USAGE;
}


sub USAGE {

die 'Usage: phylo_merger.pl output *.fas


'
}

my $out = shift;
my @in = @ARGV;
my $in = join(" ", @in);


open (OUT, ">$out") || die "I can't open $out\n";


# read in all files and get all categories to merge on

my @sys = `cat $in | grep '>' | sed 's/>//'| sort | uniq `;



#print "@sys\n";

my %h;
my %res;

#        $h{$line}{"NUMBER"}=0;
#        $h{$line}{"SEQ"}=0;

#
foreach my $line (@sys) {
    chomp $line;

    # save master
    if ($line=~/\w+/) {
        $h{$line}{"NUMBER"}=0;
        $h{$line}{"SEQ"}="";
        #push(@{$res{$line}}, "x");
        #print "$line\n";
    }
}


# go through each file and check if the sequence is there
my $index;

foreach my $file (@ARGV) {
    #print "$file\n"; 
   $index++;

    if (-s $file) {
    open (IN, "<$file") || die "I can't open $file\n";
    }
    my $len;

    while (<IN>) {

        if ($_=~/\>/) {
            my $head = $_;
            $head=~s/\>//;
            chomp $head;
            my $seq = <IN>;
            chomp $seq;
            $len = length($seq);

            if (exists $h{$head}) {
                #print "$head\t$len\t$seq\n";
                $h{$head}{"SEQ"}=  $h{$head}{"SEQ"} . $seq   ;
                $h{$head}{"NUMBER"}+=1;
            }
            else {
                print "Warn 1\n";
            }
        }
        else {
            print "Warn 2\n";
        }

    }
    close (IN);

    my $ns = "-" x $len;
    print "$file\t$len\n";

# if not, fill it in
    foreach my $tax ( keys %h ) {
        #foreach my $num ( keys %{$h{$tax}{NUMBER}} ) {
        #print "$tax\t$h{$tax}{NUMBER}\t$ns\n";

        if  ( $h{$tax}{NUMBER} < $index ) {
            #print "$tax\t$h{$tax}{NUMBER}\t$ns\n";

            # now add it
                $h{$tax}{"SEQ"}=  $h{$tax}{"SEQ"} . $ns   ;
                $h{$tax}{"NUMBER"}+=1;
        }
            #}   
    }
}



foreach my $tax ( keys %h ) {
        print OUT ">$tax\n$h{$tax}{SEQ}\n";
}



close(OUT);

