#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: protein_checker.pl infile 

Make sure the input fasta is single-line

'
}


## parse infile

my $infile = shift;
my $outfile = "$infile.fixed";
 
open (IN, "<$infile");

open (OUT, ">$outfile");
my @contam;

my    $final_A = 0;
my	$final_R = 0;
my	 $final_N = 0;
my	 $final_D = 0;
my	 $final_C= 0;
my	 $final_Q = 0;
my	 $final_E = 0;
my	 $final_G = 0;
my	 $final_H = 0;
my	 $final_I = 0;
my	 $final_M = 0;
my	 $final_L = 0;
my	 $final_K = 0;
my	 $final_F = 0;
my	 $final_P = 0;
my	 $final_S = 0;
my	 $final_T = 0;
my	 $final_W = 0;
my	 $final_Y = 0;
my	 $final_V = 0;
my	 $final_X = 0;
my	 $final_S1 = 0;
my	 $final_S2 = 0;

while (<IN>) {

    chomp $_;

    if ($_=~/^--$/) {
        print "Warning: -- lines\n";
    }
    elsif ($_=~/^$/) {
        print "Warning: blank-lines\n";

    }
    elsif ($_=~/^>/) {
        my $head = $_;
        my $seq = <IN>;
        chomp $seq;
#        print "$head\n$seq\n";
        my $line = $seq;
     	my $A_count = $line =~ tr/A//;
     	my $R_count = $line =~ tr/R//;
     	my $N_count = $line =~ tr/N//;
     	my $D_count = $line =~ tr/D//;
     	my $C_count = $line =~ tr/C//;
     	my $Q_count = $line =~ tr/Q//;
     	my $E_count = $line =~ tr/E//;
     	my $G_count = $line =~ tr/G//;
     	my $H_count = $line =~ tr/H//;
      	my $I_count = $line =~ tr/I//;
        my $M_count = $line =~ tr/M//;
        my $L_count = $line =~ tr/L//;
     	my $K_count = $line =~ tr/K//;
     	my $F_count = $line =~ tr/F//;
      	my $P_count = $line =~ tr/P//;
        my $S_count = $line =~ tr/S//;
        my $T_count = $line =~ tr/T//;
     	my $W_count = $line =~ tr/W//;
     	my $Y_count = $line =~ tr/Y//;
      	my $V_count = $line =~ tr/V//;
      	my $X_count = $line =~ tr/X//;

        my $S1_count = $line =~ tr/\*//;
        my $S2_count = $line =~ tr/\+//;

    $final_A =$final_A +$A_count;
	$final_R =$final_R +$R_count;
	 $final_N =$final_N +$N_count;
	 $final_D =$final_D +$D_count;
	 $final_C =$final_C +$C_count;
	 $final_Q =$final_Q +$Q_count;
	 $final_E =$final_E +$E_count;
	 $final_G =$final_G +$G_count;
	 $final_H =$final_H +$H_count;
	 $final_I =$final_I +$I_count;
	 $final_M =$final_M +$M_count;
	 $final_L =$final_L +$L_count;
	 $final_K =$final_K +$K_count;
	 $final_F =$final_F +$F_count;
	 $final_P =$final_P +$P_count;
	 $final_S =$final_S +$S_count;
	 $final_T =$final_T +$T_count;
	 $final_W =$final_W +$W_count;
	 $final_Y =$final_Y +$Y_count;
	 $final_V =$final_V +$V_count;
	 $final_X =$final_X +$X_count;

	 $final_S1 =$final_S1 +$S1_count;
	 $final_S2 =$final_S2 +$S2_count;

	$line =~ tr/ARNDCQEGHIMLKFPSTWYVX/\t/;
	my $others = $line;
#	print "$others\n";
	push (@contam, $others);


    }
# print "HI\n";

}

print	"Total A: $final_A\n";
print	"Total R: $final_R\n";
print	"Total N: $final_N\n";
print	"Total D: $final_D\n";
print	"Total C: $final_C\n";
print	"Total Q: $final_Q\n";
print	"Total E: $final_E\n";
print	"Total G: $final_G\n";
print	"Total H: $final_H\n";
print	"Total I: $final_I\n";
print	"Total M: $final_M\n";
print	"Total L: $final_L\n";
print	"Total K: $final_K\n";
print	"Total F: $final_F\n";
print	"Total P: $final_P\n";
print	"Total S: $final_S\n";
print	"Total T: $final_T\n";
print	"Total W: $final_W\n";
print	"Total Y: $final_Y\n";
print	"Total V: $final_V\n";
print	"Total X: $final_X\n";
print	"Total S1: $final_S1\n";
print	"Total S2: $final_S2\n";
#print	"Total M: $final_M\n";
#print	"Total L: $final_L\n";
#print	"Total K: $final_K\n";


#print	"Final GC content: $gc_content\n";

foreach my $line (@contam) {
$line =~ s/\t//g;
# $line =~ s/ /space=" "  /g;
    if ($line =~m/\+/ || $line =~m/\*/  ){
        print "stop codon: $line\n";
        }
    elsif ($line =~m/./ ) {
        print "other characters: $line\n";
    }
}

close (OUT);
