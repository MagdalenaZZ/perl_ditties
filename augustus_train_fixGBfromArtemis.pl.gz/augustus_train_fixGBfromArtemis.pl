#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: augustus_train_fixGBfromArtemis.pl input.gb cont

cont - if the entry is a scaffold - put cont


'
}

	my $in = shift;
#	my $scaf = shift;
	open (IN, "$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my $last1_CDS = 0;
my $last2_locus = 0;
my $last3_colour = 0;
my $last4_CDS = 0;

#unless ($scaf=~/cont/) {

#print $in[0];
#shift @in;
#print $in[0];
#shift @in;
#print $in[0];
#shift @in;
#print $in[0];
#shift @in;

#}

my $flag = 0;

## VALIDATOR


foreach my $line (@in) {

# change the value of flag and pass rest of file
if ($flag)  {
#print "$line";
# $flag =0;
}

elsif ($line =~/CDS/) {

#print "More CDS: $line";
#print "More CDS: $last1_CDS";
#print "More locus: $last2_locus";
#print "More colour: $last3_colour";
#print "More oldCDS: $last4_CDS";

	if ($last2_locus =~/locus/) {
		if ($last3_colour =~/colour/) {
			if ($last4_CDS =~/CDS/) {
			}
			else {
			print "Problem with $line";
			}
		}
		else {
		print "Problem with $line";
		}
	}
	else {
	print "Problem with $line";
	}

#my @arr = split (/,/, $last4_CDS);
#print "LOCUS       EmW_000091       10001 bp    DNA             INV       21-Aug-2001\n";

#print "More CDS: $line";

	
}


# change the value of flag and pass rest of file
elsif ($line =~/BASE COUNT/) {
$flag =1;
print "$line\n";
}

# move everything forward
$last4_CDS = $last3_colour;
$last3_colour = $last2_locus;
$last2_locus = $line;

#$last2_locus = $last1_CDS;
#$last1_CDS = $line;

}


## REAL CALCULATION



$flag = 0;
$last1_CDS = 0;
$last2_locus = 0;
$last3_colour = 0;
$last4_CDS = 0;


my $counter = "000001";

foreach my $line (@in) {

# change the value of flag and pass rest of file
	if ($flag)  {
	print "$line";
	# $flag =0;
	}

	elsif ($line =~/CDS/) {
#	unless ($last4_CDS=0) {
	#print "More CDS: $line";
	#print "More CDS: $last1_CDS";
	#print "More locus: $last2_locus";
	#print "More colour: $last3_colour";
#	print "\n\n";
#	print "More oldCDS: $last4_CDS\n";
	my $flag_cmp=0;
	if ($last4_CDS=~/complement/) {
	$flag_cmp =1;
	}

	# split the last CDS
	my @CDSarray= split ( /([, .()])/,$last4_CDS);
	my @grepCDSarray = grep(/\d+/, @CDSarray); 
	my @sorted = sort { $a <=> $b } @grepCDSarray;
	my $start =$sorted[0] ;
	my $end = $sorted[-1];
	chomp $end;
	my $length =($end - $start);
	# split the last locus
	my @IDarray = split (/([":])/,$last2_locus);
	my $ID = $IDarray[2];
	my $ID2= "EmW_".$counter;
		if ($last4_CDS=~/complement/) {
		print "LOCUS       $ID2       $length bp    DNA             INV       21-Aug-2001\n";
		print "      gene            complement($start\.\.$end)\n";
		print "$last4_CDS";
		print "                     /Parent=\"$ID2\.1\"\n";
		print "                     /ID=\"$ID2:exon\"\n";
		print "     polypeptide    complement($start\.\.$end)\n";
		print "                     /ID=\"$ID2:pep\"\n";
		print "                     /Derives_from=$ID2\.1\n";
		print "     mRNA           complement($start\.\.$end)\n";
		print "                     /ID=\"$ID2\.1\"\n";
		print "                     /Parent=\"$ID2\"\n";
		}
		else {
		print "LOCUS       $ID2       $length bp    DNA             INV       21-Aug-2001\n";
		print "      gene            $start\.\.$end\n";
		print "$last4_CDS";
		print "                     /Parent=\"$ID2\.1\"\n";
		print "                     /ID=\"$ID2:exon\"\n";
		print "     polypeptide    complement($start\.\.$end)\n";
		print "                     /ID=\"$ID2:pep\"\n";
		print "                     /Derives_from=$ID2\.1\n";
		print "     mRNA           complement($start\.\.$end)\n";
		print "                     /ID=\"$ID2\.1\"\n";
		print "                     /Parent=\"$ID2\"\n";
		}
	$counter++;

#	foreach my $elem (@sorted) {
#	print "$elem\n";
#	}
#	}
	}


# change the value of flag and pass rest of file
	elsif ($line =~/BASE COUNT/) {
	$flag =1;
	print "$line\n";
	}

# move everything forward
$last4_CDS = $last3_colour;
$last3_colour = $last2_locus;
$last2_locus = $line;

#$last2_locus = $last1_CDS;
#$last1_CDS = $line;


}













__END__


	if ($line =~/ID=/) {
		if ($line =~/\./) {
			print "$line";
		}
		elsif ($line =~/\:/) {
			print "$line";
		}
		else {
			my ($id, $gene ) =split (/"/, $line);
			print "LOCUS       $gene       10001 bp    DNA             INV       21-Aug-2001\n";
			print " $last2_line";
			print " $last1_line";
		}
	}
	elsif ($line =~/gene/) {
	# do nothing
	}
	elsif ($line =~/isObsolete/) {
	# do nothing
	}

	else {
	print "$line";
	}


# move everything forward
$last3_line = $last2_line;
$last2_line = $last1_line;
$last1_line = $line;
}

=pod

Export genes from Chado as gb format - make sure everything you don't want is obsolete

Run this script

Adjust the length of the "source" header so that it is as long as the scaffold - not just the first contig.