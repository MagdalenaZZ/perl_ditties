#!/usr/bin/perl -w

use strict;

unless (@ARGV > 3) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_result.pl blatout_1.psl blatout_2.psl file_1.fastq file_2.fastq 
Takes a blat-output, and retrieves the hits from a fastq file.

Then masks the hits with low-quality Ns and outputs new balanced fastq-files


<type> -s which species or type of sequence this is from:
valid choices; SMA 
(miRNA, HYM, EGU and EMU)



Warning: psl-files should have no header



This script assumes that the reads are like this:

<miRNA read> | <primer>

and that the primers are like this:

>forward (in /1 reads)
AGATCGGAAGAGCACACGTCTGAACTCCAGTCACTAGCTTATCTCGTATGCCGTCTTCTCCTTGAAAAAAAAAAAAAAACG
AGATCGGAAGAGCACACGTCTGAACTCCACTCACTAGCTTATCTCGTATGCCGTCTTCTCCTTGAAAAAAAAAAACAAAAA
AGATCGGAAGAGCACACGTCTGAACTCCAGTCACTAGCTTATCTCGTATGCCGTCTTCTCCTTGAAAAAAAAAAAAAAAAA
AGATCGGAAGAGCACACGTCTGAACTCCAGTCACTAGCTTATCTCGTATGCCGTCTTCTCCTTGAAAAAAAAAAAAAAAAA

>reverse (in /2 reads)
GATCGTCGGACTGTAGAACTCTGAACGTGTAGATCTCGGTGGTCGCCGTATCATTAAAAAAAAAAAAAATAAAAAAAAAGA
GATCGTCGGACTGTAGAACTCTGAACGTGTAGATCTCGGTGGTCGCCGTATCATTAAAAAAAAAAAAAAAAA
GATCGTCGGACTGTAGAACTCTGAACGTGTAGATCTCGGTGGTCGCCGTATCATTAAAAAAAAAAAAAAAAAAAAAAGA

>read1_end
AGATCGGAAGAGCACACGTCTGAACTCCAGTCACNNNNNNATCTCGTATGCCGTCTTCTGCTTG
>read2_end
GATCGTCGGACTGTAGAACTCTGAACGTGTAGATCTCGGTGGTCGCCGTATCATT





' . "\n";
}


my $blat = shift;
my $blat2 = shift;
my $fastq1 = shift;
my $fastq2 = shift;
my $type = "hi";


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        # an alignment length of at least 12 nucleotides and one or no mismatches
        if ($arr[0]> 11 and $arr[1] < 2 and $arr[5] < 2 and $arr[7] < 2   ) {
            #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max\t$arr[8]" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]\t$arr[8]" ;
                #print "$arr[9]\t$arr[11]\t$arr[12]\n";                
                # make a hit-match - hit just has the read, not forward or rev info
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN2, "<$blat2")|| die;



while (<IN2>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        # an alignment length of at least 12 nucleotides and one or no mismatches
        if ($arr[0]> 11 and $arr[1] < 2 and $arr[5] < 2 and $arr[7] < 2   ) {
            #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max\t$arr[8]" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]\t$arr[8]" ;
                #print "$arr[9]\t$arr[11]\t$arr[12]\n";                
                # make a hit-match - hit just has the read, not forward or rev info
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}


close (IN);
close (IN2);



# read the fastq-files line by line, and print the reads with a match to another file


unless (-s "$fastq1.chosen.fastq" and -s "$fastq2.chosen.fastq" ){

    if ($fastq1 =~ /\.gz$/) {
        open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";
    }
    else {
        open(FAS1, $fastq1) || die "can't open $fastq1";
    }

    if ($fastq2 =~ /\.gz$/) {
        open(FAS2, "gunzip -c $fastq2 |") || die "can't open pipe to $fastq2";
    }
    else {
        open(FAS2, $fastq2) || die "can't open $fastq2";
    }


    open (OUT1, ">$fastq1.chosen.fastq")|| die;
    open (OUT2, ">$fastq2.chosen.fastq")|| die;
    #open (OUTR1, ">$fastq1.not_chosen.fastq")|| die;
    #open (OUTR2, ">$fastq2.not_chosen.fastq")|| die;

    #my $lr1;
    #my $lr2;

    my $hit = 0;

    while (<FAS1>) {

        if ($_=~/^@/) {
            my $head = $_;
            $head=~s/^@//;
            $head =~s/\/1$//;
            chomp $head;
            my $seq = <FAS1>;
            my $mid = <FAS1>;
            my $qual = <FAS1>;

#        print "match $head\n";

            if (exists $hits{$head}) {
                #print "$_";
                print OUT1 "$_$seq$mid$qual";
            }
            else {
                #print OUTR1 "$_$seq$mid$qual";

            }


        }
        else {
            print "Should not happen $_";
        }
    }


    while (<FAS2>) {

        if ($_=~/^@/) {
            my $head = $_;
            $head=~s/^@//;
            $head =~s/\/2$//;
            chomp $head;
            my $seq = <FAS2>;
            my $mid = <FAS2>;
            my $qual = <FAS2>;

            #print "match $head\n";

            if (exists $hits{$head}) {
                #print "$_";
                print OUT2 "$_$seq$mid$qual";
            }
            else {
                #print OUTR2 "$_$seq$mid$qual";

            }

        }
        else {
            print "Should not happen $_";
        }
    }

    close (FAS1);
    close (FAS2);
    close (OUT1);
    close (OUT2);

}

#__END__

# read in the temp-fastqs, and trim them according to the best BLAT-hit

open (IN1, "<$fastq1.chosen.fastq")|| die;
open (IN2, "<$fastq2.chosen.fastq")|| die;
open (OUT5, ">$fastq1.primer.fastq")|| die;
open (OUT6, ">$fastq2.primer.fastq")|| die;
#open (OUT7, ">$fastq1.no_blat.fastq")|| die;
#open (OUT8, ">$fastq2.no_blat.fastq")|| die;


my %final;
my %final2;

while (<IN1>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1 =~s/\/1$//;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            my $ori_qual = $qual;

            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);

            #print "$_$out_seq1\t $new_seq\t$out_seq2\n" ;

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }

            # now choose if the read had indeed a splice-leader in it by looking at the out-take
            if ($type=~/\w+/ ) {

                # or choose a primer if this is miRNAs with the NEB protocol
                if ( $new_seq =~/^AGAT/i or $new_seq =~/AAGAGCACACGT/  ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    my $out_qual1 = substr($ori_qual, 0, $min);
                    my $out_qual2 = substr($ori_qual, $max, -1);
                    $final{$head1}{$head}="$_$out_seq1\n$mid$out_qual1\n";
                    print OUT5 "$_$new_seq$out_seq2\n$mid$new_qual$out_qual2\n";
                }


                else {
                    print "FWD: This is not a real miRNA $new_seq \n";
                }
            }
            else {
                print "You have to specify which type of sequence you are filtering $type \n";
                die;
            }
        }
        # these are reads whose partner has a primer, but they don't, so we pass them on
        else {
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print OUT1 "$_$seq$mid$qual";
            #print "This shouldnt happen! Sequence in file *chosen.fastq which was not in the psl file $_\n";
        }
    }
}




while (<IN2>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1=~s/\/2$//;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            my $ori_qual = $qual;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }
            #print "$new_seq\n";
            # now choose if the read had indeed a splice-leader in it by looking at the out-take

            if ($new_seq =~/^GATCG/i  or $new_seq =~/ACTGTAGAACT/  ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    my $out_qual1 = substr($ori_qual, 0, $min);
                    my $out_qual2 = substr($ori_qual, $max, -1);
                    $final{$head1}{$head}="$_$out_seq1\n$mid$out_qual1\n";
                    print OUT6 "$_$new_seq$out_seq2\n$mid$new_qual$out_qual2\n";
                }
            else {
                print "REV: This is not a real miRNA $new_seq\n";
            }
        }
        # these are reads whose partner has a primer, but they don't, so we pass them on
        else {
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print "$_$seq$mid$qual";
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print OUT2 "$_$seq$mid$qual";
            #print "This shouldnt happen! Sequence in file *chosen.fastq which was not in the psl file $_\n";
        }
    }
}


print "\nstep 1 worked\n";


# now finally report the paired full output



open (OUT3, ">$fastq1.trimmed.fastq")|| die;
open (OUT4, ">$fastq2.trimmed.fastq")|| die;
#open (OUT7, ">$fastq1.rubbished.fastq")|| die;
#open (OUT8, ">$fastq2.rubbished.fastq")|| die;




foreach my $key (sort keys %final) {
    #print "$key\n";
    my $sca = scalar  keys %{$final{$key}};
    #print "$sca\n";
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";
        print OUT3 "$final{$key}{$first}";
        print OUT4 "$final{$key}{$second}";

    }
}

print "\nstep 2 worked\n";

=pod

foreach my $key (sort keys %final2) {
    #print "$key\n";
    my $sca = scalar  keys %{$final2{$key}};
    #print "$sca\n";
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";
        print OUT7 "$final2{$key}{$first}";
        print OUT8 "$final2{$key}{$second}";

    }
}

print "\nstep 3 worked\n";
=cut




close (IN1);
close (IN2);
close (OUT3);
close (OUT4);
close (OUT5);
close (OUT6);
#close (OUT7);
#close (OUT8);




# system "rm -f $fastq1.chosen.fastq $fastq2.chosen.fastq ";

__END__

TGCAGCTCAGGCTCTGCCTACGAGC
ACTCCTTCGAACACCA

TGGTGTTCGAAGGAGT
ACTCCTTCGAACACCA


>Emu.SL2c
GTTACCGATA
AATCGGTCCT
TACCTGCACT
TTTGTATGGT
GAGTATC

>SL
GATGCAGCTCAGGCTCTG CCTACGAG

CTGACAGTATTTGGCTGGTCCGACGAGGGCC


CGAAGATGTA
CTCGGCCTCG
TAGGCCTGCA
TCACTCCCGT
CCAGTTAGGC
CATGTCCAGC
CACTGGATTG
GTGTTCGAAG
GAGTACAGAA
AAACCTGACT

>SL
GATGCAGCTC  AGGCTCTG CCTACGAG

>fw reversed
GATGCAGG             CCTACGAG


>fw
       CTCGTAGGCCTGCA TC

>rev
TGGTGTTCGAAGGA GT

AC TCCTTCGAACACCA

