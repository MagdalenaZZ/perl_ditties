#!/usr/local/bin/perl -w

use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: change_linebreaks.pl input1 input2

mz3 script for changing line-breaks in file 2 to match those in file 1

Output is fixed.input2


'
}


	my $in1 = shift;
	open (IN, "<$in1") || die "I can't open $in1\n";
	my @in = <IN>;
#chomp @in;
	close (IN);

#	print "IN0: $in[0]\n";
#	print "IN1: $in[1]\n";



foreach my $line (@in) {

	if ($line=~/LOCUS/) {
	print "LOTUS\n";
	print "$line";
}
	else {
	print "$line";
}

}