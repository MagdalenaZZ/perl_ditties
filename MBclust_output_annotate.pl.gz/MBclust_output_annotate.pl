#!/usr/bin/perl
use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV > 4) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~/bin/perl/mbclust_output_parser.pl matrix  <condition-size> <group-size>  <GO_annotation> <product_names>


reference-list  - matrix with all results
<condition-size>  - integer - the fewest number of groups you want the cluster to be retrieved in
<group-size> - integer - the groups with smallest number of genes you want to retrieve
<GO_annotation>  list with GO-annotation for genes
<product_names>   list with product names


A condition size larger than half the amount of tried cluster numbers (k) guarantees that not the same gene appears in many different clusters.


Example:
perl ~/bin/perl/mbclust_output_parser.pl  EMU.list 5 30


If you don\'t get any output try relaxing the parameters


';

}

my $ref = shift;
my $condition_size = shift;
my $group_size = shift;
my $go = shift;
my $prod = shift;

#my $fasta = shift;


open (RES, "<$ref") || die "Cant open file $ref\n" ;

my %res;


while (<RES>) {
    chomp;
    #print "$_\n";

    my @arr = split(/\t/,$_);
    my $gene = shift @arr;

    @arr = grep { $_ =~/\w+/ } @arr;

    #foreach my $ele (@arr) {

        #unless ($ele=~/\w+/) {
        #    delete
        #}
        # print "$ele\n"; 
        #}

    my $len = scalar(@arr);

    
    #print "$len\n";
    if ( $len > $condition_size  ) {
        my $group = join("_", @arr);
        $group=~s/cluster/-/g;
        $group=~s/^_//g;
        $group=~s/ _//g;

        #print "$gene\t$group\n";

        $res{$group}{$gene}=1;
    }


}

#__END__


# now dump files with all the group sizes and fasta
# now calculate go-terms for them


foreach my $gr (sort keys %res) {

    my $len = scalar( keys %{$res{$gr}} );

    if ( $group_size < $len) {
        open (OUT, ">$gr.group") || die "$!";
        foreach my $gen (sort keys %{$res{$gr}}) {
            print OUT "$gen\n";
        }
        close (OUT);
        #system "perl ~mz3/bin/perl/fasta_retrieve_subsets.pl $fasta $gr.group";
        #system "perl ~/bin/perl/topGO_starter.pl $gr.group $go BP $prod $gr.group";
        #print "perl ~/bin/perl/topGO_starter.pl $gr.group $go BP $prod $gr.group \n ";
    }

}

system "rm -f *.group.not_in_list";










exit;




__END__


