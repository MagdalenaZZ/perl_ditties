#!/usr/local/bin/perl -w
# mz3 script for making augustus hint-s-file from RNAseq
# do one .psl file at a time

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

## parse infile

my $genome = shift;
my $RNAseq = shift;
my $prefix = shift;

# Run BLAT

my $step1 = "echo \"running Step1 blat\n\"; blat -noHead -stepSize=5 -minIdentity=93 -maxIntron=20000 $genome $RNAseq $prefix.ali.psl"; 


# Then filter alignments for alignment quality and uniqueness (pairedness doesnt leave anything).

my $step15 = "echo \"running Step15 blat\n\"; cat $prefix.ali.psl | /nfs/users/nfs_m/mz3/bin/augustus.2.5.5/scripts/filterPSL.pl --uniq >  $prefix.ali.f.psl";

# sort the alignments

my $step2 = "echo \"running Step2 sorting\n\"; cat $prefix.ali.f.psl | sort -s -k 10,10 > $prefix.ali.sorted.psl";

# Sort alignments by target sequence and within target sequence by position for further processing

my $step3 = "echo \"running Step3 sorting\n\"; cat $prefix.ali.sorted.psl | sort -n -k 16,16 | sort -s -k 14,14 > $prefix.ali.fs.psl";


# Make a wiggle-gram 
my $step4 = "echo \"running Step4 making wig\n\"; /nfs/users/nfs_m/mz3/bin/augustus-2.4/bin/aln2wig -f $prefix.ali.fs.psl > $prefix.cov.wig";

# Now generate the exonpart hints with...
my $step5 = "echo \"running Step5 hintsEpFile\n\"; cat $prefix.cov.wig | /nfs/users/nfs_m/mz3/bin/augustus-2.4/scripts/wig2hints.pl --width=10 --margin=10 --minthresh=2 --minscore=4 --prune=0.1 --src=W --type=ep --UCSC=unstranded.track --radius=4.5 --pri=4 --strand="." > $prefix.hints.ep.gff2" ;

# now fix the faulty ep-file
my $step55 = "cat $prefix.hints.ep.gff2 | sed 's/\t\t/\t.\t/' > $prefix.hints.ep.gff";

# and this 
my $step6 = "echo \"running Step6 hintsIntronsFile\n\"; /nfs/users/nfs_m/mz3/bin/augustus-2.4/scripts/blat2hints.pl --intronsonly --in=$prefix.ali.fs.psl --out=$prefix.hints.introns.gff";


open CMD, ">$prefix.aug_BLAT2hints.sh";
print CMD "$step1 && $step15 && $step2 && $step3 && $step4 && $step5 && $step55 && $step6";
close CMD;

 system ("team133-bsub.pl long 15 $prefix.augBLAThints.o $prefix.augBLAThints.e $prefix.augBLAThints sh $prefix.aug_BLAT2hints.sh");



sub USAGE {

die 'Usage: perl augustus_BLAT2hints.pl <genome-file> <RNAseq-file.fasta> <prefix>

All files need to be real - no softlinks 

RNAseq-file needs to contain both forward and reverse reads in fasta-format.

The produced ep-file is missing a line with . - fix it by 


Once you\'ve done all of the files, you can concatenate all files using

cat hints.introns.gff hints.ep.gff  [hints2.gff, hints3.gff]  > hints.gff

No need to bsub - it bsubs itself

'
}

__END__


After youve run all files do :

cat *introns.gff > intron.hints

cat *ep.gff > ep.hints

cat ep.hints | sed s/src/source/ > ep.hints.gff 

cat ep.hints.gff | awk '{print $1 "\t" $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6 "\t" $7 "\t" $7 "\t" $8}' > ep2.hints.gff



cat intron.hints | sed s/src/source/ > intron.hints.gff 
cat intron.hints.gff | awk '{print $0 ";"}' > intron2.hints.gff

cat ep.hints | awk '{print $1 "\t" $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6 "\t.\t" $7 "\t" $8}' > hints.gff


'
}

__END__


perl ~/bin/perl/augustus_BLAT2hints.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU_Chado/emu.fasta 5817_2_nonhuman.fasta all

perl ~/bin/perl/augustus_BLAT2hints.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU_Chado/emu.fasta 5817_2_nonhuman.fasta 5817_2

perl ~/bin/perl/augustus_BLAT2hints.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU_Chado/emu.fasta 5817_1_nonhuman.fasta 5817_1

perl ~/bin/perl/augustus_BLAT2hints.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU_Chado/emu.fasta 5477_3_nonhuman.fasta 5477_3


mv EMU_v3_17June2011.corr.fas EMU_v3_17June2011.corr.fa