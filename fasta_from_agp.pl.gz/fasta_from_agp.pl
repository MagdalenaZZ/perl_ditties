#!/usr/local/bin/perl -w
# mz3 script 

use strict;


unless (@ARGV == 2 ) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: fasta_from_agp.pl  fasta agp


'
}

my $fas = shift;
my $agp= shift;
my $out= $fas . ".fas";


# read in fasta and store in hash
my %fas;

open (IN, "<$fas") or die "Cant find file $fas\n" ;


local $/ = ">";

while (my $line = <IN>)  {

  chomp($line);
  next unless $line;
  my($head,$seq)=split(/\s+/,$line);
  #print "$head\t$seq\n";
    $fas{$head}="$seq";

}

$/ = "\n";


# read in agp and produce scaffold

open (AGP, "<$agp") or die "Cant find file $agp\n" ;
open (OUT, ">$out") or die "Cant find file $out\n" ;


my $scaff=0;

while (<AGP>) {
    chomp;
    my @arr = split(/\t/,$_);

    # check if I'm in the same scaffold

    if ($scaff=~/^$arr[0]$/) {


        if ($arr[4]=~/W/) {
            #print "$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[8]\n";
            if (exists ($fas{$arr[5]}) ) {
                #print ">$arr[5]\n$fas{$arr[5]}\n";
                print OUT "$fas{$arr[5]}\n";
                delete $fas{$arr[5]};
            }
        }

        elsif ($arr[4]=~/N/) {
            # print "$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[8]\n";
            my $gap = "N" x $arr[5] ;
            print OUT "$gap\n";
        }
        else {
            die "\nIncorrectly formatted agp-file\n";
        }

    }

    else {
        print OUT ">$arr[0]\n";

    }

    $scaff= $arr[0];

}



foreach my $key (keys %fas) {
    print OUT ">$key\n$fas{$key}\n";
}


close (IN);
close (AGP);
close (OUT);







