#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_test.pl input.gff detailed_output

Takes a gff-file and checks the file integrity. Summary prints to STDOUT and detailed info prints to outfile


'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUTO, ">$out.overlapping") || die "I can't open $out.overlapping\n";

 print "Hi!\n";

 ######### sort the array  #########
 
    
# my @arr = @{$gff{$gen}};
my @rows = map { chomp; [split /[,\s]+/, $_] } @in; #read each row into an array
my @sorted = sort { $a->[0] cmp $b->[0] || $a->[3] <=> $b->[3] } @rows; # sort the rows (numerically) by second column

my @sort;

for (@sorted) {
#  print join("\t", @$_) . "\n"; # print them out as CSV
  push (@sort,  join("\t", @$_)  );
}


 
 #############################

my $lastline = "0\t0\t0\t0\t0\t0\t0\t0\t0";

 foreach my $line (@sort) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

my @last = split(/\s+/, $lastline);

	my $lcontig = $last[0];
	my $lmethod = $last[1];
	my $ltag = $last[2];
	my $lstart = $last[3];
	my $lend = $last[4];
	my $lscore = $last[5];
	my $lstrand = $last[6];
	my $ldot = $last[7];
	my $lkey = $last[8];



    if ( $contig =~/$lcontig/ ) {
        if ($lstart < $start and $lend < $start) {
            # right !
#            print "RIGHT:\n$lastline\n$line\n\n";
            print OUT "$line\n";
        }
        elsif ($lstart == $start and $lend == $end ) {
            # identical
#            print "IDENTICAL:\n$lastline\n$line\n\n";
            print OUTO "$line;identical\n";
        }
        elsif ($start >= $lstart and $end >= $lend ) {
            # overlapping to the right
            if ($key==$lkey) {
                print "Same key:\n$lastline\n$line\n\n";
    #            print OUTO "$line;identical\n";

            }
        }
        elsif ($lstart >= $start and $lend >= $end ) {
            # overlapping first is longer
        }
        elsif ($start >= $lstart and $lend >= $end ) {
            # overlapping second is longer
        }
        else {
            # else
            print "ELSE:\n$lastline\n$line\n\n";
        }


    }

    


    $lastline = $line;
}



close (OUT);
close (OUTO);

exit;

