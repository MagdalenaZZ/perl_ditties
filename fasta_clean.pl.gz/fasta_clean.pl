#!/usr/bin/perl -w

use strict;




my $largest = 0;
my $contig = '';


if (@ARGV < 1) {
	print "\n\nUsage: fasta_clean_fasta.pl fasta \n\n" ;

    print " mz3 script for cleaning up a fasta from empty lines and sequences with only NNNs  \n\n";

	exit ;
}

my $filenameA = shift @ARGV;



open (OUT, ">$filenameA.cl.fasta") or die "oops!\n" ;
open (OUT2, ">$filenameA.cl.removed") or die "oops!\n" ;
open (IN, "$filenameA") or die "oops!\n" ;

#print "Start\n";

my %new;

my @new;
my  $seq_name = 0;
my $seqexist=1;

# parse the fasta


local $/ = ">";

while (<IN>) {

	my $line = $_;	
	chomp $line;
	my(@arr)=split("\n", $line);

	if (scalar(@arr)>1) {
		#print "$line\n";
		my(@arr)=split("\n", $line);
		$seq_name=shift(@arr);
		my $seq=join("", @arr);
		$seq=~tr/\n//;
	  	$seq_name=~s/>//;
	  	$new{$seq_name} = "1";
	  	push(@new, $seq_name);
		#print "L:$seq_name:\t:$seq:\n";	


		# check if is only N

		my $ntest = $seq;
		$ntest =~ s/N//g;
		$ntest =~ s/n//g;


		if (length($ntest)>0) {
			print OUT  ">$seq_name\n$seq\n";
		}


		else {
			print  OUT2 ">$seq_name - Seq was only made of N\n$seq\n";
			# no nothing
		}


  	
	}
	elsif (scalar(@arr)>0) {
		$line=~tr/\n/#/;
		$line=~s/#//g;
		print OUT2 ">$line - Has no header or sequence\n\n";
	}
	else {
		print OUT2 ">$line - Has no header nor sequence\n\n";
	}

}

local $/ = "\n";

#print "Done!\n";

exit;

__END__

	
    if (/^>(\S+)/) {

	if ($seqexist=~/0/) {
		print OUT2 ">$seq_name - Header has no sequence \n\n";


	  $seq_name=$_;
	  $seq_name=~s/>//;
	  chomp $seq_name;
	  $new{$seq_name} = "1";
	  push(@new, $seq_name);
	  #print "$seq_name\n";
	  $seqexist=0;

	}
     else {
	$seqexist=1;

	my $seq = $_;
	chomp $seq;

	# check if is empty
	# check if is only N

	my $ntest = $seq;
	$ntest =~ s/N//g;
	$ntest =~ s/n//g;


		if (length($seq)>0) {
			#print "Seq has text  $seq\n";

			if (length($ntest)>0) {
				print OUT ">$seq_name\n$seq\n";
			}


			else {
				print OUT2 ">$seq_name - Seq was only made of N\n$seq\n";
				# no nothing
			}
		}
		else {
			print OUT2 ">$seq_name - Header had empty sequence\n$seq\n";
			# no nothing
		}
	$seq_name = 0;
	}
}





__END__


	my $seq_name = $_;
	$seq_name=~s/>//;
 	my $seq = <IN> ;
	chomp($seq) ;
    my $new_name;

#	print "SEQname:$seq_name:\n";	
	if ( exists $reads{$seq_name} ) {
			print OUT2 ">$seq_name\n" ;
			print OUT2 "$seq\n" ;
#            delete $reads{$seq_name};
            $new_name =  "$seq_name" . "\.$index" ;
            while ( exists $new{$new_name}) {
                $index++;
                $new_name =  "$seq_name" . "\.$index" ;
            }
            $new{$seq} = $new_name;
            print "Renamed\t$seq_name\t$new_name\n";
	}
    else {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;
            $new{$seq} = $seq_name;

    }

	$reads{$seq} = $seq_name ;

    }
	
    
    #last;


}

foreach my  $elem ( keys %new ) {
    print OUT3 "\>$new{$elem}\n$elem\n";
}

close (OUT);
close (OUT2);
close (OUT3);

#print "\#\#the largest length is: $contig with $largest bp \n" ;
