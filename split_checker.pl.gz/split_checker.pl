#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: split_checker.pl output \'infile-pattern\'

Takes an output which has been run on a fasta-file
and a match to the fasta-files which were the input

Example: perl ../split_checker.pl  HYM.results.raw \'HYM_\d+.fa\'

It gives output to say wether the output is free from repeats, and contains results from all the infiles 


'
}

my $res = shift;
my $pattern = shift;
my $files;
my $cwd = cwd();
# print "CWD: $cwd\n";
my $folder = cwd();
my @files;

# Read infiles into %in

my @paths = read_dir( "$folder", prefix => 1 ) ;

print "PAT:$pattern:\n";

my %in;

foreach my $file (@paths) {

    if ($file=~m/$pattern/) {
        print "Reading $file\n";
        
        push (@files, $file);
        open (IN, "<$file") || die "I can't open $file\n";
    	my @in= <IN>;
    	close (IN);

        foreach my $line (@in) {
            chomp $line;
            if ($line=~m/\>/) {
                $line=~s/\>//;
                $in{$line} = $file;
#                print "$file\t$line\n"; <STDIN>;
            }
        }
    }
    else {
        # rejected file
    }


}


# Read output into %out
#
my %out;


        open (RES, "<$res") || die "I can't open $res\n";
    	my @res= <RES>;
    	close (RES);

my %res;

foreach my $line (@res) {
    chomp $line;
    if ($line=~m/\w+/){
        $res{$line}=+1;
#        print "$line\n";
    }
}

foreach my $elem (keys %res) {
    if ($res{$elem} > 1) {
        print "$elem is repated $res{$elem} times \n";
    }
}

print "Finished reading results\n";

# parse through the output and check that everything is there

my %used;
my %used_res;



    foreach my $key (keys %in) {
           my @hits = grep(/$key/, keys %res);

           foreach my $li (@hits) {
            # store how many times an infile is used
                $used{$in{$key}}=+1;
            # store the nice results
                $used_res{$li}=+1;
           }
    }

=pod

foreach my $elem (keys %res) {
#    print "ELEM:$elem\n";
    foreach my $key (keys %in) {
#           my $el=$in{$key};
#    print "KEY:$el\n";        
        if ($elem=~m/$key/) {
#            print "$key is in $elem\n";
            # store how many times an infile is used
            $used{$in{$key}}=+1;
            # store the nice results
            $used_res{$elem}=1;
        }
    }
}
=cut


print "Finished checking output\n";


# parse through the output and flag up all lines which do not have input

foreach my $elem (keys %res) {
    if (exists $used_res{$elem}) {
     # do nothing
    }
    else {
        print "WARNING - unused result: $elem \n";
    }
}

print "Finished checking results\n";

# parse through the input and flag up any file which do not have output

#my @files2 = (keys %used);

my $quit = 0;

foreach my $line (@files) {
        if (exists $used{$line}) {
            print "This file has output: $line $used{$line}\n";
        }
        else {
            print "This file doesn't have output: $line\n";
            $quit=1;
        }
    
}


unless ($quit==0) {
    exit;
}
# print parsed results
#
print "Writing corrected results\n";

        open (OUT, ">$res.corrected") || die "I can't open $res.corrected\n";
 
foreach my $elem (keys %used_res) {
        print OUT "$elem\n";
}



    	close (OUT);


__END__


#Make sure the folder has the right path - if not a path - assume that it is in this folder

if ($folder =~m/\//) {	
	if (-d "$folder") {
		print "If: $folder\n";
		foreach my $elem (@paths) {
			$elem = "$folder\/$elem";
#			print "$elem\n";
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
#		print "Else: $cwd\/$folder\n";
		foreach my $elem (@paths) {
			$elem = "$cwd\/$folder\/$elem";
#			print "$elem\n";
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

print "Fishished reading files\n";
