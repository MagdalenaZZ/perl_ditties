#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: hyper_postprocess.pl <pval> list_of_files




i.e. 


hyper_postprocess.pl  KOs/*.txt


Annotation:

Gene1 <tab> Annotation1 (same as the one called)  <tab>  "product_name" 


' . "\n";
}


my $pval = shift;
#my $ann = shift;





my @files =  @ARGV ;

my %h;

foreach my $file (@files) {
    my $in = shift;
    open (IN, "<$file")|| die;
    #print "$file\n";
    # calculate observed and expected and split results by > and <

    while (<IN>) {
        chomp;
        if ($_=~/Probability/) {
#        if ($_=~/Prop/ and $_=~/Probability/  ) {
            # header
            #print "Header $_\n";
        }
        elsif ($_=~/\w+/) {
            #print "$_\n";
            my($gene,$k,$n,$m,$x,$N,$prob,$genes,$prods)= split(/\t/, $_);
            $gene=~s/ $//g;
            # check that it is within P-val
            if ($prob < $pval) {

# k - the number of genes drawn
# m - the number of genes with that property in the genome
# n - the number of genes without that property in the genome
# x - the number of genes with that property drawn
                my $observed = $x;
                my $freq =  ($m/$N);
                my $expected = $k * $freq;

                my $rich;

                if ($observed > $expected) {
                    #print "Enriched obs:$observed  exp:$expected $_\n";
                    $rich="E";
                }
                elsif ($observed < $expected) {
                    #print "Depleted obs:$observed  exp:$expected  $_\n";
                    $rich="D";
                }
                else {
                    #print "Equal! obs:$observed  exp:$expected $_\n";
                    $rich= "0";
                }

                if ($rich=~/0/) {
                    push (@{$h{$gene}{ "$file\_$k" }} , "0\t0\t0\t0\t0\t0"  );
                }
                elsif ($rich=~/E/)  {
                    push (@{$h{$gene}{ "$file\_$k" }} , "$rich\t$expected\t$observed\t$prob\t$genes\t$prods"  );
                }
                elsif ($rich=~/D/)  {
                    push (@{$h{$gene}{ "$file\_$k" }} , "$rich\t$expected\t$observed\t$prob\t$genes\t$prods"  );
                    #push (@{$h{$gene}{ "$file\_$k" }} , "\.\t\.\t\.\t\.\t\.\t\."  );
                }
                #print "$file\_$k\n";
            }
            else {
                    push (@{$h{$gene}{ "$file\_$k" }} , "\.\t\.\t\.\t\.\t\.\t\."  );
            }
        }
        else {
            print "Warning: skipped line $_\n";
        }
    }

    close (IN);

}


# %h {$feature} {$file $chosen}  @{$en/$dep $obs $exp $pval }





open (OUT, ">$pval.hyper.res")|| die;

print OUT "Feature\t";

foreach my $feat (sort keys %h) {
    foreach my $file (sort keys %{$h{$feat}}) {
        print OUT "$file\t$file\t$file\t$file\t$file\t$file\t";
    }
    last;
}

print OUT "\n";


foreach my $feat (sort keys %h) {
    print OUT "$feat\t";


    
    foreach my $file (sort keys %{$h{$feat}}) {
        my @arr = @{$h{$feat}{$file}};
        foreach my $elem (@arr) {
            print OUT "$elem\t";
        }
    }




    print  OUT "\n";   
}








close (OUT);



# transform and slim

#open (OUT, ">$pval.hyper.res")|| die;

system "cat $pval.hyper.res |  grep -w -e Feature -e D -e E > temp";
system "/nfs/users/nfs_m/mz3/bin/perl/transpose.pl temp > temp2";
system "cat temp2 | head -1 >  $pval.hyper.res.txt "; 
system "cat temp2 | grep -A5  -w -e D -e E  |grep -v '^--\$'  >>  $pval.hyper.res.txt "; 










