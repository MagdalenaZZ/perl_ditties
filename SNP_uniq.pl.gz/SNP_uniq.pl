#!/usr/bin/perl
use strict;

unless (@ARGV >0) {
        &USAGE;
}

sub USAGE {

die '

perl ~/bin/perl/SNP_uniq.pl file


';

}

my $in = shift;


open my $ins, "<$in"  || die "Error \n";
open (OUT, "> $in.uniq") || die "\nCannot write to file $in.uniq\n";


my %u;


while (<$ins>) {
    chomp;
 
    $u{$_}+=1;
}


foreach my $row (sort keys %u) {

    my $comp;

    if ($row=~/\.\/\./ ) {
        $comp="inc";
    }
    else {
        $comp="comp";
    }

  
    if ($row!~/1/ & $row!~/2/   ) {
        print OUT "$u{$row}\t$row\t$comp\tRef\n";
    }
 
    elsif ($row!~/0/ & $row!~/2/  ) {
        print OUT "$u{$row}\t$row\t$comp\tAllAlt\n";
    }

    else {
        print OUT "$u{$row}\t$row\t$comp\tOther\n";
    }

}


close(OUT);

exit;


