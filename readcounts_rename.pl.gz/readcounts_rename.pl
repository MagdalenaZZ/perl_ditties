#!/usr/local/bin/perl -w
#
use strict;
use Math::Round;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die '
Usage: 
perl ~/bin/perl/readcounts_rename.pl readcounts translate.list


mz3 script for giving new nice names to genes in a readcounts file

The list is a tab-delimited file with the old name and the new name on each row

old_name1<TAB>new_name1
old_name2<TAB>new_name2
old_name3<TAB>new_name3

Output comes in two files; 
1. out - the sequences with names changed 
2. out.unchanged - the sequences which were not in the list, so have not had their name changed - if this file is missing all names were changed




'
}

# open the file

my $in = shift;
my $list = shift;
my $out = $in . ".rn";
my %hash;
my @list;


# read in list (or make one)
	open (LIST, "<$list") || die "I can't open $list\n";
	@list = <LIST>;
	close (LIST);


# clean up list and put in two hashes

my %h1;
my %h2;
my %h3;

#foreach my $line (@list) {
#    chomp $line;
#    my @arr = split(/\t/, $line);
#        if (scalar(@arr)>1) {
#    		$h1{$arr[0]}{$arr[1]}=1;
#	}
    #print "$arr[0]\t$arr[1]\n";
#}

foreach my $line (@list) {
    chomp $line;
    my @arr = split(/\t/, $line);
    if (scalar(@arr)>1) {
	    $h2{$arr[1]}{$arr[0]}=1;
	}
    #print "$arr[1]\t$arr[0]\n";
}



# open fasta and output

my @in;
    open (FAS, "<$in") || die "I can't open $in\n";
    @in = <FAS>;
    close (FAS);


open (OUT, ">$out") || die "I can't open $out\n";
open (OUT2, ">$out.unchanged") || die "I can't open $out.unchanged\n";



# go through read.counts

my $ids = shift(@in);
print OUT "$ids";
#print OUT2 "$ids";

#my %adds;

foreach my $seq (@in) {
    chomp $seq;
    my @a = split(/\t/, $seq);


	foreach my $key (%h2) {

    		if (exists $h2{$key}{$a[0]} ) {
    			$h3{$key}{$a[0]}=$seq;
    		}

	}

}

# Do output

foreach my $key (keys %h3) {

    my $h3c = scalar keys %{$h3{$key}};
    #print "H3C $h3c\n";

	# If there is only one result
	if ($h3c<2) {
	foreach my $key2 (keys %{$h3{$key}}) {
	   	my @sm = split(/\t/,$h3{$key}{$key2});
	    	my $id = shift(@sm);
	    	my $smx = join("\t",@sm);
	    	print OUT "$key\t$smx\n";
	    }
	}
	# if the results need averaging
	else {
	    	my $new;
		my @newres=0;
		foreach my $key2 (keys %{$h3{$key}}) {
		    	#print "K2 $key2\t";
		    	my @a = split(/\t/,$h3{$key}{$key2});
			my $id = shift(@a);

			# check if exists, if not make
			if (scalar(@newres)<2) {
				@newres=@a;
				#print "Newres set to @a\n";
			}
			# newres has already been initialised, add values
			else {
			    		my $i=0;
		    		foreach my $ct (@a) {
					@newres[$i]=$newres[$i]+$ct;
					$i++;

				}

		    	}


	   	    }

	# now average and round
	my $i=0;
		foreach my $sum (@newres) {
			$newres[$i]=round($newres[$i]/$h3c);
			$i++;	    
		}
	#print "Added to newres $new\n";

	$new = join("\t",@newres);
	print OUT "$key\t$new\n";

    }
}



        close (OUT);
        close (OUT2);

        unless (-s "$out.unchanged") {
            system "rm -f $out.unchanged";
        }


exit;






