#!/usr/bin/perl
# Extract annotation and sequence from GenBank file

use strict;
use Getopt::Long;
use Bio::SeqIO;

my $help;
my $from=undef;
my $to=undef;

### please add to this list (see the modules under Bio/SeqIO):
my @known_formats=
  qw(gcg fasta ace raw fastq phd pir scf swiss genbank locuslink
embl game qual bsml tab raw abi chado alf ctf exp ztr pln
chaosxml chadoxml yaml tigr tigrxml agave chaos kegg interpro
lasergene strider gbdriver embldriver swissdriver);

my $script=substr($0, 1+rindex($0,'/'));
my $usage="Usage:

$script --from in-format --to out-format < file.in-format > file.out-format

Known formats:\n " . join(' ', @known_formats) . "\n\n";

die $usage unless
  &GetOptions( 'from:s' => \$from,
               'to:s' => \$to,
               'h|help' => \$help
)
  && !$help && $from && $to
  && grep($from eq $_, @known_formats)
  && grep($to eq $_, @known_formats);

my $in = Bio::SeqIO->newFh(-fh => \*STDIN , '-format' => $from);
my $out = Bio::SeqIO->newFh(-fh=> \*STDOUT, '-format' => $to);

print $out $_ while <$in>;


__END__

=head1 NAME

seqconvert - generic BioPerl sequence format converter

=head1 SYNOPSIS

seqconvert --from in-format --to out-format < file.in-format > file.out-format
# or
seqconvert -f in-format -t out-format < file.in-format > file.out-format

=head1 DESCRIPTION

This script gives command line interface to BioPerl Bio::SeqIO.

=head1 SEE ALSO

L<Bio::SeqIO>
L<bp_sreformat.PLS> for similar functionality which also supports AlignIO.

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list. Your participation is much appreciated.

bioperl-l@bioperl.org - General discussion
http://bioperl.org/wiki/Mailing_lists - About the mailing lists

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via the
web:

http://bugzilla.open-bio.org/

=head1 AUTHOR - Philip Lijnzaad

Email E<lt>p.lijnzaad-at-med.uu.nlE<gt>

=cut

__END__
 
use strict;
use warnings;
# use BeginPerlBioinfo;     # see Chapter 6 about this module
 
# declare and initialize variables
my @annotation = (  );
my $sequence = '';
my $filename = 'record.gb';
 
parse1(\@annotation, \$sequence, $filename);
 
# Print the annotation, and then
#   print the DNA in new format just to check if we got it okay.
print @annotation;
 
print_sequence($sequence, 50);
 
exit;
 
################################################################################
# Subroutine
################################################################################
 
# parse1
#
# --parse annotation and sequence from GenBank record
 
sub parse1 {
 
    my($annotation, $dna, $filename) = @_;
 
    # $annotation--reference to array
    # $dna       --reference to scalar
    # $filename  --scalar
    
    # declare and initialize variables
    my $in_sequence = 0; 
    my @GenBankFile = (  );
    
    # Get the GenBank data into an array from a file
    @GenBankFile = get_file_data($filename);
    
    # Extract all the sequence lines
    foreach my $line (@GenBankFile) {
 
        if( $line =~ /^\/\/\n/ ) { # If $line is end-of-record line //\n,
            last; #break out of the foreach loop.
        } elsif( $in_sequence) { # If we know we're in a sequence,
            $$dna .= $line; # add the current line to $$dna.
        } elsif ( $line =~ /^ORIGIN/ ) { # If $line begins a sequence,
            $in_sequence = 1; # set the $in_sequence flag.
        } else{ # Otherwise
            push( @$annotation, $line); # add the current line to @annotation.
        }
    }
    
    # remove whitespace and line numbers from DNA sequence
    $$dna =~ s/[\s0-9]//g;
}

__END__

#!/usr/bin/perl
# Parsing GenBank annotations using arrays, take 2
 
use strict;
use warnings;
# use BeginPerlBioinfo;     # see Chapter 6 about this module
 
# Declare and initialize variables
my @genbank = (  );
my $locus = '';
my $accession = '';
my $organism = '';
my $definition = '';
my $flag = 0;
 
# Get GenBank file data
@genbank = get_file_data('emu.gb') || die;
 
# Let's start with something simple.  Let's get some of the identifying
# information, let's say the locus and accession number (here the same
# thing) and the definition and the organism.
 
for my $line (@genbank) {
  if($line =~ /^LOCUS/) {
    $line =~ s/^LOCUS\s*//;
    $locus = $line;
  }elsif($line =~ /^FEATURES/) {
    $line =~ s/^FEATURES\s*//;
    $definition = $line;
    $flag = 1;
  }elsif($line =~ /^ACCESSION/) {
    $line =~ s/^ACCESSION\s*//;
    $accession = $line;
    $flag = 0;
  }elsif($flag) {
    chomp($definition);
    $definition .= $line;
  }elsif($line =~ /^  ORGANISM/) {
    $line =~ s/^\s*ORGANISM\s*//;
    $organism = $line;
  }
}
 
print "*** LOCUS ***\n";
print $locus;
print "*** DEFINITION ***\n";
print $definition;
print "*** ACCESSION ***\n";
print $accession;
print "*** ORGANISM ***\n";
print $organism;
 
exit;

__END__
