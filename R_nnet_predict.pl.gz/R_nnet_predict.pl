#!/usr/bin/perl -w


if (@ARGV < 2 ) {
    print "\nUsage: R_nnet_predict.pl Eset signal training-samples size decay\n\n\n" ;

    print "\nExample: R_nnet_predict.pl myv_COMBAT tmpsig 1:34 25 9.994e-6\n\n\n" ;
    

        exit;
}




# Input
#
$eset= shift; # Expression set
$signal=shift; # List of signal genes
$tt=shift;
$size=shift;
#$ts=shift; # Training set
$decay= shift;

open (R, ">$eset.$signal.pred.$size.$decay.R") || die "I can't open $eset.$signal.pred.$size.$decay.R\n";





# Read in a dataset

print R "library(ggplot2)\n";
print R "library(gplots)\n";
print R "library(Biobase)\n";
print R "library(\"class\")\n";
print R "library(\"nnet\")\n";
print R "library(\"CMA\")\n";


print R "attach(\"$eset.RData\")\n";
print R "try(eset <- $eset)\n";
#print R "try(eset <- df)\n";



# Read in a signal

print R "ud =  read.table(\"$signal\", header=FALSE )\n";
print R "rownames(ud) <-ud\$V1\n";
print R "colnames(ud) <- \"Symbol\"\n";

print R "chosen <- rownames(exprs(eset)) %in% rownames(ud)\n";
print R "chosen2 <- rownames(ud) %in% rownames(exprs(eset))\n";
print R "ud2 <- as.data.frame(ud[chosen2,])\n";
print R "colnames(ud2) <- \"Symbol\"\n";
print R "rownames(ud2) <-ud2\$Symbol\n";

print R "esetchosen <- exprs(eset)[chosen,]\n";
print R "exprs(eset) <- esetchosen\n";


print R "esetsub <- eset[,$tt]\n";
print R "esetsub\@phenoData\@data\$Celltype  <- factor(esetsub\@phenoData\@data\$Celltype)\n"; ##
print R "levs <- length(levels(esetsub\@phenoData\@data\$Celltype))\n"; ##
# Make the dataset
print R "ir <- t(exprs(esetsub))\n";
print R "fir <- t(exprs(eset))\n";

#print R "targets <- class.ind(as.vector(esetsub\@phenoData\@data\$Celltype) )\n";
#print R "rownames(targets) <- rownames(ir)\n";
print R "tars <- as.vector(esetsub\@phenoData\@data\$Celltype)\n";
print R "targets <- class.ind(tars)\nrownames(targets) <- rownames(ir)\n";
# LOOCV
print R "learns <- GenerateLearningsets(y=tars, method=\"LOOCV\")\n";
print R "learns\@learnmatrix\n";

# variable selection
print R "varsel_LOOCV <- GeneSelection(X = ir, y = as.factor(tars), learningsets = learns, method=\"f.test\")\n";

# Get the variables which are most helpful
print R "show(varsel_LOOCV)\n"; 
print R "toplist(varsel_LOOCV, iter = 1)\n";
print R "sort(table(varsel_LOOCV\@rankings[[1]][,1:5]), decreasing=TRUE)\n";
#print R "for (i in 1:3) {\n";
#print R "     seliter <- c(seliter, as.vector(varsel_LOOCV\@rankings[[i]][,1:5]))\n";
#print R "}\n";
#print R "sort(table(seliter), dec = TRUE)\n";
# plot(varsel_LOOCV) # makes nice plot of parameter importance



print R "nbgenes <- ncol(ir)\n";
print R "nbgenes\n";
print R "if (nbgenes>50) {nbgenes <- 50}\n";
print R "nbgenes\n";
print R "dim(ir)\n";
# tune nnet size = 1:5, decay = c(0, 2^{-(4:1)})
#print R "# Tuningstep started, please be patient...\n";
#print R "tuningstep <- CMA:::tune(X = ir, y = as.factor(tars), learningsets = learns, classifier = nnetCMA, genesel= varsel_LOOCV, nbgene = nbgenes , grids = list(size = 10:50,decay = c(0, 2^{-(14:1)})) , MaxNWts = 50000)\n";
#print R "tuningstep <- CMA:::tune(X = ir, y = as.factor(tars), learningsets = learns, classifier = nnetCMA, genesel= varsel_LOOCV, nbgene = nbgenes , grids = list(size = 10:11,decay = c(0, 2^{-(11:1)})))\n";
## seq.int(10,50,5)

print R "nrowir<-nrow(ir)\n";
print R "nrowfir<-nrow(fir)\n";

# Read in size and decay

print R "best_size <- $size\n";
print R "best_decay <-  $decay\n";


# give output

# get paramenters to average over
print R "res <- list()\n";
print R "seliter <- numeric()\n"; 
print R "for (i in 1:nrow(learns\@learnmatrix)) {\n";
print R "res[[i]] <- nnet(ir[learns\@learnmatrix[i,],], targets[learns\@learnmatrix[i,],],size = best_size, rang = 0.5,decay = best_decay, maxit = 10000, MaxNWts = 1000000, softmax=TRUE, Hess=TRUE)\n"; #change maxit to 10000#
print R "seliter <- c(seliter,res[[i]]\$wts)\n";
print R "}\n";

#print R "for (i in 1:nrow(learns\@learnmatrix)) {\n";
#print R "}\n";

# Do predictions for each trained network
print R "library(caret)\n";

print R "preds <- list()\n";
print R "varimp <- list()\n";
print R "for (i in 1:nrowir) {\n";
print R "    preds[[i]] <- predict(res[[i]], fir)\n";
print R "    varimp[[i]] <- varImp(res[[i]])\n";
print R "}\n";
print R "varimp\n";

print R "i=0\n";
print R "j=0\n";
print R "resway <- numeric()\n";

print R "for (i in 1:nrowfir) {\n";

print R "    for (j in 1:nrowir) {\n";
print R "        resway <- c(resway,preds[[j]][i,])\n";
print R "    }\n";

print R "}\n";

print R "resway2 <- unlist(resway)\n";
print R "dim(resway2) <- c((nrowir*levs),nrowfir)\n";

print R "residuls <- rep(0,nrowfir,each=(best_size+10))\n";
print R "dim(residuls) <- c(nrowfir,(best_size+10)) \n";

print R "i=0\n";
print R "for (i in 1:nrowfir) {\n";
print R '    tmp <- resway2[,i]
    dim(tmp) <- c(levs,nrowir)
    #2boxplot(t(tmp))
    residuls[i,1] <- nrowir - max(colSums(t(tmp)))
    ct =2
    residuls[i, seq(ct,(ct+levs-1))] <- apply(t(tmp), 2, mean)
    ct = length(seq(ct,levs+ct))+ct-1
    residuls[i,seq(ct,(ct+levs-1))] <- apply(t(tmp), 2, min)
    ct = length(seq(ct,levs+ct))+ct-1
    residuls[i,seq(ct,(ct+levs-1))] <- apply(t(tmp), 2, max)
    ct = length(seq(ct,levs+ct))+ct-1
    residuls[i,ct] <- order(residuls[i, 2:(levs+1)], decreasing=TRUE)[1]
}
';


print R "rownames(residuls) <- rownames(fir)\n";
print R 'whole <- length(c("Residual",rep("Mean" , levs),rep("Min" , levs),rep("Max" , levs),"Prediction","Celltype","Known"))
'; ##
print R 'colnames(residuls) <- c("Residual",rep("Mean" , levs),rep("Min" , levs),rep("Max" , levs),"Prediction","Celltype","Known",rep("NU",(best_size+10-whole)))
'; ##
print R "residuls[,(ct+1)]<-as.vector(eset\@phenoData\@data\$Celltype)\n";
print R "residuls[$tt,ct+2]<-as.vector(esetsub\@phenoData\@data\$Celltype)\n";
print R "library(plyr)\n";
print R 'residuls[,ct] <- mapvalues(residuls[,ct], from=1:levs, to=levels(esetsub@phenoData@data$Celltype))
';


print R "fn <- paste(\"$eset.$signal.$size.$decay\",\".class.txt\", sep=\"\")\n";
print R "write.table(as.data.frame(residuls),file=fn, sep=\"\\t\")\n";
#print R "dev.off()\n";

# Do PCA


print R "pca <- prcomp(as.matrix(fir), scale=FALSE)\n";
print R "scores <- data.frame(as.vector(residuls[,ct]), pca\$x[,1:3])\n";
print R "pca.rscores <- qplot(x=PC1, y=PC2, data=scores, colour=factor(as.vector(residuls[,ct]))) \n";
#,scale_fill_discrete(name="Experimental\nCondition",breaks=c("ctrl", "trt1", "trt2"), labels=c("Control", "Treatment 1", "Treatment 2"))) \n";
print R 'pca.rscores$labels$colour <- "Celltype"
';
print R "fn <- paste(\"$eset.$signal.$size.$decay\",\".final.pca.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(pca.rscores)\n";
print R "dev.off()\n";


print R "pca.rscores <- qplot(x=PC1, y=PC2, data=scores, colour=factor(as.vector(residuls[,ct+1]))) \n";
print R 'pca.rscores$labels$colour <- "Prediction"
';
print R "fn <- paste(\"$eset.$signal.$size.$decay\",\".final.prediction.pca.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(pca.rscores)\n";
print R "dev.off()\n";


print R "pca.rscores <- qplot(x=PC1, y=PC2, data=scores, colour=factor(as.vector(paste(residuls[,ct], residuls[,ct+2])))) \n";
print R 'pca.rscores$labels$colour <- "Prediction"
';
print R "fn <- paste(\"$eset.$signal.$size.$decay\",\".final.known.pca.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(pca.rscores)\n";
print R "dev.off()\n";


#print R "residuls\$Prediction\n";



exit;


__END__

# Do survival




print R 'library(survival)
library(survcomp)
library(RColorBrewer)
';
# read in survival data

print R "Survi <- read.table( \"Survi.txt\", header=TRUE, sep =\"\\t\" )\n";
print R "rownames(Survi) <- Survi\$SampleGEO\n";


# get a subset of design that matches data

print R "Surviv <- Survi[rownames(fir),]\n";

#dchosen <- rownames(Survi)  %in%  rownames(ass.heat_DE.v.GENENORM)
#Surviv <- Survi[rownames(fir),]

# Just chech that it is all right
print R "all(rownames(residuls)==rownames(Surviv))\n";


print R "cbbPalette <- c( \"#0072B2\", \"#D55E00\",\"#00EE76\" )\n";
print R "colfunc <- colorRampPalette(cbbPalette)\n";


print R "Surviv\$Class<- residuls[,11]\n";
print R "Surviv\$Class[Surviv\$Class<2]  <- \"CMP\"\n";
print R "Surviv\$Class[Surviv\$Class<3 ]  <- \"HSC\"\n";
print R "Surviv\$Class[Surviv\$Class<4]  <- \"MPP\"\n";
# as function of celltype -prediction (make a sensible cutoff and classification)
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviv\$Class), data = Surviv)\n";
print R "S.km\n";
print R "fn <- paste(\"$eset.$signal\",\".3surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(3) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviv\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(3) )\n";
print R "dev.off()\n";

print R "Surviva<-rbind(Surviv[Surviv\$Class==\"HSC\",],Surviv[Surviv\$Class==\"CMP\",])\n";
print R "survdiff(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km\n";
print R "fn <- paste(\"$eset.$signal\",\".2surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(2) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviva\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(2) )\n";
print R "dev.off()\n";


print R "fn <- paste(\"$eset.$signal\",\".RData\", sep=\"\")\n";
print R "ls <- list(ud,ir,varsel_LOOCV,best_size,best_decay,nbgenes,res,preds,residuls,Surviva)\n";
print R "save(ls, file = fn, envir = .GlobalEnv)\n";


## survdiff(Surv(OSmon, Termin)~as.vector(Surviv$Class), data = Surviv)



exit;






