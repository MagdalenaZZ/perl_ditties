#!/usr/bin/perl -w
use strict;
use Cwd;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_gff_exporter.pl fasta organism

Wrapper script to export data from Chado

'
}

my $cwd = cwd();
print "CWD: $cwd\n";

my ($sec,$min,$hour,$day,$month,$yr19,@rest) =   localtime(time);#######To get the localtime of your system
my  $time = "$day-".++$month. "-".($yr19+1900); ####To print date format as expected
#my $time = "$time[5]_$time[4]_$time[3]"; 
#print join(' ', @time);
my $fasta = shift;
my $prefix = shift;
$prefix = $prefix . "_" . $time ;
print "$prefix\n";

#system "cd /lustre/scratch103/sanger/mz3/Chado/ ";

open (OUT2, ">$prefix.exporter2.sh") or die "Cant open file $prefix.exporter2.sh\n" ;

open (OUT, ">$prefix.exporter.sh") or die "Cant open file $prefix.exporter.sh\n" ;

# print "team133-bsub.pl normal 4 sub.o sub.e sub \"rm -rf GFFs/ ; perl ~/bin/perl/chado2gff_emu.pl $fasta ; gunzip GFFs/*.gz ;  perl ~/bin/perl/chado_gff_merge.pl $fasta ;  perl ~/bin/perl/chado_gff_correct.pl final.merged.chado.gff\" \n";

#system "team133-bsub.pl normal 4 sub.o sub.e sub \"perl ~/bin/perl/chado2gff_emu.pl $fasta $prefix ; gunzip $prefix/*.gz ;  perl ~/bin/perl/chado_gff_merge.pl $fasta $prefix ;  perl ~/bin/perl/chado_gff_correct.pl final.merged.chado.gff\" \n";


print OUT  "perl ~/bin/perl/chado2gff_emu.pl $fasta $prefix" ; 
 system ( "bsub.py 4  $prefix.ex sh $prefix.exporter.sh");  # start

# system "perl ~/bin/perl/chado2gff_emu.pl $fasta $prefix"  # start


print OUT2 "gunzip $prefix/*.gz ; wait; perl ~/bin/perl/chado_gff_merge.pl $fasta $prefix ; wait;  perl ~/bin/perl/chado_gff_correct.pl $prefix.merged.chado.gff \n";

# system "team133-bsub.pl normal 4 sub2.o sub2.e sub2 sh exporter2.sh ";

# make some symbolic links
# print OUT2 "; wait; ln -s final.merged.chado.gff.corrected.gff emu.gene.gff ";
# print OUT2 "; wait;  ln -s final.merged.chado.gff.corrected.fasta emu.aa.fa ";
# print OUT2 "; wait;  ln -s products.tidied.txt emu.aa.products ";

print OUT2 "perl ~/bin/perl/gff-markup.pl $prefix.merged.chado.gff.corrected.gff $prefix.merged.chado.gff.corrected.product $prefix.gff "; 

close (OUT2);
