#!/usr/local/bin/perl -w
#
use strict;

my($exp_file, $go_file, $q_cutoff) = @ARGV;

if(!defined $q_cutoff)
{
	print STDERR "USAGE: <degfile> <ann_file> <q_cutoff>\n";
	exit;
}

open(GO, "<$go_file") or die "$!";

my %go = ();
my %counts = ();
my %desc = ();
my $terms = 0;

while(<GO>)
{
	chomp;
	my($gene, $desc, @go) = split /\t/;

	foreach my $go (@go)
	{
		my($term, $type, $desc) = split( /\,/, $go);

		next unless defined $term;

		push @{$go{$gene}}, $term;

		$desc{$term} = $desc;
		$counts{$term}++;
		$terms++;
	}
}
close GO;


open(EXP, "<$exp_file") or die "$!";

my %inc_counts = ();
my %dec_counts = ();
my $inc_size = 0;
my $dec_size = 0;

my %inc_genes = ();
my %dec_genes = ();

my $over_have_go = 0;
my $under_have_go = 0;
my $over_no_go = 0;
my $under_no_go = 0;

while(<EXP>)
{
	chomp;
	
	next if /^"id/;

	my($row, $rest) = split /\" \"/;
	my($id, $fields) = split /\" /, $rest;
	my @fields = split / /, $fields;
	
	@fields = ($id, @fields);

	# Last if we have exhausted significant matches
	next if $fields[7] eq 'NA';
	next unless $fields[7] < $q_cutoff;

	my $type = '';

	# Determine whether this match is increase or decrease in expression
	if($fields[4] > 1)
	{
		$type = 'inc';
	}
	elsif($fields[3] >= 1)
	{
		$type = 'dec';
	}

	my($gene1, $gene2) = split /\-/, $fields[0];

	if(exists $go{$gene1})
	{
		foreach my $term (@{$go{$gene1}})
		{
			if($type eq 'inc')
			{
				$inc_counts{$term}++;
				$inc_size++;
				push @{$inc_genes{$term}}, $fields[0];
			}
			else
			{
				$dec_counts{$term}++;
				$dec_size++;
				push @{$dec_genes{$term}}, $fields[0];
			}
		}

		$over_have_go++ if $type eq 'inc';
		$under_have_go++ if $type eq 'dec';
	}
	else
	{
		#print "$fields[0]\t$fields[5]\tNone\n";
		$over_no_go++ if $type eq 'inc';
		$under_no_go++ if $type eq 'dec';
	}
}
close EXP;

my @dec_pvalues = ();
my %dec_pvalues = ();
my @inc_pvalues = ();
my %inc_pvalues = ();

sub hypergeo
{
	my($m, $n, $k, $x) = @_;

	open(R, ">r.in") or die "$!";

	print R "phyper($x-1, $m, $n, $k, lower.tail=FALSE)\;\n";
	close R;

	chomp(my $result = `R --no-save < r.in`);

	$result =~ /\[1\] (.*)/;

	return $1;
}

sub multihypo_test
{
	my($pvalues) = @_;

	my $p_string = join ",", @$pvalues;

	open(R, ">r.in") or die "$!";
	print R "p.adjust(c($p_string), method=c(\"BH\"))\n";
	close R;

	chomp(my $result = `R --no-save < r.in`);

	my @p_adjust;

	while ($result =~ /\[\d+\] (.*)/g)
	{
		push @p_adjust, split /\s/, $1;
	}

	return \@p_adjust;
}

foreach my $term (sort keys %dec_counts)
{
	#print "$term\tDOWN\t$dec_counts{$term}\t$counts{$term}\t$desc{$term}\n";

	my $m = $dec_size;
	my $n = $terms - $counts{$term};
	my $k = $counts{$term};

	my $x = exists $dec_counts{$term} ? $dec_counts{$term} : 0;

	my $p = hypergeo($m, $n, $k, $x);

	push @dec_pvalues, $p;
	$dec_pvalues{$term} = $p;

	#print "$term\tDOWN\t$p\t$dec_counts{$term}\t$counts{$term}\t$desc{$term}\n";
}

my $p_adjust_dec = multihypo_test(\@dec_pvalues);

foreach my $term (sort keys %inc_counts)
{
	my $m = $inc_size;
	my $n = $terms - $counts{$term};
	my $k = $counts{$term};

	my $x = exists $inc_counts{$term} ? $inc_counts{$term} : 0;

	my $p = hypergeo($m, $n, $k, $x);

	push @inc_pvalues, $p;
	$inc_pvalues{$term} = $p;

	#print "$term\tUP\t$p\t$inc_counts{$term}\t$counts{$term}\t$desc{$term}\n";
}

my $p_adjust_inc = multihypo_test(\@inc_pvalues);

my $c = 0;

foreach my $term (sort keys %inc_counts)
{
	my $gene_count = scalar @{$inc_genes{$term}};

	print "$term\tUP\t$p_adjust_inc->[$c]\t$inc_pvalues{$term}\t$desc{$term}\t$gene_count\t@{$inc_genes{$term}}\n";

	$c++;
}

$c = 0;

foreach my $term (sort keys %dec_counts)
{
	my $gene_count = scalar @{$dec_genes{$term}};

	print "$term\tDOWN\t$p_adjust_dec->[$c]\t$dec_pvalues{$term}\t$desc{$term}\t$gene_count\t@{$dec_genes{$term}}\n";

	$c++;
}

print STDERR "Of the genes with reduced expression $over_have_go have GO terms, $over_no_go do not\n";
print STDERR "Of the genes with increased expression $under_have_go have GO terms, $under_no_go do not\n";
