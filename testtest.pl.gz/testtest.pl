#!/usr/local/bin/perl -w
use strict;
use Getopt::Long;


my $clust_num = 0;
my $go_cut  = 0;
my $skip_clustering  = 0;
my  $treat = 0;
my  $save = 0;



my($help, $data, $rpkms, $go_file, $go_res) = ();

GetOptions (
	"h|help"	=> \$help,
	"c|counts:s"	=> \$data,
	"r|rpkms:s"	=> \$rpkms,
	"g|go:s"	=> \$go_file,
	"o|out:s"	=> \$go_res,
	"nclust:s"	=> \$clust_num,
	"t|gocut:f"	=> \$go_cut,
	"s|skip_clust:s"	=> \$skip_clustering,
	"d|own_treatment_definition" => \$treat,
	"save"		=> \$save,


);


print "d $treat\n";
print "nclust $clust_num\n";
print "s $skip_clustering \n";


#print "c $data \t\t default ''\n";
#print "r $rpkms\n";

