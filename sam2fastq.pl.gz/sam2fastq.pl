#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/SAM2fastq.pl SAM/BAM 

Ex:

perl ~/bin/perl/SAM2fastq.pl my.sam

';

}


my $in = shift;
my @flags = @ARGV;

my @arr1 = split (/\//, $in);

my $out1 = "$arr1[-1].1.sam";
my $out2 = "$arr1[-1].2.sam";
my $outS = "$arr1[-1].SE.sam";


unless ( $in=~/sam/) {
    print "\n Making SAM-file $in.sam \n";
    system "samtools view -h $in > $arr1[-1].sam ";
    $in = "$arr1[-1].sam";
    print "New in: $in\n";
}

 open (IN, "<$in") or die 'Cant find infile $in ';



 my @in = <IN>;





