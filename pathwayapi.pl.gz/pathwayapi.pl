#!/usr/local/bin/perl -w
# mz3 script 

use strict;




unless (@ARGV == 1 ) {
        &USAGE;
 }

sub USAGE {

die 'Usage: patway_API.pl outputfile



'
}

my $out = shift;

# get databases

system "wget www.pathwayapi.com/api/API_GetDatabase.php";

open (IN, "<API_GetDatabase.php") || die "Cant open database\n";
open (OUT, ">$out.map") || die "Cant open $out.map\n";

my @db;

while (<IN>) {
    chomp;
    $_=~s/\[//g;
    $_=~s/\]//g;
    $_=~s/\"//g;

    @db = split(/,/,$_);    
}

print "@db\n";

close (IN);

my %db;
# not get all pathways in those databases
#

foreach my $dbs (@db) {

    #system "wget www.pathwayapi.com/api/API_GetDBPathways.php?DatabaseName=$dbs";

    open (IN, "<API_GetDBPathways.php?DatabaseName=$dbs") || die "Cant open pathways\n";
   
    my @paths;
    while (<IN>) {
        chomp;
        #$_=~s/\,/\n/g;
        #print "$_";
        $_=~s/\n/ /g;
        $_=~s/\}/\n/g;
        my @arr = split (/\,/, $_);
        my @ar2;
        foreach my $elem (@arr) {
            if ($elem=~/\"\d+\"/) {
                #print "$elem\n";
                @ar2 = split("\"", $elem);
            }
            else {
                #print "$ar2[1]\t$elem";
                $elem=~s/\t/ /g;
                $db{$dbs}{"$ar2[1]\t$elem"}{"0"}=1;
            }
        }

    }

    close (IN);



}

foreach my $k1 (keys %db) {
    #print "$k1\n";


    foreach my $k2 (keys %{$db{$k1}}) {
        #print "$k1\t$k2\n";
        my @ar3 = split(/\t/,$k2);
        #system "wget http://www.pathwayapi.com/api/API_GetPathwayGenes.php?Pathway=$ar3[0]";

        open(IN, "<API_GetPathwayGenes.php?Pathway=$ar3[0]");

        # parse results file
        while (<IN>) {
            $_=~s/\}//;
            $_=~s/\{//;
            my @ar4 = split(/\,/,$_);
            foreach my $ele (@ar4) {
                my @ar5=split(/\"/,$ele);
                print OUT "$ar5[1]\n";
            }

        }
    }


}




