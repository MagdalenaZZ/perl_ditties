#!/usr/bin/perl -w
# mz3 script for making utr hints-files for augustus

use strict;
use Data::Dumper;
use Getopt::Std;



unless (@ARGV > 5) {
        &USAGE;
}





my $help = join(@ARGV); 

if ( $help =~/--h/ or $help =~/-help/ ) { 
        &USAGE;
}

my %opt;
$opt{"--s"} = 0;
$opt{"--a"} = 0;


push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");

foreach my $elem (@ARGV) {
    
    my $arg1 = shift(@ARGV);
    chomp $arg1;
    
    if ( $arg1 =~/--s/ ) {
        $opt{$arg1} = 1;
    }
    else {
        my $arg2 = shift(@ARGV);
        $opt{$arg1} = "$arg2";
        #print "KEYS\t$arg1\t$arg2\n";
    }
}




sub USAGE {

die '

This program takes two gff-files and compares their overlaps, and produces useful stats about the overlaps



Usage: perl ~/bin/perl/gff_intersector.pl --c  transcript-output.gtf --g genes.gff ---p prefix  --s <int> --a <basepair/percent overlap>

Mandatory:

  --c :  transcripts.gff - the output from wiggleJunkie.pl
  --g :  genes.gff   - your known genes in a gff


Optional:

  --p : output prefix 
  --s : my transcripts file is made from single-stranded RNA  ( 0=no, 1=yes ) 
  --a : basepair/percent overlap of transcript on gene for transferring annotation (i.e. 0.1 means that 10% of the gene is covered by the transcript, 10 means that there is 10 bp overlap)
        Default is that any overlap is reported


Output from this progam:

*.intersect : the transcripts overlapping with an annotated gene
*.orphans : the transcripts not overlapping with an annotated gene
*.transferred : file matching up the transcripts with the overlapping gene, and the number of bases with which they overlap
 

'
}



#####_####_####_####_####_####_####_#####

# Get help


if ($opt{"--h"}) {
    &USAGE;
}

#####_####_####_####_####_####_####_#####
print "\n";

# make sure there is a file
my $c;
#my @cuff;


if ($opt{"--c"}) {
    #print $opt{"--c"} . "\n";
    VALIDATEC();
} else {
	print "\nPlease give me a transcript gff i.e.  --c  transcripts.gff  \n";
    &USAGE;
}


#####_####_####_####_####_####_####_#####

sub VALIDATEC {
    # sub validate checks that there is an inputfile, and reads it
	$c = $opt{"--c"};
    open (CUFF, "<$c") || die "I can't open $c\n";
	print "Reading in cufflinks file: $c\n";
    #@cuff2 = <CUFF>;
    close (CUFF);
}

#####_####_####_####_####_####_####_#####
print "\n";

# make sure there is a file
my $g;
my @gff;

if ($opt{"--g"}) {
    #print $opt{"--g"} . "\n";
    VALIDATEG();
} else {
	print "\nPlease give me gff file i.e.  --g  file.gtf  \n";
    &USAGE;
}


#####_####_####_####_####_####_####_#####

sub VALIDATEG {
    # sub validate checks that there is an inputfile, and reads it
	$g = $opt{"--g"};

    print "Reading in gff file: $g\n";

    # check that bedtools executes
    system "~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -b $g -a $g" || die "Your gff-file does not work in bedtools, make sure it is compatible\n";
    my $exit_value  = $? >> 8;
    if ($exit_value != 0) { die "Your gff-file does not work in BEDtools, make sure it is compatible with BEDtools and try again\n\n";};
    open (GFF, "<$g") || die "I can't open $g\n";
    @gff = <GFF>;
    close (GFF);
}

#####_####_####_####_####_####_####_#####

print "\n";

# checi if there is a prefix
my $p = "OUTPUT";

if ($opt{"--p"} and $opt{"--p"}=~/\w+/) {
    # print $opt{"--p"} . "\n";
    $p = $opt{"--p"};
	print "Prefix is set to $p \n";

    
} else {
	print "\nNo prefix given, it will be set to $p \n";
}


#####_####_####_####_####_####_####_#####

print "\n";

# check if there is s
my $s = 0;

if ($opt{"--s"}) {
    # print $opt{"--t"} . "\n";
    $s = 1;
	print "Single-stranded cuff-links \n";  
}
else {
	print "\nNot single-stranded cufflinks \n";
}

#####_####_####_####_####_####_####_#####



print "\n";

# check if there is s
my $a = 0;

if ($opt{"--a"}) {
    # print $opt{"--t"} . "\n";
    $a = $opt{"--a"};
	print "Only genes with transcripts overlapping more than $a will be reported \n";  
}
else {
	print "All overlaps will be reported \n";
    $a=0;
}

#####_####_####_####_####_####_####_#####




print "\n--------STARTING CALCULATIONS------------\n\n";



### get all the cufflinks transcripts which overlaps with a gene


# make a nice cufflinks-file
#system "perl ~/bin/perl/cufflinks2gff.pl  $c > $c.gff "; wait;
system "cat  $c | grep -w gene > $c.gene "; wait;
system "cat  $g | grep -w gene > $g.gene "; wait;


# it is stranded
if ($s=~/1/) {
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -u -s > $p.intersect"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -v -s > $p.orphans"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -wao -s > $p.transferred"; wait;


}
else {
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -u  > $p.intersect"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -v  > $p.orphans"; wait;
    system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $g.gene -a $c.gene -wao > $p.transferred"; wait;

}



# Make a file with the transferred annotation

system "cat $p.transferred |  cut -f 9,18,19 >  $p.transferred2";
open (IN, "<$p.transferred") || die "cant open file $p.transferred\n";
my @ts = <IN>;
close (IN);
system "mv $p.transferred2  $p.transferred";


### get all the cufflinks exons for those transcripts
system "cat $p.intersect |  awk -F'\t' '{print \$9}' > $c.intersect.list"; wait;
print "Finding overlaps, please be patient\n";
#system "perl ~mz3/bin/perl/my_grep.pl -i $c.gff -f $c.intersect.list -o $c.gff.chosen2 -w "; wait;
#system " cat $c.gff.chosen2 | grep -w -e CDS -e exon | sort -k1,1 -k4,4n | uniq >$c.gff.chosen3 ";
#system " cat $c.gff.chosen2 | grep -w -e CDS -e exon  >$c.gff.chosen3 ";



### Make hashes of genes

# make stats
my $orphan = `cat $p.orphans | wc -l `;
my $isect = `cat $p.intersect | wc -l `;
my $gene_number = `cat $c.gene | wc -l `;
chomp $orphan; 
chomp $isect; 
chomp $gene_number; 

print "\n\nFor your $gene_number genes, $isect transcripts overlap, and $orphan transcripts dont\'t overlap with a known gene \n\n";


open (IN2, ">$p.transferred.filtered") || die "cant open file $p.transferred.filtered\n";


my %g_in_t;
my %t_in_g;



foreach my $line (@ts) {
    chomp $line;
    #print "$line\n";
    my @arr = split(/\t/, $line);
    
    # check if there is a match, and if there is check if it is right length
    if ( $arr[9] !~/^\.$/) {
        my $glen = $arr[13]-$arr[12];

        #print "$arr[8]\t$arr[17]\n";
        #if (exists $g_in_t{$arr[17]}) {
            $g_in_t{$arr[17]}{$arr[8]}= 1 ;
            $t_in_g{$arr[8]}{$arr[17]}= 1 ;
            #print "Seen $arr[17] $arr[8]\n";
            #}
        #else {
            #$g_in_t{$arr[17]}{$arr[8]}=1;
            #$t_in_g{$arr[8]}{$arr[17]}=1;
            #print "Not seen $arr[17] $arr[8]\n";
            #}


        # check if chose basepair or overlap
        if ($a =~/\./ or $a=~/^1$/) {
            #print "Calculating $a as % overlap\n";
        
            my $len = $glen*$a;
            if ( $len < $arr[18]  ) {
                #print "Match $glen * $a  $len < $arr[18]   \n";
                print IN2 "$arr[8]\t$arr[17]\t$arr[18]\n";
            }
            else {
                #print "Too short $glen * $a  $len > $arr[18] \n";

            }
        }
        else {
            #print "Calculating $a basepair overlap\n";
        

            if ($arr[18] > $a) {
                #print "Match $arr[18] > $a   \n";
                print IN2 "$arr[8]\t$arr[17]\t$arr[18]\n";

            }
            else {
                #print "Too short   $arr[18] < $a \n";
            }
        }
        





    }


}



close (IN2);

open (IN3, ">$p.transferred.transcripts_per_gene") || die "cant open file $p.transferred.transcripts_per_gene \n";
open (IN4, ">$p.transferred.genes_per_transcript") || die "cant open file $p.transferred.genes_per_transcript \n";

my %res3;
my %res4;

foreach my $key (sort keys %g_in_t ) {

    my $len = scalar( keys %{$g_in_t{$key}});
    print IN3  "$key\t$len\t";
    $res3{$len}+=1;

    foreach my $key2 ( sort keys %{$g_in_t{$key}} ) {
        print IN3 "$key2\t";
    }
    print IN3 "\n";

}

print "\nFrequency of number of transcripts in genes\tFrequency\n";
foreach my $key (sort keys %res3) {
    print "$res3{$key}\t$key\n";
}


foreach my $key (sort keys %t_in_g ) {
    
    my $len = scalar( keys %{$t_in_g{$key}});
    print IN4  "$key\t$len\t";
    $res4{$len}+=1;


    foreach my $key2 ( sort keys %{$t_in_g{$key}} ) {
        print IN4 "$key2\t"; 
    }
 print IN4 "\n";

}

print "\nFrequency of number of genes in transcripts\tFrequency\n";
foreach my $key (sort keys %res4) {
    print "$res4{$key}\t$key\n";
}

close (IN3);
close (IN4);

exit;

