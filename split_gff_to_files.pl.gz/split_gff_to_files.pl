#!/usr/local/bin/perl -w
# mz3 script for splitting a gff-file to contigs in different folders

use strict;

unless (@ARGV == 3) {
        &USAGE;
 }

my $infile = shift;
my $prefix = shift;
my $int = shift;
my @array;

if ($int=~m/^1/) {
# Get a list of folders

my $directories = `ls -d */`;

# print "$directories";

my @arr = split(/\n/, $directories);
# Run GlimmerHMM in the contig in all folders

# print "+++$array[2]\n"; <STDIN>;
#

    foreach my $line (@arr) {
        my @lines = (split /\//, $line);

         print "----$lines[0]-----\n";

    }

}


# If you get the contig-names from the infile
#
if  ($int=~m/^2/) {

open (IN, "<$infile");
my @in = <IN>;
 
my %seen = ();

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\s+/, $line);
#    print "$arr[0]\n"; 
    push(@array, $arr[0]) unless $seen{$arr[0]}++;
}

}



foreach my $line2 (@array) {
    chomp $line2;
    if ($line2=~m/\w/) {
#print "$line2\n"; # <STDIN>;

     system "cat $infile | grep -w $line2 > $line2.$prefix.gff";

# print -s "$line2/$line2.$prefix.gff", "\n";

        if (-s "$line2.$prefix.gff" == 0) {
         system "rm -fr $line2.$prefix.gff";
        }

    }
}


sub USAGE {

die 'Usage: split_gff.pl <input_gff> prefix <int>

prefix = prefix for the output filename


perl ~/bin/perl/split_gff.pl test3.cuff.gff test33

Int
If you choose 1, the program assumes you already have directories with the right names
If you choose 2, the program will write all output in one direcory



'
}



__END__


perl ~/bin/perl/split_Glimmer_2_contigs.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU2/glimmerHMM/TrainGlimmM2011-02-16D15:14:39 test
