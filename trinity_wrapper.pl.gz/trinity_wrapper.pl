#!/usr/bin/perl
use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

Splits and chunks Trinity jobs in nice chunks
Insert the regular Trinity command you would have done. Ex:

perl ~mz3/bin/perl/trinity_wrapper.pl --seqType fq --JM 60G --left Trichuris_all_reads_1.fq --right Trichuris_all_reads_2.fq --CPU 16 --inchworm_cpu 1 --monitoring --min_kmer_cov 2 --no_run_butterfly 

Tip: always give innies fastQ-files as input, because Trinity inverts the reverse read only on fastq files.

If you have both paired and unpaired data, and the data are NOT strand-specific, you can combine the unpaired data with the left reads of the paired fragments. Be sure that the unpaired reads have a /1 as a suffix to the accession value similarly to the left fragment reads. The right fragment reads should all have /2 as the accession suffix. Then, run Trinity using the —left and —right parameters as if all the data were paired. 

(Make sure Trinity.pl is in your path before executing)


';

}



my @command = @ARGV;

my $com = join (" ",@command);

$com =~s/--no_run_butterfly/ /;


# Make random number

# my $random =  rand;
my $rand = substr( rand, 2, 5);

# print "Random\t$rand\n";




# Make the first call

# print "bsub.py -q hugemem 60  butt1_$rand perl /nfs/users/nfs_b/bf3/bin/Trinity.pl $com --no_run_butterfly \n ";
print "bsub.py --threads=2 -q hugemem 60  butt1_$rand Trinity.pl $com --no_run_butterfly \n ";



# Make the second call

# print " bsub -w \"done\(exp_$rand\)\" -o combine.o -e combine.e -q -combine\") \n ";

 open (FH, ">>butt2_$rand.sh");

print FH "cat ./trinity_out_dir/chrysalis/butterfly_commands.adj | sed 's/-Xmx20G//g' > ./trinity_out_dir/chrysalis/my_butterfly_commands.sh;wait;\n";
print FH "sh  trinity_out_dir/chrysalis/my_butterfly_commands.sh;wait;\n";
print FH "cat  trinity_out_dir/chrysalis/RawComps.*/*.allProbPaths.fasta > Trinity.fasta\n";

close (FH);


print " bsub.py --threads=2 --done=butt1_$rand 20 butt2_$rand sh butt2_$rand.sh \n ";






# Merge all the results

print "\n";




