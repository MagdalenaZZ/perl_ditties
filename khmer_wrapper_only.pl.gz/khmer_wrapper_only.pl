#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  khmer_wrapper_only.pl  kmer reads.fasta 

This script runs khmer digital normalisation
It takes one read-file, wih interleaved reads, as produced by SEECER



';

}

my $kmer = shift;
my $base = shift;



open (OUT3, ">$base\_$kmer\_KHMER.sh") || die "Cant open file $base\_$kmer\_KHMER.sh";

# do kmehr

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py  -C 20 -k $kmer -N 4 -x 2e9 --paired   $base  \n";

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/sandbox/strip-and-split-for-assembly.py $base.keep  \n";
print OUT3 "/nfs/users/nfs_m/mh12/git/python3.2/fastn_deinterleave.py $base.keep.pe $base\_1.fastq $base\_2.fastq\n";

print "\nBsubbing this job:  bsub.py  -q normal 30 $base\_$kmer\_KHMER sh $base\_$kmer\_KHMER.sh\n\n";
system "bsub.py  -q yesterday 10 $base\_$kmer\_KHMER sh $base\_$kmer\_KHMER.sh\n";


close (OUT3);


