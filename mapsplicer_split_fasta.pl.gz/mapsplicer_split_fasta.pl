#!/usr/local/bin/perl -w
# mz3 script for creating a folder structure 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


my $fasta = shift;

my @list;
my @head;


system (mkdir "fastas") unless (-d "fastas");

if ( scalar(@ARGV) > 0 ) {
my $list = shift;
    print "LIST:$list\n";

open (IN, "$list");
@list = <IN>;

# if there is a list
foreach my $scaffold (@list) {
chomp $scaffold;

# system ("mkdir $scaffold") unless (-d $scaffold);
push (@head, $scaffold);

}
}

# if there is not a list

else  {
    open (IN, "$fasta");
     @list = <IN>;

    foreach my $scaff (@list) {
    chomp $scaff;

        if ( $scaff =~/^\>/) {
            $scaff =~s/\>//;
#            print "$scaff\n";
#            system ("mkdir $scaff") unless (-d $scaff);
            push (@head, $scaff);

        }
    }
}





# write fasta

foreach my $scaffold1 ( @head) {
    my $scaffold2 = "0";

    if ( $scaffold1=~/^\>/) {
        $scaffold1 =~s/\>//;
        $scaffold2 = $scaffold1;
    }
    else {
        $scaffold2 = $scaffold1;
    }

    #print "$scaffold2\n";
#print ("cat $fasta | grep $scaffold2 -w -A 1 > ./$scaffold1/$scaffold1.fasta") ;

system ("cat $fasta | grep $scaffold2 -w -A 1 > ./fastas/$scaffold1.fa") 
#unless (-e  "./$scaffold/$scaffold.fasta" );

}


sub USAGE {

die 'Usage:  split_fasta_to_dirs.pl <fasta-file>  optional:<list> 



fasta-file - fasta with name and sequence
list - list of sequence-names



'
}
