#!/usr/bin/perl -w

use strict;
#use File::Slurp;
#use Cwd;
use Data::Dumper;
use Data::Dump;


my $largest = 0;
my $contig = '';


if (@ARGV < 1) {
	print "\n\nUsage: Pathway_DESeq.pl merged.reads my.design <included columns> <prefix> <design> <file with genes>  <species> \n\n" ;

    print " mz3 script for taking eXpress_read_counts and turning them into a DESeq2 matrix \n\n";
    print "Suitable for interaction terms\n\n";

    print "Verify the re-leveling strategy!!!\n";
	exit ;
}


push(@ARGV, " ");
my $file = shift;
my $des = shift;  
my $incl = shift;
my $pre = shift;
my $de=shift;
my $species = shift;
my @paths = @ARGV;

# open the file
open (IN, "$file") || die "I can't open $file\n";
open (IN2, "$des") || die "I can't open $des\n";
my @des = <IN2>;


# make a choice of subset rows and columns 

my @inc = split(/\,/, $incl);

unshift @inc, "0";

my @design;

foreach my $ele (@inc) {
    my $ne = $des[$ele];
    $ne=~s/^\t//;
    $ne=~s/^\s+//g;
    push (@design, "$ne" );

    #print "$ele\t$ne\n";
}



# make the same choice for genes

my @submat;

while (<IN>) {
    chomp;
    my @arr = split(/\s+/, $_);
    my @new_arr;
    #print "@new_arr\n";

    foreach my $ele (@inc) {
        #$ele--;
	if (exists $arr[$ele]) {
    		push (@new_arr, $arr[$ele] );
	}
    }

	if (scalar(@new_arr)>0) {
    		my $new = join("\t", @new_arr);
    		#print "$new\n";
    		push(@submat, "$new\n");
	}
}





# write outfiles

open (OUT, ">$pre.tab") || die "I can't open $pre.tab\n";
open (OUT2, ">$pre.design") || die "I can't open $pre.design\n";

foreach my $l (@design) {
    print OUT2 "$l";
}

foreach my $l (@submat) {
    print OUT "$l";
}

close(OUT2);
close(OUT);


# check the experimental design

my @desi1 = split(/[\*,\+,\:]/, $de);
$desi1[0]=~s/~//;




#__END__

# now do DESeq2 commandlines
# this bit is same for all

open (R, ">$pre.R") || die "I can't open $pre.R\n";

print R "\n";
print R "\n";
print R "library(DESeq2)\n";

print R "CountTable = read.table( \"$pre.tab\", header=TRUE, row.names=1 )\n";
print R "design =  read.table( \"$pre.design\", header=TRUE, row.names=1 )\n";
print R "dds<-DESeqDataSetFromMatrix(countData= CountTable,colData= design,design=$de)\n";

print R "## releveling\n";
print R "try(dds\$Trans <- relevel(dds\$Trans, \"normal\"))\n";
print R "try(dds\$Cell <- relevel(dds\$Cell, \"LSK\"))\n";
print R "try(dds\$Hox <- relevel(dds\$Hox, \"hasHox\"))\n";
print R "try(dds\$BCat <- relevel(dds\$BCat, \"WT\"))\n";
print R "try(dds\$Biol <- relevel(dds\$Biol, \"A\"))\n";
print R "try(dds\$Virus <- relevel(dds\$Virus, \"Puro\"))\n";
print R "try(dds\$Treatment <- relevel(dds\$Treatment, \"WT\"))\n";
print R "try(dds\$Treatment <- relevel(dds\$Treatment, \"shKDM5B\"))\n";
print R "try(dds\$Treatment <- relevel(dds\$Treatment, \"shKDM5A\"))\n";
print R "try(dds\$Treatment <- relevel(dds\$Treatment, \"pLKO1\"))\n";
print R "try(dds\$BMI1 <- relevel(dds\$BMI1, \"WT\"))\n";
print R "try(dds\$Ezh2 <- relevel(dds\$Ezh2, \"WT\"))\n";
print R "\n";

print R "dds <-DESeq(dds)\n";
#print R "res <-results(dds, addMLE=TRUE )\n";
print R "res <-results(dds)\n";
print R "resOrdered<-res[order(res\$padj),]\n";
#print R "deseq2.fc=resOrdered\$log2FoldChange\n";

&pathway("$pre");


system "R CMD BATCH $pre.R > $pre.Rout";



exit;


############################################################

sub pathway
{

    my $PRE = $_[0];
    print "PRE $PRE\n";

print R " \n";
print R "####### PATHWAY ANALYSIS #######\n";
print R "require(gage)\n";
print R "require(pathview)\n";

# get results
#print R "deseq2.res <- resOrdered\n";
print R "deseq2.fc=resOrdered\$log2FoldChange\n";
print R "names(deseq2.fc)=rownames(resOrdered)\n";
print R "exp.fc=deseq2.fc\n";
print R "out.suffix=\"$PRE\"\n";
print R "kegg.mouse <- kegg.gsets(species=\"$species\", id.type=\"entrez\")\n";
print R "fc.kegg.p <- gage(exp.fc, gsets = kegg.mouse , ref = NULL, samp = NULL)\n";
print R "write.table(as.data.frame(fc.kegg.p),file=\"$PRE\.gage.txt\", sep=\"\\t\")\n";
print R 'sel.h <- fc.kegg.p$greater[, "q.val"] < 0.2 & !is.na(fc.kegg.p$greater[, "q.val"])';
print R " \n";
print R "path.ids.h <- rownames(fc.kegg.p\$greater)[sel.h]\n";
print R 'sel.l <- fc.kegg.p$less[, "q.val"] < 0.2 & !is.na(fc.kegg.p$less[,"q.val"])';
print R " \n";
print R 'path.ids.l <- rownames(fc.kegg.p$less)[sel.l]';
print R " \n";
#print R "path.ids.all <- c(substr(c(path.ids.h, path.ids.l),1,5),\"05202\",\"04550\",\"04310\")\n";
print R "path.ids.all <- c(substr(c(path.ids.h, path.ids.l),1,5)";
foreach my $elem (@paths) {
    	chomp $elem;
	if($elem=~/\w+/) {
		print R "\,\"$elem\"";
    }
}
print R ")\n";
print R "path.ids.all \n";
print R "max<- max(na.omit(deseq2.fc))\n";
print R "pathpv.out.list <- sapply(path.ids.all, function(pid) pathview(gene.data = exp.fc, pathway.id = pid,  out.suffix=\"$PRE.gage\", ";
print R "species = \"$species\", high = list(gene = \"seagreen3\", cpd = \"blue\"), mid = list(gene = \"lightgoldenrod\", cpd = \"lightgoldenrod\"), low = list(gene = \"indianred1\", cpd =\"yellow\"), limit=list(gene=max, cpd=20) ))\n";

print R " \n\n#SPIA\n";
print R "require(SPIA)\n";

print R "sig_genes1 <- subset(resOrdered, padj<0.01)\n";
print R "sig_genes <-sig_genes1\$log2FoldChange\n";
print R "names(sig_genes) <- rownames(sig_genes1)\n";
print R "all_genes <- rownames(dds)\n";
#print R "all_genes <- mcols(dds)\$Entrez\n";
#print R "all_genes <-  as.vector(na.exclude(mcols(dds)\$Entrez))\n";
print R "spia_result <- spia(de=sig_genes, all=all_genes, organism=\"$species\", plots=FALSE)\n";
print R "spia_result\n";
print R "write.table(as.data.frame(spia_result),file=\"$PRE.spia.txt\", sep=\"\\t\")\n";
print R "try(plotP(spia_result, threshold=0.01)) \n";
print R "sign.spia <- subset(spia_result, pGFdr<0.01) \n";
#print R "sign.spia$ID  \n";
print R "pathpv.out.list <- sapply(sign.spia\$ID , function(pid) pathview(gene.data = exp.fc, pathway.id = pid,  out.suffix=\"$PRE.spia\", ";
print R "species = \"$species\", high = list(gene = \"seagreen3\", cpd = \"blue\"), mid = list(gene = \"lightgoldenrod\", cpd = \"lightgoldenrod\"), low = list(gene = \"indianred1\", cpd =\"yellow\"), limit=list(gene=max, cpd=20) ))\n";


print R "\n####### END PATHWAY ANALYSIS #######\n\n";



}



#############################################################


