#!/usr/bin/perl -w
#converts BLAST outfmt 6 to Artemis-style gff entries.
#Usage BLAST2gff.pl <input_BLAST_outfmt6> >output-file

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLAST2gff.pl <blast.output> orientation

Takes a blast-output in tab-format, and produces a gff-file

The orientation indicates wheter the contig in the output-file is the database (db) (first column) or the query (q) (second column)

'
}

my %hash;
my $strand=0;
my $in =shift;
my $ori =shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

    	open (OUT, ">$in.gff") || die "I can't open $in.gff\n";


foreach my $elem (@in) {
    chomp $elem;

    if ($elem=~m/#/) {

    }
    else {
#    tr/=/ /;
        $elem =~s/lcl\|//;

    	my @line = split (/\s+/, $elem);
    	my $query = $line[0];
    	my $target = $line[1];
    	my $similarity = $line[2];
    	my $bitscore = $line[3];
    	my $basechanges = $line[4];
    	my $indels = $line[5];
    	my $querystart = $line[6];
    	my $queryend = $line[7];
    	my $targetstart = $line[8];	
    	my $targetend = $line[9];
    	my $evalue = $line[10];	
    	my  $score = $line[11];

        if ($ori=~/db/) {
#        print "$targetstart\t$targetend\n";
        	if (($targetend - $targetstart) > 0){
           	$strand="+"; 
           #	print "plus $strand\n"; <STDIN>;
                print OUT	my $newline =  "$target\tBLAST\tCDS\t$targetstart\t$targetend\t.\t$strand\t.\tnote=$query;colour=16;\n"; #;note=similarity $similarity;note=evalue $evalue;\n";
        	}
        	else {
            	$strand="-"; 
            #	print "negative $strand\n";<STDIN>;
                print OUT	my $newline =  "$target\tBLAST\tCDS\t$targetend\t$targetstart\t.\t$strand\t.\tnote=$query;colour=16;\n"; #;note=similarity $similarity;note=evalue $evalue;\n";
	
        	}
        }

        elsif ($ori=~/q/) {
            #print "$querystart\t$queryend\n";
        	if (($queryend - $querystart) > 0){
           	    $strand="+"; 
                #print "plus $strand\n"; <STDIN>;
                print OUT	my $newline =  "$query\tBLAST\tCDS\t$querystart\t$queryend\t.\t$strand\t.\tnote=$target;colour=16;\n";        	}
        	else {
            	$strand="-"; 
                #print "negative $strand\n";<STDIN>;
                print OUT	my $newline =  "$query\tBLAST\tCDS\t$queryend\t$querystart\t.\t$strand\t.\tnote=$target;colour=16;\n"; 	
        	}
        }
        else {
            print "Can't understand your orientation\nPlease write db or q\n";
            &USAGE;
        }

    }
}

close (OUT);

