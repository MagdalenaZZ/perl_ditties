#!/usr/bin/perl -w
#converts BLAST outfmt 6 to Artemis-style gff entries.
#Usage BLAST2joined_fasta.pl <input_BLAST_outfmt6> >output-file

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: transcriptome_eliminate_self-complimentary_wrapper.pl fasta

Takes a fasta-file, blasts each sequence against itself and determines wether it is self-complimentary.
If it is, the programme tries to break it.

NOT FINISHED!!!!!

'
}

# read the fasta and make blasts against itself 
my $in =shift;

#system "perl ~mz3/bin/perl/transcriptome_eliminate_self-complimentary.pl $in"; wait;


# pick the output, and run against itself again

#system "perl ~mz3/bin/perl/transcriptome_eliminate_self-complimentary.pl $in.res.list.in_list.all_split.fasta"; wait;


# read in the fasta
open (FAS, "<$in.res.list.in_list.all_split.fasta.res.list.in_list") || die "I can't open $in.res.list.in_list.all_split.fasta.res.list.in_list\n";

my %fas;
$/ = ">";

while (<FAS>){
    my @arr = split(/\s+/,$_);
    #print "$arr[0]\t$arr[1]\n";
    $fas{$arr[0]}="$arr[1]";
}

$/ = "\n";


# read in the blast

open (BLA, "<$in.res.list.in_list.all_split.fasta.tmp.all.blast") || die "I can't open $in.res.list.in_list.all_split.fasta.tmp.all.blast\n";



# figure out what is going on with the sequence
# store in a hash containing:  $res {$query} {errors} = "coordinates";

my $seen = 0;
my %res;

while (<BLA>){
    my @line = split(/\s+/,$_);
    #print "\n $line[0]\n";
    #$fas{$arr[0]}="$arr[1]";
    my $query = $line[0];
    my $target = $line[1];
    my $similarity = $line[2];
    my $bitscore = $line[3];
    my $basechanges = $line[4];
    my $indels = $line[5];
    my $querystart = $line[6];
    my $queryend = $line[7];
    my $targetstart = $line[8];	
    my $targetend = $line[9];
    my $evalue = $line[10];	
    my $score = $line[11];
    my $qdiff = $queryend - $querystart;
    my $tdiff = $targetend - $targetstart;

    # length of sequence
    my $len = length(  $fas{$query}  );
    # now test what is wrong with the sequences
    
    # filter
   if ( $evalue > 0.0001) {
      # ignore
   }
    
    
    # primary complement
    elsif ($querystart==$targetstart and $queryend==$targetend ) {
        # do nothing
        #print "\nSAME: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
        #print "$len\t$fas{$query}\n";
        #$right{$query}{"$ele"}=1;
        $seen = "0";
        $res{$query}{"SAME"}= "$_";
    }
    # prefect palindrome
    #my @same = split(/\t/,$res{$query}{"SAME"});

    
    elsif ( "$querystart" == "$targetend" and "$queryend" == "$targetstart" ) {    
             
    # if it is full length, see by input
    
        if ( $querystart=~/^1$/ and $queryend=~/^$len$/ ) {
            $res{$query}{"PER_PAL"}= "$_";
            # else do sth else 
            #print "PER PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";

        }
        else {
            #print "PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
            # $res{$query}{"PAL"}= "$_";
            
            # first scenario - 5' sequence is self complementary / 3' sequence not
	    if ( $querystart=~/^1$/ and $queryend!=/^$len$/ ) {
	      $res{$query}{"3_MM_PAL"}= "$_";
          # print "3_MM_PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
	    }
	    # second scenario - 3' sequence is self complementary / 5' sequence not
      	    elsif ( $querystart!=/^1$/ and $queryend=~/^$len$/ ) {
	      $res{$query}{"5_MM_PAL"}= "$_";
          #print "5_MM_PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
            }
	     # third scenario - internal sequence is self complementary / 5' and 3' end sequences not
      	    elsif ( $querystart!=/^1$/ and $queryend!=/^$len$/ ) {
	      $res{$query}{"53_MM_PAL"}= "$_";
          #print "53_MM_PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
            }
            else {
	      # catch exceptions
	      $res{$query}{"OTHER"}= "$_";
          #print "OTHER: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
	    }
        }
    }
    # reverse complement complete - second hit
    elsif ( $qdiff>0 and $tdiff<0 and $seen=~/$query/ ) {    
         #print "2ND REV: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"2ND"}= "$_";
    }
    # reverse complement complete - first hit
    elsif ( $qdiff>0 and $tdiff<0  ) {    
         #print "1ST REV: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"1ST"}= "$_";
         $seen = $query;
    }
    elsif ( $qdiff>0 and $tdiff<0  ) {    
         #print "DIFF: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"DIFF"}= "$_";
    }
    else {
        #print "ELSE: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
        $res{$query}{"ELSE"}= "$_";
    }


#    $seen = $query ;

}



# deal with the sequences

my %nseq;

foreach my $gene (keys %res ) {

    my @arr;

    foreach my $key (keys %{$res{$gene}} ) {

        push ( @arr, $key);

    }

    my @sorted = sort(@arr);
    my $string = join(" ", @sorted);
    #print "$gene\t$string\n";

    my $seq = "$fas{$gene}";
    my $len = length($fas{$gene});

# if there is a perfect palindrome covering the whole length, split in two and keep both parts
# recognise by keys: SAME amd PERPAL

    if ($string =~/^PER_PAL SAME$/){

        my $half = int($len/2);
        #print "ORI: $gene\t$len\t$half\t$seq\n";
        #print "ORI: $gene\t$seq\n";

        my $seq1 = substr($seq, 0 ,$half );
        my $seq2 = revcomp(substr($seq, $half ));
        my $gene1 = $gene . "_1";
        my $gene2 = $gene . "_2";
        #print "RES: $gene1\t$seq1\n$gene2\t$seq2\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
    }

# if there is a perfect palindrome, but a sticky-out bit, then ....
# recognise by SAME and PERPAL2
    elsif ($string =~/^3_MM_PAL SAME$/) {
        #print "ORI: $gene\t$seq\n";
        #print $res{$gene}{"3_MM_PAL"} . "\n";
        my @bl = split(/\t/, $res{$gene}{"3_MM_PAL"});
        #print "$bl[6]\t$bl[7]\t$bl[8]\t$bl[9]\n";
        my $half = int($bl[7]/2);

        my $seq1 = substr($seq, 0 ,$half );
        my $seq2 = revcomp(substr($seq, $half ));
        my $gene1 = $gene . "_1";
        my $gene2 = $gene . "_2";
        #print "RES: $gene1\t$seq1\n$gene2\t$seq2\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
    }

    elsif ($string =~/^5_MM_PAL SAME$/) {
        my @bl = split(/\t/, $res{$gene}{"5_MM_PAL"});
        #print "ORI: $gene\t$seq\n";
        #print "$len ". $res{$gene}{"5_MM_PAL"} . "\n";
        my $half = int( (($bl[7]-$bl[6])/2)+$bl[6] );
        #print "$half\t$bl[6]\t$bl[7]\t$bl[8]\t$bl[9]\n";
        my $seq1 = substr($seq, 0 ,$half );
        my $seq2 = revcomp(substr($seq, $half));
        my $gene1 = $gene . "_1";
        my $gene2 = $gene . "_2";
        #print "RES: >$gene1\n$seq1\n>$gene2\n$seq2\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
    }

    elsif ($string =~/^53_MM_PAL SAME$/) {

        my @bl = split(/\t/, $res{$gene}{"53_MM_PAL"});
        my $half = int(  (($bl[7]-$bl[6])/2)+$bl[6]   );
        #print "ORI: $gene\t$seq\n";
        #print "$half\t$len\t$bl[6]\t$bl[7]\t$bl[8]\t$bl[9]\n";
        my $seq1 = substr($seq, 0 ,$half );
        my $seq2 = revcomp(substr($seq, $half ));
        my $gene1 = $gene . "_1";
        my $gene2 = $gene . "_2";
        #print "RES: >$gene1\n$seq1\n>$gene2\n$seq2\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
    }

# if there are two distinct hits

    elsif ($string =~/^1ST 2ND SAME$/) {
        my @bl1 = split(/\t/, $res{$gene}{"1ST"});
        #my @bl2 = split(/\t/, $res{$gene}{"2ND"});

        my $fir = $bl1[8] ;
        my $sec = $bl1[6];
        my $thir = ($bl1[6] - $bl1[8]);

        #print "ORI: $gene\t$seq\n";
        #print "$fir\t$sec\t$thir\t$len\t$bl1[6]\t$bl1[7]\t$bl1[8]\t$bl1[9]\n";
        #print "$half\t$len\t$bl2[6]\t$bl2[7]\t$bl2[8]\t$bl2[9]\n";

        my $seq1 = substr($seq, 0 ,$fir );
        my $seq2 = revcomp(substr($seq, $sec ));
        my $seq3 = substr($seq, $fir, $thir );

        my $gene1 = $gene . "_1";
        my $gene2 = $gene . "_2";
        my $gene3 = $gene . "_3";

        #print ">$gene1\n$seq1\n>$gene2\n$seq2\n>$gene3\n$seq3\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
        $nseq{$gene3}="$seq3";
    }


    else {
        print "Warning, don't know how to deal with: $gene $string\n";
        $nseq{$gene}="$seq";
    }


}

print "\n\n";



# now print your lovely new sequences

open (OUT, ">$in.tmp.fas") || die "I can't open $in.tmp.fas\n";


foreach my $gen (sort keys %nseq) {
    print OUT ">$gen\n$nseq{$gen}\n";
}

close (OUT);

# clean up things
system "cat $in.res.list.in_list.all_split.fasta.res.list.not_in_list $in.tmp.fas > $in.norevcomp.fas ";
#system "rm -f $in.res.list.not_in_list";
#system "rm -f $in.tmp.fas";





sub revcomp {
        my $dna = shift;

	# reverse the DNA sequence
        my $revcomp = reverse($dna);

	# complement the reversed DNA sequence
        $revcomp =~ tr/ACGTacgt/TGCAtgca/;
        return $revcomp;
}


exit;


__END__

