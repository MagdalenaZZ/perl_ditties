#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: fake_pairs_from_fastq.pl input.fastq read-length reps

mz3 script for making fake Illumina reads from 454 fastq files

Choose any read-length you like


'
}


	my $in = shift;
	my $readlength = shift;
	my $reps = shift;
	$readlength --;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my @firsts;
chomp @firsts;

=pod
# simple version - only taking the first 76 bp


foreach my $line (@in) {
chomp $line;
# $portion = substr($string_variable, start number, length); 
my $portion = substr($line, 0, $readlength);
print "$portion\n";
 push (@firsts, $portion);
}

=cut

my @arr=split (/.fastq/, $in);

# print "$arr[0]\n";
# print "$arr[1]\n";

	open (OUTF, ">$arr[0].1.fastq") || die "I can't open $arr[0].1.fastq\n";
#	my @in = <OUTF>;

	open (OUTR, ">$arr[0].2.fastq") || die "I can't open $arr[0].2.fastq\n";
#	my @in = <OUTR>;


# more complex version - taking 76 bp random from a fastq

while ($reps > 0) {

my $lastline = 0;
my $lastline2 = 0;

foreach my $line (@in) {

chomp $line;

	if ($line=~/^\+$/) {
#		print "Line:$line\n";	
#		print "Last: $lastline\n";
#		print "Last2: $lastline2\n";
		# $portion = substr($string_variable, start number, length); 
		my $length = length ($lastline); # right length
#		print "Length:$length\n";
		my $newlength = ($length - $readlength-1);
#		print "Newlength:$line\n";
		my $range = $newlength;
#		print "Range:$range\n";
		my $random_number = int(rand($range));
#		print "Rand:  $random_number\n";
		my $portion = substr($lastline, $random_number, ($readlength+1));
		$lastline2 =~s/_left/-$reps\/1/;
		$lastline2 =~s/_right/-$reps\/2/;
		$lastline2 =~s/\@/\>/;
		my $header = $lastline2;

		if ($header=~/\/1/) {
			print OUTF "$header\n";
			print OUTF "$portion\n";
		}
		elsif ($header=~/\/2/) {
			print OUTR "$header\n";
			print OUTR "$portion\n";
		}
#		push (@firsts, $portion);
	}
	$lastline2 = $lastline;
	$lastline = $line;
}

$reps--;

}

	close (OUTF);
	close (OUTR);