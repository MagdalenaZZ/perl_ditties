#!/usr/bin/perl -w

use strict;


unless (@ARGV==3) {
        &USAGE;
}

sub USAGE {

die '


DERELICT NON_FUNCTIONING program

Usage: blast2go_2tab.pl infile gff outfile

Do Blast2GO and then export as annot_GO_file




'
}

	my $in = shift;
	my $gff = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my %hash; 
my %hash2; 
my $index=0;

foreach my $line (@in) {
chomp $line;
	my @arr=split(/\t/, $line);
	my $gene = "$arr[0]";
	my $aspect = "$arr[4]"; # F C or P
	my $term = "$arr[3]";
	my $product = "$arr[1]";
	my $dbxref = "GO_REF:0000001";
	my $date = "20110915";
	my $evidence ="IEA";
	my $autocomm ="From Blast2GO";
	my $goid="$arr[2]";

	my $goann = "\/GO=\"aspect\=$aspect;GOid=$goid;term=$term;db_xref=$dbxref;date=$date;evidence=$evidence;autocomment=$autocomm\"";

#	print "Key:$gene:$goann\n";

	$hash{$gene}{$index} = "$goann";
	$hash2{$gene} = "$product";
# $hash{'fred'} = "USA"; $hash{'john'} = "CANADA"; 
$index++;
}

open (OUT2, ">$out.products") || die "I can't open $out.products\n";

foreach my $key (sort keys %hash2) {
	print OUT2 "$key\t$hash2{$key}\n";
}

close (OUT2);


open (GFF, "<$gff") || die "I can't open $gff\n";
my @gff = <GFF>;
close (GFF);



my @newgff;

foreach my $line (@gff) {
chomp $line;
	my @line=split(/\t/, $line);

	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];



	if ($tag =~/^gene$/) {
		$key =~s/ID=//;
		my @key = split(/\t/, $key);
#		print "Key:$key[0]:\n";
		if ($hash{$key[0]}) {
			my @gos;
			foreach $index (keys %{ $hash{$key[0]}} ) {
#			print "Key:$key[0]: value :$hash{$key[0]}{$index}:\n";
			push (@gos, $hash{$key[0]}{$index});
			}
			my $goss=join("\t",@gos);
			my $prod1= "$hash2{$key[0]}";
			my $prod2="/product=\"$prod1\"";
			my $newline = "$line\t$prod2\t$goss";
#			print "$newline\n";
			push (@newgff, $newline);
		}
		else {
			push (@newgff, $line);
		}
	}
	else {
		push (@newgff, $line);
	}

}

open (OUT, ">$out") || die "I can't open $out\n";

foreach my $elem (@newgff) {
	print OUT "$elem\n";
}

close (OUT);