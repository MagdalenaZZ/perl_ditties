#!/usr/bin/perl -w


use strict;


if (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: TTD_parser.pl   TTD_download.txt    TTD_crossmatching.txt

Takes the download from TTD and parses it




What can possibly go wrong...  :-)



'
}

my $in = "TTD_download.txt";
my $in2 = "TTD_crossmatching.txt";


open (IN, "<$in") || die "I can't open $in\n";
open (IN2, "<$in2") || die "I can't open $in2\n";
my @in= <IN>;
close (IN);
my @in2= <IN2>;
close (IN2);


open (OUT, ">$in.summary") || die "I can't open $in.summary\n";

my %h;


foreach my $line ( @in) {
    chomp $line;
    my @arr = split (/\t/, $line);

    if ($arr[1] =~/Name/) {
#        print "$arr[0]\n";
        $h{$arr[0]}{"Name"}{$arr[2]}=1;
    }

    elsif ($arr[1] =~/Inhibitor/) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $h{$arr[0]}{"Inhib"}{$arr[3]}= "$arr[2]";
#        print "$arr[3]" . "\t\t" . "$arr[2]\n";
    }
    elsif ($arr[1] =~/Drug/ and $arr[5]=~/Approved/ ) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $arr[4]=~s/ /_/g;
        $h{$arr[0]}{"Drug"}{$arr[3]}{"Info"}="$arr[2]\:$arr[4]";
#        print "$arr[0]\t$arr[3]\t$arr[2]\t$arr[4]\n";
    }

    elsif ($arr[1] =~/Agonist/ ) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $arr[3]=~s/ /_/g;
        $h{$arr[0]}{"Agonist"}{$arr[3]}{"Info"}="$arr[2]";
#        print "$arr[0]\t$arr[3]\t$arr[2]\t$arr[4]\n";
    }
    elsif ($arr[1] =~/Antagonist/ ) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $arr[3]=~s/ /_/g;
        $h{$arr[0]}{"Antagonist"}{$arr[3]}{"Info"}="$arr[2]";
#        print "$arr[0]\t$arr[3]\t$arr[2]\t$arr[4]\n";
    }


    elsif ($arr[1] =~/UniProt/) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $h{$arr[0]}{"Uni"}{$arr[2]}= 1;
#        print "$arr[2]\n";
    }
    elsif ($arr[1] =~/Pathway/) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $h{$arr[0]}{"Path"}{$arr[2]}= 1;
#        print "$arr[0]\t$arr[2]\n";
    }

    elsif ($arr[1] =~/Type/) {
#        print "$line\n";
        $arr[2]=~s/ /_/g;
        $h{$arr[0]}{"Type"}{$arr[2]}= 1;
#        print "$arr[2]\n";
    }
    else {
        # do hotnigh;
    }

}


=pod

foreach my $lin2 ( @in2) {
    chomp $lin2;
    my @arr2 = split(/\t/, $lin2);
    
    foreach my $tar ( keys %h) {

        if (exists $h{$tar}{"Drug"}{$arr2[0]}){
            $h{$tar}{"Drug"}{$arr2[0]}{"Info2"}{$arr2[2]}="$arr2[3]";           
        }

        if (exists $h{$tar}{"Agonist"}{$arr2[0]}){
#            print "AGO_$tar\n";
            $h{$tar}{"Agonist"}{$arr2[0]}{"Info2"}{$arr2[2]}="$arr2[3]";
        }
        if (exists $h{$tar}{"Antagonist"}{$arr2[0]}){
#            print "AGO_$tar\n";
            $h{$tar}{"Antagonist"}{$arr2[0]}{"Info2"}{$arr2[2]}="$arr2[3]";
        }

        else {
            # do nothin;
        }

    }
}


=cut


# empty hash

print "NAME\tUniProt\tDRUG\tANT\tINH\n";

my @o='';


foreach my $tar (  keys %h) {
       
        print OUT "$tar";

        foreach my $nm  ( sort keys %{$h{$tar}{"Name"}} ) {
            push (@o, "NAM_$nm");
        }

        foreach my $dr   ( sort keys %{$h{$tar}{"Drug"}} ) {
##                     print "\t" . "DR_" . "$dr";
            push (@o, "DRU_$dr");

                foreach my $info ( sort keys %{$h{$tar}{"Drug"}{$dr}} ) {
#                    print "IN_$info\t\t";
                                push (@o, "DIF_$h{$tar}{Drug}{$dr}{Info}");
                }

        }
#        print "\t";
        foreach my $ag   ( sort keys %{$h{$tar}{"Agonist"}} ) {
##                    print "\t" . "AN_" . "$an";
            push (@o, "AGO_$ag");

                foreach my $info ( sort keys %{$h{$tar}{"Agonist"}{$ag}} ) {
##                    print "\t" . "IN_" . "$info";
##                    print "\t" . "INA_" . "$h{$tar}{Antagonist}{$an}{Info}";
                      push (@o, "GNA_$h{$tar}{Agonist}{$ag}{Info}");
                        
                }

        }
        foreach my $an   ( sort keys %{$h{$tar}{"Antagonist"}} ) {
##                    print "\t" . "AN_" . "$an";
            push (@o, "ANT_$an");

                foreach my $info ( sort keys %{$h{$tar}{"Antagonist"}{$an}} ) {
##                    print "\t" . "IN_" . "$info";
##                    print "\t" . "INA_" . "$h{$tar}{Antagonist}{$an}{Info}";
                      push (@o, "INA_$h{$tar}{Antagonist}{$an}{Info}");
                        
                }

        }

        foreach my $re   ( sort keys %{$h{$tar}{"Pathway"}} ) {
            push (@o, "PAH_$re");
#            print "PAH $re\n";
        }

        foreach my $inh   ( sort keys %{$h{$tar}{"Inhibitor"}} ) {
##            print "\t" . "INH_" . "$inh";
            push (@o, "INH_$inh");
#            print "INH $inh\n";
          }

        foreach my $un   ( sort keys %{$h{$tar}{"Uni"}} ) {
            push (@o, "UNP_$un");
        }


        print OUT "\t";
        print shift(@o);
        my @sort = sort (@o);
        print OUT join("\t", @sort) . "\n";
        @o='';
}

close (OUT);

exit;


