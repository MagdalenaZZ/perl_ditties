#!/usr/bin/perl -w
use strict;




unless (@ARGV == 2) {
        &USAGE;
 }

my $in = shift;
my $add = shift;

open (IN, "<$in") or die "Can\'t open file $in\n" ;

my @in = <IN> ;

foreach my $line (@in){
chomp $line;
#		print "$line\n";
	if ($line=~/gene/ ) {
		print "$line\;$add\n";
	}
	else {
		print "$line\n";
	}

}



sub USAGE {

die 'Usage: gff_add_end.pl <input_gff> add-line


# mz3 script for adding a line to the ends of genes
# the line can be something like colour=8
# or \'note="Gene has no BLAST similarities"\' 
# and will only be added to genes

'
}