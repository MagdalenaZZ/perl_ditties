#!/usr/bin/perl
use strict;

unless (@ARGV ==2) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/grep_per_line.pl file pattern.file


';

}

my $file = shift;
my $pat = shift;


print "File:$file PAT:$pat\n" ;

my %pats;

open (IN, "<$pat") || die "Cannot find file :$pat:\n";


while (<IN>) {
    chomp;

    $pats{$_}=1;


}

close (IN);

open (IN2, "<$file") || die "Cannot find file :$file:\n";
my @in = <IN2>;


foreach my $key (keys %pats) {

    my $newkey = $key;
    $newkey=~s/\t/-/g;
    $newkey=~s/\s+/-/g;

    #print "NEW:$newkey:\n";

    open (OUT, ">$file.$newkey") || die "Cannot open file $file.$newkey \n";

    #print "KEY:$key:\n";
    my $quoted_word = quotemeta($key);
    foreach my $l (@in) {
        chomp $l;
        my $var = $l;
        $var=~s/\t/-/g;
        $var=~s/\s+/-/g;

        if ($l=~/$key/) {
        #if ($l=~/\Q$key\E/) {
        #if ($key=~/$quoted_word/) {
        #print ":$newkey:$var:\n";
        #if ($var=~/$newkey/) {
                print OUT "$l\n";
            }
            else {
                #print "NO $key  $l\n";
            }
    
    }

}

close (IN2);
exit;





