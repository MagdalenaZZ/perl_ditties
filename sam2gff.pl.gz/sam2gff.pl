#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/sam2gff.pl file.sam

';

}


my $in = shift;



open (IN, "<$in") or die 'Cant find infile  ';

my $a = "A";

while (<IN>) {
    chomp;
    my @arr = split(/\s+/, $_ );
    my $qname = $arr[0];
    my $flag = $arr[1];
    my $rname = $arr[2];
    my $pos = $arr[3];
    my $mapq = $arr[4];
    my $cigar = $arr[5];
    my $rnext = $arr[6];
    my $pnext = $arr[7];
    my $tlen = $arr[8];
    my $seq = $arr[9];
    my $qual = $arr[10];

    my $start = $pos;
    $cigar=~s/\s+//g;


    my @cign = split (/\D+/, $cigar );
    my @cigt = split (/\d+/, $cigar );

#    print "Cigar:$cigar:\n";
    
    my $cigt2 = join(" ", @cigt);
#    print "T:$cigt2:\n";
    my $cign2 = join(" ", @cign);
#    print "N:$cign2:\n";

    my $end = eval (join '+', @cign) + $start;
#    print "S:$end\n";


    print "$arr[2]\tsamfile\tgene\t$start\t$end\t.\t+\t.\tID=$arr[0]$a\n";
    print "$arr[2]\tsamfile\tmRNA\t$start\t$end\t.\t+\t.\tID=$arr[0]$a.1;Parent=$arr[0]$a\n";



#    my $i = scalar(@cigt)-1;
    my $i = 0;


    my $curr_pos = $start;

    foreach my $op (@cigt) {
        if ($op=~/M/) {
#            print "i:$i:\n";
            my $cstart = $curr_pos;
            my $cend = $cstart + $cign[$i];
            print "$arr[2]\tsamfile\tCDS\t$cstart\t$cend\t.\t+\t.\tID=$arr[0]$a.1:exon:$i;Parent=$arr[0]$a.1\n";

            $curr_pos = $curr_pos + $cign[$i];
            $i++;


        }
        elsif ($op=~/N/) {

            $curr_pos = $curr_pos + $cign[$i];
            $i++;

        }
        else {
            "Weird cigar:$cigar:\n";
        }

    }




$a++;

}



