#!/usr/local/bin/perl -w
#
#
use strict;



unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: TF_strip.pl file interpro_annotation

Takes a file with InterPro IDs and adds annotation



'
}


# Read in file

my $file= shift;
open(IN, "<$file") or die "$!";
open(OUT, ">$file.TFs") or die "$!";

my %h;


while (<IN>) {
    chomp;

    my @arr = split(/\t/, $_);
    my $gene = shift(@arr);
    my $ipr = $arr[1] . "\t". $arr[2];
    $ipr=~s/-/\t/g;
    $ipr=~s/,/\t/g;
    $ipr=~s/-/\t/g;
    $gene=~s/\.\.pep//g;
    $gene=~s/\|3//g;
    $gene=~s/\|5//g;

    #print "$gene\t$ipr\n";
    my @arr2 = split(/\t/, $ipr);

    foreach my $ele (@arr2){
        $h{$gene}{$ele}=1;
        #print "$gene\t$ele\n";
    }
}


# parse interpro

my %h2;

my $file2= shift;
open(IN2, "<$file2") or die "$!";

while (<IN2>) {
    chomp;
    $_=~s/ /\t/;
    my @arr = split(/\t/, $_);

    if (scalar(@arr)> 1) {
        #print "$arr[0]\t$arr[1]\n";


        foreach my $key (keys %h) {
            foreach my $key2 (keys %{$h{$key}}) {
                if ($arr[0]=~/$key2/) {
                    $arr[1]=~s/\,//g;
                    $h{$key}{$key2}= $arr[1];
                    #print "$key\t$key2\t$arr[1]\n";
                }
            }
            
        }
    }
}


# make output

foreach my $key (keys %h) {

        print OUT "$key\t";
        my @id;
        my @desc;

    foreach my $key2 (sort keys %{$h{$key}}) {
            push(@id, $key2);
            push(@desc, $h{$key}{$key2});
    }
    my $id = join(",",@id);
    my $desc = join(",",@desc);
    print OUT "$id\t$desc\n";
}

close (OUT);
exit;


