#!/usr/local/bin/perl -w

use strict;

unless (@ARGV > 0 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl gff_and_fasta_subset.pl file.fas file.gff flanking 

Takes a fasta and a gff-file, and merges them, and gives them new coordinates


'


}

my $fas = shift;
my $gff = shift;
my $flank = shift;


=pod
# Read in fasta and make a new merged fasta


system "cat $fas | grep -v '>' > $fas.temp ";

open (IN, "<$fas.temp") or die "Cant find $fas.temp\n" ;
my @in = <IN>;
open (OUT, ">$fas.temp2") or die "Cant find $fas.temp2\n" ;


print OUT ">$prefix\n";
print OUT @in;

system "/nfs/pathogen005/mz3/mh12/python/fasta2multiline.py $fas.temp2 $fas.m.fas 300";
system "rm -f $fas.temp $fas.temp2 ";


=cut


# Make a faidx
system "samtools faidx $fas";

open (FAI, "<$fas.fai") or die "Cant find $fas.fai\n" ;


# Read in the faidx


my @farr;

while (<FAI>) {
    my @arr = split(/\s+/, $_);
#    my @arh = split(/\:/, $arr[0]);   
     push (@farr, "$arr[0]\t$arr[1]"  );
#    print "$arr[0]\t$arr[1]\n";
}


# Read in gff

my %gash;



open (GFF, "<$gff") or die "Cant find $gff\n" ;

while (<GFF>) {
    chomp $_;

    my @arf = split(/\s+/, $_);
    push ( @{$gash{$arf[0]}}, $_ );
#    print "GFF:$arf[0]:\n";

}


# Adjust gff-coords

my $newcord = "0";

my @new_scaf;

open (OG, ">$gff.new.gff") or die "Cant find $gff.new.gff\n" ;

foreach my $line (@farr){

#    print "New scaffold:$line:\n";
    my @ar3 = split(/\s+/, $line);
#    my @ar4=split(/\(/, $ar3[2]);
#    my @ar5=split(/-/, $ar4[0]);

#    my $adj = $ar3[1] - $flank;

#    print "FAIDX:$ar3[0]\t$ar3[1]\n";


# If this gene exists on a known scaffold

    if (exists $gash{$ar3[0]}) {

#        print "This scaffold has genes\n"; 
        my $genst;
        my $sst;
        my $new_start;
        my $new_end;
        my $sstart;
        my $send;

        foreach my $elem (  @{$gash{$ar3[0]}} ) {

#            print "$elem\n";
            my @gf = split(/\t/, $elem );


#   if this is a gene on a new scaffold         
            if ( $gf[2]=~/gene/) {
#                print "Line $elem is a gene\n";


                    $sstart = $gf[3]-$flank;
                    $send= $gf[4]+$flank;
                # check that start is not before start

                    $genst =  $flank - $gf[3] ;
                    $new_start =  $flank  ;
                    $new_end = $flank + ( $gf[4] - $gf[3] )  ;

# if gene starts before flanking region                
                if ($flank > $gf[3]  ) {
                
                    print "WARN: gene $gf[8] is shorter than $flank\n :$elem: \n";
                    $genst = "0";
                    $new_start =  $gf[3]  ;
                    $new_end = $gf[3] + ( $gf[4] - $gf[3] )  ;
                    $sstart = "0"  ;
                }

# if gene and flanking region is longer than scaffold

                if ( $gf[4] + $flank > $ar3[1] ) {
                    print "WARN: scaffold $ar3[0] length $ar3[1] is shorter than gene $gf[8] and flank $flank\n :$elem: \n";

                    $genst =  $flank - $gf[3] ;
#                    $new_end =  $ar3[1] ;
                    $send= $ar3[1] ;

                }

#                    $genst =  $flank - $gf[3] ;
#                    $new_start =  $flank  ;
#                    $new_end = $flank + ( $gf[4] - $gf[3] )  ;


#            my $start = ($new_start , $new_end )[$new_start  > $new_end ];
#            my $end = ($new_start , $new_end )[$new_start  < $new_end ];

#                push ( @gf, $gf[3] ) ;
#                push ( @gf, $gf[4] ) ;

#                my $sstart = $gf[3]-$flank;
#                my $send= $gf[4]+$flank;

                $sst = $gf[0] . "-$sstart-$send";
                push(@new_scaf, $sst);

                $gf[0] = $sst   ;
                $gf[3] = $new_start   ;
                $gf[4] = $new_end  ;
            }
# if it is a part belonging to that gene            
            else {

                my $new_start =  $genst +  $gf[3]  ;
                my $new_end = $new_start  + ( $gf[4] - $gf[3] )  ;
#                push ( @gf, $gf[3] ) ;
#                push ( @gf, $gf[4] ) ;
                $gf[0] = $sst   ;
                $gf[3] = $new_start   ;
                $gf[4] = $new_end  ;

            }


#            $gf[3] = "0";
#            $gf[4] = "0";

            print OG join("\t", @gf) . "\n";

        }
    }
    else {
#        print "Not exists\n";

    }

    $newcord = $newcord + $ar3[1];

#    print "New:$newcord:\n";
}



# make contigs-file
open (O2, ">$gff.cho") or die "Cant find $gff.cho\n" ;

foreach my $key ( @new_scaf ) {

 my @arl =  split (/-/, $key);

 print O2 "$arl[0]\t$arl[1]\t$arl[2]\n";
# print "$arl[0]\t$arl[1]\t$arl[2]\n";
}


system "perl ~/bin/perl/fasta_subset_from_coords.pl $fas $gff.cho $flank";




exit;









