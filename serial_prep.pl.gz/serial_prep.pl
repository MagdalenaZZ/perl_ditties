#!/usr/bin/perl -w


use strict;




# BLAST uniprot - tab output

/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=5 --splitmem=10 --protein_ref /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/annotation/head.test.fas /lustre/scratch103/sanger/mz3/gene_pred/uniprot90/uniref90.fasta tes 200000 -D 3 -m 8 -v 5 -p blastp

/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=5 --splitmem=10 --protein_ref /lustre/scratch103/sanger/mz3/gene_pred/EMUv3/augustus/refine_genes/step15_product_calls/all.fasta /lustre/scratch103/sanger/mz3/gene_pred/uniprot90/uniref90.fasta test 200000 -D 3 -m 8 -v 5 -p blastp


# Make an OrthoMCL run

# team133-bsub.pl basement 25 omcl.o omcl.e omcl orthomcl_chado -fasta=EMUopti_ap.aa.fa,EMUopti_ap_my.final.aa.fa -dataset=fake -dev

team133-bsub.pl normal 10 omcl.o omcl.e omcl orthomcl.pl --mode 1 --fa_files EmW.fa,uniref90.fa

# Make a BLAST-run
# orthomcl.pl --mode 3 --blast_file AtCeHs_blast.out --gg_file AtCeHs.gg


# run blast-splitter in output tabular format
/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=2 --splitmem=10 --megablast  /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/annotation/augs369.o.aa /lustre/scratch101/sanger/mz3/gene_pred/uniprot90/uniref90.fasta testaa8222 500000 -D 3 -p 0 -m 8



__END__

serial.pl -b all.blast -a blast_ann_new.txt -o  all_orthomcl.out -t target.txt -q right.final -f right.final.aa

serial.pl -k -b -a -o -t -q -f 

 -b Etenella_uniproteuk.blast -a uniprot.ann -o all_orthomcl.out -t T_gondii.ann -q Etenella -f Etenella_cds.fa 

	"h|help"		=> \$help,

	"k|known:s"		=> \$known,

Supercontig_2.51	 40S ribosomal protein S3a 
Supercontig_38.13	 Heat shock protein 90 
Supercontig_4.94	 Pyruvate kinase 
Supercontig_18.63	 14-3-3 protein 
Supercontig_4.32	 Sporulated oocyst TA4 antigen 
Supercontig_316.1	 Sporozoite antigen 
Supercontig_54.17	 Sporozoite developmental protein 

	"b|blast:s"		=> \$blast_hits,
NODE_10042_length_3761_cov_10.726402.1	B9QDW2.1	45.19	104	52	1	19	122	315	413	1e-11	70.9
NODE_10042_length_3761_cov_10.726402.1	B9PTV4.1	45.19	104	52	1	19	122	315	413	1e-11	70.9
NODE_10042_length_3761_cov_10.726402.1	B6KKF6.1	45.19	104	52	1	19	122	315	413	1e-11	70.9
NODE_10042_length_3761_cov_10.726402.1	Q7RPC5.1	37.14	105	59	2	19	122	115	213	3e-06	53.1


	"a|blast_ann:s"		=> \$blast_hits_ann,
Q9V2L2.1	Putative 1-aminocyclopropane-1-carboxylate deaminase (EC 3.5.99.7)
Q8U4R3.2	Putative 1-aminocyclopropane-1-carboxylate deaminase (EC 3.5.99.7)
O57809.2	Putative 1-aminocyclopropane-1-carboxylate deaminase (EC 3.5.99.7)
Q9Y9P1.1	Putative 3-methyladenine DNA glycosylase (EC 3.2.2.-)
A3CTY6.1	Putative 3-methyladenine DNA glycosylase (EC 3.2.2.-)
Q0W5C8.1	Putative 3-methyladenine DNA glycosylase (EC 3.2.2.-)


	"o|ortho:s"		=> \$orthomcl_run,
ORTHOMCL1(58 genes,1 taxa):	 Supercontig_25.17(Etenella) Supercontig_25.18(Etenella) Supercontig_26.20(Etenella) Supercontig_29.10(Etenella) Supercontig_29.11(Etenella) Supercontig_29.12(Etenella) Supercontig_29.13(Etenella) Supercontig_29.15(Etenella) Supercontig_29.16(Etenella) Supercontig_29.17(Etenella) Supercontig_29.18(Etenella) Supercontig_29.19(Etenella) Supercontig_29.20(Etenella) Supercontig_29.21(Etenella) Supercontig_29.22(Etenella) Supercontig_29.23(Etenella) Supercontig_29.24(Etenella) Supercontig_29.25(Etenella) Supercontig_29.26(Etenella) Supercontig_29.27(Etenella) Supercontig_29.28(Etenella) Supercontig_29.29(Etenella) Supercontig_29.30(Etenella) Supercontig_29.31(Etenella) Supercontig_29.32(Etenella) Supercontig_29.33(Etenella) Supercontig_29.34(Etenella) Supercontig_29.35(Etenella) Supercontig_29.36(Etenella) Supercontig_29.6(Etenella) Supercontig_29.7(Etenella) Supercontig_29.8(Etenella) Supercontig_4.11(Etenella) Supercontig_4.12(Etenella) Supercontig_4.13(Etenella) Supercontig_4.14(Etenella) Supercontig_4.15(Etenella) Supercontig_4.16(Etenella) Supercontig_4.17(Etenella) Supercontig_4.18(Etenella) Supercontig_4.19(Etenella) Supercontig_4.20(Etenella) Supercontig_4.21(Etenella) Supercontig_4.22(Etenella) Supercontig_4.23(Etenella) Supercontig_4.24(Etenella) Supercontig_4.32(Etenella) Supercontig_4.33(Etenella) Supercontig_4.34(Etenella) Supercontig_4.35(Etenella) Supercontig_4.36(Etenella) Supercontig_4.37(Etenella) Supercontig_4.38(Etenella) Supercontig_4.39(Etenella) Supercontig_412.1(Etenella) Supercontig_412.2(Etenella) Supercontig_66.28(Etenella) Supercontig_921.1(Etenella)

	"t|target:s"		=> \$target_ann,
gb|TGME49_103850	hypothetical protein, conserved 
gb|TGME49_103550	hypothetical protein 
gb|TGME49_001100	hypothetical protein 
gb|TGME49_001400	hypothetical protein 
gb|TGME49_001770	cullin 3, putative 
gb|TGME49_002600	hypothetical protein 
gb|TGME49_002840	zinc finger (C3HC4 type) / FHA domain-containing protein 
gb|TGME49_002940	hypothetical protein 

	"q|query:s"		=> \$query,
Etenella

	"f|query_fasta:s"	=> \$query_fasta
>Supercontig_0.1 Supercontig_0.1 undefined product 492:2238 reverse MW:21406
MPATAGWVRMPQSNRVAVSASLRTHAIWTDSVGYDPYAPSSSSSSSSSSSSSAEDPLKDK
AKELLTLARLTGTLSTHTPGACTKCNQVGHLAFQCRNDFRFAEEEKTRALSAALKQKEEE
EDDERLRRALGIGSDDEGPQRAPVKRRRSSSSSSSSSSSSDDEDERRKKKKKKSKRRKEK
KSKHKSHKKKRSH
>Supercontig_0.2 Supercontig_0.2 undefined product 3988:5133 reverse MW:25945
MSKAFAARLLKTDGCRSKPFHSPFAAAVLKKFGWTERPRYSARGVVQQQRKETQEETDDE
DTSAASSKKAKKQQQQQQQQQQQCLIEEEAGPQQIKSKKRKRRKRESEVEDTEDPAAAAA
AAAADAAAQEDAAADAAADAAAADAAADDVRPKKTKKKKKHRQQQEEEEQQQQEQQQQQQ
EEESQVAESEEAAAKRRKKEKKRLARLAAQQQQEGHAAVAAAAAADAADAAATAADL



serial.pl -k -b -a -o -t -q -f 