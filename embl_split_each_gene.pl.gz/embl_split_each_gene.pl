#!/usr/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/embl_split.pl input


Input needs to be an embl-file with sequences delimited by //


'
}

my $in = shift;

#system "cat $in | grep -w -i -e ID -e FH -e FT -e SQ > $in.all";
open (IN, "<$in") || die "I can't open $in\n";

my @list = <IN>;

open (OUT, ">tmp") || die "I can't open tmp\n";

# $\ = "ID";
#
my $id = shift(@list);
my $id2 = shift(@list);
my $id3 = shift(@list);

#print "$id$id2$id3";


#__END__


my $gene = 1;

foreach my $elem (@list) {

	unless ($elem=~/^FT   CDS/) {
	print OUT "$elem";
	}
	if ($elem=~/^FT   CDS/) {
        print OUT "\/\/\n";
		close (OUT);
		my @arr = split(/\s+/, $elem);
#		print "Arr1: $arr[1]\n";
#		my $length =length($arr[1]);
#		print "Length:  $length\n";
#		my $arr2 = $arr[1];
#		chomp $arr2;
		$arr[1]	=~ s/;//;
#		print "Arr2: $arr[1]\n";
		open (OUT, ">gene_$gene.embl") || die "I can't open gene_$gene.embl\n";
        print OUT "$id$id2$id3";
        print OUT "$elem";
        $gene++;
	
	}

}

close (IN);

system "rm -f tmp";
