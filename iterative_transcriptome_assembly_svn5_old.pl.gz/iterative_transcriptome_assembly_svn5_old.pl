#!/usr/bin/perl -w

use strict;
use Getopt::Std;



unless (@ARGV > 0) {
        &USAGE;
}

my $help = join(@ARGV); 




if ( $help =~/--h/ or $help =~/-help/ ) { 
        &USAGE;
}


my %opt;

push (@ARGV, " ");
push (@ARGV, " ");
push (@ARGV, " ");

foreach my $elem (@ARGV) {
    my $arg1 = shift(@ARGV);
    my $arg2 = shift(@ARGV);
    $opt{$arg1} = "$arg2";
    }



sub USAGE {

    die '


Usage: iterative_transcriptome_assembly.pl   [options]

Insert velveth and velvetg options, and a list of files:

 --vh :  velveth options, kmer first, no options to do with files or file-format
 --vg :  velvetg options, same options you would insert to velvetg i.e.   "-ins_length 383 -unused_reads yes -min_contig_lgth 200 -clean yes -read_trkg yes  -exp_cov 9999999"
 --vo :  oases options, same options you would insert to oases i.e.   "-ins_length 383 -unused_reads yes -min_trans_lgth 200  -scaffolding yes"


  --m :  mapping options
  --f : file containing velveth-style file-format specification and read-files 
  --i : initial assembly, full-length DNA-transcripts in fasta-format (optional), i.e. "file.fasta"

FILE FORMAT SPECIFICATION FILE:
-fastq.gz  -interleaved -shortPaired interleaved_reads.fastq.gz
-fastq  -separate -shortPaired reads_1.fastq reads_2.fastq
-fasta  -separate -shortPaired Reads_1.fasta Reads_2.fasta

The program will iterate over each line in this file, and assemble reads that do not map to previous assemblies
Obviously, for each line, only provide one or two read-files

 
  --h :  this help


  Assembly kmer 23
  Mergning kmer 25


    
    ' . "\n";
}


#####_####_####_####_####_####_####_#####

# Get help


if ($opt{"--h"}) {
    &USAGE;
}

#####_####_####_####_####_####_####_#####
print "\n";

# make sure there is a file
my $f;
my @inf;

if ($opt{"--f"}) {
    # print $opt{"--f"} . "\n";
    VALIDATEF();
} else {
	print "\nPlease give me files and formats in velvet-style format i.e.  --f \"  -fastq  -shortPaired reads.fastq \" \n";
    &USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEF {
    # sub validate checks that there is an inputfile, and reads it
	$f = $opt{"--f"};
    open (IN, "<$f") || die "I can't open $f\n";
	print "Read in file: $f\n";
    @inf = <IN>;
    close (IN);
}

#####_####_####_####_####_####_####_#####

# make sure there is velveth-options
my $vh;
my $kmer;

if ($opt{"--vh"}) {
    VALIDATEVH();
} else {
	print "\nPlease give me velveth commands i.e. --vh \"57\" \nYou have to at least give the kmer size as an integer\n";
    &USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEVH {
    # sub validate checks that there is an inputfile, and reads it

	$vh = $opt{"--vh"};
	print "Velveth options: $vh\n";
    my @arr = split(/\s+/ ,$vh);
    $kmer = $arr[0];
    unless ($arr[0]=~/^\d+$/) {
	    print "\nYour velveth command has to start with the kmer size in integer form  i.e. --vh \"57\"\n";
        die;
    }
}

#####_####_####_####_####_####_####_#####

# make sure there is velvetg-options
my $vg;

if ($opt{"--vg"}) {
    VALIDATEVG();
} else {
	print "\nPlease give me velvetg commands i.e.  --vg \" \"   \n";
    &USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEVG {
    # sub validate checks that there is input
    
	$vg = $opt{"--vg"};
	print "Velvetg options: $vg\n";

}


#####_####_####_####_####_####_####_#####

# make sure there is velvetg-options
my $vo;

if ($opt{"--vo"}) {
    VALIDATEVO();
} else {
	print "\nPlease give me oases commands i.e.  --vo \" \"   \n";
    &USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEVO {
    # sub validate checks that there is input

	$vo = $opt{"--vo"};
	print "Oases options: $vo\n";

}



#####_####_####_####_####_####_####_#####

# make sure there is mapping-options
my $m = " ";

if ($opt{"--m"}) {
    VALIDATEM();
} else {
	print "\nMapping options:  \n";
    #&USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEM {

    # sub validate checks that there is an inputfile, and reads it
	$m = $opt{"--m"};
	print "Mapping options: $m\n";

}


#####_####_####_####_####_####_####_#####

# check if there is an initial fasta
my $initial = '';

if ($opt{"--i"}) {
    VALIDATEI();
} else {
	print "\nInitial file:  \n";
    #&USAGE;
}

#####_####_####_####_####_####_####_#####

sub VALIDATEI {

    # sub validate checks if there is an inputfile
	$initial = $opt{"--i"};
	print "Initial assembly: $initial\n";

}


#####_####_####_####_####_####_####_#####
print "\n";


# Make a random number
my $rand = substr( rand, 2, 5);
# Make a folder of assemblies
mkdir "Assemblies.$rand";


print "This program will now assemble each pair of fasta-files in the library-file separately, taking into account the sequences already assembled/provided\nAfter that, it will do a range of kmer assemblies with the previously unassembled reads. These assemblies will start from (your original kmer + 10) to 19\n\n";

#####_####_####_####_####_####_####
# start loop

my $first = 0;
my $index = 1;


# check if there is an initial file 
if ( -s "$initial" ) {
    $first = 2;
    $index = 0;
}



open (FH, ">$rand.sh");
print "Writing commands to $rand.sh\n";

foreach my $file (@inf) {
    #print "FILE:$file\n";
    unless ($file=~/\w+/) {
        next;
    }

#####_####_####_####_####_####_####_##### 
    # try if this is the first assembly, and no leads
    if ($first =~/0/) {

        print FH "#\n##### Making first assembly... #####\n";

        print  FH "velveth $rand\_$index $vh $file\n";
        print  FH "velvetg $rand\_$index $vg -read_trkg yes\n";
        print  FH "oases $rand\_$index $vo\n";

        # check if the assembly has been done, or die
        print FH "if [ -s $rand\_$index/transcripts.fa ];then  echo \"Cool Beans\";\nelse\n\t";
        print FH "echo \"Failed to make file $rand\_$index/transcripts.fa\"\n\texit 1\nfi\n";

        $first = 1;
    }
#####_####_####_####_####_####_####_#####
    #Make subsequent assemblies
    else {
        


        # Make a joined fasta of assemblies
        ## ...Or use provided infiles
        if ($first == 2) {
           print  FH "cat $initial > Assemblies.$rand.fa\n"; 
        }
        else {


                    # Link from first assembly to assembly-folder
            print  FH "cd Assemblies.$rand\n";
            print  FH "ln -s ../$rand\_$index/transcripts.fa $rand\_$index.transcripts.fa\n";
            print  FH "cd ..\n";
            print  FH "cat Assemblies.$rand/*.fa > Assemblies.$rand.fa\n";
        }
        

#####_####_####_####_##

## Map next all
        print  FH "\n##### Mapping $index #####\n";

        # pick out the files to map
        my @files = split(/\s+/,$file);
        my @final_file;

        foreach my $file (@files) {
            #print "File: $file\n";

            if ($file =~/^-/ or $file!~/\w+/) {
                #print "not file: $file\n";
            }
            else {
                ##print "Real file $file\n";
                push (@final_file, $file);
            }

        }


        my $fill = join(" ", @final_file);

        my $len = scalar(@final_file);

        #print "\n Length $len\t$final_file[0]\t$final_file[1]\n";
        ## make index
        print FH "bowtie2-build Assemblies.$rand.fa Assemblies.$rand \n";
        ## print "Length length(@final_file)\n";
        if ( scalar(@final_file) == 2 ) {
            #print "\nLength is two: length $len\t$final_file[0]\t$final_file[1]\n";
            print FH "bowtie2 $m -x Assemblies.$rand -X 1000 -1 $final_file[0] -2 $final_file[1] --un-conc unmapped.$rand.$index.fastq  >  mapped.$rand.$index.sam \n";
        }
        elsif ( scalar(@final_file) == 1 ) {
            #print "\nLength is one: length $len\t$fill\n";

            if ($fill=~/\.gz$/) {
                $fill =~s/\.gz//;
                print FH "##### zipped $fill  #####\n";
                print FH "gunzip -c $fill.gz  > $fill\n";
            }
            print FH "##### unpaired file $fill #####\n";
            print FH "perl /nfs/users/nfs_t/tdo/Bin/join.solexaBack.actual.sga.pl $fill $fill\n";
            print FH "bowtie2 $m -x Assemblies.$rand -X 1000 -1 $fill\_1.fastq -2 $fill\_2.fastq  --un-conc unmapped.$rand.$index.fastq  >  mapped.$rand.$index.sam \n";
            my $tmp = $fill . "SE.fastq";
            print FH "rm -f $tmp\n";
            print FH "rm -f $fill\_1.fastq $fill\_2.fastq\n ";
            print FH "rm -f *$rand*bt2\n"; 
        }
        elsif ( scalar(@final_file) == 0 ) {
            print "No inputfile in line $f, please change your file $f\n";
            die;
        }
        else {
            print "\n You have more than two input files in one line of your file $f, please separate them to different lines, and restart\n";
            die;
        }

        print FH "rm -f mapped.$rand.$index.sam\n";

        
 #####_####_####_####_##


## now assemble the next one
        my $i = $index;
        $index++;

        print  FH "\n##### Making $index assembly... #####\n";
        
        if ($m =~/-f/) {
            #print  FH "velveth $rand\_$index $vh -fastq -shortPaired -separate unmapped.$rand.$i.1.fastq unmapped.$rand.$i.2.fastq -short -fasta $rand\_$i/UnusedReads.fa \n";
            print  FH "velveth $rand\_$index $vh -fasta -shortPaired -separate unmapped.$rand.$i.1.fastq unmapped.$rand.$i.2.fastq -long  -fasta Assemblies.$rand.fa \n";
            #print  FH "velveth $rand\_$index $vh -fastq -shortPaired -separate unmapped.$rand.$i.1.fastq unmapped.$rand.$i.2.fastq \n";
            #print "IF\n velveth $rand\_$index $vh -fasta -shortPaired -separate unmapped.$rand.$i.1.fastq unmapped.$rand.$i.2.fastq -long  -fasta Assemblies.$rand.fa \n";
        }
        else {
            print  FH "velveth $rand\_$index $vh -fastq -shortPaired -separate unmapped.$rand.$i.1.fastq unmapped.$rand.$i.2.fastq -long  -fasta Assemblies.$rand.fa \n";
            #print "ELSE\n";
        }
        print  FH "velvetg $rand\_$index  $vg -read_trkg yes -unused_reads yes\n";
        print  FH "oases $rand\_$index $vo\n";

        # check if the assembly has been done, or die
        print FH "if [ -s $rand\_$index/transcripts.fa ];then  echo \"Cool Beans\";\nelse\n\t";
        print FH "echo \"Failed to make file $rand\_$index\"\n\texit 1\nfi\n";

    
    }

}


#####_####_####_##### FIX LAST #####_####_####_####_##



## Link from last assembly to assembly-folder

print  FH "\n##### Making last assembly formatting... #####\n";

print  FH "cd Assemblies.$rand\n";
print  FH "ln -s ../$rand\_$index/transcripts.fa $rand\_$index.transcripts.fa\n";
print  FH "cd ..\n";

## Make a joined list of assemblies

print  FH "cat Assemblies.$rand/*.fa > Assemblies.$rand.fa\n";


#####_####_####_####_####_####_####_#####

## Final assembly of unused reads

# Map all unused reads to the result
print  FH "\n##### Final mapping of unused reads... #####\n";

## make index
print FH "bowtie2-build Assemblies.$rand.fa Assemblies.$rand \n";
print FH "cat $rand*/UnusedReads.fa > $rand.UnusedReads.fa\n";
print FH "bowtie2 -x Assemblies.$rand -f -s -U $rand.UnusedReads.fa --un unmapped.$rand.$index.sam >  mapped.$rand.$index.sam\n";
print FH "cat unmapped.$rand.$index.sam |  sed 's/:UU/:UU\\n/g' |  awk '{print \">\"\$1\"\\n\"\$10}'  > unmapped.$rand.$index.fa \n";

## Final assembly of unused reads

print  FH "\n##### Final assemblies with lower kmers... #####\n";

print FH " velveth $rand.prep 31 -noHash -create_binary -fasta  unmapped.$rand.$index.fa  \n";

#my @veh = split(/\s+/,$vh);

$kmer += 10;


for ( ; $kmer > 19 ; $kmer=$kmer-2) {
    $index++;

    print FH "mkdir $rand\_$index\n";
    print FH "cd $rand\_$index\n";
    print FH "ln -s ../$rand.prep/CnyUnifiedSeq \n";
    print FH "ln -s ../$rand.prep/CnyUnifiedSeq.names \n";
    print FH "cd ..\n";

    print  FH "velveth $rand\_$index $kmer -reuse_Sequences -create_binary -long -fasta Assemblies.$rand.fa\n";
    print  FH "velvetg $rand\_$index $vg -read_trkg yes -unused_reads yes\n";
    print  FH "oases $rand\_$index $vo\n";

    ## Link from the assembly to assembly-folder
    
    # check if the assembly has been done, or die
    print FH "if [ -s $rand\_$index/transcripts.fa ];then  echo \"Cool Beans\";\nelse\n\t";
    print FH "echo \"Failed to make file $rand\_$index/transcripts.fa\"\n\texit 1\nfi\n";

    print  FH "cd Assemblies.$rand\n";
    print  FH "ln -s ../$rand\_$index/transcripts.fa $rand\_$index.transcripts.fa\n";
    print  FH "cd ..\n"; 

}

#####_####_####_####_####_####_####_#####

print FH "\n##### Cleanup #####\n";
print FH "rm -f *$rand*bt2 unmapped.$rand*\n";


#####_####_####_####_####_####_####_#####

## Make merge and oases
print  FH "\n##### Making final merging and Oases... #####\n";

print FH "velveth $rand.MergedAssembly27 27 -long -fasta Assemblies.$rand/*transcripts.fa\n";
print FH "velvetg $rand.MergedAssembly27 -read_trkg yes -conserveLong yes \n";

# do oases
print FH "oases $rand.MergedAssembly27 -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes \n";

#####_####_####_####_####_####_####_#####



close(FH);


exit;


__END__
sh 37491.sh &
sh 51098.sh &


sh  40281.sh &
sh 91689.sh &
sh 48239.sh &


sh 13702.sh &
sh 95733.sh &
sh 27219.sh &

velveth 37491.MergedAssembly57 57 -long Assemblies.37491/*transcripts.fa
velvetg 37491.MergedAssembly57 -read_trkg yes -conserveLong yes
oases 37491.MergedAssembly57 -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes



54505.sh - testing with inserting long reads back
