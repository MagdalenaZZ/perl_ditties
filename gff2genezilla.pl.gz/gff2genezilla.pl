#!/usr/bin/perl -w
# mz3 script 


use strict;


unless (@ARGV > 0 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl gff2genezilla.pl gff-file 




'
}


my $in = shift;
my $out = $in . ".gfz";

open (IN, "<$in") or die "Cant find infile $in\n" ;

my @in=<IN>;

#=pod
if (-e "$out") {
    die "File $out already exists, cant overwrite\n";
}
else {
    print "outfile $out\n\n";
}
#=cut

open (OUT, ">$out") or die "Cant find infile $out\n" ;


my %seen;
#my $last;
my @res;
my $counter = 0;
my $first=0;
push(@in,"gene\tgene\tgene\tgene\tgene\tgene");

foreach my $el (@in) {
	chomp $el;
    #tr/=/ /;

	my @line = split (/\s+/, $el);

    if ($line[2]=~/exon/) {
        # ignore;
        #next;
    

	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $note = $line[8];
    #my $note2 = $line[11];

	$note =~ s/"//g;
	$note =~ s/;//g;
    $note =~ s/ID=//g;
	my @arr = split (/\:/, $note);
    $line[8]= "transcript_id=" . $arr[0];
    #$note2 =~ s/"//g;
    #$note2 =~ s/;//g;

    #my $gene = $note;
    #my $trans = $note2;

    #print "$note\t$arr[0]\n";

        if (exists $seen{$arr[0]}) {
            # this gene has been seen before
            $line[2]="internal-exon";
            my $newline = join("\t",@line);
            push (@res, $newline);
        }
        else {
            $line[2]="initial-exon";
            $seen{$arr[0]}=1;
            #print "Declaring $arr[0]\n";
            my $newline = join("\t",@line);
            push (@res, $newline);
            #$newline=$last;
        }

    $counter++;

    }

    # catch last exon
    elsif ($line[2]=~/gene/) {
        

#=pod        
        if ($first=~/1/) {
#=cut

            my $newline = pop(@res);

            my @nline = split (/\t/, $newline);

            #print "Gene\n$newline\n";

            if ($nline[2]=~/initial-exon/) {
                # make single-exon gene
                $nline[2]="single-exon";
                $newline =  join("\t",@nline);
                push (@res, $newline);

            }
            elsif ($nline[2]=~/internal-exon/) {
                # make final exon
                $nline[2]="final-exon";
                $newline =  join("\t",@nline);
                push (@res, $newline);


            }
            else {
                print "Warning! unexpected gff-format\n";
            }

        }
        else {
            # skip first line
            print "Skipped line $el\n";
            $first=1;
            next;

        }



    }



}

# fix last element







foreach my $ele (@res) {
    print OUT "$ele\n";
}
   
print "Exon count: $counter\n\n";
close (IN);
close (OUT);

