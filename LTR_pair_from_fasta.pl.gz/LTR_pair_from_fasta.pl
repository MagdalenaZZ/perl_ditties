#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: LTR_pair_from_fasta.pl fasta_with_LTRs.fas

Takes a gff-file fasta-file with LTRs, and matches together the 3 and 5 LTRs



# make sure the fasta is single-line


NOT FINISHED!!!!



'
}


	my $in = shift;
	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;

#	open (OUT, ">$in.fas") || die "I can't open $in.fas\n";


my %ins;

while (<IN>) {

    if ($_=~/^>\w+/) {
        my $head = $_;
        my $seq = <IN>;
        chomp $head;
        chomp $seq;

        my @head =split(/\:/, $head);
        #print "$head[0]\n";

        if ($head=~/5LTR/) {
            $ins{$head[0]}{"5LTR"}= "$head\n$seq\n";
        }
        elsif ($head=~/3LTR/) {
            $ins{$head[0]}{"3LTR"}= "$head\n$seq\n";
        }

    }

}


my @files;

foreach my $key (keys %ins) {

    my $len = scalar(keys $ins{$key});

    print "$key\t$len\n";

    if ($len==2) {
    
        my $fi = $key;
        $fi =~s/\>ID=//;
        $fi =~s/\>//;
        $fi = $fi . ".fas";
        push (@files, $fi);
        open (FI, ">$fi") || die "Cant open file $fi\n";

        #print "opening file $fi\n";
        print FI $ins{$key}{"5LTR"};
        print FI $ins{$key}{"3LTR"};

        close (FI);

        #system "perl ~/bin/perl/phylogenize_me.pl $fi nuc aln";
        #print "perl ~/bin/perl/phylogenize_me.pl $fi nuc aln\n";
        system "muscle -in $fi -out $fi.mfa";
    }

}



close (IN);



print "\n\n\n";
# read in the aligned fasta file


open (OUT, ">$in.out") || die "I can't open $in.out\n";

print OUT  "Pair\tLength\tmatch\tIndels\tAtoC\tAtoG\tAtoT\tCtoA\tCtoG\tCtoT\tGtoA\tGtoC\tGtoT\tTtoA\tTtoC\tTtoG\n";



foreach my $fas (@files) {

    system "fasta2singleLine.py $fas.mfa $fas.mfa.sl";
    open (FAS, "<$fas.mfa.sl") || die "I can't open $fas.mfa.sl\n";
    my  @fas = <FAS>;
    close (FAS);
    chomp @fas;
    system "rm -f  $fas.mfa $fas.fixed $fas.fixed.key ";

# call consensus and count up mismatches

    my $indel = 0;
    my $atoc = 0;
    my $atog = 0;
    my $atot = 0;
    my $ctoa = 0;
    my $ctog = 0;
    my $ctot = 0;
    my $gtoa = 0;
    my $gtoc = 0;
    my $gtot = 0;
    my $ttoa = 0;
    my $ttoc = 0;
    my $ttog = 0;
    my $match = 0;
    my $countindel=0;

    my @first = split(//,$fas[1]);
    my @second = split(//,$fas[3]);

    my $len = scalar(@first);
    for (my $i = 0; $i < $len; $i++) {
        #print "$first[$i]\n";
        #print "$second[$i]\n";

        # if there is a match
        if ( $first[$i]=~/\-/i or $second[$i]=~/\-/i) {
            $countindel++;
            #print "Found an indel $first[$i]  $second[$i]\n";
        }
        
        
        else {
        
            if ($countindel > 0) {
                $indel++;
                #print "Indel length $countindel\n";
                $countindel=0;
            }

            
            if ($first[$i]=~/$second[$i]/) {
                $match++;
            }
            elsif ( $first[$i]=~/a/i and $second[$i]=~/c/i) {
                $atoc++;
                #print "$first[$i] to $second[$i] is a to c \n";
            }
            elsif ( $first[$i]=~/a/i and $second[$i]=~/g/i) {
                $atog++;
            }
            elsif ( $first[$i]=~/a/i and $second[$i]=~/t/i) {
                $atot++;
            }
            elsif ( $first[$i]=~/c/i and $second[$i]=~/a/i) {
                $ctoa++;
                #print "$first[$i] to $second[$i] is c to a \n";
            }
            elsif ( $first[$i]=~/c/i and $second[$i]=~/g/i) {
                $ctog++;
            }
            elsif ( $first[$i]=~/c/i and $second[$i]=~/t/i) {
                $ctot++;
            }
            elsif ( $first[$i]=~/g/i and $second[$i]=~/a/i) {
                $gtoa++;
            }
            elsif ( $first[$i]=~/g/i and $second[$i]=~/c/i) {
                $gtoc++;
            }
            elsif ( $first[$i]=~/g/i and $second[$i]=~/t/i) {
                $gtot++;
            }
            elsif ( $first[$i]=~/t/i and $second[$i]=~/a/i) {
                $ttoa++;
            }
            elsif ( $first[$i]=~/t/i and $second[$i]=~/c/i) {
                $ttoc++;
            }
            elsif ( $first[$i]=~/t/i and $second[$i]=~/g/i) {
                $ttog++;
            }

            else {
                print "DUNNO $first[$i]\t$second[$i]\n";
            }

        }



    }

    if ($countindel > 0) {
        $indel++;
        #print "Indel length $countindel\n";
        $countindel=0;
    }

    $fas=~s/\.fas//;

    print OUT "$fas\t$len\t$match\t$indel\t$atoc\t$atog\t$atot\t$ctoa\t$ctog\t$ctot\t$gtoa\t$gtoc\t$gtot\t$ttoa\t$ttoc\t$ttog\n";
}


#    my $len;
#    my %fas;






exit;
