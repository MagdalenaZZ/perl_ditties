#!/usr/local/bin/perl -w

use strict;
#use Text::ParseWords;

unless (@ARGV==3) {
        &USAGE;
}

sub USAGE {

die 'Usage: hmmer_chooser.pl in eval out

Give a hmmer-searh output-file 
The program will merge all hits, and then report the best hit from several different models, if their evalue is less than eval


'
}

	my $in = shift;
	my $eval = shift;
#    my $maxlen = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

    
my %genes;
my %res;
my $index = 1;
my %gff;

# make hmm output to gff
#
foreach my $line (@input) {

    unless ($line =~/^#/) {
my @var	= split(/\s+/, $line);

my $gene= $var[0];
my $acc = $var[1];
my $model = $var[2];
my $acc2 = $var[3];
$acc2 =~s/Group\.//;

my $full_eval = $var[6];
my $full_score = $var[5];
my $full_bias = $var[6];
my $best_eval = $var[7];
my $best_score = $var[8];
my $best_bias = $var[9];
my $dom_exp = $var[10];
my $dom_reg = $var[11];
my $dom_clu = $var[12];
my $dom_ov = $var[13];
my $dom_env = $var[14];
my $dom_dom = $var[15];
my $dom_rep = $var[16];
my $dom_inc = $var[17];
my $dom_desc = $var[18];

#print "Eval $var[6]\n";

        if ( $eval >= $dom_clu ) {
            $genes{$gene}{$full_eval}= $line;
            push (@{$gff{$gene}} , "$gene\thmm\tCDS\t$dom_inc\t$dom_desc\t$dom_clu\t\+\t\.\tID\=$gene\.$acc2");
            $index++;
        }
    }

}

# sort arrays after co-ords



# MERGE OVERLAPPING HITS

my %merged;

foreach my $line (keys %gff) {
#    print "$line\n";

my @unsort = @{$gff{$line}} ;
my @ordered_users = sort { (split '\t', $a)[3] <=> (split '\t', $b)[3] || (split '\t', $a)[4] <=> (split '\t', $b)[4]    } @unsort ;    

my $i=2;
my $line2 = 0;
my $line3 = 0;

    foreach my $elem ( @ordered_users ) {
#        print "\n$elem\n";
        
        my @arr = split(/\t/, $elem);
        my $start = $arr[3];
        my $end = $arr[4];


        if (exists $merged{$line} ) {
            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
            my ($estart , $eend) = split (/\t/, $merged{$line});

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];

            my $new = "$min\t$max";
#            print "New: $new\n";
            
                $merged{$line} = "$min\t$max";                

            }

        elsif (exists $merged{$line2} ) {

            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
            my ($estart , $eend) = split (/\t/, $merged{$line2});

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];

            my $new = "$min\t$max";
#            print "New: $new\n";
            
                $merged{$line2} = "$min\t$max"; 
            }
        }


        elsif (exists $merged{$line3} ) {

            #test if the gene is overlapping the known co-ordinates
#            print "Exist: $merged{$line}\n";
            my ($estart , $eend) = split (/\t/, $merged{$line3});

            # test if the gene overlaps with the known co-ord
            if (  $start  < ($eend+1)  ) {
                # overlaps - calculate new coords
                
            # max
                my $max = ($end, $eend)[$end < $eend];
            # min
                my $min = ($start, $estart)[$start > $estart];

            my $new = "$min\t$max";
#            print "New: $new\n";
            
                $merged{$line3} = "$min\t$max"; 
            }
        }



            # have to make a new one
            else {
                # dont overlap
                $line2 = $line . "#$i";
                $merged{$line2} = "$start\t$end";
                $i++;

#                print "NEW: $line2\t$start\t$end\n";
            }



        }

# if it doesn't exist before, add the first one
        else {
            $merged{$line} = "$start\t$end";
        }
        

    }

}




foreach my $key (sort keys %merged) {

my @arr = split( /#/, $key);
push (@arr, 1);
#my @arr2 = split(/\:/, $arr[1]);

#print OUT "$arr[0]#$arr[1]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$key\n";
print OUT "$arr[0]\thmm\tCDS\t$merged{$key}\t.\t\+\t\.\tID\=$arr[0]\.$arr[1]\n";


}


close (OUT);
