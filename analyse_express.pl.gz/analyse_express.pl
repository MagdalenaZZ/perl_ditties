#!/usr/local/bin/perl -w
# Given results from DEGexp and gene annotation, determine overrepresented GO terms
# and functionally annotate over and under expressed genes
use strict;

my($deseqout, $ann, $q_cut) = @ARGV;

if(!defined $q_cut)
{
	print STDERR "USAGE: <deseqout> <ann> <q_cut>\n";
	exit;
}

my $go_q_cut = 0.05;
my $topn = 20;
my $sig_script = '~mz3.bin/perl/sig_goterms.pl';

open(ANN, "<$ann") or die "$!";

my %desc = ();
my %go = ();

my $with_desc = 0;

while(<ANN>)
{
	chomp;
	my($gene, $desc, @go) = split /\t/;

	if(defined $desc)
	{
		$desc{$gene} = $desc;
	}
	else
	{
		$desc = 'hypothetical';
	}

	if(defined $go[0])
	{
		$go{$gene} = \@go;
	}

	$with_desc++ unless $desc =~ /^hypothetical/;
}
close ANN;

my $with_go = scalar keys %go;
print STDERR "$with_go genes have GO terms\n$with_desc genes have descriptions\n";

open(DEG, "<$deseqout") or die "$!";

my %over = ();
my %under = ();
my %genes = ();

my $under_go = 0;
my $over_go = 0;
my $hypo = 0;

my %val1 = ();
my %val2 = ();
my %fc = ();

while(<DEG>)
{
	chomp;
	next if /^\"id/;

	my($row, $rest) = split /\" \"/;

	my ($id, $fields) = split /\" /, $rest;

	my @fields = split / /, $fields;

	$id =~ s/\"//;
	@fields = ($id, @fields);

	my($gene, $baseMean, $val1, $val2, $fc, $log_fold, $p, $padj) = @fields;

	$val1{$gene} = $val1 unless $val1 eq 'NA';
	$val2{$gene} = $val2 unless $val2 eq 'NA';
	$fc{$gene} = $fc;

	$genes{$gene} = $padj;

	if ($padj eq 'NA')
	{
		next;
	}

	if($padj <= $q_cut)
	{
		if($fc >= 1)
		{
			$over{$gene} = $padj;

			if(exists $go{$gene})
			{
				$over_go++;
			}
		}
		else
		{
			$under{$gene} = $padj;

			if(exists $go{$gene})
			{
				$under_go++;
			}
		}
	}
}
close DEG;

my $total_under = scalar keys %under;
my $total_over = scalar keys %over;

print "$over_go of $total_over have increased expression and have GO terms\n";
print "$under_go of $total_under have reduced expression and have GO terms\n";

print "\nDifferentially Expressed Genes\n";
foreach my $over (sort {$over{$a}<=>$over{$b}} keys %over)
{
	if(exists $desc{$over})
	{
		print "UP\t$over\t$over{$over}\t$val1{$over}\t$val2{$over}\t$fc{$over}\t$desc{$over}\n";
	}
	else
	{
		print "UP\t$over\t$over{$over}\t$val1{$over}\t$val2{$over}\t$fc{$over}\n";
	}
}

foreach my $under (sort {$under{$a}<=>$under{$b}} keys %under)
{
	if(exists $desc{$under})
	{
		print "DOWN\t$under\t$under{$under}\t$val1{$under}\t$val2{$under}\t$fc{$under}\t$desc{$under}\n";
	}
	else
	{
		print "DOWN\t$under\t$under{$under}\t$val1{$under}\t$val2{$under}\t$fc{$under}\n";
	}
}


print STDERR "Running $sig_script $deseqout $ann $q_cut...\n";
chomp(my @result = `$sig_script $deseqout $ann $q_cut`);

my %go_desc = ();
my %sig_go = ();

foreach my $res (@result)
{
	#print $res."\n";
	my($term, $dir, $p, $q, $desc, $gene_count, $genes) = split /\t/, $res;

	$go_desc{$term} = $desc;

	next unless $q <= $go_q_cut;

	my @genes = split /\s/, $genes;

	$sig_go{$dir}->{$q}->{$term} = \@genes; 
}

print "\nDifferentially Represented GO Terms\n";

foreach my $dir (sort {$b cmp $a} keys %sig_go)
{
	foreach my $q (sort {$a<=>$b} %{$sig_go{$dir}})
	{
		foreach my $term (sort keys %{$sig_go{$dir}->{$q}})
		{
			print "$dir\t$q\t$term\t$go_desc{$term}\n";

			foreach my $gene (@{$sig_go{$dir}->{$q}->{$term}})
			{
				$desc{$gene} = '' unless exists $desc{$gene};

				print "\t$gene $desc{$gene}\n";
			}
		}
	}
}

# When using read counts top expressed gene will not be correct
#my $c = 0;
#foreach my $gene (sort {$val1{$b}<=>$val1{$a}} keys %val1)
#{
#	$desc{$gene} = '' unless exists $desc{$gene};
#	print "COND1\t$gene\t$val1{$gene}\t$desc{$gene}\n";
#	last if $c >= $topn;
#	$c++;
#}
#print "\n";
#$c = 0;
#foreach my $gene (sort {$val2{$b}<=>$val2{$a}} keys %val2)
#{
#	$desc{$gene} = '' unless exists $desc{$gene};
#	print "COND2\t$gene\t$val2{$gene}\t$desc{$gene}\n";
#	last if $c >= $topn;
#	$c++;
#}
