#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: phylogenize_me.pl infile prot/nuc aln/phy

Make sure the input fasta is single-line
Choose if your sequence in protein or nucleotide and if you want alignment or phylogeny


'
}


## parse infile

my $infile = shift;
my $model = shift;
my $task = "phylogeny";

if (scalar(@ARGV) > 0) {
$task = shift;
}


my $outfile = "$infile.fixed";
 
open (IN, "<$infile") || die "cant find file $infile\n";

open (OUT, ">$outfile") || die "cant find file $outfile\n";
open (OUT2, ">$outfile.key");

my @name_change;

my %new;
my $uni_index ="A";
#my $ind = 0;
#my $ind2 = 0;


while (<IN>) {

#    $uni_index ="A";

    chomp $_;

    if ($_=~/^--$/) {
    }
    elsif ($_=~/^$/) {
    }
    elsif ($_=~/^>/) {
        my $head = $_;
        my $old = $head;
        my $seq = <IN>;
        chomp $seq;
        print OUT2 "$head\t";
        $head=~s/\|PACid:/\:/;
        $head=~s/EmW_00/Em_/;
        $head=~s/EmuJ_00/Em_/;
        $head=~s/EgG_00/Eg_/;
        $head=~s/EgrG_00/Eg_/;
        $head=~s/CEL_WBGene00/C_/;
        $head=~s/SME_ASA/M_/;
        $head=~s/SME_mk4\.0/M_/;
        $head=~s/DRE_ENSDARG0000/R_/;
        $head=~s/DME_FBpp/D_/;
        $head=~s/HmN_00/Hm_/;
        $head=~s/TsM_00/Ts_/;
        $head=~s/RNA815_/L_/;
        $head=~s/MUS_CCDS/U_/;
        $head=~s/HSA_CCDS/O_/;
        $head=~s/Smp_/Sm_/;
        $head=~s/Hsap_/O_/;
        $head=~s/Tthe_/Y_/;
        $head=~s/Spur_/ec_/;
        $head=~s/Mmus_/U_/;
        $head=~s/Dmel_/D_/;
        $head=~s/C2d_Ddis/d_/;
        $head=~s/Ddis_DDB/d_/;
        $head=~s/Mbre_/mz_/;
        $head=~s/Monbr1_/mz_/;
        $head=~s/Lotgi1_/mo_/;
        $head=~s/Capca1_/an_/;
        $head=~s/Nemve1_/ne_/;
        $head=~s/Cioin2/nv_/;

        $head=~s/\(/_/;
        $head=~s/\)/_/;
        $head=~s/:/_/;
        $head=~s/\.//g;
        $head=~s/\,//;
#        print OUT2 "$head\t";


        my $new_head=substr($head,0 ,11 );
        #       my @head = split(/""/, $head);
        #       my @new_head = splice(@head, 0, 10);
#        print "$new_head\n";
        

# the head exists already - make a new
        if (exists $new{$new_head}) {
            $new_head=~s/\>//;
            my $newer = "\>" ."$uni_index" . "$new_head";
            my $newer_head = substr($newer,0 ,11 );

#            if (exists $new{$newer_head}) {
#                $newer_head=~s/\>//;
#                my $newer = "\>" ."$uni_index" . "$new_head";
#                my $newer_head = substr($newer,0 ,11 );
#                print "WARNING: repeat header $new_head, changed to $newer_head\n";
#                $uni_index++;
#            }
#            else {
            while (exists $new{$newer_head}) {
#                print "FATAL WARNING: repeat header $new_head, changed to $newer_head exists already\n";
#                die 'Fix the repeat headers
#                ';
                $uni_index++;
                $newer = "\>" ."$uni_index" . "$new_head";
                $newer_head = substr($newer,0 ,11 );

            }
#            else {
                $new{$newer_head}=$seq;
#                print "NEW:$newer_head\n";
                print OUT2 "$newer_head\n";
                 $uni_index ="A";
#            }
#                $ind++;
#            }
            print "WARNING: $old became repeat header $new_head, changed to $newer_head\n";

        }
        else {
                $new{$new_head}=$seq;
                print OUT2 "$new_head\n";
#                $ind2++;
#                $uni_index ="A";

            }
    }
    else {
     print  "Something wrong with this line:$_ it has not been read\n";
    }
}

#print "$ind\t$ind2\n";

foreach my $elem (keys %new) {
    print OUT "$elem\n$new{$elem}\n";
}


close (OUT);
close (OUT2);
close (IN);
#__END__

#if ()
#print "WARNING: repeat header $new_head, changed to $newer_head\n";

# run mafft

if ($task=~/^aln/) {
system ("/software/pubseq/bin/mafft --anysymbol   --retree 2 --reorder $infile.fixed > $infile.mfa");
wait;
}




else {
	system ("/software/pubseq/bin/mafft --anysymbol   --retree 2 --reorder $infile.fixed > $infile.mfa");
	wait;
	system ("/software/pubseq/bin/mafft --anysymbol   --retree 2 --phylipout --reorder $infile.fixed > $infile.phy");
	wait;
	system ("/software/pubseq/bin/mafft --anysymbol --retree 2 --clustalout --reorder $infile.fixed > $infile.aln");
	wait;


	print "Alignment is finished\n";

	system "rm -f RAxML*$infile.tre";


# run raxml
# 
if ($model=~/p/) {
        print "Using protein model while calculating phylogeny\n";
system (" ~jc17/bin/raxmlHPC -s $infile.phy -n $infile.tre -m PROTGAMMAJTT -p 4582634"); wait;
}
elsif ($model=~/n/) {
    print "Using nucleotide model while calculating phylogeny\n";
system (" ~jc17/bin/raxmlHPC -s $infile.phy -n $infile.tre -m GTRGAMMAI"); wait;
}



else {
    print "Warning: Dont know if your model is nucleotide or protein\n";
    die;
}

=pod
# make a nice phy-file
#
open (IN, "<$infile.phy");
my @in = <IN>;

my $header = pop (@in);
my @lengths = split(/\s+/, $header);
print "Header: $header\n";

foreach my $line (@in[1..$lengths[0]]) {
    chomp $line;
#    if ($line=~/_/) {
        print "$line\n";
$    }

}
=cut


print "Phylogeny is finished\n";


system ("~mz3/bin/perl/tree_painter.pl RAxML_bestTree.$infile.tre ");

print "Phylogeny is coloured\n";


}



