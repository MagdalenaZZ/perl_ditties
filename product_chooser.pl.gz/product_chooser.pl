#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '



Usage: perl ~/bin/perl/product_chooser.pl infile outfile


Give the program a concatenated list of products, and it will choose if a gene is

"hypothetical protein" "expressed protein" "conserved protein" or "any nice name"

    and choose the best combination



'
}

	my $in = shift;
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my %new;

# make format right 

foreach my $line (@in) {
chomp $line;
	$line=~s/mz3/hypothetical protein/g;
	$line=~s/hypothetical_protein/hypothetical protein/g;
	$line=~s/conserved_protein/conserved protein/g;

	my @arr = split(/\t/,  $line );

    # if the gene does not exist

    unless (exists $new{$arr[0]}) {
        $new{$arr[0]} = $arr[1];
        print "Declare: $arr[0]\t$new{$arr[0]}\n";
    }


    # replace hypothetical protein with anything else
    if ($new{$arr[0]} =~/product=\"hypothetical protein\"/) {
            $new{$arr[0]} = $arr[1];
            print "Replace: $arr[0]\t$arr[1]\n";
    }


#        print "THIS:$arr[0]\t$new{$arr[0]}\n";


    # replace conserved and expressed proteins with "conserved and expressed" product
    elsif ( $new{$arr[0]} =~/product=\"expressed protein\"/ and $arr[1] =~/product=\"conserved hypothetical protein\"/ ) {
            print "Gene $arr[0] is both conserved and expressed\n";
            $new{$arr[0]} = "\/product=\"expressed conserved protein\"";

    }
    elsif ( $new{$arr[0]} =~/product=\"conserved hypothetical protein\"/ and $arr[1] =~/product=\"expressed protein\"/ ) {
            print "Gene $arr[0] is both conserved and expressed\n";
            $new{$arr[0]} = "\/product=\"expressed conserved protein\"";    
    }

    elsif ( $new{$arr[0]} =~/product=\"expressed protein\"/) {

        if  ($arr[1] =~/product=\"hypothetical protein\"/) {

        # do nothing
            }
        else {
               print "Replace expressed: $arr[0]  $arr[1] NOT $new{$arr[0]} \n";
                $new{$arr[0]} = $arr[1];

        }

    }

    elsif ( $new{$arr[0]} =~/product=\"conserved hypothetical protein\"/) {

        print "$arr[0] $new{$arr[0]} is conserved hypothetical protein $arr[1]\n";

        if  ($arr[1] =~/product=\"hypothetical protein\"/) {

        # do nothing
            }
        else {
               print "Replace conserved: $arr[0]  $arr[1] NOT $new{$arr[0]} \n";
                $new{$arr[0]} = $arr[1];

        }

    }

    elsif ( $new{$arr[0]} =~/product=\"expressed conserved protein\"/) {

        if  ($arr[1] =~/product=\"hypothetical protein\"/) {

        # do nothing
            }
        elsif  ($arr[1] =~/product=\"conserved hypothetical protein\"/) {

        # do nothing
            }
        elsif  ($arr[1] =~/product=\"expressed protein\"/) {

        # do nothing
            }

        else {
               print "Replace conserved expressed: $arr[0]  $arr[1] NOT $new{$arr[0]} \n";
                $new{$arr[0]} = $arr[1];
        }

    }



    # save all genes which have good names already
    #
=pod
    
    elsif ($arr[1] !~/product=\"hypothetical protein\"/) {

        if ($new{$arr[0]} !~/product=\"expressed protein\"/) {
            if  ($arr[1] !~/product=\"expressed conserved protein\"/) {
                print "Replace2: $arr[0]  $arr[1] NOT $new{$arr[0]} \n";
                    $new{$arr[0]} = $arr[1];
            }
        }

        elsif ($new{$arr[0]} !~/product=\"expressed conserved protein\"/) {
            if  ($arr[1] !~/product=\"expressed conserved protein\"/) {
                print "Replace3: $arr[0]  $arr[1] NOT $new{$arr[0]} \n";
                    $new{$arr[0]} = $arr[1];
            }
        }
    }
    
    # replace conserved and expressed proteins with real names
#    elsif ( $new{$arr[0]} =~/conserved hypothetical protein/ || $new{$arr[0]} =~/expressed protein/ 
#            and $arr[1] !~/product=\"hypothetical protein\"/ ) {
#            print "Gene $arr[0] $new{$arr[0]} was replaced by real name $arr[1]\n";
#            $new{$arr[0]} = $arr[1] ;    
#    }
#
=cut

    else {

#        print "Else:$arr[0]\t$new{$arr[0]}\t $arr[1]\n";
        print "Dont replace: $arr[0]  $new{$arr[0]} NOT  $arr[1]\n";
#                    $new{$arr[0]} = $arr[1];

    }




}

#__END__


	open (OUT, ">$out") || die "I can't open $out\n";

# remove duplicate products

foreach my $gene (sort keys %new) {

    print OUT "$gene\t$new{$gene}\n";
    # check if there are both conserved and expressed
    #
#    if ($gene)


}

close (OUT);


__END__

# remove hypothetical protein
			if ($index==1) {
				foreach my $elem2 (@ret) {	
					if ($elem2=~/\/product=\"hypothetical protein\"/) {	
#						shift @ret;   ### <=== this takes away the wrong element!
						$elem2='';
					}
# remove notes of hypothetical proteins
					elsif ($elem2=~/\/note="Product 'hypothetical protein' is based on blast-similarity with GenBank:/) {
						$elem2='';
					}
# fix genbank accession in notes
					elsif ($elem2=~/\/note="Product/) {
#						print "Elem:$elem2\n";
						my @arr4= split (/:/,$elem2);
						$arr4[1]=~s/ /_/;
#						print "Arr4:$arr4[1]\n";
						$elem2=join(":", @arr4);
#						print "Elem:$elem2:\n"
					}


				}			
			}

# check the integrity of the entries
			foreach my $elem (@ret) {
				if ($elem!~/\w/) {
    				print "Elem not word:$elem:\n";
                }
                elsif ($elem!~/\/*\"*\"/) {
                   print "Elem not intact:$elem:\n"; 
                }
                elsif ($elem=~/\t/) {
                    print "Elem has tab:$elem:\n";
                }
                else {
                }
            }
            
                $final = join("\t", @ret);
#                print "FIRST:$first\n";
                my $new_line = "$first\t$final";
                $new_line=~s/\t\t/\t/g;
                $new_line=~s/\t\t/\t/g;
                $new_line=~s/\t\t/\t/g;
                if ($new_line=~/\w+/) {
        			print OUT "$new_line\n";
#					print "#### END ######\n";	
                }
		    }
# if the gene doesnt have a product, give it a hypothetical one
		else {
			print OUT "$line\t/product=\"hypothetical protein\"\n";
		}
		

	}

	elsif ($line=~/CDS/ or $line=~/mRNA/) {
    	print OUT "$line\n";
	}
    else {
        print "WARN:weird line:$line:\n";
    }



}







