#!/usr/bin/perl -w

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

    die '


Usage: GSEA_make_geneset.pl gene_names.list title

Takes a file with gene names and turns in into a GSEA geneset

Give the gene set a title



' . "\n";
}


my $in = shift;
my $title = shift;


open (IN, "<$in")|| die;
open (OUT, ">$title.gmt")|| die;

my @a;

push(@a, "$title");
push(@a, "NA");

while(<IN>) {
chomp;
    push(@a, "$_");
}


my $gset = join("\t", @a);

print OUT "$gset\n";


exit;

