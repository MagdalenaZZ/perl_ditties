#!/usr/bin/perl -w


use strict;


if (@ARGV < 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: RCDBget.pl RCDBlist  

Takes a list of RCDB-numbers and associates them with the UniProt entry for them




What can possibly go wrong...  :-)



'
}

my $in = shift;


        open (IN, "<$in") || die "I can't open $in\n";
        #   	my @in= <IN>;
#    	close (IN);

my %h;

my $id;
my $head;
my $seq;

        while (<IN>) {


            if ($_ =~/drugbank-id/ ) {
#                print "$_";
                my @arr = split(/[\<\>]/, $_);
                my @arr2 = split(/[\<\>]/, <IN>);
#                print "$arr[2]\n";
#                print "$arr2[2]\n";
                $h{ $arr[2] }{"Name"} = "$arr2[2]";
                $id = $arr[2] ;
                $h{ $id }{"Group"} = "0";


            }
            
            
            elsif ($_ =~/<description>/ ) {
                    $_=~s/<description>//;
                    $_=~s/<\/description>//;
                    $_=~s/        //;
                    $h{ $id }{"Desc"} = "$_";

            }

            elsif ($_ =~/<group>/ ) {
#                print "$_";
                my @arr = split(/[\<\>]/, $_);
#                print "$arr[2]\n";
                $h{ $id }{"Group"} = "$arr[2]";
            }

            elsif ($_ =~/<header>/ ) {
                    chomp $_;
                    $_=~s/<header>//;
                    $_=~s/<\/header>//;
                    $_=~s/        //;
                    $_=~s/\|\|/\|/g;
                    $_=~s/\|\|/\|/g;
                    $_=~s/\|\|/\|/g;
                    $_=~s/\|\|/\|/g;
                    $head = $_;               
            
            }

            elsif ($_ =~/<chain>/ ) {
                    chomp $_;
                    $_=~s/<chain>//;
                    $_=~s/<\/chain>//;
                    $_=~s/        //;
#                     print "$_";
                $h{ $id }{"Seq"}{"$head\n$_"}=1;

                $head="";
            }
            elsif ($_ =~/references>#/ ) {
          
#                     print "$_";
                $h{ $id }{"Ref"} = "$_";

            }
           
    # empty hash
    #           elsif ($_ =~/<drug type="/ {

#                }


        }

open (OUT, ">$in.approved.fas") || die "I can't open $in.approved.fas\n";
open (OUT2, ">$in.approved.txt") || die "I can't open $in.approved.txt\n";

foreach my $ids ( keys %h ) {

    if ( $h{$ids}{"Group"} =~/approved/ ) {
    my $index="1";
        foreach my $sequ ( keys %{$h{$ids}{"Seq"}} ) {
            print OUT ">$ids.$index\t";
            print OUT "$sequ\n";
            $index++;
        }
        $index="1";
    }

}



close (IN);
close (OUT);
close (OUT2);

exit;

