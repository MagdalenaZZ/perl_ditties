#!/usr/local/bin/perl -w
# mz3 script for changing augustus-output to blast2go-input
use strict;

unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/aug2blast2go.pl augustus-output start end queue blastmem iprmem


perl ~/bin/perl/aug2blast2go.pl augs369.o 1 3

Make a new folder and copy the augustus output-file there. Launch the script from there.

augustus-output 	the output file from augustus
start 			integer - the first amino acid you want to analyse
end 			integer - the last amino acid you want to analyse
queue 			which queue to bsub to - he script bsubs itself
blastmem			integer - how much memory you want for the job
iprmem			integer - how much memory you want for the job

when done - load in BLAST and IPR folder to blast2go, and choose File - Export - Mapping results - By seq


This version has blast-splitter to do the BLAST-job  
_svn1 splits the blastall query 

'
}


	my $gtf = shift;
	my $start = shift;
	my $end = shift;

 use Cwd;

 my $cwd = getcwd;
# print "CWD $cwd\n";



# Export proteins from the genome
#my $cmd1 = " ~/bin/augustus.2.5.5/scripts/getAnnoFasta.pl $gtf ";
#system " ~/bin/augustus.2.5.5/scripts/getAnnoFasta.pl $gtf ";

# Clean up the file a little bit


# make file single line
system  "fasta2singleLine.pl $gtf.faa $gtf.sl.faa  ";

# make a list of sequences
unless (-e  "$gtf.sl.faa.list") {
system "cat $gtf.sl.faa | grep '>' > $gtf.sl.faa.list";
}

# make a new folder
my $foldername="aa" . "$start" . "_" . "$end";
unless (-e  $foldername) {
system "mkdir $foldername";
}

#unless (-e  "$foldername/BLAST") {
#system "mkdir $foldername/BLAST";
#}

unless (-e  "$foldername/IPR") {
system "mkdir $foldername/IPR";
}

# cut that list after the co-ordinates given in the input
open (IN, "<$gtf.sl.faa.list") || die "I can't open $gtf.sl.faa.list\n";
	my @list = <IN>;

open (LIST, ">$gtf.sl.faa.list.$foldername.cut") || die "I can't open $gtf.sl.faa.list.$foldername.cut\n";
 ## adjust the co-ordinates to perl
$start--;
$end--;
	
my @cutlist = @list[$start..$end];


# print LIST @cutlist;


foreach my $elem  (@cutlist) {
 $elem =~s/\>//;
# print "$elem\n";
}

print LIST @cutlist;

#my $lsbno =1;
# split the protein sequences
foreach my $line2 (@cutlist) {
chomp $line2;
my $name = "$line2" . ".faa";
system "cat $gtf.sl.faa | grep -w $line2 -A 1 > $foldername/$name";
#$lsbno++;
}

# make a BLAST-inputfile and launch BLAST-splitter
system "cat $foldername/*.faa > $foldername/$foldername.blastin";

open (SH, ">$foldername.blastall.sh") || die "I can't open $foldername.blastall.sh\n";

print SH "/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=2 --splitmem=5 --protein_ref $cwd/$foldername/$foldername.blastin /lustre/scratch101/blastdb/Supported/nr $cwd/$foldername/BLAST 500000 -a 1 -b 20 -v 20 -p blastp -e 0.001 -m 7;\n";




=pod

blastall -a 1 -b 20 -v 20 -p blastp -e 0.001 -m 7 -d /lustre/scratch101/blastdb/Supported/nr -i $foldername/$foldername.blastin -o $foldername/BLAST/$foldername.blast.xml;\n";


/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=2 --splitmem=5 /lustre/scratch103/sanger/mz3/genome/HYM_BLAST/fixed2/contigs.fa.original /lustre/scratch103/sanger/mz3/genome/HYM_BLAST/fixed2/final_leftovers_bin_1000.fasta bin2 500000 -D 3 -p 0

# Do a BLAST-search:
open (SH, ">$foldername.blastall.sh") || die "I can't open $foldername.blastall.sh\n";

foreach my $elem (@cutlist) {
print SH "blastall -a 1 -b 20 -v 20 -p blastp -e 0.001 -m 7 -d /lustre/scratch101/blastdb/Supported/nr -i $foldername/$elem.aa -o $foldername/BLAST/$elem.blast.xml;\n";

} 

=cut



# submit job
# system "team133-bsub.pl basement 30 b2g_$foldername.o b2g_$foldername.e b2g_$foldername sh $foldername.blastall.sh";
system "sh $foldername.blastall.sh";

	close (IN);
	close (LIST);

###########################################################################


#Do an InterProScan search for the protein
open (SH2, ">$foldername.ipr.sh") || die "I can't open $foldername.ipr.sh\n";

foreach my $elem (@cutlist) {
print SH2 "/nfs/users/nfs_m/mz3/bin/perl/iprscan -cli -verbose -format xml -iprlookup -goterms -nocrc -i $foldername/$elem.faa -o $foldername/IPR/$elem.ipr.xml;\n";
}

system "team133-bsub.pl normal 5 $foldername.b2gipr.o $foldername.b2gipr.e $foldername.b2gipr sh $foldername.ipr.sh";


###########################################################################

open (OUT, ">$foldername.out") || die "I can't open $foldername.out\n";


$start++;
$end++;

print OUT "perl ~/bin/perl/aug2blast2go_after.pl $gtf $start $end $foldername $cwd";


close (SH2);
close (OUT);

###########################################################################




__END__

team133-bsub.pl basement 20 b2gi2.o b2gi2.e b2gi2 java -jar /software/pathogen/external/apps/blast2go_pipeline/blast2go.jar -in /lustre/scratch101/sanger/mz3/blast2go/aug369/aa0_29/BLAST/ -out aa0_29.out -ipr /lustre/scratch101/sanger/mz3/blast2go/aug369/aa0_29/IPR/ -a  aa0_29.annot -d aa0_29.dat



__END__

#Do an InterProScan search for the protein
open (SH2, ">$foldername.ipr.sh") || die "I can't open $foldername.ipr.sh\n";

my $lsb = '$LSB_JOBINDEX';
foreach my $elem (@cutlist) {
print SH2 "/nfs/users/nfs_m/mz3/bin/perl/iprscan -cli -verbose -format xml -iprlookup -goterms -nocrc -i $foldername/$elem.faa.$lsb -o $foldername/IPR/$elem.ipr.xml.$lsb;\n";
} 

# system "team133-bsub.pl normal 5 b2gipr_$foldername.o b2gipr_$foldername.e b2gipr_$foldername sh $foldername.ipr.sh";


$lsbno--;

print "bsub -o ipr.%I.o -e ipr.%I.e -J" . "ipr." . "[" . "1-$lsbno" ."] ". "sh $foldername.ipr.sh" ."\n";


__END__


bsub -o out.%I.o -e out.%I.e -J"blast.[1-10]" "blastall -p blastn -m 8 -F F -e 1e-6 -W 15 -d ../../iCORN3/Eimeria.3 -i contigs.1k.split.\$LSB_JOBINDEX -o comp.\$LSB_JOBINDEX.blast "

cat > doit.sh
blastall -p blastn -m 8 -F F -e 1e-6 -W 15 -d ../../iCORN3/Eimeria.3 -i contigs.1k.split.$LSB_JOBINDEX -o comp.$LSB_JOBINDEX.blast


chmod 755 ./doit.sh
bsub -o out.%I.o -e out.%I.e -J"blast.[1-1]"



# Check if it has given some result - if not, lower the expectation value 
bsub blastall -a 1 -b 20 -v 20 -p blastp -m 7 -d /lustre/scratch101/blastdb/Supported/nr -i EmW_000001.1.fasta -o results.xml &


#Do an InterProScan search for the protein


#copy the properties-file
cp /software/pathogen/external/apps/blast2go_pipeline/b2gPipe.properties .

#Run BLAST2go on the results
