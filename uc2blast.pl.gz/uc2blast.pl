#!/usr/bin/perl
use strict;
use My::ReadFasta;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  usearchParser.pl  uc original.fasta


Takes the output from usearch and calls consensus


';

}

my $uc = shift;
my $fas = shift;

my %fas;
my %clus;




###  parse cluster file  ####

open (CLU, "<$uc") || die "Cant find file $uc";
open (OUT, ">$uc.blast") || die "Cant find file $uc.blast";

my $ind = "A";
my %h;

while (<CLU>) {
    #print "$ind\n";
    chomp;
    my @arr = split(/\t/, $_);
    if ($arr[0]=~/^H$/) {

       
        #print "$_\n";


        if ($arr[8]=~/revcomp_/ and $arr[9]=~/revcomp_/  ) {
            $arr[8]=~s/revcomp_//;
            $arr[9]=~s/revcomp_//;
            print OUT "$arr[8]\t $arr[9]\t$arr[3]\t100\t0\t0\t1\t100\t1\t100\t0.000000001\t1\n";
# ($queryId, $subjectId, $percIdentity, $alnLength, $mismatchCount, $gapOpenCount, $queryStart, $queryEnd, $subjectStart, $subjectEnd, $eVal, $bitScore)
        }
        elsif ($arr[8]!~/revcomp_/ and $arr[9]=~/revcomp_/  ) {
            $arr[9]=~s/revcomp_//;
            print OUT "$arr[8]\t $arr[9]\t$arr[3]\t100\t0\t0\t1\t100\t100\t1\t0.000000001\t1\n";
# ($queryId, $subjectId, $percIdentity, $alnLength, $mismatchCount, $gapOpenCount, $queryStart, $queryEnd, $subjectStart, $subjectEnd, $eVal, $bitScore)
        }
        elsif ($arr[8]=~/revcomp_/ and $arr[9]!~/revcomp_/  ) {
            $arr[8]=~s/revcomp_//;
            print OUT "$arr[8]\t $arr[9]\t$arr[3]\t100\t0\t0\t100\t1\t1\t100\t0.000000001\t1\n";
# ($queryId, $subjectId, $percIdentity, $alnLength, $mismatchCount, $gapOpenCount, $queryStart, $queryEnd, $subjectStart, $subjectEnd, $eVal, $bitScore)
        }
        else {
            print OUT "$arr[8]\t $arr[9]\t$arr[3]\t100\t0\t0\t1\t100\t1\t100\t0.000000001\t1\n";
# ($queryId, $subjectId, $percIdentity, $alnLength, $mismatchCount, $gapOpenCount, $queryStart, $queryEnd, $subjectStart, $subjectEnd, $eVal, $bitScore)
        }

    }
}







