#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

if (@ARGV < 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: blast_retriever.pl blast-output blastDB blast-infile  <e-value>

Takes an tab-format output from BLAST and the database
and retrieves all the hits
and aligns them


'
}

my $blast= shift;
my $db = shift;
my $in = shift;
my $eval = 0;

# open files
if ( scalar(@ARGV) > 0 ) {
	$eval = shift;
}

        open (IN, "<$blast") || die "I can't open $blast\n";
    	my @blast= <IN>;
    	close (IN);

        open (IN3, "<$in") || die "I can't open $in\n";
    	my @in= <IN3>;
    	close (IN3);

        open (IN2, "<$db") || die "I can't open $db\n";


        open (OUT, ">$blast.ret.fas") || die "I can't open $blast.ret.fas\n";

#    	my @db= <IN2>;


# get all the hits

my %hits;
foreach my $line (@blast) {
    chomp $line;
    my @arr = split(/\s+/,$line);
    if ( $arr[10] < $eval) {  
        $hits{$arr[1]}{"$arr[8]-$arr[9]"}=1;
        #print "hit $arr[1]\n" ;

    }

}

# collect all fasta from query
foreach my $line (@in) {
	if ($line=~/^--$/) {
	}
	elsif ($line=~/\w+/) {
	    print OUT "$line" ;
    	}

}


# collect all fasta from DB
while (<IN2>) {

    #    print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $1;
	 $seq_name=~s/>//;
	my $seq = <IN2> ;
	chomp($seq) ;
	
	if (exists $hits{$seq_name} ) {
            #print OUT ">$seq_name\n" ;
            #print OUT "$seq\n" ;

            foreach my $key (keys %{$hits{$seq_name}} ) {
                #print "SEQname:$seq_name $key\n";

                # retrieve fasta-seq
                my($qs,$qe)=split(/\-/, $key);

                # check orientation
                #my $rev =0;
                
                # if it is reverse
                if ($qs > $qe) {
                    #$rev=1;
                    my $len = $qs-$qe;
                    my $sub = substr($seq,$qe,$len);
                    # reverse-complement
                    my $rev = reverse($sub);
                    $rev=~tr/ACGTactg/TGCAtgca/;
                    print OUT ">$seq_name $key-\n$rev\n";
                                        
                

                }
                # if it is forward
                else {
                    my $len = $qe-$qs;
                    my $sub = substr($seq,$qs,$len);
                    print OUT ">$seq_name $key+\n$sub\n";
                }

            }


	}
    else {
        #   print  ">$seq_name\n" ;
#			print OUT2 "$seq\n" ;

    }


    }
    	
}

close (IN2);
close (OUT);


# do alignment
#

print "bsub.py 10 $blast.ret muscle -in $blast.ret.fas  -out $blast.ret.fas.fst\n";

system "bsub.py 10 $blast.ret muscle -in $blast.ret.fas  -out $blast.ret.fas.fst";



