#!/usr/local/bin/perl -w
# mz3 script for making new agp-file and sequence file for IMAGE results which have been merged

use strict;

unless (@ARGV == 5) {
        &USAGE;
}

sub USAGE {

die 'Usage: IMAGE_2agp.pl <final.stats> <agp-file> <input.fas> <final.IMAGE.fas> prefix

Final-stats = IMAGE final.stats file
agp-file = the file with agp positions before IMAGE iterations
input.fas = the file with all contigs before iterations
final.IMAGE.fas = the file with IMAGE inserts
prefix = whatever you like

One sequence per line for the fasta-files

Run GARM, or get agp-file another way
Run IMAGE, and merge some gaps
Run IMAGE-post-script to get stats-files
Give this program the IMAGE final.stats, the original agp file, a file with all contigs before iterations, and the file with IMAGE-inserts you get from the IMAGE-post-script

This script will then give you 2 files:
1. A new agp-file with correct positions
2. A file with all fasta-sequences in order


'
}

# Read final.stats file

    my $finalstats_file = shift;
    my $agp_file =shift;
    my $input_fasta =shift;
    my $IMAGE_fasta =shift;
    my $prefix = shift;

open (STATS, "<$finalstats_file");
my @stats = <STATS>;
chomp @stats;

open (AGP, "<$agp_file");
my @agp = <AGP>;
close (AGP);

# in the stats-file grep "Merge"
my @merged_contigs = '';

# get name of merger, the merged and the new.fas
my @merger= '';
my @merged= '';
my  @insert= '';
chomp (@merged_contigs);

foreach my $line (@stats) {
#	print "$line \n"; <STDIN>;
	if ($line =~/Merge/) {
		my($s1, $s2, $s3, $s4, $s5, $s6, $s7, $s8)= split (/\s+/, $line);
		if ($s2=~/\+veGap/) {
#			print "$s8\n";
			$s8 =~ s/^\s//; #remove leading spaces
			push (@merger, $s4);
			push (@merged, $s6);
			push (@insert, "$s8");
		}
		else {
#		write a fancy sub-routine to sort this one out
		}
	}
	else {
	# do nothing
	}
}

####### get merger from file
open (INSERTS, ">inserts.grep.list");
my @new_inserts = @insert[1..$#insert];
foreach my $elem2 (@new_inserts) {
print INSERTS "$elem2\n";
}
close (INSERTS);

####### make a file containing the inserts

system `cat $IMAGE_fasta | grep -A 1 -w -f inserts.grep.list | grep -v '-' > new_inserts.fas `;
open (INFAS, "<$input_fasta");
my @infas = <INFAS>;

open (IMAGEFAS, "<$IMAGE_fasta");
my @IMAGEFAS = <IMAGEFAS>;
close (IMAGEFAS);

##################### get merger from file

$/= '>';

open (IMAGEFAS, "<new_inserts.fas");
open (NEWAGP, ">new_inserts.agp");

my @imagefas2 = <IMAGEFAS>;
my @agp_inserts;  # array to hold info about merger-pieces

foreach my $sequence (@imagefas2) {
	if ($sequence =~/\w/){
		my($name, $sequence2)= split (/\n/, $sequence);
		# count length of merger
		my $length = length ($sequence2);
		my $newline ="$name\t$length";
		if ($newline =~/IM/) {
 			push (@agp_inserts, "$newline");
 			print NEWAGP "$newline\n";#<STDIN>;
		}
	}
	else {
# print "Nothing here: $sequence\n";
	}
}

# print NEWAGP "@agp_inserts";
close (NEWAGP);

$/= "\n";

######################## from stats-file
# find out which contigs have an overlap

my @mergers = '';
my @first_mergers = '';
open (LIST, ">mergers.list");

foreach my $line2 (@stats) {

	if ($line2 =~/Merge/) {
		if ($line2 =~/\+veGap/) {
		my($Merge, $veGap, $s3, $scaffold1, $and, $scaffold2, $arrow, $merger)= split (/\s+/, $line2);
		my $newline = "$scaffold1\t$scaffold2\t$merger";
		my($newline2, $newline3, $newline4, $newline5, $newline6)= split (/.s/, $newline);
		my $newline7 = "s$newline3\ts$newline4";
		my($newline8, $newline9, $newline10,$newline11) = split (/\s+/, $newline7);
		my $newline12= "$newline8\t$newline10\t$newline11";
		push (@mergers, $newline12);
		print LIST "$newline12\n";
		}
		else {
#		write a fancy sub-routine to sort this one out
		}
	}
}

############## add length value to mergers
# find out what length the overlap is

my @merger2 = '';

if (-e "mergers.list2") { 
system `rm -f mergers.list2 `;
open (LIST2, ">>mergers.list2");
} 
else {
open (LIST2, ">>mergers.list2");
}

foreach my $line (@mergers) {
	my ($s1, $s2) = split ( /\t/, $agp_inserts[0]);
		if ($line=~/$s1/) {
			print LIST2 "$line\t$s2\n";
			push (@merger2, "$line\t$s2");
			shift (@agp_inserts);
		}

}
close (LIST2);
close (LIST);

##### make a list of stats

if (-e "mergers.list3") { 
system `rm -f mergers.list3`;
open (LIST3, ">>mergers.list3");
} 
else {
open (LIST3, ">>$prefix.mergers.list");
}

print LIST3 "From_scaf\tTo_scaf\tIMAGE\tagp\n";


##################### insert merger into agp-file

my $index=0;
my @new_agp = '';
shift (@merger2);


foreach my $line (@agp) {
	my ($t1, $t2, $t3, $t4, $t5, $t6, $t7, $t8)=split (/\s+/, $line); # split the line in the agp-file
#	print "$line\n";

	if (scalar(@merger2)> 0) {
		my ($scaffold1, $scaffold2, $merger, $length) = split (/\s+/, $merger2[0]); # split the merger-line
#				print "T6:    $t6\n";
#				print "Scaf1: $scaffold1\n";
			if ($t6=~/$scaffold1/) {
				push (@new_agp, $line);
# Make new line			
#				print "Match\n";
				my $newline = $agp[$index+1];
#				print LIST3 "$newline\n";
				my ($s1, $s2, $s3, $s4, $s5, $s6, $s7, $s8)= split (/\s+/, $newline);
				my $newline2 = "$s1\t$s2\t$s3\t$s4\tW\t$merger\t1\t$length\t+\n";
				print LIST3 "$scaffold1\t$scaffold2\t$length\t$s6\n";
#				print "$newline2";
				push (@new_agp, $newline2);
# Move on
				shift (@merger2);
				shift (@agp);			
			}
			else {
			push (@new_agp, $line);
			}
	}
	else {
		push (@new_agp, $line);
	}
$index++;	
}

close (LIST3);

open (NEW_AGP, ">new.agp");
print NEW_AGP @new_agp;
shift @new_agp;

###### re-calculate lengths
my $start = 1;
my $new_start = 1;
my $end = 0;
my $new_end = 0;
my $length = 0;
my @final_agp ;
my @new_names ;

open (FINAL_AGP, ">$prefix.final.agp");

foreach my $row (@new_agp) {
	chomp ($row);
	my ($s1, $s2, $s3, $s4, $s5, $s6, $s7, $s8, $s9) = split (/\s+/, $row);

	if ($s5=~/N/) {
		$length = $s6;
		$new_start = $new_end + 1;
		$new_end = $new_start + $length-1;
		my $newline = "$s1\t$new_start\t$new_end\t$s4\t$s5\t$s6\t$s7\t$s8";
		print FINAL_AGP "$newline\n";
		push (@final_agp, "$newline");
	}

	elsif ($s5=~/W/) {
		$length = $s8;
		$new_start = $new_end + 1;
		$new_end = $new_start + $length-1;
		my $newline = "$s1\t$new_start\t$new_end\t$s4\t$s5\t$s6\t$s7\t$s8\t$s9";
		print FINAL_AGP "$newline\n";
		push (@final_agp, "$newline");
		push (@new_names, "$s6\n");
	}

	else {
		print "Error\n";
	}

}

close (STATS);
close (INFAS);
close (NEW_AGP);
close (FINAL_AGP);

##### make new fasta file

open (GREP_FASTA, ">final.fasta.grep.list");
print GREP_FASTA @new_names;
close (GREP_FASTA);

#########  make correct fasta

if (-e "$prefix.final.fasta") { 
system `rm -f $prefix.final.fasta`;
open (FINAL_FASTA, ">>$prefix.final.fasta");
} 
else {
open (FINAL_FASTA, ">>$prefix.final.fasta");
}

print FINAL_FASTA '>';
$/= '>';

system `cat new_inserts.fas $input_fasta > $prefix.unsorted.fasta `;

open (NEW, "<$prefix.unsorted.fasta");
my @fastas = <NEW>;
close (NEW);
my $count = 0;
my @final_fasta;

foreach my $line (@new_names) {

 	for ($count = $#fastas; $count >= 1; $count--) {
 		my ($v1, $v2, $v3)= split (/\n/,$fastas[$count]);
		if ($line =~/\b$v1\b/) {
			push (@final_fasta, $fastas[$count]);
			print FINAL_FASTA $fastas[$count];
		}
		else {
#			print "N: $line \n";
		}
	}
}

$/= "\n";

 system ` rm -f new_inserts.agp mergers.list2  mergers.list  inserts.grep.list new.agp new_inserts.fas final.fasta.grep.list $prefix.unsorted.fasta `;

close (FINAL_FASTA);



__END__

=pod

#### Compare the overlaps to each other

if (-e "mergers.list3") { 
system `rm -f mergers.list3`;
open (LIST3, ">>mergers.list3");
} 
else {
open (LIST3, ">>mergers.list3");
}


print LIST3 "From_scaf\tTo_scaf\tIMAGE\tagp\n";




perl ~/bin/perl/IMAGE_2agp.pl  <final.stats> <agp-file> <input.fas> <final.IMAGE.fas> 

/nfs/helminths/users/mz3/Hymenolepis/microstoma/GARM/new_scaffolds.edited_gt5k.fasta.agp
/lustre/scratch103/sanger/mz3/genome/GARM/new_scaffolds.edited_gt5k.fasta.contigs_sing_n_scaf.fasta
/nfs/helminths/users/mz3/Hymenolepis/microstoma/IMAGE/1503Hymeno/Hymeno20/final.consensus.fa
/nfs/helminths/users/mz3/Hymenolepis/microstoma/IMAGE/1503Hymeno/Hymeno20/final.stats


perl ~/bin/perl/IMAGE_2agp.pl scaffold00002.final.stats scaffold00002.agp scaffold00002.contigs.fas final.consensus.fa testa

perl ~/bin/perl/IMAGE_2agp.pl final.stats new_scaffolds.edited_gt5k.fasta.agp  new_scaffolds.edited_gt5k.fasta.contigs_sing_n_scaf.fasta final.consensus.fa testa