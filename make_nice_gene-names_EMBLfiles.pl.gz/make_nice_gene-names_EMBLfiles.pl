#!/usr/local/bin/perl -w
# mz3 script for sorting and choosing sequence length

use strict;
    use Bio::SeqIO;

sub USAGE {
die '

Perl-program for changing gene-names of an EMBL-file

Usage <input-file> <output-filename> 
Ex. make_nice_gene-names_EMBLfiles.pl file.embl file.corrected.embl

Written by: mz3@sanger.ac.uk

'
}

unless (@ARGV == 2) {
        &USAGE;
}

    my $input_file = shift;
    my $output_file =shift;

open (INFILE, "<$input_file");
open (OUTFILE, ">$output_file");

my @input = <INFILE>;


# parse the input-file

foreach my $line (@input) { 
	if ($line =~ /locus_tag/ || $line =~ /ID=/  ) {
		if ($line =~ /EMUvs2/) {	
		print OUTFILE "$line\n";
		}
		elsif ($line =~ /CEGMA/) {
		my ($line1, $line2) = split (/"/, $line);
		my ($line3, $line4) = split (/_/, $line2);
		my $newline = "$line1\"EMUvs2.trainingset.KOG.$line4\"";
		print OUTFILE "$newline\n";
		}
		elsif ($line =~ /KOG/) {
		my ($line1, $line2) = split (/"/, $line);
		my ($line3, $line4) = split (/_/, $line2);
		my $newline = "$line1\"EMUvs2.trainingset.$line3\"";
		print OUTFILE "$newline\n";
		}
		elsif ($line =~ /pathogen_EMU_contig_/) {
		my ($line1, $line2) = split (/"/, $line);
		my ($line3, $line4, $line5) = split (/\./, $line2);
		my $newline = "$line1\"EMUvs2.trainingset.aug.$line4\"";
		print OUTFILE "$newline\n";
		}
		elsif ($line =~ /DUP/) {
		my ($line1, $line2) = split (/"/, $line);
		my ($line3, $line4) = split (/-/, $line2);
		my $newline = "$line1.$line4";
		print OUTFILE "$newline\n";
		}
		else {
		print OUTFILE $line;
		print "Warning for line: $line - didn\'t match any pattern";
		}
}

else {

 print OUTFILE $line;
}


}

close (INFILE);
close (OUTFILE);

__END__


=pod


 
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_6286.embl

perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_6706.embl total.pathogen_EMU_scaffold_6706.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7517.embl total.pathogen_EMU_scaffold_7517.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7793.embl total.pathogen_EMU_scaffold_7793.corrected.embl 
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7816.embl total.pathogen_EMU_scaffold_7816.corrected.embl 
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7837.embl total.pathogen_EMU_scaffold_7837.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7843.embl total.pathogen_EMU_scaffold_7843.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7859.embl total.pathogen_EMU_scaffold_7859.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7860.embl total.pathogen_EMU_scaffold_7860.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7868.embl total.pathogen_EMU_scaffold_7868.corrected.embl
perl ~/bin/perl/make_nice_gene-names_EMBLfiles.pl total.pathogen_EMU_scaffold_7870.embl total.pathogen_EMU_scaffold_7870.corrected.embl


Warning for line: FT                   /locus_tag="pathogen_EMU_g2"
 - didn't match any patternWarning for line: FT                   /locus_tag="pathogen_EMU_scaffold_mz3"
 - didn't match any patternWarning for line: FT                   /locus_tag="pathogen_EMU_contig26745.g125b"
farm2-head1[mz3]307: cat total.pathogen_EMU_scaffold_7870.corrected.embl | grep pathogen_EMU_g2
FT                   /locus_tag="pathogen_EMU_g2"


total.pathogen_EMU_scaffold_7816.embl
 /ID="dfhdf.1:exon:2"


