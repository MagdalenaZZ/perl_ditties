#!/usr/local/bin/perl
use strict;
use lib "ENV{GARMLIB}"; 
use GetData;

my $list = shift;
my $fasta = shift;
open LIST, $list;
open FAS, $fasta;

my $contig1=0;
my $contig2=0;

my $match = 200;
my $identity = 97;
my $tail = 200;


my %fas = GetData::loadfasta($fasta);

my %scaffs;


while (<LIST>) {
	split (/\s+/);
	my $scaff = $_[0];
	my $contig = $_[1];
	push(@{$scaffs{$scaff}}, $contig);
}

foreach my $scaff (keys %scaffs) {
#	print "I'm reoverlapping $scaff";# <STDIN>;
	next if scalar @{$scaffs{$scaff}} == 1;
	my $total = (scalar @{$scaffs{$scaff}})-1;
	for (my $index = 0; $index < $total; $index++) {
		 $contig1 = $scaffs{$scaff}[$index];
		 $contig2 = $scaffs{$scaff}[$index+1];
		
		# HERE CREATE FASTA FILES FOR CONTIGS 1 and 2		
		open (FILE1, ">$contig1.fasta");
		open (FILE2, ">$contig2.fasta");
	print FILE1 ">$contig1\n$fas{$contig1}\n";
	print FILE2 ">$contig2\n$fas{$contig2}\n";
	close (FILE1);
	close (FILE2);

my $nucmer = "nucmer --maxmatch -l 35 -c 200 --prefix=$contig1.vs.$contig2 $contig1.fasta $contig2.fasta; wait";
my $showcoords = "show-coords -H -c -l -o -r -L $match -I $identity $contig1.vs.$contig2.delta | nucmerAnnotate -ignore $tail | egrep 'BEGIN|END' > $contig1.vs.$contig2.coords";

		system("$nucmer");
		system("$showcoords");
#		print "Check showcoords\n"; #<STDIN>;

	if (-z "$contig1.vs.$contig2.coords") {
	system `rm -fr $contig1.vs.$contig2.* $contig1.fasta $contig2.fasta`;
	}


	}
=pod
		my $result = `cat $contig1.vs.$contig2.coords`;

		if ($result) {
			print "have overlap\n$result\n"; <STDIN>;
			chomp $result;
			my @line = (split /\s+/, $result);
			my $ovl = $line[6];


# sort out the tails
			my $con1pos1 = $line[0];
			my $con1pos2 = $line[1];
			my $con2pos1 = $line[3];
			my $con2pos2 = $line[4];

# recalculate the lengths and make new merged sequences
			my $len1 = $line[11];
			my $len2 = $line[12];
			my $seq1 = $seq{$contig1};
			my $seq2 = $seq{$contig2};
			my $begin = $seq1;
			my $end = substr($seq1, $ovl+1); # start position is ovl+1 to the end of seq2;
			my $newseq = $begin.$end;
=cut
		
	
}
