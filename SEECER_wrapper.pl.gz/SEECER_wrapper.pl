use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  SEECER_wrapper.pl  kmer reads_1 reads_2 

This script produces 



';

}



my $kmer = shift;
my $file1 = shift;
my $file2 = shift;


unless ($kmer=~/^\d+$/) {
    die 'kmer have to be a digit';
}


# if file is .gz, unzip here

my $zip = 0;
my $base;
my $f1;
my $f2;

# unzip GZIPPED files


if ($file1=~/\.gz$/) {
    # unzip
    $zip = 1;
    my @arr = split(/\//,$file1);
    $arr[-1]=~s/\.gz//;
    print "gunzip -c $file1 > $arr[-1] \n";
    $f1 = $arr[-1] ;

    my @arr2 = split(/\//,$file2);
    $arr2[-1]=~s/\.gz//;
    print "gunzip -c $file2 > $arr2[-1] \n";
    $f2 = $arr2[-1]; 


    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;

    #print "\n$base\n";

}

elsif ($file1=~/\.fastq$/) {
    # nothing
    my @arr = split(/\//,$file1);
    my @arr2 = split(/\//,$file2);
    
    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;
    $base =~s/\.\././g;

}




# make seecer input and bsub
#
open (SH, ">$base\_$kmer.seecer.sh");


if (-d "$base\_$kmer") {
    die  "\nFolder $base\_$kmer already exists, pelase try different files or different kmer, or delete this folder\n\n";
}
else {
    mkdir "$base\_$kmer";
}

print "\n\n";


if ($zip == 1) {
    print SH "bsub.py 8 $base\_$kmer\_1  bash ~/bin/SEECER-0.1.2/SEECER/bin/my_run_seecer.sh -t $base\_$kmer -k $kmer $f1 $f2\n";
}

elsif ($zip == 0) {
    print SH "bsub.py 8 $base\_$kmer\_1 bash ~/bin/SEECER-0.1.2/SEECER/bin/my_run_seecer.sh -t $base\_$kmer -k $kmer $file1 $file2 \n";
}




open (OUT3, ">$base\_$kmer.seecer2.sh");

print OUT3 "# preprocessing for khmer\n";

print OUT3 "rm -f $base\_1.fastq_N $base\_1.fastq_N \n";
print OUT3 "rm -fr  $base\_$kmer\n";

print OUT3  "~mh12/git/python/fastn_shuffle.py   $file1\_corrected.fa   $file2\_corrected.fa   $base.fasta\n";

print OUT3 "rm -f $file1\_corrected.fa   $file2\_corrected.fa \n";



print SH "bsub.py --dep=\"$base\_$kmer\_1\" -q normal 2 $base\_$kmer\_2 sh $base\_$kmer.seecer2.sh\n";

close (SH);
close (OUT3);


print "bsubbing jobs:  sh $base\_$kmer.seecer.sh\n\n";
system "sh $base\_$kmer.seecer.sh\n\n";

exit ;

=pod

Trying to read:
DjF3_294733_whole.9234_6#11.    10.80.no_polyA      fastq _1.fastq_corrected.fa
Should read:
DjF3_294733_whole.9234_6#11.    fastq.  10.80.no_polyA    _1.fastq_corrected.fa

DjF3_294733_whole.9234_6#11.fastq.10.80.no_polyA_1.fastq


