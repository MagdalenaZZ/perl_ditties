#!/usr/local/bin/perl -w
#
use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die '


mz3 script for giving new nice names to genes in a gff-file



Usage 1 - I have no names: 
perl ~/bin/perl/gff_nice_names.pl gff  prefix  <starting number>

Usage 2 - I have a list of names to use :
perl ~/bin/perl/gff_nice_names.pl gff  list


List:
old_name1    new_name1
old_name2    new_name2
old_name3    new_name3



'
}

my $mode = 0;



# open the file

my $gff = shift;
my $prefix = shift;
my $nno = shift;

if (-s $prefix) {
    $mode = 2;
    print "\nMode 2\n";
}
elsif ($prefix=~/\w+/ and $nno=~/\d+/) {
    $mode =1;
    print "\nMode 1\n";
}
else {
    die "\nI dont understand which mode you are trying to use, please refer to usage\n\n";

}

#my $gff = shift;


	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

    	open (OUT, ">$gff.nice") || die "I can't open $gff.nice\n";
        open (OUT2, ">$gff.nice.key") || die "I can't open $gff.nice.key\n";

#	my @gff = <GFF>;


### Mode 1
        
if ($mode=~/1/) {

# parse the array

    unless ($nno=~/\w+/) {
      $nno = "000000000";
    }

    my $new_name = "ID=$prefix" . "_" . "$nno";

    foreach my $line (@gff) {
    chomp $line;

        my @arr=split(/\t/, $line);


        if ($arr[2]=~/gene/) {
            my $count = 0;
            while ($count < 100) {
                $nno++;
                $count++;
            } 
            $new_name = "ID=$prefix" . "_" . "$nno";
            print OUT2 "$arr[8]\t$new_name\n";
            $arr[8]=$new_name;
            my $gene = join("\t", @arr);
        }

        elsif ($arr[2]=~/mRNA/) {
            my @arr8mrna=split(/;/, $arr[8]);
            # fix gene name
            $arr8mrna[0]=$new_name . "\.1";
            # fix parent name
            my $new_arr8mrna1=$new_name;
            $new_arr8mrna1=~s/ID=/Parent=/;
            $arr8mrna[1]=$new_arr8mrna1 ;
            # check result 
            $arr[8] = join(";", @arr8mrna);
        }

        elsif ($arr[2]=~/CDS/) {      
            # fix CDS name
            my @arr8cds=split(/:/, $arr[8]);
            $arr8cds[0]=$new_name;
            # fix parents name       
            my @new_arr8cds= split(/=/,$arr8cds[2]);
               $new_name=~s/ID=//;
            $new_arr8cds[1]=$new_name . "\.1";
            my $new = join ("=", @new_arr8cds);
            $arr8cds[2]=$new;
            $arr[8]=join (":", @arr8cds);
            unless ($arr[8]=~/ID=/) {
                $arr[8]="ID=" . "$arr[8]";
            }
        }

        else {
            print "WARN: something wrong with line $line\n";
        }

        my $new_line=join("\t", @arr);
        print OUT "$new_line\n";
    }

}






elsif ($mode=~/2/) {


    # read in the list

    open (LIST, "<$prefix") || die "I can't open $prefix\n";

    my %h;
    while (<LIST>) {
        chomp;
        #print "$_\n";
        my @arr = split(/\t/,$_);
        if ($arr[1]=~/\w+/) {
            $h{$arr[0]}=$arr[1];
        }
        #print "old $arr[0]\tnew $arr[1]\n";
    }

    
# parse the array

    my $new_name=0;

    foreach my $line (@gff) {
    chomp $line;

        my @arr=split(/\t/, $line);


        if ($arr[2]=~/gene/) {
            
            $arr[8]=~s/^ID=//;
            # check if it exists
            #print "$arr[8]\n";
            
            # replace
            if (exists $h{$arr[8]}) {
                #print "$arr[8]\t$h{$arr[8]}\n";
                $new_name = $h{$arr[8]};
                $arr[8]="ID=" . $h{$arr[8]};
                #print "NEW $new_name\n";
            }
            else {
                $new_name = $arr[8];
                $arr[8]="ID=" . $arr[8];
                #print "OLD $new_name\n";
            }

        }

        elsif ($arr[2]=~/mRNA/) {
            #print "1    $arr[8]\t$new_name\n";
            my @arr8mrna=split(/;/, $arr[8]);
            # fix gene name
            $arr8mrna[0]= "ID=" . $new_name . "\.1";
            # fix parent name
            my $new_arr8mrna1= $new_name;
            $new_arr8mrna1=~s/ID=/Parent=/;
            $arr8mrna[1]="Parent=" . $new_arr8mrna1;
            # check result 
            $arr[8] = join(";", @arr8mrna);
            #print "2    $arr[8]\n";
        }
        elsif ($arr[2]=~/CDS/ || $arr[2]=~/exon/) {      
            # fix CDS name
            my @arr8cds=split(/:/, $arr[8]);
            $arr8cds[0]=$new_name;
            # fix parents name       
            my @new_arr8cds= split(/=/,$arr8cds[2]);
               $new_name=~s/ID=//;
            $new_arr8cds[1]=$new_name . "\.1";
            my $new = join ("=", @new_arr8cds);
            $arr8cds[2]=$new;
            $arr[8]=join (":", @arr8cds);
            unless ($arr[8]=~/ID=/) {
                $arr[8]="ID=" . "$arr[8]";
            }
        }
        else {
            #print "WARN: something wrong with line $line\n";
        }

        my $new_line=join("\t", @arr);
        print OUT "$new_line\n";
    }

}

else {
    print "This is impossible\n"; die;
}




close (OUT);
close (OUT2);


exit;

__END__

    EmuJ_000037200
         004000000
