#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/SAM_pick_scaffolding_reads.pl SAM/BAM 

Ex:




';

}

__END__


my $in = shift;
my @flags = @ARGV;

my @arr1 = split (/\//, $in);

my $out = "$arr1[-1].filtered.sam";

unless ( $in=~/sam/) {
    print "\n Making SAM-file $in.sam \n";
    system "samtools view -h $in > $arr1[-1].sam ";
    $in = "$arr1[-1].sam";
    print "New in: $in\n";
}

 open (IN, "<$in") or die 'Cant find infile $in ';



# my @in = <IN>;

my %h;

foreach my $elem (@flags) {
    $h{$elem}=1;
    print "FLAG:$elem\n";
}

print "Outfile: $out\n";
 open (OUT, ">$out") or die 'Cant find outfile $out ';


 while (<IN>) {
     my @arr = split(/\s+/, $_);
#     print "$arr[1]\n";

     if ( exists $h{ $arr[1] } ) {
        print OUT "$_";
     }
    
}


close (IN);
close (OUT);



 open (IN2, "<$out") or die 'Cant find outfile $out ';

    system "cat $out | perl ~tdo/Bin/sam2fastq.2files.pl ForScaffold";

close (IN2);



open (IN2, "<$out") or die 'Cant find outfile $out ';




close (IN2);











