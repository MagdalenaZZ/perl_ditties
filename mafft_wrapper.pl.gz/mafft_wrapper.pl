#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: mafft_wrapper.pl input


'
}


	my $in = shift;
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

    # translate sequence names


while (<IN>) {


}
