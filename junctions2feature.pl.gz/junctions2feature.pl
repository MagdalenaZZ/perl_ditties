#!/usr/bin/perl
use strict;
use Clone qw(clone);

unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/junctions2feature.pl $fas $in.$cov.$anc.gff $cov $anc

Read the junctions file, and make groups of junctions



';

}



my $fas = shift;
my $in = shift;
#my $cov = shift;
#my $anc = shift;



#### read the junctions file, and make groups of junctions



# Make fasta single-line
unless (-s "$fas.sl") {
    print "fasta2singleLine.py $fas $fas.sl\n";
    system "fasta2singleLine.py $fas $fas.sl";
}


# Get fasta sequences
#
open(FAS, "<$fas.sl") || die "Cant read file $fas.sl";

my %fas;

while (<FAS>) {
    chomp;
    #print "$_\n";
    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head}= $seq;
    }

}



# read in the junctions

my @res;

open(JN, "<$in") || die "\nCant read file $in, check that it has been produced by wiggleJunkie.pl\n\n";
open(OUT, ">$in.introns") || die "\nCant read file $in.introns, check that it has been produced by wiggleJunkie.pl\n\n";


# read in all junctions and give them orientations

while (<JN>) {
    chomp;
    #print "$_\n";
    my @arr = split(/\t/, $_);
    if (exists $fas{$arr[0]}) {

        $arr[2]= "intron";
        my $len = length($fas{$arr[0]});
        #print "Len $len\n";
        my $last = $arr[4]-2;
        my $left = substr( $fas{$arr[0]}, ($arr[3]-1 ), 2 );
        my $right = substr( $fas{$arr[0]}, $last, 2 ); 
        #print "$arr[8]\t$left\t$right\n";

        # check which orientation they are

        if ($left =~/gt/i and $right=~/ag/i) {
            $arr[6]='+';
        }
        elsif ($left =~/ct/i and $right=~/ac/i) {
            $arr[6]='-';
        }
        elsif ($left =~/gc/i and $right=~/ag/i) {
            $arr[6]='+';
        }
        elsif ($left =~/ct/i and $right=~/gc/i) {
            $arr[6]='-';
        }
        elsif ($left =~/gt/i and $right=~/at/i) {
            $arr[6]='+';
        }
        elsif ($left =~/at/i and $right=~/ac/i) {
            $arr[6]='-';
        }
        else {
            print "Cant determine orientation of strand: $arr[8]\t$left\t$right \n";
            $arr[6]='NA';
        }

        unless ($arr[6]=~/NA/) {
            my $newl = join("\t", @arr);
            push(@res, $newl);
            #print "Made $newl\n";
        }



    }
    else {
        print "Warning: Contig $arr[0] does not exist in fasta\n";
    }
}


my @sorted = sort { (split '\t', $a)[3].(split '\t', $a)[4] <=> (split '\t', $b)[3].(split '\t', $b)[4] } @res;
@res = @sorted;


foreach my $elem (@res){
    print OUT "$elem\n";
}

undef @res;




##################################################
##################################################
##################################################
##################################################
##################################################




#print "Hi $in.introns\n";

#### Time to scaffold the introns together


# combine the results to transcript-groups by finding overlapping ones

open(IN2, "<$in.introns") || die "Cant read file $in.introns, check that it has been produced";
my @in2 = <IN2>;


my @res;

foreach my $ele (@in2) {
    chomp $ele;
    push (@res, $ele);
    #print "$ele\n";
}



my $i = 1;
my $is = 10000000;
my $ie = 0;
my $strand="+";
my %groups;
my %unassigned;
my $lastl = shift(@res);
my $first=0;
my $ext = 0;

foreach my $line (@res) {
    chomp $line;
    #print "$line\n";
    
    my @ar1 = split(/\t/, $line);
    my @ar2 = split(/\t/, $lastl);
    my $scaf=$ar1[0];
    

# make the first feature
    if ($first=~/^0$/) {
        $is = $ar2[3] ;
        $ie = $ar2[4] ;
        $first=1;
        #print "Feature $i initiated to $is $ie, scaff $scaf\n";

        # add feature to group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$lastl");
        push (@{$groups{$scaf}{$i}{F}},"$line");
        #print "$lastl\n";
        #print "$line\n";

        # set strand if I can
        if ( $ar1[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar1[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }
        if ( $ar2[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar2[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }


    }


# if different strand on introns switch strand, and make a new feature
    elsif ( $ar1[1]=~/FromBam/ and  $ar1[6]!~/\Q$strand\E/    ) {
#        push ( @{ $groups{$ar1[0]}{$i} } , $lastl );
            #$is = $ar1[3];
            #$i++;

            # start a new feature

            $i++;
            $is = $ar2[3] ;
            $ie = $ar2[4] ;
            $lastl=~s/\t$strand\t/\t$ar1[6]\t/;
            $strand=$ar1[6];

            #print "Feature $i switch $strand \n$lastl\n$line\n";

            # claim the previous line too
            $groups{$scaf}{$i}{SE}="$is\t$ie";
            $groups{$scaf}{$i}{ORI}="$strand";
            push (@{$groups{$scaf}{$i}{F}},"$lastl");
            push (@{$groups{$scaf}{$i}{F}},"$line");
    }

    
    # replace the orientation on feature
    elsif ($ar1[1]=~/FromBed/) {
        $ar1[6]=$strand;
        $line=join("\t", @ar1);
    }





# merge overlapping features
    elsif ( ($ar1[3]-100 ) < $ie) {
        my $ovl = ($ar1[3] ) -  $ie ; 
        #print "   overlapping \t $is $ie \t $ar1[3] $ar1[4] $ovl\n";
        #$ext = 1;
        #
        #
        # if extension happended, update the feature length
 
        my $min = $is;
        my $max = $ie;
        my $min2 = ($ar1[3], $min  )[$ar1[3] > $min ];
        my $ie2 = ($max, $ar1[4])[$max < $ar1[4]];
        $is = $min2;
        $ie = $ie2;
        #print "Feature $i extended to $is $ie\n";

        # add feature to group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$line");

        # add orientation
        if ( $ar2[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar2[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }


    }

# Initiate a new feature
    else {
        my $ovl = ($ar1[3] ) -  $ie ; 
        #print "   else        \t\t$ar1[3]  $ar1[4]  $is $ie  $ovl\n";
        #$ext = 0;



        # now when there is no extension, I have to create a new feature
        $i++;
        $is = $ar1[3] ;
        $ie = $ar1[4] ;
        #print "Feature $i initiated at $is $ie\n";

       # add feature to new group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$line");


    }




    $lastl=$line;

}




# print the resulting intron-groups

# The grouped ones
open(OUT, ">$in.trans.gff") || die "Cant read file $in.trans.gff";
print "\nls -l $in.trans.gff \n";

# The un-grouped ones
open(OUT2, ">$in.trans.left.gff") || die "Cant read file $in.trans.left.gff";
print "\nls -l $in.trans.left.gff \n";

foreach my $scaf (sort keys %groups) {

    #print "$scaf\n";
    
    foreach my $i (sort { $a <=> $b }  keys %{$groups{$scaf}}) {



        #foreach my $key (sort { $a <=> $b }  keys %{$groups{$scaf}{$i}}) {
        my $coord =$groups{$scaf}{$i}{"SE"};
        my $ori =$groups{$scaf}{$i}{"ORI"} ;
        #print "$scaf\t$i\t$coord\n";


        my @int = @{ $groups{$scaf}{$i}{"F"} };


        #foreach my $ele (@int) {
            #print "$ele\n";
            #}

# for sets of overlapping introns print them gff.trans.gff            
        if (scalar(@int)> 1) {

            # make gene


            #my $first = @int[0];
            my $last = @int[-1];
            #my @min = split(/\t/,$first);
            my @max = split(/\t/,$last);
            #my $min = $min[3];
            #my $max = $max[4];
            if ($ori=~/^\.$/) {
                $ori = $max[6];
            }

            if ($ori=~/^$/) {
                #print "No ori\n";
                $ori="\.";
            }    
    
            print OUT "$scaf\tassigned\tgene\t$coord\t.\t$ori\t.\tID=$i\n";
            print OUT "$scaf\tassigned\tmRNA\t$coord\t.\t$ori\t.\tID=$i.1;Parent=$i\n";

            system "rm -f $in.tmp.gff ";
            open(OUT3, ">$in.tmp.gff") || die "Cant read file $in.tmp.gff";
            foreach my $ele (@int) {
                print OUT3 "$ele;Parent=$i.1\n";
                print "$ele;Parent=$i.1\n";
            }

            close (OUT3);
            system "cat $in.tmp.gff >> $in.tmp";

            # remove the part of an exon overlapping with an intron.trans.left.gff 
            system "cat $in.tmp.gff | grep intron > $in.tmp.gff.intron ";
            system "cat $in.tmp.gff | grep CDS > $in.tmp.gff.CDS ";
            system "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/subtractBed  -a $in.tmp.gff.CDS -b $in.tmp.gff.intron  > $in.tmp.gff2";
            
            open(OUT4, "<$in.tmp.gff2") || die "Cant read file $in.tmp.gff2";
            my @intx=<OUT4>;
            close (OUT4);

            foreach my $elex (@intx) {
                chomp $elex;
                $elex=~s/\t\+\t/\t$ori\t/;
                $elex=~s/\t\-\t/\t$ori\t/;
                $elex=~s/\t.\t.\t.\t/\t\.\t$ori\t\.\t/;
                my @elex2 = split(/;/, $elex);
                
                print OUT "$elex2[0];Parent=$i.1;$elex2[1];\n";
                print "$elex2[0];Parent=$i.1;$elex2[1];\n";

            }
        }
# these introns do not overlap with any other introns
        else {

            my $int = join("\t", @int);
            
            # print leftovers in separate file

            if ( $int =~/intron/) {
                my $len2 = scalar(@int);
                print OUT2 "@int\n";
            }
            else {
                # filter strange things
            }

        }
    }

}

$i++;
close (OUT);
close (OUT2);



unless (-e "junctions2feature") {
    mkdir "junctions2feature";
}

#system "mv $in.gff junctions2feature ";

print "\nls -l  $in.tmp.gff \n";
print "\nls -l   $in.tmp \n";
print "\nls -l  $in.tmp.gff.CDS \n";
print "\nls -l   $in.tmp.gff.intron \n";



system "rm -f $in.tmp.gff ";
system "mv  $in.tmp junctions2feature";
system "mv $in.tmp.gff.CDS junctions2feature";
system "mv   $in.tmp.gff.intron junctions2feature";

exit;




















