#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta_cut_bases.pl input.fasta int

Takes a fasta-file and cuts start and end of sequences by int length


'
}

	my $in = shift;
	my $cut = shift;
	open (IN, "$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my $line2 = 0;

foreach my $line (@in) {

	my $new_line = 0;
	if ($line2 =~/>/) {
#matches $line seq
#matches $line2 name
	my $length = length($line);
	my $cutlength = ($length -  (2*$cut) -1);
#	print $line2;
	$new_line = substr($line, $cut,  $cutlength); 
#	print $line2;
#	print $new_line;
print $line2;
print "$new_line\n";
	}
	elsif ($line =~/>/)   {
#matches $line name
#	print $line2;
	}
	else {
	print "Error close to here: $line";	
	}


$line2 = $line;

#print $line2;
#print "$new_line\n";
}

#my $size = length($name)

#$portion = substr($string_variable, start number, length); ...