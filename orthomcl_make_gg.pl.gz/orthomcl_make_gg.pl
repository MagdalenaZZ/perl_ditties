#!/usr/bin/perl -w
use strict;
use Cwd;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: orthomcl_make_gg.pl outprefix fasta-files

This script takes fasta-input and makes orthomcl files and gives instructions for how to run it


'
}


my $prefix = shift;
#my $ori1 = shift;
#my $ori2 = shift;
#my $ori3 = shift;
#my $ori4 = shift;
#my $ori5 = shift;
#my $in = "$ori1,$ori2,$ori3,$ori4,$ori5";

my $in = shift;
my $in2 = "$prefix.all.fa";
# my $result = sub constructAllFasta( $in,$in2 );
my $ORTHOMCL_DATA_DIR = "/lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL";
my $genome_gene_file = "$prefix.my.gg";
my @taxa;
my %gindex;
my %gindex2;

#print "In1:$in:\n";
#print "In2:$in2:\n";

my $cwd = cwd();

print "Cwd:$cwd:\n";



# Two arguments:
# 1. String Variable: Fasta file names, each representing one species, separated by comma, e.g. "Bme.fa,Ccr.fa,Eco.fa"
# 2. String Variable: Name of All_Fasta file
# Last modified: 10/02/06
# sub constructAllFasta {
	my $fa_files = $in;
	my $all_fa_file = $in2;
	my %seq_len;

	my @fafiles=split (",",$fa_files);


my $fas=join (" ",@fafiles);
print "Fasta-files:$fas:\n";

system "cat $fas > $prefix.all.fa"; 
print "Finished merging infiles\n";
system "makeblastdb -in $prefix.all.fa -dbtype prot -parse_seqids";
print "Finished making a blastdb\n";

	my $totalgeneno=0;
	open (ALLFA,">$all_fa_file") or dieWithUnexpectedError("can't write to $all_fa_file!");
	foreach my $fafile (sort @fafiles) {
		print "Reading $fafile\n";
		open (FA,$fafile) or die("can't open $fafile!");
		$/='>';
		my $taxon=(split (".fa",$fafile))[0];
		push (@taxa,$taxon);
		while (<FA>) {
			next unless ($_ ne '>');
			$_=~s/\>$//;
			$_=~s/\r|\n$//;
#			chop $_;
			print ALLFA ">$_\n";
			my @lines=split(/\r|\n/,$_);
			my $id=shift @lines;
			my $len=length(join('',@lines));
			$seq_len{$id}=$len;
			push (@{$gindex{$taxon}},$id);
		}
		close (FA);
		$/="\n";
		foreach (@{$gindex{$taxon}}) {$gindex2{$_}=$taxon;}
		$totalgeneno+=@{$gindex{$taxon}};
	}
	close (ALLFA);
	open (GG,">$genome_gene_file");

	foreach my $taxon (@taxa) {
		print GG "$taxon:";
		foreach (@{$gindex{$taxon}}) {
			print GG " $_";
		}
		print GG "\n";
	}

	close (GG);

#	write_log("\nFASTA file <$all_fa_file> (".@fafiles." genomes, $totalgeneno sequences) generated!\n\n");
#	return \%seq_len;
# } ## constructAllFasta


	open (OUT, ">commands.out") || die "I can't open commands.out\n";

print OUT "BLAST-command:/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=10 --splitmem=10 --protein_ref  $cwd\/$prefix.all.fa $cwd\/$prefix.all.fa $prefix\_out 1000000 -e 1e-05 -p blastp -m 8 -b 100000 -v 100000 \n";
print OUT "OMCL-command: team133-bsub.pl normal 10 $prefix.o $prefix.e $prefix orthomcl.pl --mode 3 --blast_file out\/all.blast --gg_file $prefix.my.gg -m8blast\n";
# print "OMCL-command chado: \n";

	close (OUT);


if (-s  "$prefix.all.fa" and -s "$prefix.my.gg" and -s "$prefix.all.fa.phr" and -s "$prefix.pin" and -s "$prefix.psd" and -s "$prefix.psq")
{
print "All output seems to have formed correctly, so I\'m submitting the BLAST-jobs for you now \n Use the orthoMCL-command in the command.out file when the BLAST-jobs have finished\n";
#system "/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=10 --splitmem=10 --protein_ref  $cwd\/$prefix.all.fa $cwd\/$prefix.all.fa $prefix\_out 1000000 -e 1e-05 -p blastp -m 8 -b 100000 -v 100000";
} 

else {
	print "Warning: Some file was not properly formed, please check the output before proceeding\n";
}

#if (-e $prefix.my.gg and -e $prefix\_out\/all.blast)
#{
 
#} 


__END__
############### for OMCL ##############################

/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=10 --splitmem=10 --protein_ref /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.fa /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.fa all_out 1000000 -e 1e-05 -p blastp -m 8 -b 100000 -v 100000

can increase number of sequences because database is small


team133-bsub.pl normal 10 test.o test.e test orthomcl.pl --mode 3 --blast_file /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.blast --gg_file /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.gg


/nfs/users/nfs_m/mh12/git/python/blast_splitter.py --combinemem=10 --splitmem=10 --protein_ref /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/test/test.all.fa /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/test/test.all.fa test_out 1000000 -e 1e-05 -p blastp -m 8 -b 100000 -v 100000


team133-bsub.pl basement 25 om2.o om2.e om2 orthomcl.pl --mode 3 --blast_file /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.blast --gg_file /lustre/scratch101/sanger/mz3/gene_pred/EMUv3/augustus/testOCL/all.gg -m8blast pi_cutoff=100