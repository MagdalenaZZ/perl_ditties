#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die '
Usage: perl ~/bin/perl/augustus_fix_gff-coords.pl input.gff augustus.aa augustus.codingseq

Sequences as single lines

Example:
perl ~/bin/perl/augustus_fix_gff-coords.pl head.res head.AUGUSTUSnoH.aa head.AUGUSTUSnoH.codingseq


'
}

my $gff = shift;
my $aa = shift;
my $cs = shift;

	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (AA, "<$aa") || die "I can't open $aa\n";
	my @aa = <AA>;
	close (AA);

	open (CS, "<$cs") || die "I can't open $cs\n";
	my @cs = <CS>;
	close (CS);

	open (ERR, ">$gff.errors") || die "I can't open $gff.errors\n";



# Make a hash with gene-name {aa} {cs} {coord} 

my $gene; 
my %hash;
#my @list;
my %hash1;

foreach my $line (@gff) {
chomp $line;

my @arr1=split(/\s+/, $line);
#my @arr=split(/\s+/, $lastline);
    if ($arr1[2]=~/gene/) {
        $arr1[8]=~s/ID=//;
        #print "GENE_NAME:$arr1[8]:\n";
        $hash1{$arr1[8]}= $arr1[8];
    }
}


foreach my $line (@aa) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
        #print "Gene:$gene\n";
	}
	else  {
		$line=~s/\*//;
		if (exists $hash1{$gene}) {
            $hash{$gene}{aa}=$line;
            #print "$gene AA\n";
        }
	}

}

foreach my $line (@cs) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
        #print "Gene:$gene\n";
	}
	else  {
  		if (exists $hash1{$gene}) {
    		$hash{$gene}{cs}=$line;
#            print "$gene CS\n";
    	}
    }

}


#print "Middle\n";

foreach my $key (keys %hash) {

# print "HASHkey:$key:\n";
# print "Protein $hash{$gene}{aa}\n";
# print "Seq $hash{$gene}{cs}\n";

	open (TEMP, ">temp.fas") || die "I can't open temp.fas\n";
	print TEMP ">$gene\n$hash{$key}{cs}\n";
	close (TEMP);

#	print ERR "$key\t";
	system `transeq -sequence temp.fas -outseq temp.pep >& temp.err`;
#	print "$key\t";
	system `~mh12/git/python/fasta2singleLine.py temp.pep temp.sl.pep`;

#print "Trans:" . `transeq $hash{$gene}{cs}` . "\n";
	open (TEMP2, "<temp.sl.pep") || die "I can't open temp.sl.pep\n";
	my @temp2 = <TEMP2>;
	close (TEMP2);
#	print "$temp2[0]$temp2[1]";

#count the bases

	my $b_count = $hash{$key}{cs} =~ tr/[acgtnACGTN]//;
	my $third = ($b_count/3) - 1;
	my $a_count = $hash{$key}{aa} =~ tr/[A-Z]//;
#	my $GC_count = $line =~ tr/GgCc//;

#	print ERR "$key\t$b_count\t$a_count\t$third\n";
# $hash{$key}{aa}\n$hash{$key}{cs}\n";

	 if ($third==$a_count) {
#		print "$key length correct $third\n";
		if ($hash{$key}{aa}=~/X$/) {
			$hash{$key}{coord}="0";   #warn not X
#			print ERR "WARN:$key length only correct with X in seq $third = this gene finishes on taa stop codon \n";
		}
        elsif ($hash{$key}{aa}=~/X/) {
			print ERR "WARN:$key has stop codon in coding sequence\n";
			$hash{$key}{coord}="4";   #warn has stop codon
        }
		else {
			$hash{$key}{coord}="0";
		}
    }
    #elsif ($third==($a_count-1)) {
        
    #}
	 else {
		if ( $third=~/333333/) {
#		print "$key -1\n";
		$hash{$key}{coord}="-1";
		}
		elsif ($third=~/666666/) {
#		print "$key -2\n";
		$hash{$key}{coord}="-2";
		}
		else {
			print ERR "WARN: $key length not correct $third because sequence is missing stop codon\n";
		    $hash{$key}{coord}="3";  #warn has correct third, but not right count
		}
	}

# compare the bases 

	chomp $temp2[1];  #temp2[1] is the translated amino acid
    # if there are stop codons in coding sequence, translate them to X
    if ($temp2[1]=~m/\*\w/) {
        $temp2[1]=~s/\*/X/g;
        $temp2[1]=~s/X$/\*/;
#        print "TEMP:$temp2[1]:\n";
    }
	$temp2[1]=~s/\*//g;
#	$temp2[1]=~s/X$/\*/g;
	$hash{$key}{aa}=~s/\*//g;
#    $temp2[1]=~s/\*//g;
	# If the sequences are identical - good
	if ($hash{$key}{aa}=~/$temp2[1]/ and $temp2[1]=~/$hash{$key}{aa}/) {
#		print "ID:$key\n$hash{$key}{aa}\n$temp2[1]\n";	
		$hash{$key}{off}="identical";
	}
	# if the sequence is contained, but probably just stop different
	elsif ($temp2[1]=~/$hash{$key}{aa}/) {
		$hash{$key}{off}="end";	
#		print "NOT SAME STOP:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
	}
	# if the sequences are different - bad
	else {
#		print "NOT SAME START:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
		$hash{$key}{off}="start";	
		

	}
#	close (TEMP2);

#close (TEMP);


}

#__END__
########### Fix the gene #################
my $firstCDS=0;
my $lastline="0\t0\t0\t0\t0\t0\t0\t0\t0";
push(@gff, "0\t0\tgene\t0\t0\t0\t0\t0\t0");
push(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
# unshift(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
my $end=0;
	open (GFF2, ">$gff.corrected") || die "I can't open $gff.corrected\n";


my $lasttag=0;

foreach my $line (@gff) {
chomp $line;


my @arr1=split(/\t/, $line);
my @arr=split(/\t/, $lastline);


# my $lasttag=0;
my $cds;
# print "LINE:$line\n";

	if ($arr1[2]=~/gene/) {
		#lastline is final CDS
		if ($lasttag=~/mRNA/) {
			$lasttag="singleCDS";
#			print "LINE:$line:\n";
#			print "LAST:$lastline:\n";
#			print "$lasttag\n";
		}
		else {
			$lasttag="finalCDS";
#			print "LINE:$line:\n";
#			print "LAST:$lastline:\n";
#			print "$lasttag\n";
		}
	}
	elsif ($arr1[2]=~/mRNA/) {
		#lastline is gene
		$lasttag="gene";
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

	}
	elsif ($arr1[2]=~/CDS/) {
		#lastline is mRNA and current CDS = firstCDS
		if ($arr[2]=~/mRNA/) {
			$lasttag="mRNA";
			# current line is firstCDS!
			$firstCDS=1;
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
		#lastline is CDS and current line CDS = middleCDS
		elsif ($arr[2]=~/CDS/ and $firstCDS=~/1/) {
			$lasttag="firstCDS";
			$firstCDS=0;
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
		elsif ($arr[2]=~/CDS/ and $firstCDS=~/0/) {
			$lasttag="middle";
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
				
	}
	elsif ($arr1[2]=~/^0$/) {
	}
	else {
		print "ERROR: $line\n";
	}

#	$lastline=$line;
#} # temp end



############## Get keys for lastline ##############################
my $key=0;

	if ($arr[2]=~/gene/) {
		$arr[8]=~s/ID=//;
		$key=$arr[8];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/mRNA/) {
		my @new =split(/;/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/CDS/) {
		my @new =split(/:/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/0/) {
		# do nothing
	}
	else {
		print ERR "ERROR: $line\n";
	}

	$lastline=$line;

# print "KEY:$key:\n";
#
  	$arr[8]=~s/ID=//;
    $arr[8]="ID=" . "$arr[8]";
    #  $arr[8]=~s/\t/ /;


################# fix tailing product tabs and spaces #################################################
    #
       my $length1 =(scalar(@arr) -1 );
        
       if ($length1 > 9 and $arr[2] =~/gene/) {
				my $new3 = join("\t", @arr);
#				print  "$new3\n";
                my @slice1= @arr[0..8];
                my @slice2= @arr[9..$length1];
                my $tail = join("\t", @slice2);
                $tail=~s/\t/ /;
                $tail=~s/\"\ \//\"\t\//;
                #  print "TAIL:$tail\n";
                my @slice3 = split(/\t/, $tail);
                #push (@slice1, "\t");
                push (@slice1, @slice3);
                @arr=@slice1;
	
       }

    #
##################################################################

	if ($key!~/^0$/ and $key=~/\w+/) {
		my $new;

		if (exists $hash{$key}{coord} and exists $hash{$key}{off}) {
		my $coord="$hash{$key}{coord}";	
		my $off="$hash{$key}{off}";

# All well
			if ($coord=~/0/ and $off=~/identical/) {
				$new = join("\t", @arr);
				print GFF2 "$new\n";
			}

########### positive strand ######################################################

# One off in start
			elsif ($coord=~/-1/ and $off=~/start/ and $arr[6]=~/\+/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] + 1);
					$arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
                    $new = join("\t", @arr);
					print GFF2 "$new\n";
                    # print "$new\n";

				}
# One off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}


# One off in end
# One off in end, but unaffected line
			elsif ($coord=~/-1/ and $off=~/end/ and $arr[6]=~/\+/) {
				if ( ($lasttag=~/finalCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
                    #
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust end with -1\n";
#					}
					$arr[4]= ($arr[4] - 1);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}


# Two off in start
# Two off in start, but unaffected line
			elsif ($coord=~/-2/ and $off=~/start/ and $arr[6]=~/\+/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust start with -2\n";
#					}
					$arr[3]= ($arr[3] + 2);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}

# Two off in end
# Two off in end, but unaffected line
			elsif ($coord=~/-2/ and $off=~/end/ and $arr[6]=~/\+/) {
				if ( ($lasttag=~/finalCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\tadjust end with -2\n";
#					}
					$arr[4]= ($arr[4] - 2);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}




############ negative values ################################


# One off in start
			elsif ($coord=~/-1/ and $off=~/start/ and $arr[6]=~/\-/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/finalCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust start with -1\n";
#					}
					$arr[4]= ($arr[4] - 1);
					$new = join("\t", @arr);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					print GFF2 "$new\n";
				}
# One off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}


# One off in end
# One off in end, but unaffected line
			elsif ($coord=~/-1/ and $off=~/end/ and $arr[6]=~/\-/) {
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust end with -1\n";
#					}
					$arr[3]= ($arr[3] + 1);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}

# Two off in start
# Two off in start, but unaffected line
			elsif ($coord=~/-2/ and $off=~/start/ and $arr[6]=~/\-/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust start with -2\n";
#					}
					$arr[3]= ($arr[3] + 2);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}

# Two off in end
# Two off in end, but unaffected line
			elsif ($coord=~/-2/ and $off=~/end/ and $arr[6]=~/\-/) {
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print ERR "$lasttag\t$key\t$arr[6]\t adjust end with -2\n";
#					}
					$arr[3]= ($arr[3] + 2);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in end, but unaffected line
				else {
					$new = join("\t", @arr);
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
					print GFF2 "$new\n";
					print ERR "$lasttag\t$key\t$arr[6]\t not adjusted\n";
				}
			}


# catch exceptions #######################
		    elsif ($coord=~/^4$/) {
                $new = join("\t", @arr);
                if ($lasttag=~/gene/) {
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
			    	print GFF2 "$new\t/note=\"stop codon in translation\"\n";
                }
                else {
			    	print GFF2 "$new\n";  
                }
                #  print "\n";
            }
		    elsif ($coord=~/^3$/) {
                $new = join("\t", @arr);
                if ($lasttag=~/gene/) {
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
			    	print GFF2 "$new\t/note=\"gene doesn\'t have stop codon\"\n";
                }
                else {
                    print GFF2 "$new\n";
                }
                #  print "\n";
            }
            else {
                if ($lasttag=~/gene/) {
			    	print ERR "WARN:$key has inconsistent values. This is because gene-model has multiple problems, for instance double stop-codons or extra bases. coord:$coord, off:$off, strand:$arr[6]\n";
                }
                $arr[8]=~s/ID=//;
                $arr[8]="ID=" . "$arr[8]";
                $new = join("\t", @arr);
                if ($lasttag=~/gene/) {
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
			    	print GFF2 "$new\t/note=\"gene-model has multiple problems, for instance double stop-codons or extra bases. Correct protein:$hash{$key}{aa}\"\n";
                }
                else {
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
                    print GFF2 "$new\n";
                }
			}

########################################
            # end of loop  (exists $hash{$key}{coord} and exists $hash{$key}{off}) 
		}
        # at this point, all EmW genes are manually curated, so I'm assuming that they are okay, even though I don't have seqs for them
		else {
            if ($arr[8]=~/EmW/) {
                    $arr[8]=~s/ID=//;
                    $arr[8]="ID=" . "$arr[8]";
                	$new = join("\t", @arr);
                    print GFF2 "$new\n";
                    if  ($lasttag=~/gene/) {
		    	        print ERR "WARN:$key contains EmW, so it is assumed to be correct\n";
                    }
            }
            else {
		    	print ERR "WARN:$key has something wrong with it\n";
            }
		}
	}
# end of loop 	if ($key!~/^0$/ and $key=~/\w+/) 
	else {
		print ERR "WARN:$key is not 0 or word\n";
	}

}




close (GFF2);

close (ERR);

system 'rm -f temp.pep temp.sl.pep temp.fas temp.err'; 




__END__
