use strict;
use warnings;


unless (@ARGV == 1) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: uniprot2ensembl_families.pl <list of UniProt IDs>


'
}



use Bio::EnsEMBL::Registry;

## Load the registry automatically
my $reg = "Bio::EnsEMBL::Registry";
$reg->load_registry_from_url('mysql://anonymous@ensembldb.ensembl.org');


# mz3 script to load in a list of uniprot-IDs and get out all the members of the gene-tree it belongs to

my $file = shift;

open (IN, $file) || die;
my @unis = <IN>;
close (IN);

open (OUT4, ">>$file.results") || die;

my $mems;
my $tot;
my %stat;

my %total;

foreach my $uni ( @unis ) {
# my $uni = $unis[0];
	chomp $uni;
    print "INPUT:  $uni\n";
	
	open (OUT, ">$uni.members.fas");

	$tot++;
    my $member;

	## Get the compara member adaptor
	my $member_adaptor = $reg->get_adaptor("Multi", "compara", "Member");

    if (defined $member_adaptor ) {
	## Get the member for SwissProt entry O93279
	     $member = $member_adaptor->fetch_by_source_stable_id("Uniprot/SWISSPROT", $uni);
    }
    else {
        print "Member_adaptor $member_adaptor cannot be defined\n";
        die;
    }

	if (defined $member) {
		open (OUT2, ">>$file.fas") || die;
		## Print the stable ID and the sequence
		print OUT2 ">", $member->stable_id, "\n";
		print OUT2 $member->sequence, "\n";

		$mems++;

		# find the gene CACNG1  ENSP00000226021

		## Get the compara member
		# my $member = $member_adaptor->fetch_by_source_stable_id("ENSEMBLGENE", "ENSG00000108878");


		# Get family adaptor
		my $family_adaptor = $reg->get_adaptor("Multi", "compara", "Family");
	
		# get family
		my $fams = $family_adaptor->fetch_all_by_Member($member);


		my $fam_mem;
		# go through those families

		foreach my $family ( @$fams ) {

	 		print OUT4 $uni . "\t" . $family->description, " (description score = ", $family->description_score, ")\t";
	
  			## print the members in this family
  			my $all_members = $family->get_all_Members();
  			foreach my $this_member (@$all_members) {

			$fam_mem++;
 			#print $this_member->source_name, " ", $this_member->stable_id, " (", $this_member->taxon->name, ")\n";

			# get the member_ID
			my $id = $this_member->stable_id;

				if ($this_member->source_name =~/Uniprot/) {
		    		print OUT ">$id\n";
				print	OUT $this_member->sequence . "\n";
				$total{$id} =  $this_member->sequence;
				}
				elsif ($this_member->source_name =~/ENSEMBLPEP/) {
		    		print OUT ">$id\n";	
				print	OUT  $this_member->sequence . "\n";	
				$total{$id} =  $this_member->sequence;	
				}
	
		  	}
			$stat{$uni}{$fam_mem}=1;
			print OUT4 "$fam_mem\n";
#  		print "\n";
		close (OUT);
		}

	}
	else {
		print OUT4 "$uni not in Ensembl\n";
		next;
	}


}

print "There were $tot genes with $mems defined families\n";

# print the stats

foreach my $p ( keys %stat) {
	foreach my $q ( keys %{$stat{$p}}  ) {
		print "$p has $q members\n";
	}	
}


# get final result

open (OUT3, ">$file.total.members.fas");

foreach my $res (sort keys %total) {

	print OUT3 ">$res\n$total{$res}\n";

}

close (OUT3);

exit;

__END__


# Get the alignemnt

my $aln=$family->get_SimpleAlign();

# This is a bioperl alignment object - so you need Bio::AlignIO to read it

use Bio::AlignIO;

# Get the alignIO object from BioPerl
my $alignIO = Bio::AlignIO->newFh(-format => "fasta");

# Print the alignment
print $alignIO $aln;

