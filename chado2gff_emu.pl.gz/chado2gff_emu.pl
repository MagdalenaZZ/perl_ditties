#!/usr/bin/perl -w
use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado2gff_emu.pl fasta prefix
Wrapper script to export gff from Chado

warning! need to bsub it

'
}

my $fastafile = shift @ARGV ;
my $prefix =  shift @ARGV ;
my $contig_name = '' ;

my %fasta = () ;
my @names = () ;

my $flag = 0 ;

## read the fastas
open (IN, "$fastafile") or die "Cant open file $fastafile\n" ;
while (<IN>) {

	if (/>(\S+)/) {
		my $name = $1 ;		
		my $seq = <IN> ;
		chomp($seq) ;	
		$fasta{$name} = $seq ;
		push(@names, $name) ;
	}
}


# Make folder

mkdir "$prefix" or die "oops can't create folder $prefix\n" ;
chdir "$prefix" ;

open (OUT, ">../$prefix.exporter1.sh") or die "Cant open file ../$prefix.exporter1.sh\n" ;


for (my $i = 0 ; $i < @names ; $i += 100 ) {

    my $string = '' ; 
    my $to = $i + 100 ;
    
    if ( $to > @names ) {
	$to = $#names + 1 ; 
    }
    
    for (my $j = $i ; $j < $to ; $j++ ) {
    	$string .= "$names[$j] "; 
    }
#    print "$string\n"; <STDIN> ; 
    print OUT "writedb_entry -test -o GFF -fp . -u script -p KL37m_X7 -s $string\n" ;

    # system("writedb_entry -test  -f y -c pgsrv1:5432/pathogens?mz3\@sanger.ac.uk -o GFF  -pp y  -fp ./$prefix -u script -p KL37m_X7  -s $string") ;

}

#  chdir "\.\." ;

system "bsub.py 4 ../$prefix.exporter1 sh ../$prefix.exporter1.sh";


#command:  writedb_entry -Djava.awt.headless=true -f y -c pgsrv1:5432/pathogens?jit@sanger.ac.uk -o GFF -u script -p Jason417 -i n -fp ./artemis/GFF/Emultilocularis/1 -s pathogen_EMU_contig_10380 pathogen_EMU_contig_12776 pathogen_EMU_contig_14905 pathogen_EMU_contig_16573 pathogen_EMU_contig_16597 pathogen_EMU_contig_17044 pathogen_EMU_contig_1733 pathogen_EMU_contig_18153 pathogen_EMU_contig_2012 pathogen_EMU_contig_2051


#system("writedb_entries.py -o Emultilocularis -x . -d pgsrv1/pathogens?jit@sanger.ac.uk") ;
#
print "END\n";

#
close (OUT);
