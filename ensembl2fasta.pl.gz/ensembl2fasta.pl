#!/usr/local/bin/perl -w

use strict;


unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: ensembl2fasta.pl Chado.gff

Parses an embedded gff file from Chado, and makes it into useful formats

'
}

my $file = shift;

open IN, "<$file" || die "Can't open $file\n: $!\n";

open FAS, ">$file.fas" || die "Can't open $file.fas\n: $!\n";
open GFF, ">$file.gff" || die "Can't open $file.gff\n: $!\n";


while ( <IN> ) {
    chomp;
    my @arr = split(/\t/, $_);
    my $len = scalar(@arr);
    if ($len == 9) {
        #print "GFF\t$_\n";
        if ($arr[2] =~/^CDS$/ || $arr[2] =~/^gene$/ || $arr[2] =~/^mRNA$/   ) {
            print GFF "$_\n";
        }
        else {
            #print "$_\n";
        }
    }
    elsif ($len == 1) {
        #print "FASTA\t$_\n";
        unless ($_ =~/##/) {
            print FAS "$_\n";
        }

    }
    else {
        print "UNKNOWN\t$len\t$_\n";
    }

}



close (IN);
close (FAS);
close (GFF);

print "Printing outputfiles $file.fas and $file.gff\n...now translating them\n";

system "perl ~/bin/perl/fasta_from_gff.pl $file.fas $file.gff $file";

exit;




