#!/usr/bin/perl -w

use strict;

if (@ARGV < 2) {
        print "\n\nUsage: make_expression_set.pl expressionfile design name \n\n" ;

    print " mz3 script for making an R.data object\n\nExample:  make_expression_set.pl Data.vst.txt Data.design Data\n\n";

        exit ;
}



my $in = shift;
my $design=shift;
my $name=shift;


open (R, ">$name.R") or die "Cannot open file $name.R\n" ;

print R "library(Biobase)\n";

# Get the assay data
print R "exprs <- as.matrix(read.table(\"$in\", header=TRUE, sep=\"\\t\", row.names=1, as.is=TRUE))\n";
print R 'class(exprs)
dim(exprs)
colnames(exprs)
head(exprs[,1:5])
';



# Add phenoData
print R "pData <- read.table(\"$design\", header=TRUE, sep=\"\\t\")\n";
print R 'rownames(pData) <- pData$ID 
dim(pData)
rownames(pData)
summary(pData)

try(pData$Donor <- as.factor(pData$Donor))
try(pData$Date <- as.factor(pData$Date))

# test that expression and pData are the same
all(rownames(pData)==colnames(exprs))

# also check if the phenodata is correctly stored as numbers or factors
sapply(pData, class)


# make an instance of phenoData
phenoData <- new("AnnotatedDataFrame", data=pData)

phenoData 

# you can add in other single pieces of info too
annotation <- "hgu133plus2"

# A MAIME file contains general information about the project
experimentData <- new("MIAME",name="Pierre Fermat", lab="Francis Galton Lab", contact="pfermat@lab.not.exist", title="Smoking-Cancer Experiment", abstract="An example ExpressionSet", url="www.lab.not.exist", other=list(notes="Created from text files" ))


';


# fatureData
# featuredata <- new("AnnotatedDataFrame",data=TCGA2013@featureData@data)

# Chech if feautredata mateches up with arraydata
# all(rownames(TCGA2013@featureData@data)==rownames(exprs))


# Now we are creating the full dataset
#
#print R "$name <- ExpressionSet(assayData=exprs, phenoData=phenoData,experimentData=experimentData, annotation=annotation, featureData=featuredata)\n";
print R "$name <- ExpressionSet(assayData=exprs, phenoData=phenoData,experimentData=experimentData, annotation=annotation)\n";

#Us2015 <- ExpressionSet(assayData=exprs, phenoData=phenoData,experimentData=experimentData, annotation="hgu133plus2")


# save the expressionset as an Rdata object
print R "save($name, file = \"$name.RData\", envir = .GlobalEnv)\n";

close(R);

print "R CMD BATCH $name.R\n";
system "R CMD BATCH $name.R";


exit;




