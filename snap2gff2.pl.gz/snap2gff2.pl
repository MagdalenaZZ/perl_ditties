#!/usr/bin/perl -w
# mz3 script for changing SNAP into gff

use strict;


# get rid of all the lines that starts with #




my %genes;
my %cds;
my $flag = 0;

open (OUT, ">SNAP.artemis.gff") or die "Cant write to file SNAP.artemis.gff\n" ;

while (<>) {
    chomp $_;
    $_=~s/\./\_/g;
	my @line = split (/\s+/, $_);


	my $method = $line[3];
	my $name = $line[0];
	my $tag = $line[4];
    $tag =~s/Exon/Eixon/;
	my $start = $line[5];
	my $end = $line[6];
	my $score = $line[7];
    $score=~s/\_/\./g;
	my $strand = $line[8];
	my $trans = $line[9];
	my $note = $line[10];
	$note = "ID=$note";
    my @arr = split (/\_/ ,$note);
	($start, $end) = sort {$a <=> $b} ($start, $end);
    if ($strand =~/\-/ and $tag =~/Eterm/) {
        $tag = "Einit";
    }
    elsif ($strand =~/\-/ and $tag =~/Einit/) {
        $tag = "Eterm";
    }


    my $new_line = "$name\t$method\t$tag\t$start\t$end\t$score\t$strand\t\.\t$note";
#    print "$start\t$end\t$note\t$arr[3]\n";
    push ( @{$genes{$name}{$arr[3]}}, $new_line );

}

foreach my $scaff (sort keys %genes ) {


foreach my $elem (sort { $a <=> $b } keys %{$genes{$scaff}} ) {
#    print "$elem\n";

#    my @sorted = sort @{$genes{$elem}} ;
    my @row = @{$genes{$scaff}{$elem}} ;
    my @row2 = map { chomp; [split /[,\s]+/, $_] } @row;
    my @sorted = sort { $a->[3] <=> $b->[3] || $a->[4] <=> $b->[4]  }  @row2 ;  # sort the rows (numerically) by third and fourth column    
    
    my @sort;
    for (@sorted) {
    #  print join("\t", @$_) . "\n"; # print them out as CSV
      push (@sort,  join("\t", @$_)  );
    }


    # make gene and mRNA

    
#        print "FW:$sort[0]\n";
#        print "LAST:$sort[-1]\n";

    my @first = split ( /\t/ , $sort[0]);    
    my @last = split ( /\t/ , $sort[-1]); 
#    print "$first[6]\n";
    my $part_f = "5' partial";
    my $part_r = "3' partial";
    if ($first[6]=~/\-/ ) {
        $part_f = "3' partial";
        $part_r = "5' partial";
    }

    if ( $first[2] =~/Einit/ and $last[2] =~/Eterm/  ) {
#        print "FW\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene";
        my $na = pop @st;
        $na =~s/ID=//g;
#        print "$sort[0]\n";
#        print "$sort[-1]\n"; 
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";  
        }
    elsif ( $first[2] =~/Einit/ and $last[2] =~/Eixon/  ) {
#        print "3' partial\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene";

        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na;comment=\"$part_r\";\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";        
    }
    elsif ( $first[2] =~/Eixon/ and $last[2] =~/Eterm/  ) {
#        print "5' partial\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene"; 

        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na;comment=\"$part_f\";\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";

    }
    elsif ( $first[2] =~/Esngl/ and $last[2] =~/Esngl/  ) {
#        print "single\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        $st[2] = "gene"; 

        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";

    }
    elsif ( $first[2] =~/Einit/ and $last[2] =~/Einit/  ) {
#        print "only start\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene"; 

        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na;comment=\"$part_r\";\\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";

    }

    elsif ( $first[2] =~/Eterm/ and $last[2] =~/Eterm/  ) {
#        print "only end\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene"; 


        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na;comment=\"$part_f\";\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";
    }

    elsif ( $first[2] =~/Eixon/ and $last[2] =~/Eixon/  ) {
#        print "only middle\n";
#        print "$sort[0]\n";
#        print "$sort[-1]\n";
        my @st = split( /\t/, $sort[0]);
        my @end = split( /\t/, $sort[-1]);
        $st[4] = $end[4];
        $st[2] = "gene"; 

        my $na = pop @st;
        $na =~s/ID=//g;
        my $new = join ("\t", @st);
        print OUT "$new\tID=$na;comment=\"5' partial\";comment=\"3' partial\";\n";
        $new =~s/gene/mRNA/;
        $new =~s/ID=//g;
        print OUT "$new\tID=$na.1;Parent=$na\n";
    }

    else {
        print "WEIRD: $sort[0]\n";
        print "WEIRD: $sort[-1]\n";

    }

    # print CDSs
    my $index=1;
    foreach my $line (@sort) {
        $line=~s/Einit/CDS/;
        $line=~s/Einint/CDS/;
        $line=~s/Eterm/CDS/;
        $line=~s/Eixon/CDS/;
        $line=~s/Esngl/CDS/;
        my @arr = split (/\t/, $line);
        $arr[8] =~s/ID=//g;
        print OUT "$line:exon$index;Parent=$arr[8].1;\n";
        $index++;
    }

}
}




close (OUT);

__END__

