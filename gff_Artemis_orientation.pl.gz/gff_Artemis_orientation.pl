#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_Artemis orientation input.gff output.gff 

Takes a gff-file and sorts it Artemis style
1-2
3-4
5-6
no matter original orientation in the file (different genes can have different orientations)
Genes in output sorted the same way as in input
Preserves formatting in rows, such as last line notes

'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";



my @in2;

# sort all things in 1-2 direction

foreach my $line (@in) {
chomp $line;
	my @arr =split(/\t/, $line);
	my @arr2 =split(/\t/, $line);
	if ($arr[3] > $arr[4] ) {
		$arr2[3]=$arr[4];
		$arr2[4]=$arr[3];		
		my $right =join("\t", @arr2);
		push (@in2, $right);
#		print "Right: $right\n";
	}	
	elsif ($line =~/\w+/) {
		push (@in2, $line);
#		print "Line: $line\n";
	}
	else {
		print "Dodgy line: $line\n";
	}

}


# Now sort the genes
my $start="0";
my $gene2=0;
my $mrna2=0;
my @st='';
my @cdss ='';
my @AoA;


foreach my $line (@in2) {
chomp $line;
if ($line=~/\w+/) {
	my @arr =split(/\t/, $line);
#        print "74 $line\n";   
# For all genes
	if ($arr[2]=~/^gene$/ and $start==1) {	

# First dump the old gene
			my $gen = "$gene2";
			my $mrna = "$mrna2";
#            print "81 $mrna2\n";
#			print "OLD:$cdss[0]\n";
			shift @cdss;
			my @cds = @cdss;
#			print "NOW2:$cds[-1]\n";
			my $highest=0;
			my $lowest=0;
			shift @AoA;
				foreach my $val (@cds) {
#					print "CDSX: $val\n";
					my @alt=split(/\t/, $val);
					push(@AoA, [ @alt ]);
				}
			shift @st;
			if (exists $AoA[1][0]) {
 			@st = sort tableSorter @AoA;
#			 print "Sorted\n";
			}
			else {
#			 print "Single\n";
 			@st = @AoA;
			pop @st;
			}

			my $first_start = $st[0][3];
			my $last_end = $st[-1][4];
				my @gene3= split(/\t/,$gen);
				$gene3[3]=$first_start;
				$gene3[4]=$last_end;
				$gen= join("\t",@gene3);

				my @mrna3= split(/\s+/,$mrna);
				$mrna3[3]=$first_start;
				$mrna3[4]=$last_end;
				$mrna= join("\t",@mrna3);

			print OUT "$gen\n";
			print OUT "$mrna\n";
			for (my $i = 0; $i < @st; $i++) {
				my $elem2 = join("\t", @{$st[$i]});
 				print OUT "$elem2\n";
			}
			# Clear all arrays
			@AoA='';
			@st='';
			$gene2=0;
			$mrna2=0;
			@cdss ='';
# Make new gene value for next round
 			$gene2=$line;
#	print "End gene: $line\n";
	}

# For the first gene
	elsif ($arr[2]=~/^gene$/ and $start==0) {
		$gene2=$line;
#		print "End first gene: $line\n";
	}
# For CDS
	elsif ($arr[2]=~/^CDS$/ or $arr[2]=~/^exon$/ ) {
		push(@cdss, $line);
#		print "End CDS: $line\n";
	}
# For mRNAs
	elsif ($arr[2]=~/^mRNA$/ or $arr[2]=~/^polypeptide$/ ) {
		$mrna2=$line;
		$start=1;
#		print "End mRNA: $line\n";
	}
	else {
		print "Weird line: $line\n";	
	}


}
else {
    print "Weird line2: $line\n";	
}
}

# empty the last hash

			my $gen = "$gene2";
			my $mrna = "$mrna2";
#			print "OLD:$cdss[0]\n";
			shift @cdss;
			my @cds = @cdss;
#			print "NOW2:$cds[-1]\n";
			my $highest=0;
			my $lowest=0;
			shift @AoA;
				foreach my $val (@cds) {
#					print "CDSX: $val\n";
					my @alt=split(/\t/, $val);
					push(@AoA, [ @alt ]);
				}
			shift @st;
			if (exists $AoA[1][0]) {
 			@st = sort tableSorter @AoA;
#			 print "Sorted\n";
			}
			else {
#			 print "Single $mrna\n";
 			@st = @AoA;
			pop @st;
			}

			my $first_start = $st[0][3];
			my $last_end = $st[-1][4];
				my @gene3= split(/\t/,$gen);
				$gene3[3]=$first_start;
				$gene3[4]=$last_end;
				$gen= join("\t",@gene3);
#        		 print "$mrna\n";
				my @mrna3= split(/\s+/,$mrna);
				$mrna3[3]=$first_start;
				$mrna3[4]=$last_end;
				$mrna= join("\t",@mrna3);

			print OUT "$gen\n";
			print OUT "$mrna\n";
			for (my $i = 0; $i < @st; $i++) {
				my $elem2 = join("\t", @{$st[$i]});
 				print OUT "$elem2\n";
			}


close (OUT);
##################################################################################
##################################################################################


sub tableSorter ($$) {
     my($row1, $row2) = @_;
     
     my $column1comparison = $row1->[3] <=> $row2->[3];
     if($column1comparison != 0){
         return $column1comparison;
     }
     
#     my $column2comparison = $row1->[4] <=> $row2->[4];
#     if($column2comparison != 0){
#         return $column2comparison;
#     }
  
#       my $column6comparison = $row1->[6]  <=> $row2->[6];
#     if($column6comparison != 0){
#         return $column6comparison;
#     }

#       my $column12comparison = $row1->[12] cmp  $row2->[12];
#     if($column12comparison != 0){
#         return $column12comparison;
 #    }

 #      my $column5comparison = $row1->[5] cmp $row2->[5];
 #    if($column5comparison != 0){
 #        return $column5comparison;
#     }

   return $row1->[0] cmp $row2->[0];
 }
