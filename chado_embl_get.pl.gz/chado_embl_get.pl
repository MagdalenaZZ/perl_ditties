#!/usr/bin/perl -w


# use strict;

use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_embl_cleanup.pl folder out-prefix


From a folder, it gathers all embl-files in the directories, merges them into 1 out-file
This is the folder which CONTAINS the folders 1/ 2/ 3/ e.t.c.

First run the writedb_entries.py script 


'
}

# Unzip the files in all folders and cat them

my $folder = shift;
my $prefix = shift;
my $cwd = cwd();
# print "CWD: $cwd\n";
my $dir = cwd();
my @dirs ;



my @paths = read_dir( "$folder", prefix => 1 ) ;


foreach my $elem (@paths) {
        #print "Elem $elem\n";
        unless ($elem=~m/\./) {
        push (@dirs, $elem);

    }
}

#Make sure the folder has the right path - if not a path - assume that it is in this folder

if ($folder =~m/\//) {	
	if (-d "$folder") {
		print "If: $folder\n";
        #print "@dirs\n";
		foreach my $elem (@dirs) {
            #$elem = "$folder\/$elem";
			print "`gunzip -r $elem\n";
            system `gunzip -r $elem `;
			print "Unzipping of $elem finished\n";

            unless (-z  "$elem.embl" ){
                system  `cat $elem/*.embl > $elem.embl `;
            }
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
#		print "Else: $cwd\/$folder\n";
		foreach my $elem (@dirs) {
			$elem = "$cwd\/$folder\/$elem";
			print "`gunzip -r $elem\n";
            system `gunzip -r $elem `;
            print "Unzipping of $elem finished\n";

            unless (-z  "$elem.embl" ){
                system  `cat $elem/*.embl > $elem.embl `;
            }
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

print "Fishished reading files\n";



# Concatenate all files

my $nothing = " ";
push (@dirs, $nothing);
#open (EXC, ">exception.list") || die "I can't open exception.list\n";
my $filelist = join( "/*.* ", @dirs); 

# print "List:$filelist:\n";

if (-z "$prefix.all.originals.embl") {
    print "\n\nFile $prefix.all.originals.embl already exists, delete it and try again\n\n";
    die;
}
else {
    system `cat $filelist > $prefix.all.originals.embl`;
    print "cat $filelist > $prefix.all.originals.embl";
}



