#!/usr/bin/perl -w


use strict;


if (@ARGV < 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: RCDBget.pl RCDBlist  

Takes a list of DrugBank-numbers and associates them with the UniProt entry for them




What can possibly go wrong...  :-)


NOT FINISHED SCRIPT!!!!


'
}

my $in = shift;


        open (IN, "<$in") || die "I can't open $in\n";
        #   	my @in= <IN>;
#    	close (IN);


        while (<IN>) {


            if ($_ =~/drugbank-id/ ) {
                print "$_";
            }
            elsif ($_ =~/protein-sequence/ ) {
                    print "$_";
            }





        }




