#!/usr/bin/perl -w
use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_gff_correct.pl file.gff

# From a gff-file raw from chado, it flags up mistakes, and makes a cleaned-up version


First run the writedb_entry script 


'
}


my $file = shift @ARGV;


open OUT , ">", "$file.corrected.gff" or die "ooooopssps\n" ;
open OUT_INTRON, ">", "$file.corrected.intron.gff" or die "ooops can't create!\n" ;
#open OUT_OBSOLETE, ">", "$file.corrected.gff.obsolete.genes" or die "oopasodosa\n" ;

open AA, ">", "$file.corrected.fasta" or die "oooops can't create amino acid file!\n" ; 
open PRODUCT, ">", "$file.corrected.product" or die "oooops!\n" ; 

open (IN, "$file") or die "oops!\n" ;



my %gene_start = () ;
my %gene_end = () ;
my %gene_strand = () ;
my %gene_exons = () ;
my %gene_loc = () ;

my %gene_trans_len = () ;


my @gene_order = () ;

my %obsolete = () ;
my $gene = '' ; 

my %aa_present = () ; 

## read in the chado annotations
while (<IN>) {
	

    if (/\#\#FASTA/ or /\#\#gff-version 3/ or  /\#\#sequence-region/   ) { 
        next;
    }
    if ( /^\#\#/ ) {
	print OUT $_ ;
	next ;
    }
    
    chomp;

    #print "LINE $_\n";

    my @r = split(/\s+/, $_ ); 

    if (scalar(@r) < 4 ) {
        #print "What @r\n";
        next;
    }

#}

#__END__


    next if $r[8] =~ /isObsolete=true/ ;

    # parse out the annotation                                                                                                                                                                                                                          
    if ( $r[2] eq 'polypeptide' ) {

	# parse out fasta
        if ( $r[8] =~ /translation=(\S+)/ ) {
	    my $aa = uc($1) ; 
	    #print "$aa\n" ; 

	    if ($aa =~ /[*+]/) {
		print "$gene translation wierd!\n" ; 
	    }
	    else {
		my $peptide = ''  ;
		if ( $r[8] =~ /ID=(\S+):pep\;/ ) {
		    $peptide = $1 ; 
		}
		
		if ( $peptide =~ /(\S+)\.\d+/ ) {
		    if ( $aa_present{$1} ) {
			print "already one splice variant printed!\n" ; 
		    }
		    else {
			print AA ">$peptide\n$aa\n" ;
			$aa_present{$1}++ ; 
		    }
		}


	    }

        }

        # get product names
        my @arr =split (/;/, $r[8]);

        my $id;
        foreach my $elem (@arr) {
                if ($elem=~/ID=/) {
                $elem=~s/ID=//;                    
                $elem=~s/\.1:pep//;
                $elem=~s/\.1{pep}//;
                #print "$elem\n";
                $id = $elem;
            }
            elsif ($elem=~/product=/) {
                my @arrs = split(/%3B/, $elem);
                foreach my $li (@arrs) {
                    $li=~s/product=term%3D//;
                    $li=~s/%2Cterm%3D//;
                    $li=~s/%2C//;
                    $li=~s/%29//;
                    $li=~s/%28//;
                    $li=~s/%2B//;
                    $li=~s/\+/ /g;
                    print PRODUCT "$id\t/product=\"$li\"\n";
                }
            }
        }

    }

    
    if ( $r[2] ne 'exon' && $r[2] ne 'CDS' ) {
	    next ; 
    }

    # find exons
    if ( $r[8] =~ /ID=(\S+):exon:/ ) {
	$gene = $1 ; 
    #print "gene1 $gene\n";
    }
    else   {
        #print "discarded $gene\n";
    }
    # add in as genes
    unless ( $gene_start{$gene} ) {
        #print "gene2 $gene\n";
	$gene_start{$gene} = $r[3] ;
	$gene_end{$gene} = $r[4] ;
	push(@gene_order, $gene) ;
    }
    
    if ( $gene_start{$gene} && $r[3] < $gene_start{$gene} ) {
	$gene_start{$gene} = $r[3] ;
    }
    
    if ( $gene_end{$gene} && $r[4] > $gene_end{$gene} ) {
	$gene_end{$gene} = $r[4] ;
    }
    
    $gene_strand{$gene} = $r[6] ;
    $gene_loc{$gene} = $r[0] ;


    if ( $gene_exons{$gene} ) {
	$gene_exons{$gene} .= ",$r[3]..$r[4]" ;
    }
    else {
	$gene_exons{$gene} = "$r[3]..$r[4]" ;
    }
    

    $gene_trans_len{$gene} += ( $r[4] - $r[3] + 1) ;


    #last;
}
close(IN) ;


for my $obsolete_genes (sort keys %obsolete) {
    print "obsoleted: $obsolete_genes\n" ;
}




my %isoforms = () ;
my $RP = 1 ; # relative position 

foreach my $gene ( @gene_order ) {


    #print "$gene\t$gene_start{$gene}\t$gene_end{$gene}\t$gene_strand{$gene}\n" ;

    my $gene_name = $gene ;
    $gene_name =~ s/\.\d+//g ;
    $gene_name =~ s/:mRNA//g ;

    unless ( $isoforms{$gene_name} ) {
	print OUT "$gene_loc{$gene}\tchado\tgene\t$gene_start{$gene}\t$gene_end{$gene}\t.\t$gene_strand{$gene}\t.\tID=$gene_name\n" ;
	$isoforms{$gene_name}++ ;
    }
    else {
	print "$gene_name isoform!\n" ;
	next ;

    }

    if ( $gene =~ /mRNA/ ) {
	
	print OUT "$gene_loc{$gene}\tchado\tmRNA\t$gene_start{$gene}\t$gene_end{$gene}\t.\t$gene_strand{$gene}\t.\tID=$gene\;Name=$gene\;Parent=$gene_name\;TL=$gene_trans_len{$gene}\n" ;
    }
    else {
	print OUT "$gene_loc{$gene}\tchado\tmRNA\t$gene_start{$gene}\t$gene_end{$gene}\t.\t$gene_strand{$gene}\t.\tID=$gene:mRNA\;Name=$gene:mRNA\;Parent=$gene_name\;TL=$gene_trans_len{$gene}\n" ;
    }


    my @exons = split /,/ , $gene_exons{$gene};

    #print "@exons\n" ;

    if ($gene_strand{$gene} eq '+' ) {

	for (my $i = 0 ; $i < @exons ; $i++ ) {
	    
	    
	    my @exon_coord = split /\.\./, $exons[$i] ;
	    
	    if ( $gene =~ /mRNA/ ) {
		print OUT "$gene_loc{$gene}\tchado\texon\t$exon_coord[0]\t$exon_coord[1]\t.\t$gene_strand{$gene}\t.\tID=$gene:exon:" . ($i+1) . "\;Name=$gene:exon:" . ($i+1) . "\;Parent=$gene\;RP=$RP\n" ;
	    }
	    else {
		print OUT "$gene_loc{$gene}\tchado\texon\t$exon_coord[0]\t$exon_coord[1]\t.\t$gene_strand{$gene}\t.\tID=$gene:exon:" . ($i+1) . "\;Name=$gene:exon:" . ($i+1) . "\;Parent=$gene_name:mRNA\;RP=$RP\n" ;
	    }
	    
	    $RP += ( $exon_coord[1] - $exon_coord[0] ) ;

	}
	

        # print out introns
        if ( @exons > 1 ) { 

          for (my $i = 0 ; $i < $#exons ; $i++ ) {                                                                                                                                                                                                                       
              my @exon_coord = split /\.\./, $exons[$i] ;                                                                                                                                                                                                
              my @exon_coord_next = split /\.\./, $exons[$i+1] ;

              next if ($exon_coord_next[0]-1) <= ($exon_coord[1]+1) ;

             if ( $gene =~ /mRNA/ ) {
                  print OUT_INTRON "$gene_loc{$gene}\tchado\tintron\t" . ($exon_coord[1]+1).  "\t" . ($exon_coord_next[0]-1). "\t.\t$gene_strand{$gene}\t.\tID=$gene:intron:" . ($i+1) . "\;Name=$gene:intron:" . ($i+1) . "\;Parent=$gene\;RP=$RP\n" ;
             }
             else {
                 print OUT_INTRON "$gene_loc{$gene}\tchado\tintron\t"  . ($exon_coord[1]+1).  "\t" . ($exon_coord_next[0]-1). "\t.\t$gene_strand{$gene}\t.\tID=$gene:intron:" . ($i+1) . "\;Name=$gene:intron:" . ($i+1) . "\;Parent=$gene_name:mRNA\;RP=$RP\n" ;
             }

           }
        }


    }
    else {


        for (my $i = $#exons ; $i > -1 ; $i-- ) {


            my @exon_coord = split /\.\./, $exons[$i] ;

            if ( $gene =~ /mRNA/ ) {
                print OUT "$gene_loc{$gene}\tchado\texon\t$exon_coord[0]\t$exon_coord[1]\t.\t$gene_strand{$gene}\t.\tID=$gene:exon:" . ($i+1) . "\;Name=$gene:exon:" . ($i+1) . "\;Parent=$gene\;RP=$RP\n" ;
            }
            else {
                print OUT "$gene_loc{$gene}\tchado\texon\t$exon_coord[0]\t$exon_coord[1]\t.\t$gene_strand{$gene}\t.\tID=$gene:exon:" . ($i+1) . "\;Name=$gene:exon:" . ($i+1) . "\;Parent=$gene_name:mRNA\;RP=$RP\n" ;
            }

            $RP += ( $exon_coord[1] - $exon_coord[0] ) ;

	}
	

        # print out introns                                                                                                                                                                                                                                          
        if ( @exons > 1) {

           for (my $i = $#exons ; $i > 0 ; $i-- ) {
              my @exon_coord = split /\.\./, $exons[$i] ;                                                                                                                                                                                                            
              my @exon_coord_next = split /\.\./, $exons[$i-1] ;                                                                                                                                                                                                    
                                                                     
              next if ($exon_coord_next[0]-1) <= ($exon_coord[1]+1) ;
                                                                                                                                                                                                        
             if ( $gene =~ /mRNA/ ) {
	        print OUT_INTRON "$gene_loc{$gene}\tchado\tintron\t" . ($exon_coord[1]+1).  "\t" . ($exon_coord_next[0]-1). "\t.\t$gene_strand{$gene}\t.\tID=$gene:intron:" . ($i+1) . "\;Name=$gene:intron:" . ($i+1) . "\;Parent=$gene\;RP=$RP\n" ;
             }
             else {
                print OUT_INTRON "$gene_loc{$gene}\tchado\tintron\t"  . ($exon_coord[1]+1).  "\t" . ($exon_coord_next[0]-1). "\t.\t$gene_strand{$gene}\t.\tID=$gene:intron:" . ($i+1) . "\;Name=$gene:intron:" . ($i+1) . "\;Parent=$gene_name:mRNA\;RP=$RP\n" ;
             }

           }
        }





    }
    

$RP = 1 ;


 

}




close (PRODUCT);

print "all done!!!\n" ;
