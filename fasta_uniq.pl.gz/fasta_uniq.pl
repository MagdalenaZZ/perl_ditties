#!/usr/bin/perl -w

use strict;




my $largest = 0;
my $contig = '';


if (@ARGV < 1) {
	print "\n\nUsage: fasta_uniq.pl fasta \n\n" ;

    print " mz3 script for retriveing fasta-files if their headers are in a list \n\n";

	exit ;
}

my $filenameA = shift @ARGV;
my $contig_name = shift @ARGV;
my %reads = () ;


open (OUT, ">$filenameA.uniq") or die "oops!\n" ;
open (OUT2, ">$filenameA.not_uniq") or die "oops!\n" ;
open (OUT3, ">$filenameA.all_uniq") or die "oops!\n" ;

open (IN, "$filenameA") or die "oops!\n" ;

=pod

while (<IN>) {
	chomp ;
	my @line = split /\s+/ , $_ ;
	$reads{$line[0]} = 1 ;
    # print "Line:$line[0]:\n";
}
close(IN) ;

=cut

open (IN, "$filenameA") or die "oops2!\n" ;

my %new;

while (<IN>) {

    my $index = "2";
    # print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $_;
	$seq_name=~s/>//;
    chomp $seq_name;
	my $seq = <IN> ;
	chomp($seq) ;
    my $new_name;

#	print "SEQname:$seq_name:\n";	
	if ( exists $reads{$seq_name} ) {
			print OUT2 ">$seq_name\n" ;
			print OUT2 "$seq\n" ;
#            delete $reads{$seq_name};
            $new_name =  "$seq_name" . "\.$index" ;
            while ( exists $new{$new_name}) {
                $index++;
                $new_name =  "$seq_name" . "\.$index" ;
            }
            $new{$new_name} = $seq;
            print "Renamed\t$seq_name\t$new_name\n";
	}
    else {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;
            $new{$seq_name} = $seq;

    }

	$reads{$seq_name} = $seq ;

    }
	
    
    #last;


}

foreach my  $elem ( sort keys %new ) {
    print OUT3 "\>$elem\n$new{$elem}\n";
}

close (OUT);
close (OUT2);
close (OUT3);

#print "\#\#the largest length is: $contig with $largest bp \n" ;
