#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}

	my $name = shift;
	my $out = shift;
	open (IN, "<$name") || die "I can't open $name\n";
	my @input = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";



my $old_qseqid=0;
my $old_sseqid=0;

foreach my $line (@input) {
my @var	= split(/\s+/, $line);

my $qseqid= $var[0];
my $sseqid = $var[1];
my $pident = $var[2];
my $length = $var[3];
my $mismatch = $var[4];
my $gapopen = $var[5];
my $qstart = $var[6];
my $qend = $var[7];
my $sstart = $var[8];
my $send = $var[9];
my $evalue = $var[10];
my $bitscore = $var[11];

# print "$var[11]\n";


if ($qseqid=~/$old_qseqid/) {
	if ($qseqid=~/$sseqid/ && $sseqid=~/$qseqid/) {
#	print "Self-match $qseqid vs $sseqid\n";
	}
	else {
#	print "$pident and  $length\n";
		if ($pident > 95 and $length > 3000) {
#	print "SIGNIFICANT: $pident and  $length\n";
			if ($old_sseqid=~/$sseqid/){
				print OUT  "Identity $pident and length $length start $sstart end $send\n";
			}
			else {
				print OUT  "$qseqid vs $sseqid\n";
				print OUT  "Identity $pident and length $length start $sstart end $send\n";
			}
		}
	}
}

else {
#start anew for each new query sequence
# filter lines where there is a new query
		if ($pident > 95 and $length > 3000) {
#	print "SIGNIFICANT: $pident and  $length\n";
			if ($qseqid=~/$sseqid/){
				if ($sseqid=~/$qseqid/){
				#self-match
				}
				else {
				print OUT "$qseqid vs $sseqid\n";
				print OUT "Identity $pident and length $length start $sstart end $send\n";
				}
			}
			else {
				print OUT "$qseqid vs $sseqid\n";
				print OUT "Identity $pident and length $length start $sstart end $send\n";
			}

# print "$qseqid is not $old_qseqid\n";
# print "Identity $pident and length $length\n";
}

$old_qseqid=$qseqid;
$old_sseqid=$sseqid;
}

}


sub USAGE {

die 'Usage: BLASTparser.pl infile.fas  outfile


Flexible parser of BLAST outfmt 6

bsub -o c1x.o -e c1x.e -JC1 -M10000000 -R"select[mem>10000] rusage[mem=10000]" perl ~/bin/perl/BLASTparser.pl infile.fas > outfile




'
}

	close (OUT);


__END__
