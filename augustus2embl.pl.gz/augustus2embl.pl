#!/usr/local/bin/perl -w
# mz3 script for changing augustus-output to embl
use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/augustus2embl.pl augustus-output 


perl ~/bin/perl/aug2blast2go.pl augs369.o 1 3


Not really working?


'
}

	my $gtf = shift;


open (IN, "<$gtf") || die "I can't open $gtf\n";


	my @list = <IN>;
	my @list2;

foreach my $elem (@list) {
chomp $elem;

# change gene to "CDS "
	if ($elem =~/gene/) {
# fix the line length
	$elem =~ s/gene/CDS /;
	push (@list2, $elem);
#	my @arr = split(/\(/, $elem);
#	print "$elem"  . "\n";
	}

	elsif ($elem =~/CDS/) {
# fix the line length
	$elem =~ s/CDS/CDS /;
	push (@list2, $elem);
	}

	else {
#	print "$elem\n"
	push (@list2, $elem);
	}
}

foreach my $elem (@list2) {

#print "Elem: $elem\n";

if ($elem =~/CDS/)  {
	if ($elem =~/complement/) {
		# clean initial duplicates
		my @arr = split(/\(/, $elem);
		print "$arr[0]"  . "(";
		print "$arr[1]"  . "(";
		my @arr2 = split(/\,/, $arr[2]);
		shift @arr2;
	#	pop (@arr2);
		my $new_elem = join(",",  @arr2);
		print "$new_elem";
#		my $length= length($elem);
		unless ($new_elem =~/\)/) {
		print ",";
		}
		print "\n";
	}
	elsif ($elem =~/join/) {
		# clean initial duplicates
		my @arr = split(/\(/, $elem);
		print "$arr[0]"  . '(';
#		print "1 $arr[1]"  . "\n";
		my @arr2 = split(/\,/, $arr[1]);
		shift @arr2;
#		pop (@arr2); 
		my $new_elem = join(",",  @arr2);
		print "$new_elem";
		unless ($new_elem =~/\)/) {
		print ",";
		}
		print "\n";
	}
	else {
		print "$elem\n";
	}
}

else {
print "$elem\n";
}

}

