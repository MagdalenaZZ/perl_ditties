#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==5) {
        &USAGE;
}


sub USAGE {

die 'Usage: SAM_extract_PE_coverage.pl input.bam genome.fas  <cov> <max-insert length>  <dist>

Takes a BAM-file and makes a gff junction-file containing all features covered by paired-end reads


It will only output features present in <converage int> reads or more,
    and will only consider paired-end reads spaced by less than  <max-insert length>


Adjoining features will be merged if they are less than <dist> away from each other

Example:
/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl pathogens_HYM_contig_0013.bam pathogens_HYM_contig_0013.fas 5 20000 5




'
}

# get parameters
my $in = shift;
my $fasta = shift;
my $cov = shift;
my $max = shift;
my $dist=shift;


# Make a genome-file for BEDtools
unless (-s "$fasta.genome") {
        system "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fasta"; wait;
    }

# filter bam to get proper pairs    
#system "samtools view -f2 $in  > $in.PE.$cov.$max.sam ";

# filter bam dont worry about proper pairs
system "samtools view -f2 $in  > $in.PE.$cov.$max.sam ";

## extract all the coverages and output to BED


# open SAM and TMP file
open (IN, "<$in.PE.$cov.$max.sam") || die "I can't open $in.PE.$cov.$max.sam\n";
open (TMP, ">$in.$cov.$max.tmp") || die "I can't open $in.$cov.$max.tmp\n";


# catch proper paired reads, best position and not very split 
while (<IN>) {

    my @arr=split(/\s+/,$_);
    if ($arr[8] > 0 and ($arr[1]=~/99/ or $arr[1]=~/147/ or $arr[1]=~/83/ or $arr[1]=~/163/ ) and $arr[5]!~/\d+M\d+N\d+M\d+N\d+M/ ) {
        my $end = $arr[3] + $arr[8] -1 ;
            if ( $arr[8] < $max ) {
                print TMP "$arr[2]\t$arr[3]\t$end\n";
            }
        }
}

close (IN);
close (TMP);


# merge overlapping coverages from BED using BEDtools and coverage2feature.pl 
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -i $in.$cov.$max.tmp -g $fasta.genome -bga > $in.$cov.$max.tmp2";
system "perl ~/bin/perl/coverage2feature.pl  $in.$cov.$max.tmp2 BED $cov $dist";

# Filter features shorter than 200 bp
system "cat $in.$cov.$max.tmp2.gff.c2f.gff | awk -F';' '{print \$1}' | awk '(\$5 - \$4) > 200' > $in.PE.$cov.$max.gff ";

unless (-e "SAM_extract_PE_coverage") {
    mkdir "SAM_extract_PE_coverage";
}

system "mv $in.$cov.$max.tmp2.gff.c2f.gff  SAM_extract_PE_coverage ";
system "mv $in.PE.$cov.$max.sam  SAM_extract_PE_coverage ";
system "mv $in.$cov.$max.tmp SAM_extract_PE_coverage";
system "mv $in.$cov.$max.tmp2 SAM_extract_PE_coverage ";
#system "mv $in.$cov.$max.tmp2.gff SAM_extract_PE_coverage";

exit;

__END__



