#!/usr/bin/perl -w

use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: prefix_file.pl file


Takes a file, and prefixes all lines with the first part of its file-name.

I.e. file  SPEC.fas

blah   blah blah
blah2   blah blah

Get lines:

SPEC_blah   blah blah
SPEC_blah2   blah blah





' . "\n";
}


my $in = shift;
my $out = "P." . $in;


my @prefix = split(/\./, $in);

open (IN, "<$in")|| die;
open (OUT, ">$out")|| die;


while (<IN>) {

    if ($_=~/^$prefix[0]_/) {
        print OUT "$_";
    }
    else {
        print OUT "$prefix[0]" . "_" . $_;
    }
}

print "If there is something underneath here, several things may have been renamed the same thing\n";
print "-------------------------------------------------------------------------------------------\n";
system "cat $out | cut -f1 | uniq | sort | uniq -c | awk \'\$1 > 1\'";
print "-------------------------------------------------------------------------------------------\n";


close (IN);
close (OUT);

exit;



