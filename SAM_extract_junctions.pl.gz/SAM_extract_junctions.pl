#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=3) {
        &USAGE;
}


sub USAGE {

die 'Usage: SAM_extract_junctions.pl input.bam/sam <converage int>  <anchor length>

Takes a BAM-file and makes a gff junction-file

It will only output features present in <converage int> reads or more
and features with an anchor length of   <anchor length> or more for all mapped fragments
i.e. cigar 2M 10N 10M will be filtered if <anchor length> is 3




'
}

# format

	my $in = shift;
	my $cov = shift;
	my $men = shift;

#    my %gff;

# read in BAM to BED

my $file = `file $in`;
my $file2 = `head -1 $in`;
# print ":$file:\n";

if ($file=~/gzip/) {
    system "samtools view $in > $in.$cov.$men.sam";
	open (IN, "<$in.$cov.$men.sam") || die "I can't open $in.$cov.$men.sam\n";
    print "\nInput $in read as a BAM-file\n";
}
elsif ($file2!~/@/) {
#    system "samtools view -S $in -o $in.$cov.$men.sam";   
	open (IN, "<$in") || die "I can't open $in\n";
    print "\nInput $in read as a SAM-file without header\n";
}
elsif ($file=~/ASCII/) {
    system "samtools view -S $in -o $in.$cov.$men.sam";   
	open (IN, "<$in.$cov.$men.sam") || die "I can't open $in.$cov.$men.sam\n";
    print "\nInput $in read as a SAM-file\n";
}
elsif ($in=~/\.bam$/) {
    system "samtools view $in > $in.$cov.$men.sam";
	open (IN, "<$in.$cov.$men.sam") || die "I can't open $in.$cov.$men.sam\n";
    print "\nInput $in read as a BAM-file\n";
}
elsif ($in=~/\.sam$/) {
    system "samtools view -S $in -o $in.$cov.$men.sam";   
	open (IN, "<$in.$cov.$men.sam") || die "I can't open $in.$cov.$men.sam\n";
    print "\nInput $in read as a SAM-file\n";
}


else {
    print "\nI dont know if your infile is SAM or BAM\n";
}


 
    open (TMP, ">$in.$cov.$men.tmp") || die "I can't open $in.$cov.$men.tmp\n";
    open (ERR, ">$in.$cov.$men.errors") || die "I can't open $in.$cov.$men.errors\n";

    while (<IN>) {

# catch gapped alignment
        my @arr=split(/\s+/,$_);
        if ($arr[5]=~/N/ and $arr[1]<300 ) {
#            print "$_";
              my $cigar = $arr[5];
              my @cign = split (/\D+/, $cigar );
              my @cigt = split (/\d+/, $cigar );
              my $cigt2 = join(" ", @cigt);
#             print "T:$cigt2:\n";
              my $cign2 = join(" ", @cign);
#             print "N:$cign2:\n";


            if ($cigt2 eq " M N M" and $cign[0]>="$men" and $cign[2]>="$men") {
#                print "hit\n";
                my $start = $arr[3] + $cign[0];
                my $end = $start + $cign[1];

               print TMP "$arr[2]\tSAM\tCDS\t$start\t$end\t.\t+\t.\tID=$arr[0]\n";
            }
            elsif ($cigt2 eq " M N M N M"   and $cign[0]>="$men" and $cign[2]>="$men" and $cign[4]>="$men" ) {
#                    print "hit2\n";
                my $start = $arr[3] + $cign[0];
                my $end = $start + $cign[1];
                my $start2 = $arr[3] + $cign[0] + $cign[1] + $cign[2] ;
                my $end2 = $start2 + $cign[3];

               print TMP "$arr[2]\tSAM\tCDS\t$start\t$end\t.\t+\t.\tID=$arr[0]\_p\n";
               print TMP "$arr[2]\tSAM\tCDS\t$start2\t$end2\t.\t+\t.\tID=$arr[0]\_p\n";

            }
            elsif  ($cigt2 eq " M N M"  || $cigt2 eq " M" ) {
                # do nothing
            }
            elsif  ($cigt2 eq " M N M N M N M"  ) {
                print ERR "$_";
            }

            else {
                print ERR "ignored\t:$cigt2:\t$_\n";
            }



           
        }
    }


	close (IN);
	close (TMP);
	close (ERR);

	open (TMP2, "<$in.$cov.$men.tmp") || die "I can't open $in.$cov.$men.tmp\n";


	my @in = <TMP2>;


my %coo;
my %cm;




# hash looks like coo{contig}{coords}= number-of-supp    
foreach my $line (@in) {
    chomp $line;
    my @arr = split(/\t/, $line);

# change initial coordinate    
    if ($arr[3]=="0") {
        $arr[3]="1";
    }
    $arr[4]=$arr[4]-1;
    $coo{ $arr[0] }{ "$arr[3]\t$arr[4]" } +=1;
    $cm{ $arr[0] }{ "$arr[3]\t$arr[4]" }{ "$arr[8]"} +=1 ;

}



# make a gff
my $i = "A";

	open (GFF, ">$in.$cov.$men.gff") || die "I can't open $in.$cov.$men.gff\n";
	open (GFF2, ">$in.$cov.$men.gff.annotated") || die "I can't open $in.$cov.$men.gff.annotated\n";

foreach my $cont ( sort keys %coo) {
#    print "$cont\n";
    foreach my $co (sort { (split '\t', $a)[0] <=> (split '\t', $b)[0] } keys %{$coo{$cont}} ) {
        if ( $coo{$cont}{$co}  >=  $cov ) {
            print GFF "$cont\tFromBam\tCDS\t$co\t.\t+\t.\tID=$i\_$coo{$cont}{$co}\n";
            print GFF2 "$cont\tFromBam\tCDS\t$co\t.\t+\t.\tID=$i\_$coo{$cont}{$co}\t";

            foreach my $key (sort keys %{$cm{$cont}{$co}} ) {
                print GFF2 " $key";
            }
            print GFF2 "\n";

            $i++;
        }

    }
}

#system "rm -f $in.$cov.$men.tmp ";


# clean up

unless (-e "SAM_extract_junctions") {
    mkdir "SAM_extract_junctions";
}

system "mv $in.$cov.$men.gff.annotated SAM_extract_junctions ";
system "mv $in.$cov.$men.tmp SAM_extract_junctions ";
system "mv $in.$cov.$men.errors SAM_extract_junctions ";




exit;









__END__

foreach my $line (@gff) {
    chomp $line;
    my @arr = split(/\s+/, $line);
    if ($arr[2]=~/CDS/) {
        print "$arr[3]\t$arr[4]\t$arr[8]\n";
    }
}

# write juncions from hash    

# <chrom> <left> <right> <+/->




__END__

Supplying your own transcript annotation data:

The options below allow you validate your own list of known transcripts or junctions with your RNA-Seq data. Note that the chromosome names in the files provided with the options below must match the names in the Bowtie index. These names are case-senstitive.

	
-j/--raw-juncs <.juncs file> 	

Supply TopHat with a list of raw junctions. Junctions are specified one per line, in a tab-delimited format. Records look like:

<chrom> <left> <right> <+/->

left and right are zero-based coordinates, and specify the last character of the left sequenced to be spliced to the first character of the right sequence, inclusive. That is, the last and the first positions of the flanking exons. Users can convert junctions.bed (one of the TopHat outputs) to this format using bed_to_juncs < junctions.bed > new_list.juncs where bed_to_juncs can be found under the same folder as tophat






