#!/usr/local/bin/perl -w

use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: change_linebreaks.pl input1 input2

mz3 script for changing line-breaks in file 2 to match those in file 1

Output is fixed.input2


'



	my $in1 = shift;
	my $in2 = shift;

	open (IN, "<$in1") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (IN2, "<$in2") || die "I can't open $in\n";
	my @in2 = <IN2>;
	close (IN2);


my $newline1;
for my $test ("\015\012","\015","\012") { # match various newline char+s, default to unix
  $newline1 = $test;
 last if /$test/;
}




#$/ = $newline;


foreach my $line (@in2) {
$line =~ s/\015?\012?$/$newline1/;
print OUT $line;
}



my $LF = "\012";
my $CR = "\015";

my $UnixNL = $LF;
my $DOSNL  = $CR . $LF;
my $MacNL  = $CR;




__END__

sed -e 's/$/\r/' inputfile > outputfile                # UNIX to DOS  (adding CRs)
sed -e 's/\r$//' inputfile > outputfile                # DOS  to UNIX (removing CRs)
perl -pe 's/\r\n|\n|\r/\r\n/g' inputfile > outputfile  # Convert to DOS
perl -pe 's/\r\n|\n|\r/\n/g'   inputfile > outputfile  # Convert to UNIX
perl -pe 's/\r\n|\n|\r/\r/g'   inputfile > outputfile  # Convert to old Mac

To identify what type of line breaks a text file contains, the file command can be used. Moreover, the editor vim can be convenient to make a file compatible with the Windows notepad text editor. For example:

[prompt] > file myfile.txt
myfile.txt: ASCII English text
[prompt] > vim myfile.txt
  within vim :set fileformat=dos
             :wq
[prompt] > file myfile.txt
myfile.txt: ASCII English text, with CRLF line terminators


