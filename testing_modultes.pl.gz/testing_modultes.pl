#!/usr/local/bin/perl

  use strict;
  use Storable;
  use File::Path;
  use File::Basename;
  use Spreadsheet::WriteExcel;
  use LWP::Simple;
use LWP::UserAgent ();
use HTTP::Status ();
use HTTP::Date ();


my $output = LWP::Simple::get("http://www.ncbi.nlm.nih.gov/protein/gi|256081707");
# print "$output";
my $output2 = LWP::Simple::get("http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nucleotide&id=24475906,224465210,50978625,9507198&rettype=acc");
# print "$output2";

 die "Couldn't get it!" unless defined $output2;

 print "Worked!!!\n\n";
__END__


use warnings;
# use HMMstar;
# use geneid;
use Getopt::Std;
our ($opt_h, $opt_v);
getopts('hv');

__END__

die "
usage: $0 [options] <gff> <fasta> <output dir>
options:
  -h  help
  -v  verbose
" unless @ARGV == 3;

my ($GFF, $DNA, $DIR) = @ARGV;
my $genome = HMMstar::Genome::read($DNA, $GFF);
system("mkdir $DIR") unless -d $DIR;


#  my $seplines = ("-" x 60)."\n";

 # my $libraryfile = $ARGV[0];
#  my $base_name = $ARGV[1];
#  my $extending = $ARGV[2];
 # my $unpaired_file = $ARGV[3];


print "Okay\n";



# this is how to test where a module is
# in window
# perl -MData::Dump=pp -e 'use FindLibrary::ThisModule;pp(\%INC)'
# ex: perl -MData::Dump=pp -e 'use Pod::Usage;pp(\%INC)'

# perl -MData::Dump=pp -e 'use LWP::Simple;pp(\%INC)'

#perl -M'LWP' -e 'use Data::Dumper; print Dumper \%INC' | grep LWP
