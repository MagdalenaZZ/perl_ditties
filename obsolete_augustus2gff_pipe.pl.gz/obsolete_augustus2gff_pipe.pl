#!/usr/local/bin/perl -w

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

#unless ($ARGV[0] =~/gtf/) {
#        &USAGE;
#}
	my $in = shift;

system "perl ~mz3/bin/perl/augustus2gff.pl $in $in.gff 1 && perl ~mz3/bin/perl/fix_children_gff4Artemis.pl $in.gff $in.art.gff && rm -fr $in.gff  $in.tun.art.gff";

#&& rm -fr $in.gff $in.art.gff

sub USAGE {

die 'Usage: perl augustus2gff_pipeline.pl <gtf-file> 



'
}
