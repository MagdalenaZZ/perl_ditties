#! /usr/bin/perl -w
#
#
#

use strict;

#my $PI = `echo $$` ;


if (@ARGV != 1 ) {
    print "$0 bam\n" ;
	exit;
}

#my $cutoff = 10;

my $bam = shift ;

#my %intron_bam = () ;

#print STDERR "start parsing...\n" ;



open (IN, "samtools view $bam |") or die "Cannot open BAM-file\n" ;

while (<IN>) {

    chomp ;
    my @a = split /\t/, $_ ;

	# trim sequence and qual from left

	# trim sequence and qual from right

#    next unless $r[5] =~ /N/ ;
#    next unless $r[4] >= $cutoff;
	#print "\n$r[5]\n";
}



exit;







