#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_overlap_finder.pl gff

Finds adjoining overlapping features

Warning: consequtive overlaps are not handled right!!!!


'
}

	my $in = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my $start = 0;
my $end = 0;
my $last_line = 0;

my @out;


my %conts;

# read in each contig separately

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\s+/, $line);
    if ($arr[4]-$arr[3] > 50000 ) {
        print "WARNING: long gene discarded: $line\n";
    }
    else {
        push ( @{$conts{ $arr[0] }},  "$line"); 

    }

    

}

# put in a fake line

foreach my $key (sort keys %conts) {
    push ( @{$conts{ $key }},  "$key\t0\t0\t999999999999998\t999999999999999\t0\t0\t0\t0\t0\t"); 
}



# sort out contigs one by one and check overlaps

	open (OUT, ">$in.out") || die "I can't open $in.out\n";
	open (STA, ">$in.stats") || die "I can't open $in.stats\n";
    print STA "Gene_1\tGene_2\tGene_1_start\tGene_1_end\tGene_2_start\tGene_2_end\tTot_length\tOverlap\t%\n";
#    print "\n";

    my @gff;

foreach my $key (sort keys %conts) {

#    print "$conts{$key}[0]\n";
    my @unsort = @{$conts{$key}};

    my @sort = sort { (split '\t', $a)[3] <=> (split '\t', $b)[3] || (split '\t', $a)[4] <=> (split '\t', $b)[4]    } @unsort ;

#            print "START\n";
    # check overlap with previous

    my $last_end = "0";
    my $last_start = "0" ;
    my $pre_start = "0" ;
    my @last_gene= '' ;
    my $let = "A";
    my $last_1 = "0";
    my $last_2 = "0";
    my $last_con = "0";
 
    foreach my $lin (@sort) {
#        print "$lin\n";
        my @ar2 =split (/\s+/, $lin);

    

        my $min = ($ar2[3], $ar2[4] )[$ar2[3]> $ar2[4]];
        my $max = ($ar2[3], $ar2[4] )[$ar2[3] < $ar2[4]];
        my $gene = $ar2[8];

#        print " \n $last_start\t$last_end\t$min\t$max\n";

        # judge overlap
        #if ($min=~/999999999999999/) {

                #}
        # not overlapping
            if ( $last_end <= $min ) {
                
                # empty last 
                #
#                print "OVL stopped on: $ar2[0]\t$ar2[1]\t$ar2[2]\t$last_start\t$last_end\t.\t+\t.\t";
                my $len = scalar(@last_gene);

#                print OUT "$ar2[0]\t$ar2[1]\t$ar2[2]\t$last_start\t$last_end\t.\t+\t.\tID=$key.$let" ."_" ."$len";
#                print OUT  join(";", @last_gene);
#                print OUT ";$gene\n";
                
                my $a = "$ar2[0]\t$last_1\t$last_2\t$last_start\t$last_end\t.\t+\t.\tID=$key.$let" ."_" ."$len";
                my $b =  join(";", @last_gene);
                my $c = ";$gene\n";
                $c=~s/\;\;/\;/g;
#                my $gff = "$a$b$c";

                unless ( $last_1=~/^0$/ ) {
                    push (@gff, "$a$b$c");
                }

                @last_gene= '' ;
#                 print "NOVL $min more than $last_end\n";
               
                 $pre_start = $min;
                $last_start = $min;
                $last_end = $max;
                $let++;
                $last_1 = $ar2[1];
                $last_2 = $ar2[2];
                $last_con = $ar2[0];

                push (  @last_gene ,$gene);

            }
            # different strands
            elsif ($last_con!~/$ar2[0]/) {

                $pre_start = $min;
                $last_start = $min;
                $last_end = $max;
                $let++;
                $last_1 = $ar2[1];
                $last_2 = $ar2[2];
                $last_con = $ar2[0];


            }
        #  overlapping
            else {

# make stats
                my $len1 = $last_end - $pre_start ;
                my $len2 = $max - $min ;

        my $min2 = ($pre_start, $min  )[$pre_start> $min ];
        my $max2 = ($last_end, $max  )[$last_end < $max ];

                my $totlen = $max2 - $min2  ;


                my $ovl = $last_end - $min;
                my $ovlpro = sprintf( "%.2f" , (100*($ovl/$totlen))) ;
#                $rounded = sprintf("%.3f", $number);
                
#                my @ls = split (/ID=/, $last_gene[-1]);
                my $string = $last_gene[-1];
                $string =~ s/^\s+//g;
                $string =~ s/^\s+//g;
                print STA "$string\t$gene\t$pre_start\t$last_end\t$min\t$max\t$totlen\t$ovl\t$ovlpro\n";


# adjust for next round
#                 print "OVL $min less than $last_end\n";
                $pre_start = $min;
                $last_end = $max;
                $last_1 = $ar2[1];
                $last_2 = $ar2[2];
                $last_con = $ar2[0];
                push (  @last_gene ,$gene);


            }


    
        }
#   shift @gff;
}


# pop @gff;

foreach my $elem (@gff) {
    print OUT "$elem";
}

close (IN);
close (OUT);


__END__



