#!/usr/bin/perl -w

use strict;

unless (@ARGV > 2) {
        &USAGE;
}

sub USAGE {

    die '


Usage: fastn_trim_poly-A.pl   <poly-A-length>  <%trim>   read_1.fastq [ read_2.fastq  ] 

This script takes a fastq/fasta paired or unpaired file(s).
    
In an unpaired file, it strips out the sequences which have a total AT-content more than <%trim> 
    and at least one string of poly-A the length of <poly-A-length>

In a paired file, it strips out all pairs for which at least one of the members fail the criteria




### Example:

fastn_trim_poly-A.pl 8 80 read_1.fastq  read_2.fastq   <- strips our reads of at least 80% AT, and containing a polyA-track of at least 8 As



### You can adjust the parameters to practically discard either the <%trim> criterion or the <poly-A-length> criterion :

fastn_trim_poly-A.pl 8 5 read_1.fastq  read_2.fastq   <- strips our reads of at least 5% AT (should be most reads), and containing a polyA-track of at least 8 As

fastn_trim_poly-A.pl 1 95 read.fasta     <- strips our reads of at least 95% AT, and containing a polyA-track of at least 1 As (should be most reads)


A suitable balance could for instance be 10 80.




    
    ' . "\n";
}

my $pol = shift;
my $percent = shift;
my $fas = shift;
my $fas2 = shift;

my $polA = "A" x $pol ;
my $pola = "a" x $pol ;
my $polT = "T" x $pol ;
my $polt = "t" x $pol ;

#print "$polA\n";



my $paired = 0;
if ($fas2 =~/\w+/) {
        $paired = 1;
}


=pod
if ($fas =~/q$/ ) {
    print "I'm fastq\n";
}
elsif ($fas =~/a$/ ) {
    print "I'm fasta\n";
}
=cut

if ( $paired == 1 and $fas =~/a$/  ) {
     print "I'm paired fasta\n";

    open (IN, "<$fas");
    open (IN2, "<$fas2");

    $fas=~s/_1\./\./;
    open (OUT, ">$fas.$pol.$percent.no_polyA_1");
    open (OUT2, ">$fas.$pol.$percent.no_polyA_2");
    open (DIS, ">$fas.$pol.$percent.no_polyA.discarded");




    print "\nNOT IMPLEMENTED\n\n";









}

elsif ( $paired == 1 and $fas =~/q$/ ) {
     print "I'm paired fastq\n";

    open (IN, "<$fas");
    open (IN2, "<$fas2");

    $fas=~s/_1\./\./;
    open (OUT, ">$fas.$pol.$percent.no_polyA_1");
    open (OUT2, ">$fas.$pol.$percent.no_polyA_2");
    open (DIS, ">$fas.$pol.$percent.no_polyA.discarded");



    while (<IN>) {
        
        chomp;

        if ($_=~'^@') {
        my $head = $_;
        my $seq = <IN>;
        my $link = <IN>;
        my $qual = <IN>;
        my $length = length($seq);
        my $A_count = $seq =~ tr/AaTt//;
        my $quota = 100*($A_count/$length);

        #print "1\t$head\t$seq";   
        #print "1\t$quota\n";


            while (<IN2>) {
                chomp;
                #print "2$_\n";
                
                if ($_=~'^@') {
                    my $head2 = $_;
                    my $seq2 = <IN2>;
                    my $link2 = <IN2>;
                    my $qual2 = <IN2>;
                    my $length2 = length($seq2);
                    my $A_count2 = $seq2 =~ tr/AaTt//;
                    my $quota2 = 100*($A_count2/$length2);

                    #print "2\t$head2\t$seq2";                    
                    #print "2\t$quota2\n";


                    if ($quota > $percent and ( $seq=~/$polA/ or $seq=~/$pola/ or  $seq=~/$polT/ or $seq=~/$polt/ )  ) {
                        print DIS "$head\n$seq$link$qual";
                        print DIS "$head2\n$seq2$link2$qual2";

                    }
                    elsif ($quota2 > $percent and ( $seq2=~/$polA/ or $seq2=~/$pola/ or  $seq2=~/$polT/ or $seq2=~/$polt/ )  ) {
                        print DIS "$head\n$seq$link$qual";
                        print DIS "$head2\n$seq2$link2$qual2";

                    }
                    else {
                        print OUT "$head\n$seq$link$qual";
                        print OUT2 "$head2\n$seq2$link2$qual2";

                    }




                    last;
                }
                

            }
        }

    }








}

elsif ( $paired == 0 and $fas =~/q$/ ) {
     print "I'm unpaired fastq\n";
    open (OUT, ">$fas.$pol.$percent.no_polyA");
    open (DIS, ">$fas.$pol.$percent.no_polyA.discarded");

    open (IN, "<$fas");
    while (<IN>) {
    chomp;

        if ($_=~'^@') {
        my $head = $_;
        my $seq = <IN>;
        my $link = <IN>;
        my $qual = <IN>;
        my $length = length($seq);
        my $A_count = $seq =~ tr/AaTt//;
        my $quota = 100*($A_count/$length);
        #print "$length\t$A_count\t$quota\t$percent\n";
        
        if ($quota > $percent and ( $seq=~/$polA/ or $seq=~/$pola/ or  $seq=~/$polT/ or $seq=~/$polt/ )  ) {
            print DIS "$head\n$seq$link$qual";
        }
        else {
            print OUT "$head\n$seq$link$qual";

        }

        }

    }



}


else {
     print "I'm unpaired fasta\n";

    open (OUT, ">$fas.$pol.$percent.no_polyA");
    open (DIS, ">$fas.$pol.$percent.no_polyA.discarded");

    system "fasta2singleLine.py $fas $fas.sl";
    open (IN, "<$fas.sl");
    while (<IN>) {
    chomp;

        if ($_=~'^>') {
        my $head = $_;
        my $seq = <IN>;
#        my $link = <IN>;
#        my $qual = <IN>;
        my $length = length($seq);
        my $A_count = $seq =~ tr/AaTt//;
        my $quota = 100*($A_count/$length);
        #print "$length\t$A_count\t$quota\t$percent\n";
        
        if ($quota > $percent and ( $seq=~/$polA/ or $seq=~/$pola/ or  $seq=~/$polT/ or $seq=~/$polt/ )  ) {
            print DIS "$head\n$seq";
        }
        else {
            print OUT "$head\n$seq";

        }

        }

    }

}



close OUT;

exit;



