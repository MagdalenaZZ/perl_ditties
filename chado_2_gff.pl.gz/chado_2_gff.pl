#!/usr/local/bin/perl -w
#
use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die '
Usage: 
perl ~/bin/perl/chado_2_gff.pl gff  


mz3 script run after chado_exporter.pl
Takes a gff from Chado, and makes it Artemis-readable

'
}

# open the file

my $gff = shift;
my $prefix = shift;

#my $gff = shift;


	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

    	open (OUT, ">$gff.nice.gff") || die "I can't open $gff.nice.gff\n";

#	my @gff = <GFF>;




# parse the array



foreach my $line (@gff) {
chomp $line;
         $line=~s/ID=//g;
         $line= $line . "\t/product=\"-\"";
# print "$nno\n";
    my @arr=split(/\t/, $line);


    if ($arr[2]=~/gene/) {

         print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr[8]\n";
         $arr[2]=~s/gene/polypeptide/;
         $arr[9]=~s/\///;
         print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr[8].pep;Parent=$arr[8].1;$arr[9]\n";


     } 
        
    elsif ($arr[2]=~/mRNA/) {
        my @arr3 = split (/[\.;]/, $arr[8]);
        $arr3[2]=~s/Name=/Parent=/;
        print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr3[0].1;$arr3[2]\n";

    }

    elsif ($arr[2]=~/exon/) {
        $arr[2]=~s/exon/CDS/;
        my @arr4 = split (/[\.;:]/, $arr[8]);
        print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr4[0]:$arr4[1]:$arr4[2]:$arr4[3];Parent=$arr4[0].1\n";



    }

    else {
        print "WARN: something wrong with line $line\n";
    }

#    my $new_line=join("\t", @arr);
#    print "$line\n";
#    print OUT "$new_line\n";
}




	close (OUT);

