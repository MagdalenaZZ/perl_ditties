#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

    die '


Usage: fasta_stripLeadingN.pl  fasta

Strips NNNNs from start and end of contigs


' . "\n";
}


my $fas = shift;
my $str = 1;


open (OUT, ">$fas.N.fas");

system "fasta2singleLine.py $fas $fas.sl";


open (IN, "<$fas.sl");



while (<IN>) {
chomp;

    if ($_=~'^>') {
        my $head = $_;
        my $seq = <IN>;
        $seq = uc($seq);
        my $length = length($seq);
        #print "BEFORE: $head\n$seq\n";

	    if ($seq =~ /^N/ ) {
            #$seq =~s/$polyA/$polyN/gi;
            #$seq =~s/$polyT/$polyN/gi;
            #my $length = $str;

            for (; $length > 0 ; $length--) {
                $seq =~s/^N//gi;
                #$seq =~s/^N//gi;
                #$seq =~s/^N//gi;
            }
        }
       
        # reset length
        $length = length($seq);
         
	    if ($seq =~ /N$/ ) {
            #$seq =~s/$polyA/$polyN/gi;
            #$seq =~s/$polyT/$polyN/gi;
            #my $length = $str;

            for (; $length > 0 ; $length--) {
                $seq =~s/N$//gi;
                #$seq =~s/N$//gi;
                #$seq =~s/N$//gi;
            }
        }

        #print " AFTER: $head\t$seq\n";
        print  OUT "$head\n$seq";

    }

}

close OUT;

exit;





