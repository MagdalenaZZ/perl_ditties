#!/usr/local/bin/perl -w

# 

use strict;
use Cwd;
use File::Slurp;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: cuffdiff_prepare.pl gff  \'infile-pattern\'


Prepares input for cuffdiff

...and then tries to match the other BAM-files in the folder to suggest a nice cuffdiff input 

Example: perl ../cuffdiff_prepare.pl HYM.gff \'HYM_\w+\'


'
}



my $in = shift;
my $pattern = shift;
my @arrx = split(/\./, $in);
my $in2 = $arrx[0];


	open (IN, "<$in") || die "I can't open $in\n";
	my @gff = <IN>;
	close (IN);


	open (OUT, ">$in.cuff") || die "I can't open $in.cuff\n";


    # fix gff

foreach my $line (@gff) {
chomp $line;
    my @arr = split (/\t/, $line);
    if ($arr[2]=~/^gene$/) {
        print OUT "$arr[0]\t$arr[1]\ttranscript\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\t$arr[8]\n";
    }
    elsif ($arr[2]=~/^CDS$/ ) {
       print OUT "$arr[0]\t$arr[1]\texon\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\t$arr[8]\n";
    }
    elsif ($arr[2]=~/^exon$/) {
        my @arr8 = split(/;/, $arr[8]);
        $arr8[2] =~s/:mRNA//;
        print OUT "$arr[0]\t$arr[1]\texon\t$arr[3]\t$arr[4]\t.\t$arr[6]\t.\t$arr8[0];$arr8[2]\n";
    }

    else {
    }
}

	close (OUT);

print "\nFinsished making nice gff: $in.cuff\n";
# suggest input

my $cwd = cwd();
my @files = read_dir( "$cwd", prefix => 1 ) ;

my $fasta = "GENOME";
my @bams;

foreach my $file (@files) {
    chomp $file;
    if ($file =~m/$pattern/ ) {
        if ($file =~/\.fa$/ || $file =~/\.fasta$/ || $file =~/\.fas$/  ) {
            $fasta = $file;
        }
        elsif ($file =~/\.bam/) {
            push ( @bams, $file);
        }
        else {
        }
    }
    else {
        # ignore
    }
}

print "Found genome fasta-file: $fasta\n";

my $bam = join(" ", @bams);
my $len  = scalar(@bams);
print "Found $len BAM-files : $bam\n";


print "\nSuggested cufflinks input:\nbsub.py -q basement 5 $in2 cuffdiff -b $fasta -o $in2 -v -u -p 4  $in.cuff $bam\n\n";




# make key for post-processing 

open (OUT2, ">$in.key") || die "I can't open $in.key\n";


my $ind = "1";



foreach my $ba (@bams) {

print OUT2 "q$ind\t$ba\n";
print  "q$ind\t$ba\n";
$ind++;

}

close (OUT2);
