#!/usr/bin/perl -w
# mz3 script for adding parent-children relationship to a gtf file and make it into gff

use strict;


unless (@ARGV == 1) {
        &USAGE;
}

# my @array;
my $current_ID = "";
my $last_ID = "";
my $counter = "0";
my @result = '';
my $ID_number = "0";

while (<>) {
	chomp;
tr/=/ /;

	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $note = $line[9];
#	$note =~ s/"//g;
#	$note =~ s/;//;

if ($tag =~ /transcript/) {
	$ID_number ++;
	my $newline = "$name\t$method\tgene\t$start\t$end\t.\t$strand\t.\tID=cuff$ID_number\n";
	push (@result, $newline);
#	print" $newline";
	my $newline2 = "$name\t$method\ttranscript\t$start\t$end\t.\t$strand\t.\tID=Transcript.cuff$ID_number;Parent=cuff$ID_number\n";
#	print "$newline2";
	push (@result, $newline2);

	$last_ID = $note;
	$counter = "0";
}
elsif ($tag =~ /exon/) {	
	$current_ID = $note;		
		if ($current_ID eq $last_ID) {
		$counter ++;
		}
	my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t.\tID=cuff$ID_number.Exon$counter;Parent=Transcript.cuff$ID_number\n";
	push (@result, $newline);
#	print "$newline";<STDIN>;
#	$last_ID = $note;
}

else {
print "This line is not transcript or exon: $_";
}

}
 print @result;


sub USAGE {

die 'Usage: perl cufflinks2gff.pl <gff-file> > outputname

This version re-names those blasted cufflinks-names


'
}

__END__

