#!/usr/local/bin/perl -w
#
use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die '
Usage: 
perl ~/bin/perl/fasta_rename.pl fasta list out


mz3 script for giving new nice names to genes in a fasta-file

The list is a tab-delimited file with the old name and the new name on each row

old_name1<TAB>new_name1
old_name2<TAB>new_name2
old_name3<TAB>new_name3

Output comes in two files; 
1. out - the sequences with names changed 
2. out.unchanged - the sequences which were not in the list, so have not had their name changed - if this file is missing all names were changed

If you call list LIST , you will get the sequenced re-named seq1..seqn




'
}

# open the file

my $fasta = shift;
my $list = shift;
my $out = shift;
my %hash;
my @list;




# read in list (or make one)

if ($list=~/^LIST$/) {
    system "cat $fasta | tr -d ' '  > $fasta.temp";
    system "samtools faidx $fasta.temp";
    open (LIST2, "<$fasta.temp.fai") || die "I can't open $fasta.temp.fai\n";
    open (KEY, ">$fasta.key") || die "I can't open $fasta.key\n";

    my $i=1;
        while (<LIST2>) {
            my @arr = split(/\t/,$_);
            push ( @list, "$arr[0]\tseq$i\n");
            print KEY "$arr[0]\tseq$i\n";
            $i++;
        }
    close (LIST2);
    system "rm -f $fasta.fai";
    print "\nRenaming with generic names\n\n";


}
else {
	open (LIST, "<$list") || die "I can't open $list\n";
	@list = <LIST>;
	close (LIST);




}


# clean up list and put in a hash


foreach my $line (@list) {
    chomp $line;
    my @arr = split(/\t/, $line);
    #$arr[0]=~s/ID=//;
    #$arr[1]=~s/ID=//;
    $hash{$arr[0]}=$arr[1];
    #print "$arr[0]\t$arr[1]\n";
}





# open fasta and output

my @fas;

if ($list=~/^LIST$/) { 
    open (FAS, "<$fasta.temp") || die "I can't open $fasta.temp\n";
    @fas = <FAS>;
    close (FAS);

}

else {
    open (FAS, "<$fasta") || die "I can't open $fasta\n";
    @fas = <FAS>;
    close (FAS);
}


open (OUT, ">$out") || die "I can't open $out\n";
open (OUT2, ">$out.unchanged") || die "I can't open $out.unchanged\n";




my $add="0";


# go through fasta




foreach my $seq (@fas) {
    chomp $seq;


    unless ($seq=~/\w+/) {
        next;
    }

    # for each label that is a header

    if ($seq=~/^>/) {
        $seq=~s/\>//;
        
        

        # if it has a new name, change it
        if (exists $hash{$seq}) {
            #print "EXISTS\t$seq\t$hash{$seq}\n";
            print OUT "\>$hash{$seq}\n";
            $add="1";
        }

        # if it does not have a replacement name - ignore and keep old name  
        else {
            #print "NONE \t$seq\t$hash{$seq}\n";
            print OUT2 "\>$seq\n";
            $add="0";
        }
    }



    #deal with the protein/DNA sequences
    else {
        #if they belong to a changed gene
        if ($add=~/1/){
            print OUT "$seq\n";
            #print "$seq\n";

         }
        #if they belong to an unchanged gene
        else {
            print OUT2 "$seq\n";
            #print "$seq\n";
        }

    }

}
    
        
        
        close (OUT);
        close (OUT2);

        unless (-s "$out.unchanged") {
            system "rm -f $out.unchanged";
        }

system "rm -f $fasta.temp $fasta.temp.fai ";
exit;
