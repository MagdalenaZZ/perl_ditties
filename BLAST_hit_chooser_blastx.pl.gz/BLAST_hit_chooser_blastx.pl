#!/usr/local/bin/perl -w

# mz3 script for taking tophat output accepted_hits.sam and turning it into cufflinks-ready file


use strict;

unless (@ARGV == 3) {
        &USAGE;
}

my $blast = shift;
my $list = shift;
my $out = shift;

sub USAGE {

die 'Usage: BLAST_hit_chooser.pl BLASTinput list outputname

Takes a list of genes and retrieves the best BLAST-hits from each of those



'
}



	open (IN, "<$blast") || die "I can't open $blast\n";
	my @blast = <IN>;
	close (IN);


	open (IN, "<$list") || die "I can't open $list\n";
	my @list = <IN>;
	close (IN);


	open (OUT, ">$out") || die "I can't open $out\n";
#	open (OUT2, ">$out.errors") || die "I can't open $out.errors\n";


my %hash;
#make a hash of gene-names
foreach my $line (@list) {
chomp $line;
		my @arr = split(/\s+/, $line);
        push (@{$hash{$arr[0]}}, 1); 
	}

# attach the first blast-hit to that key
# unless it is on the negative strand or there is alread a match there
my $index=0;

foreach my $line (@blast) {
chomp $line;
		my @arr = split(/\s+/, $line);
        my $key = $arr[0];
        if ( $hash{$key} =~m/^1$/ & $arr[12] !~m/\-/ ) {
            push (@($hash{$key}},  $line); 
    	$index++;
        }
        else {
            # less optimal hit
        }

    }
}

# report result
#
foreach my $key (sort keys %hash) {
    #   my @arr = split ();
print OUT "$hash{$key}\n";

}

close (OUT);
# print the best hit
#


__END__

foreach my $line (@list) {
chomp $line;
my $index = 0;
	foreach my $elem (@blast) {
		my @arr = split(/\s+/, $elem);
		if ($arr[0]=~/$line/ and $line=~/$arr[0]/) {
			print OUT "$elem";
			$index = 1;
#			shift @list;
		}
		else {
#			print OUT2 "$arr[0] is not in gff-file\n";
#			shift @blast;
		}

	}

	if ($index==1) {
		shift @list;
	}
}

foreach my $line (@list) {
print OUT2 "$line does not have a BLAST-hit\n";
}

close (OUT);
close (OUT2);

