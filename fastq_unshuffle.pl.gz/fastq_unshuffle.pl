#!/usr/bin/perl
use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die ' 

perl ~/bin/perl/fastq_unshuffle.pl shuffled.fastq

Suitable even if the fastq is very shuffled/unbalanced

Warning: ignores strandedness of unpaired reads


';

}


my $com=shift;

 open (IN, "<$com");

$com=~s/\.fastq//;




open (OUT1, ">$com.1.fastq");
open (OUT2, ">$com.2.fastq");
open (OUTS, ">$com.se.fastq");


my %h;

while (<IN>) {



    if ($_=~/^@/) {
    
        my $head = $_;
        my $seq = <IN>;
        my $mid = <IN>;
        my $qual = <IN>;

#        print "HI\n";

        chomp $head;
        chomp $seq;
        chomp $mid;
        chomp $qual;
        my @arr = split ( /\//, $head);
        push (@arr, "SE");

        #       print "$arr[0]\t$arr[1]\t$head\t$seq\t$mid\t$qual\n";

        $h{$arr[0]}{$arr[1]} = "$head\n$seq\n$mid\n$qual\n";

    }
    else {
        # no
    }


}

close (IN);

foreach my $sq (sort keys %h) {

   my  $count = keys %{$h{$sq}};

#   print "COUNT\t$sq\t$count\n";

# deal with if the count is 2 - pair
#
   if ($count =~/2/) {

      foreach my $key ( sort keys %{$h{$sq}} ) {

       if ($key =~/1/) {
            print OUT1 "$h{$sq}{$key}";
       }
       elsif ($key=~/2/) {
            print OUT2 "$h{$sq}{$key}";
       }
        

        }

    }

# deal with if the count is 1 - unpaired
#


   if ($count =~/1/) {

      foreach my $key ( sort keys %{$h{$sq}} ) {

#       if ($key =~/1/) {
   #    }
   #    elsif ($key=~/2/) {
   #    }
        my @arr2 = split(/\n/, $h{$sq}{$key});
        $arr2[0]=~s/\/2/\/1/;

        print OUTS "$arr2[0]\n$arr2[1]\n$arr2[2]\n$arr2[3]\n";

        }

    }






}


close (OUT1);
close (OUT2);
close (OUTS);



