#!/usr/bin/perl -w


if (@ARGV < 2 ) {
    print "\nUsage: R_nnet_wrapper.pl Eset signal training-set Size-range Decay-range\n\n\n" ;

    print "\nExample: R_nnet_wrapper.pl myv_COMBAT tmpsig 1412:1442 20,30,5 20:3  \n\n\n" ;
    #print "\nExample: R_nnet_wrapper.pl myv_COMBAT tmpsig Celltype~. 1412:1442 20,30,5 20:3  \n\n\n" ;

    print "\nEset = an R expressionset object e.g. es.RData only type es. The name of the es is expected to be the same as \n" ;
    print "\nsignal = a list with gene names of genes that should be used (same as in eset) \n" ;
    print "\nTraining set columns in data set (the others are expected to be the test-set)\n\n\n" ;
    print "\nNeural network optimisation paramenters\n" ;
    print "\nSize-range is from 20 to 30, in intervals of 5 \n\n\n" ;
    print "\nDecay-range is from 2^-20 to 2^-3 \n\n\n" ;

        exit;
}




# Input
#
my $eset= shift; # Expression set
my $signal=shift; # List of signal genes
#$model=shift;
my $tt=shift;
my $sr=shift;
my $sr2=$sr;
$sr=~s/\,/_/g;
my $dr= shift;

#$ts=shift; # Training set
#$num= shift;

open (R, ">$eset.$signal.$sr.$dr.R") || die "I can't open $eset.$signal.$sr.$dr.R\n";

print R "library(pryr)\n";
print R "library(ggplot2)\n";
print R "library(gplots)\n";
print R "library(Biobase)\n";
print R "library(\"class\")\n";
print R "library(\"nnet\")\n";
print R "library(\"CMA\")\n";
#print R "fi <- paste(\"$eset\",\".RData\", sep=\"\")\n";
print R "load(\"$eset.RData\")\n";
print R "attach(\"$eset.RData\")\n";
print R "try(eset <- $eset)\n";
#print R "try(eset <- df)\n";




# Take only the signal part of the dataset
print R "ud =  read.table(\"$signal\", header=FALSE )\n";
print R "rownames(ud) <-ud\$V1\n";
print R "colnames(ud) <- \"Symbol\"\n";

print R "chosen <- rownames(exprs(eset)) %in% rownames(ud)\n";
print R "chosen2 <- rownames(ud) %in% rownames(exprs(eset))\n";
print R "ud2 <- as.data.frame(ud[chosen2,])\n";
print R "colnames(ud2) <- \"Symbol\"\n";
print R "rownames(ud2) <-ud2\$Symbol\n";

print R "esetchosen <- exprs(eset)[chosen,]\n";
print R "exprs(eset) <- esetchosen\n";
print R "mem_used()\n";

# Take only the relevant samples
print R "esetsub <- eset[,$tt]\n";


print R 'cols <- apply(as.data.frame(cbind(as.vector(esetsub@phenoData@data$Celltype),as.vector(esetsub@phenoData@data$Transformation))), 1, paste, collapse=".")
cols[cols=="CMP.Normal"] <- "green"
cols[cols=="CMP.ME"] <- "darkgreen"
cols[cols=="CMP.MAF6"] <- "darkgreen"
cols[cols=="HSC.Normal"] <- "pink"
cols[cols=="HSC.ME"] <- "red"
cols[cols=="HSC.MAF6"] <- "red"
cols[cols=="MPP.Normal"] <- "yellow"
cols[cols=="MPP.ME"] <- "orange"
cols[cols=="MPP.MAF6"] <- "orange"
cols[cols=="LMPP.Normal"] <- "yellow"
cols[cols=="LMPP.ME"] <- "orange"
cols[cols=="LMPP.MAF6"] <- "orange"
cols[cols=="GMP.Normal"] <- "yellow"
cols[cols=="GMP.ME"] <- "orange"
cols[cols=="GMP.MAF6"] <- "orange"


';

print R "hmcols<-colorpanel(100,\"darkred\",\"white\",\"darkgreen\")\n";
print R "fn <- paste(\"$eset.$signal\",\".heat.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "heatmap.2(exprs(esetsub), trace=\"none\", col=hmcols, Rowv=FALSE, ColSideColors=cols )\n";
print R "dev.off()\n";





# Make the dataset
print R "ir <- t(exprs(esetsub))\n";
print R "fir <- t(exprs(eset))\n";

#print R "targets <- class.ind(as.vector(esetsub\@phenoData\@data\$Celltype) )\n";
#print R "rownames(targets) <- rownames(ir)\n";
print R "tars <- as.vector(esetsub\@phenoData\@data\$Celltype)\n";
print R "targets <- class.ind(tars)\nrownames(targets) <- rownames(ir)\n";
# LOOCV
print R "learns <- GenerateLearningsets(y=tars, method=\"LOOCV\")\n";
print R "learns\@learnmatrix\n";

# variable selection
print R "varsel_LOOCV <- GeneSelection(X = ir, y = as.factor(tars), learningsets = learns, method=\"f.test\")\n";

# Get the variables which are most helpful
print R "show(varsel_LOOCV)\n"; 
print R "toplist(varsel_LOOCV, iter = 1)\n";
print R "sort(table(varsel_LOOCV\@rankings[[1]][,1:5]), decreasing=TRUE)\n";
#print R "for (i in 1:3) {\n";
#print R "     seliter <- c(seliter, as.vector(varsel_LOOCV\@rankings[[i]][,1:5]))\n";
#print R "}\n";
#print R "sort(table(seliter), dec = TRUE)\n";
# plot(varsel_LOOCV) # makes nice plot of parameter importance



print R "nbgenes <- ncol(ir)\n";
print R "nbgenes\n";
print R "if (nbgenes>30) {nbgenes <- 30}\n";
print R "nbgenes\n";
print R "dim(ir)\n";
# tune nnet size = 1:5, decay = c(0, 2^{-(4:1)})
#print R "# Tuningstep started, please be patient...\n";
#print R "tuningstep <- CMA:::tune(X = ir, y = as.factor(tars), learningsets = learns, classifier = nnetCMA, genesel= varsel_LOOCV, nbgene = nbgenes , grids = list(size = 10:50,decay = c(0, 2^{-(14:1)})) , MaxNWts = 50000)\n";
#print R "tuningstep <- CMA:::tune(X = ir, y = as.factor(tars), learningsets = learns, classifier = nnetCMA, genesel= varsel_LOOCV, nbgene = nbgenes , grids = list(size = 10:11,decay = c(0, 2^{-(11:1)})))\n";
## seq.int(10,50,5)

print R "nrowir<-nrow(ir)\n";
print R "nrowfir<-nrow(fir)\n";

# for each parameter set, write out the within result and the prediction result
# create a neural network for each
#

print R '
#size <- seq.int(20,30,5)
#decay <-  c(0, 2^{-(4:1)})
#size <- seq.int(10,50,5)
#decay <-  c(0, 2^{-(20:3)})

';



print R "size <- seq.int($sr2)\ndecay <- c(0, 2^{-($dr)})\nsize\ndecay\n";

print R "mem_used()\n";
print R ' 

nnets <- list()
ind=1
for (sz in size) {
        for (j in decay) {
            for (i in 1:nrow(learns@learnmatrix)) {
                nnets[[ind]] <- i+j
                nnets[[ind]] <- nnet(ir[learns@learnmatrix[i,],], targets[learns@learnmatrix[i,],],size = sz, rang = 0.5,decay = j, maxit = 10000, MaxNWts = 1000000, softmax=TRUE, Hess=TRUE, trace=FALSE)
                ind=ind+1
            }
            print(paste("Decay ",j))
        }
        print (paste("Size ",sz))
}


';
print R "mem_used()\n";


# apply the nnets to the testsets and the training sample
# for each nnets

print R ' 
reps <- rep( nrowir:1,length(size)*length(decay))
evals <- data.frame()
i=1

for (i in 1:length(nnets)) {
evals[i,1] <- sum(diag(table(max.col(predict(nnets[[i]], ir))[-reps[i]],max.col(targets)[-reps[i]])))/sum(table(max.col(predict(nnets[[i]], ir))[-reps[i]],max.col(targets)[-reps[i]]))
#   predicted value == real value  
evals[i,2] <- max.col(predict(nnets[[i]], ir[reps[i],])) == max.col(t(as.matrix(targets[reps[i],])))
}
';





print R ' 
nnets <-list()
colnames(evals) <- c("Within", "NewPred")
evals$Size <- rep(size, each =length(decay)*nrowir)
evals$Decay <- rep(decay, length(size) , each=nrowir)
evals$Reps <- rep(1:nrowir, length(size)*length(decay))
evals$SizeDecay <-paste(rep(size, each =length(decay)*nrowir), rep(decay, length(size) , each=nrowir), sep="_")

library(dplyr)

by_Size <- group_by(evals, Size)
by_Decay <- group_by(evals, Decay)
by_Reps <- group_by(evals, Reps)
by_SizeDecay  <- group_by(evals, SizeDecay)


summarise(by_Size, mean(Within), mean(NewPred))
summarise(by_Decay, mean(Within), mean(NewPred))
summarise(by_Reps, mean(Within), mean(NewPred))

as.data.frame(summarise(by_SizeDecay, mean(Within), mean(NewPred)))

tmp <- as.data.frame(summarise(by_SizeDecay, mean(Within), mean(NewPred)))

';

print R "mem_used()\n";

print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".evalues.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R 'plot(tmp$`mean(Within)`,tmp$`mean(NewPred)`, xlab="Training set accuracy", ylab="Test set accuracy")
';
print R "dev.off()\n";
print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".evalues.tab\", sep=\"\")\n";
print R "write.table(tmp,file=fn, sep=\"\\t\")\n";

print R 'best <- which.max( tmp[,3]*10+tmp[,2] )*nrowir
best_size <- evals$Size[best]
best_decay <- evals$Decay[best]
best_size
best_decay
';


# get paramenters to average over
print R "res <- list()\n";
print R "seliter <- numeric()\n"; 
print R "for (i in 1:nrow(learns\@learnmatrix)) {\n";
print R "res[[i]] <- nnet(ir[learns\@learnmatrix[i,],], targets[learns\@learnmatrix[i,],],size = best_size, rang = 0.5,decay = best_decay, maxit = 10000, MaxNWts = 1000000, softmax=TRUE, Hess=TRUE)\n";
print R "seliter <- c(seliter,res[[i]]\$wts)\n";
print R "}\n";

print R "for (i in 1:nrow(learns\@learnmatrix)) {\n";
print R "}\n";

# Do predictions for each trained network
print R "library(caret)\n";

print R "preds <- list()\n";
print R "varimp <- list()\n";
print R "for (i in 1:nrowir) {\n";
print R "    preds[[i]] <- predict(res[[i]], fir)\n";
print R "    varimp[[i]] <- varImp(res[[i]])\n";
print R "}\n";
print R "varimp\n";

print R "i=0\n";
print R "j=0\n";
print R "resway <- numeric()\n";

print R "for (i in 1:nrowfir) {\n";

print R "    for (j in 1:nrowir) {\n";
print R "        resway <- c(resway,preds[[j]][i,])\n";
print R "    }\n";

print R "}\n";

print R "resway2 <- unlist(resway)\n";
print R "dim(resway2) <- c((nrowir*3),1452)\n";

print R "residuls <- rep(0,nrowfir,each=20)\n";
print R "dim(residuls) <- c(nrowfir,20) \n";

print R "i=0\n";
print R "for (i in 1:nrowfir) {\n";
print R '    tmp <- resway2[,i]
    dim(tmp) <- c(3,nrowir)
    #2boxplot(t(tmp))
    residuls[i,1] <- nrowir - max(colSums(t(tmp)))
    residuls[i,2:4] <- apply(t(tmp), 2, mean)
    residuls[i,5:7] <- apply(t(tmp), 2, min)
    residuls[i,8:10] <- apply(t(tmp), 2, max)
    residuls[i,11] <- order(residuls[i,2:4], decreasing=TRUE)[1]
}
';

print R "mem_used()\n";

print R "rownames(residuls) <- rownames(fir)\n";
print R 'colnames(residuls) <- c("Residual","Mean1","Mean2","Mean3","Min1","Min2","Min3","Max1","Max2","Max3","Prediction","Celltype",rep("NU",8))
';
print R "residuls[,12]<-as.vector(eset\@phenoData\@data\$Celltype)\n";
print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".class.txt\", sep=\"\")\n";
print R "write.table(as.data.frame(residuls),file=fn, sep=\"\\t\")\n";
#print R "dev.off()\n";

# Do PCA


print R "pca <- prcomp(as.matrix(fir), scale=FALSE)\n";
print R "scores <- data.frame(as.vector(residuls[,11]), pca\$x[,1:3])\n";
print R "pca.rscores <- qplot(x=PC1, y=PC2, data=scores, colour=factor(as.vector(residuls[,11]))) \n";
#,scale_fill_discrete(name="Experimental\nCondition",breaks=c("ctrl", "trt1", "trt2"), labels=c("Control", "Treatment 1", "Treatment 2"))) \n";
print R 'pca.rscores$labels$colour <- "Celltype"
';
print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".final.pca.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(pca.rscores)\n";
print R "dev.off()\n";

#print R "residuls\$Prediction\n";



# Do survival




print R 'library(survival)
library(survcomp)
library(RColorBrewer)
';
# read in survival data

print R "Survi <- read.table( \"Survi.txt\", header=TRUE, sep =\"\\t\" )\n";
print R "rownames(Survi) <- Survi\$SampleGEO\n";


# get a subset of design that matches data

print R "Surviv <- Survi[rownames(fir),]\n";

#dchosen <- rownames(Survi)  %in%  rownames(ass.heat_DE.v.GENENORM)
#Surviv <- Survi[rownames(fir),]

# Just chech that it is all right
print R "all(rownames(residuls)==rownames(Surviv))\n";


print R "cbbPalette <- c( \"#0072B2\", \"#D55E00\",\"#00EE76\" )\n";
print R "colfunc <- colorRampPalette(cbbPalette)\n";


print R "Surviv\$Class<- residuls[,11]\n";
print R "Surviv\$Class[Surviv\$Class<2]  <- \"CMP\"\n";
print R "Surviv\$Class[Surviv\$Class<3 ]  <- \"HSC\"\n";
print R "Surviv\$Class[Surviv\$Class<4]  <- \"MPP\"\n";
# as function of celltype -prediction (make a sensible cutoff and classification)
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviv\$Class), data = Surviv)\n";
print R "S.km\n";
print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".3surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(3) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviv\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(3) )\n";
print R "dev.off()\n";

print R "Surviva<-rbind(Surviv[Surviv\$Class==\"HSC\",],Surviv[Surviv\$Class==\"CMP\",])\n";
print R "survdiff(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km <- survfit(Surv(OSmon, Termin)~as.vector(Surviva\$Class), data = Surviva)\n";
print R "S.km\n";
print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".2surv.pdf\", sep=\"\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "plot(S.km, lty = 1, xlab=\"OS Survival months\", ylab=\"Cohort\", col= colfunc(2) ,  conf.int=TRUE  )\n";
print R "levs <- levels( as.factor(Surviva\$Class))\n";
print R "legend(\"topright\", legend = levs , lty = 1,  col = colfunc(2) )\n";
print R "dev.off()\n";


print R "fn <- paste(\"$eset.$signal.$sr.$dr\",\".RData\", sep=\"\")\n";
print R "ls <- list(ud,ir,varsel_LOOCV,best_size,best_decay,nbgenes,res,preds,residuls,Surviva)\n";
print R "save(ls, file = fn, envir = .GlobalEnv)\n";


## survdiff(Surv(OSmon, Termin)~as.vector(Surviv$Class), data = Surviv)



exit;


