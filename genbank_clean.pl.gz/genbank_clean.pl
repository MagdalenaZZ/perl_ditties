#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: in out

Give a list of gene-names and product description
This program filters the list


'
}


	my $in = shift;

	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">$out.filtered.out2") || die "I can't open $out.filtered.out2\n";

foreach my $line (@in) {
chomp $line;
my @line = split (/"/, $line);

if (exists $line[1]  ) {

#	print ":$line[0]:$line[1]:$line[3]::\n";

#}
#__END__
	$line[1] =~ s/ /_/g;
	$line[1] =~ s/_\(Fragment\)//;
	$line[1] =~ s/PREDICTED:_//;
	$line[1] =~ s/-like//;
    $line[1] =~ s/_like_//;
    $line[1] =~ s/_like$//;
	$line[1] =~ s/-related//;
	$line[1] =~ s/_\(putative\)//;
	$line[1] =~ s/_putative//;
	$line[1] =~ s/putative_/_/;
	$line[1] =~ s/putative:_/_/;
	$line[1] =~ s/Putative_/_/;
	$line[1] =~ s/,_conserved_site/,_/;
	$line[1] =~ s/homolog//;
    $line[1] =~ s/human//;
	$line[1] =~ s/conserved_/_/;
	$line[1] =~ s/Conserved_/_/;
	$line[1] =~ s/Similar_to_/_/;
	$line[1] =~ s/similar_to_/_/;
	$line[1] =~ s/Putative_uncharacterized_protein_//;
	$line[1] =~ s/similar_to_//;
	$line[1] =~ s/Putative_uncharacterized_protein//; 
	$line[1] =~ s/ADAM/adam/ ; 
	$line[1] =~ s/HSP/heat_shock_protein/ ; 
	$line[1] =~ s/TSES/Taenia_soluim_Excretory_and_Secretory_Product(TSES)/ ; 
	$line[1] =~ s/TSP/thrombospondin/ ; 
	$line[1] =~ s/TGTP/Glucose_Transport_Protein_TGTP/ ;
	$line[1] =~ s/PKG/Protein_Kinase_G/ ;
	$line[1] =~ s/\_,_putative// ;
	$line[1] =~ s/LOW_QUALITY_PROTEIN:_structural_maintenance_of// ;
	$line[1] =~ s/__/_/;
	$line[1] =~ s/_isoform_[0-9]//g;
	$line[1] =~ s/\//:/g;
	$line[1] =~ s/\_isoform//g;
	$line[1] =~ s/\_\(yeast\)//g;
	$line[1] =~ s/\_\(predicted\)//g;
	$line[1] =~ s/,$//g;
	$line[1] =~ s/related_to_yeast_//g;
	$line[1] =~ s/\_\(yeast_Atg\_\)//g;
	$line[1] =~ s/_related$//g;
	$line[1] =~ s/probable\_//g;
	$line[1] =~ s/\-1_3\-/-1,3-/g;
	$line[1] =~ s/\-1_4\-/-1,4-/g;
	$line[1] =~ s/\-1_6\-/-1,6-/g;
	$line[1] =~ s/3,5/3',5'/g;
	$line[1] =~ s/-/_/g;
#	$line[1] =~ s/\d_\d/-/g;
	$line[1] =~ s/_member_[0-9]/_/g;
	$line[1] =~ s/Protein/protein/g;
	$line[1] =~ s/\_\(S\._cerevisiae\)//g;
	$line[1] =~ s/\_\(Drosophila\)//g;
	$line[1] =~ s/\_precursor//g;
	$line[1] =~ s/\_precurs//g;
	$line[1] =~ s/predicted\_gene\_//g;
	$line[1] =~ s/predicted\_gene//g;
	$line[1] =~ s/\_high\_molecular\_weight//g;
    $line[1] =~ s/similar\_to//g;
    $line[1] =~ s/gastrula_zinc_finger_protein_XlCGF57\.1/zinc_finger_protein/g;
    $line[1] =~ s/acetylglucosaminyltransferaseputati/galactosyltransferase/g;
    $line[1] =~ s/diagnostic_protein_Taenia_soluim_Excretory_and_Secretory_Product\(TSES\)38/TSES38_protein/g;
    $line[1] =~ s/diagnostic_protein_Taenia_soluim_Excretory_and_Secretory_Product\(TSES\)33/TSES33_protein/g;
    $line[1] =~ s/histone_cluster_1,_H4j/histone_H4/g;
    $line[1] =~ s/kDa/_kDa_/g;
    $line[1] =~ s/kda/_kDa_/g;
    $line[1] =~ s/protein_cognate/protein/ig;
    $line[1] =~ s/heat_shock_cognate_/heat_shock_protein_/ig;
    $line[1] =~ s/kD_/_kDa_/g;
    $line[1] =~ s/heat_shock_70kDa_protein_1/heat_shock_70_kDa_protein/ig;
    $line[1] =~ s/member_B4_/member_B4/g;
    $line[1] =~ s/novel_/_/g;
    $line[1] =~ s/protein_protein/protein/g;
    $line[1] =~ s/GP50a/GP50/g;
    $line[1] =~ s/GP50b/GP50/g;
    $line[1] =~ s/GP50c/GP50/g;
    $line[1] =~ s/G1Y162/EG95/g;
    $line[1] =~ s/EMY162/EG95/g;
    $line[1] =~ s/x_linked/_/ig;
    $line[1] =~ s/y_linked/_/ig;
    $line[1] =~ s/antigen_Sm21\.7/tegumental_antigen/gi;
    $line[1] =~ s/tegument_antigen/tegumental_antigen/gi;
    $line[1] =~ s/venom_allergen_\(val\)_\d+_protein/venom_allergen_\(val\)_protein/gi;
    $line[1] =~ s/antigen_B\d/antigen_B/gi;
    $line[1] =~ s/^_//g;
    $line[1] =~ s/\[/\(/g;
    $line[1] =~ s/\]/\)/g;
    $line[1] =~ s/\(_/\(/g;
    $line[1] =~ s/_\)/\)/g;
    $line[1] =~ s/ii/II/g;
    $line[1] =~ s/iii/III/g;
    $line[1] =~ s/protocadherin2/protocadherin_2/g;
    $line[1] =~ s/protocadherinX/protocadherin_X/g;
    $line[1] =~ s/gamma_\w$/gamma/g;
    $line[1] =~ s/1subunit_gnai1/subunit_alpha/g;
    $line[1] =~ s/betadelta/delta/g;
    $line[1] =~ s/NADP_specific/NADP_dependent/g;
    $line[1] =~ s/_CoA_/_coenzyme_A_/g;
    $line[1] =~ s/proteins/protein/g;
    $line[1] =~ s/_copy_/_/g;
    $line[1] =~ s/_CRA_b/_/g;
    $line[1] =~ s/_CRA_a/_/g;


#_(Drosophila)

#	$line[1] =~ s/\_a//g;
	$line[1] =~ s/\_\_/\_/g;
	$line[1] =~ s/\_\_/\_/g;
	$line[1] =~ s/\_$//g;
	$line[1] =~ s/\,$//g;
	$line[1] =~ s/\.$//g;
    $line[1] =~ s/_and$//g;
    $line[1] =~ s/_for$//g;
    $line[1] =~ s/_from$//g;
    $line[1] =~ s/_in$//g;
    $line[1] =~ s/domain_containing$/domain_containing_protein/g;

    $line[1] =~ s/_recognized_by$//g;
	$line[1] =~ s/_,/,/g;

    #fix 14-3-3

    if ($line[1]=~m/14_3_3/  ) {
#        my @arrs = split(/\(/, $line[1]);
#        $line[1] = $arrs[0];
        $line[1]=~s/14_3_3/14-3-3_/;
        $line[1]=~s/__/_/;

#        print "$line[1]\n";  
    }

    # fix dynein
    #
    if ($line[1]=~m/light_chain/ & $line[1]=~m/dynein/   ) {
#        my @arrs = split(/\(/, $line[1]);
#        $line[1] = $arrs[0];
        $line[1]= "dynein_light_chain";
#        print "$line[1]\n";  
    }
    if ($line[1]=~m/heavy_chain/ & $line[1]=~m/dynein/   ) {
#        my @arrs = split(/\(/, $line[1]);
#        $line[1] = $arrs[0];
        $line[1]= "dynein_heavy_chain";
#        print "$line[1]\n";  
    }
    if ($line[1]=~m/intermediate_chain/ & $line[1]=~m/dynein/   ) {
#        my @arrs = split(/\(/, $line[1]);
#        $line[1] = $arrs[0];
        $line[1]= "dynein_intermediate_chain";
#        print "$line[1]\n";  
    }

    #fix tegumantal antigens
    #

    if ($line[1]=~m/22\.6/ & $line[1]=~m/tegument/   ) {
#        my @arrs = split(/\(/, $line[1]);
#        $line[1] = $arrs[0];
        $line[1]= "tegumental_antigene";
#        print "$line[1]\n";  
    }

    if ($line[1]=~m/\(/ & $line[1] !~m/\)/  ) {
        my @arrs = split(/\(/, $line[1]);
        $line[1] = $arrs[0];
    }

    # fix antigen B
    #
        if ($line[1]=~m/^antigen_B/   ) {
             $line[1]= "Tapeworm_specific_antigen_B";
#        print "$line[1]\n";  
     }


    # fix annexins
    
        if ($line[1]=~m/^annexin/i   ) {
             $line[1]= "annexin";
#        print "$line[1]\n";  
     }

    # fix neurolignin
    
        if ($line[1]=~m/^neuroligin/i   ) {
             $line[1]= "neuroligin";
#        print "$line[1]\n";  
     }




    if ($line[1]=~m/\[/ & $line[1] !~m/\]/  ) {
        my @arrs = split(/\[/, $line[1]);
        $line[1] = $arrs[0];
    }



	if ($line[1] =~/[A-Z]+_[A-Z]+_[A-Z]+/) {
		$line[1] =~ tr/A-Z/a-z/;
		$line[1] =~ s/low_quality_protein:_//;
		if ($line[1] =~/hypothetical_protein/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
		}
		elsif ($line[1] =~/uncharacterized_protein/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
		}
		else {
		print OUT "$line[0]\"$line[1]\"\t$line[2]\"\n";
		}
	}

	if ($line[1] =~/^Uncharacterized_protein/) {
		if ($line[1] =~/involved/) {
			print OUT "$line[0]\"$line[1]\"\t$line[2]\"\n";
		}
		else {
			print OUT2 "\"mz3\":Uncharacterized_protein:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
			print OUT "$line[0]\"mz3\"\n";
		}
	}
	if ($line[1] =~/^EG95/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
	}
	elsif ($line[1] =~/^Putative_uncharacterized_protein$/) {
		print OUT2 "\"mz3\":pup2:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^ $/) {
		print OUT2 "\"mz3\":blank:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}

#save some genes
	elsif ($line[1] =~/^VP\d+/) {
		print OUT "$line[0]\"$line[1]\"\t$line[2]\"\n";
	}
	elsif ($line[1] =~/^AC\d+$/) {
		print OUT "$line[0]\"adenylyl_cyclase_($line[1])\n";
	}
	elsif ($line[1] =~/^RAG\d+$/) {
		print OUT "$line[0]\"recombination_activating_gene($line[1])\n";	
	}
	elsif ($line[1] =~/^P\d+$/) {
		print OUT "$line[0]\"$line[1]\"\t$line[2]\"\n";
	}
	elsif ($line[1] =~/^Gp\d+$/) {
		print OUT "$line[0]\"Glycoprotein_$line[1]\n";
	}
#remove others
	elsif ($line[1] =~/^hypothetical_protein$/) {
		print OUT2 "\"mz3\":MGF:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/SJCHG\w+_protein/) {
		print OUT2 "\"mz3\":sjap:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Protein_MGF/) {
		print OUT2 "\"mz3\":MGF:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+$/) {
		print OUT2 "\"mz3\":number:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] !~/[a-z]+[a-z]+/) {
		if ($line[1] =~/^[A-Z][A-Z][A-Z][0-9]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][A-Z][0-9]$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][A-Z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z]-[0-9]$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}		
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][a-z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][A-Z][A-Z]$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}	
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][0-9][0-9]$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][0-9][0-9][0-9]$/ or $line[1] =~/^[A-Z][A-Z][A-Z]-[0-9][0-9]$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}
		elsif ($line[1] =~/^CG[0-9]+$/ ) {
		print OUT2 "\"mz3\":not_lower:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
		}	
		elsif ($line[1] =~/^[A-Z][A-Z][0-9]$/ or $line[1] =~/^\w\w\w\w$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}
		elsif ($line[1] =~/^\w\w\w\w\w$/ or $line[1] =~/^\w\w\w\w\w\w$/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
		}
		else {
		print OUT2 "\"mz3\":not_lower:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
		}
	}
	elsif ($line[1] =~/^Protein_\db$/) {
		print OUT2 "\"mz3\":Protein_b:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+[LR]$/) {
		print OUT2 "\"mz3\":LR:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+kd$/) {
		print OUT2 "\"mz3\":kd1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+_kDa_protein$/) {
		print OUT2 "\"mz3\":kd2:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kDa_protein$/) {
		print OUT2 "\"mz3\":kd3:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kd_protein$/) {
		print OUT2 "\"mz3\":kd34:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+\.\d+K_protein$/) {
		print OUT2 "\"mz3\":kd5:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^\d+\_protein$/) {
		print OUT2 "\"mz3\":protein:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Putative_uncharacterized_protein/) {
		print OUT2 "\"mz3\":pup:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/PREDICTED:_hypothetical_protein/) {
		print OUT2 "\"mz3\":PHP:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Predicted_protein$/) {
		print OUT2 "\"mz3\":pp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Conserved_domain_protein/) {
		print OUT2 "\"mz3\":cdp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Putative_membrane_protein$/) {
		print OUT2 "\"mz3\":Pmp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Membrane_protein$/) {
		print OUT2 "\"mz3\":Mp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Putative_Membrane_protein$/) {
		print OUT2 "\"mz3\":Mp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
#	elsif ($line[1] =~/Polyprotein/) {
#		print OUT2 "\"mz3\":pop:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
#		print OUT "$line[0]\"mz3\"\n";
#	}
	elsif ($line[1] =~/predicted_protein/) {
		print OUT2 "\"mz3\":pp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Secreted_protein$/) {
		print OUT2 "\"mz3\":sp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Predicted_membrane_protein$/) {
		print OUT2 "\"mz3\":pmp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Novel_protein$/) {
		print OUT2 "\"mz3\":np:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Putative_transporter$/) {
		print OUT2 "\"mz3\":ptp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Uncharacterized_conserved_protein$/) {
		print OUT2 "\"mz3\":ucp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^conserved_unknown_protein$/) {
		print OUT2 "\"mz3\":ucp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Genome_polyprotein/) {
		print OUT2 "\"mz3\":Gp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}	
	elsif ($line[1] =~/^Lipoprotein$/) {
		print OUT2 "\"mz3\":Lp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Genome$/) {
		print OUT2 "\"mz3\":gen:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/whole_genome_shotgun_sequence/) {
		print OUT2 "\"mz3\":wgs:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_sequence/) {
		print OUT2 "\"mz3\":wgs:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_assembly/) {
		print OUT2 "\"mz3\":wga:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Os0\w+00_protein$/) {
		print OUT2 "\"mz3\":os:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_FG/) {
		print OUT2 "\"mz3\":fg:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_LOC/) {
		print OUT2 "\"mz3\":hlc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^LOC[0-9]+_protein$/) {
		print OUT2 "\"mz3\":loc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^MGC[0-9]+_protein$/) {
		print OUT2 "\"mz3\":mgc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/hypothetical_protein,_partial/) {
		print OUT2 "\"mz3\":hypp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/UPI\w+_related_cluster/) {
		print OUT2 "\"mz3\":UPI:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^unknown$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypotheticial_protein$/) {
		print OUT2 "\"mz3\":nsp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^conserved_hypothetical_protein$/) {
		print OUT2 "\"mz3\":chp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypotherical_protein$/) {
		print OUT2 "\"mz3\":hp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^expressed_hypothetical_protein$/) {
		print OUT2 "\"mz3\":ehp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^unnamed$/) {
		print OUT2 "\"mz3\":unn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_isoform_1$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Conserved_hypothetical_protein$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_isoform_[0-9]$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_protein,_conserved$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Hypothetical_protein_/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Hypothetical_Protein$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_conserved_protein$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_membrane_associated_protein$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypothetical_LOC[0-9]+$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^novel_protein_human_hypothetical$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^hypother0ical_protein$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Unknown_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^novel_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Unknown$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Protein_of_unknown_function$/i) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^unknown_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
#	elsif ($line[1] =~/^protein_of_unknown_function/) {
#		print OUT2 "\"mz3\":ukn1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
#		print OUT "$line[0]\"mz3\"\n";
#	}
	elsif ($line[1] =~/^uncharacterized_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^uncharacterized_conserved_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^uncharacterized_protein_/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^novel_protein_vertebrate$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^structural_maintenance_of$/ or $line[1] =~/^structural_maintenance_of$/) {
		print OUT2 "\"mz3\":smo:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^novel_protein_\(zgc:[0-9]+\)$/ ) {
		print OUT2 "\"mz3\":smo:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/\_PA$/ ) {
		print OUT2 "\"mz3\":dro:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/briggsae/ ) {
		print OUT2 "\"mz3\":brig:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}

	elsif ($line[1] =~/^C[BR][A-Z]_/  & $line[1] =~/[0-9]_protein$/ ) {
		print OUT2 "\"mz3\":cre:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^protein$/ ) {
		print OUT2 "\"mz3\":pro:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/low_quality_protein/ ) {
		print OUT2 "\"mz3\":pro:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/ENSANGG/ ) {
		print OUT2 "\"mz3\":ens:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^Uncharacterized_protein/ ) {
		print OUT2 "\"mz3\":unc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/mKIAA/ || $line[1] =~/KIAA/ & $line[1] =~/_protein$/ ) {
		print OUT2 "\"mz3\":kia:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
	elsif ($line[1] =~/^RIKEN_cDNA/) {
		print OUT2 "\"mz3\":rik:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^Drosphila/) {
		print OUT2 "\"mz3\":dro:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/UPF0/) {
		print OUT2 "\"mz3\":upf:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^hypothetical_protein_LOC\d+/) {
		print OUT2 "\"mz3\":loc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^si:ch/) {
		print OUT2 "\"mz3\":si:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/Temporarily_Assigned_Gene_name_family_member/) {
		print OUT2 "\"mz3\":temp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/_open_reading_frame_/) {
		print OUT2 "\"mz3\":orf:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/zgc:\d+/) {
		print OUT2 "\"mz3\":zgc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^cDNA_sequence_\w+/ || $line[1] =~/^cDNA_sequence_\w+/i ) {
		print OUT2 "\"mz3\":cdna:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^secreted_protein$/i) {
		print OUT2 "\"mz3\":cdna:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^upf\d+/ || $line[1] =~/upf0493_protein/ ) {
		print OUT2 "\"mz3\":upf:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/wu:\d+/ || $line[1] =~/wu:\w+/  ) {
		print OUT2 "\"mz3\":wu:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
    }
    elsif ($line[1] =~/^hypothetical_secreted_protein$/i) {
		print OUT2 "\"mz3\":cdna:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^expressed_sequence_/i) {
		print OUT2 "\"mz3\":exp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}
    elsif ($line[1] =~/^raw_/i) {
		print OUT2 "\"mz3\":raw:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}




#    elsif ($line[1] =~/gastrula_zinc_finger_protein_XlCGF57/) {
#		print OUT2 "\"mz3\":gzc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
#		print OUT "$line[0]\"mz3\"\n";
#	}

    # print remaining
	elsif ($line[1] =~/\w+/) {
		print OUT "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
	}	
	else {
#		print "$line[0]\"$line[1]\"$line[2]\"$line[3]\"\n";
	}

}
}

# Unknown_protein
# hypothetical_protein_isoform_1
#hypotherical_protein
#expressed_hypothetical_protein
#unnamed
# conserved_hypothetical_protein
	close (OUT);
	close (OUT2);

__END__

	elsif ($line[1] =~//) {
		print OUT2 "\"mz3\"::\t\"$line[1]\"$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\"mz3\"\n";
	}

		print OUT "$line[0]\"mz3\"\n";
