#!/usr/bin/perl -w

use strict;
use Cwd;

unless (@ARGV > 1 ) {
        &USAGE;
}


sub USAGE {

    die '


Usage: ChIPQC_wrapper.pl 1/mul samples


This pipeline makes a shell script which it submits as an R job.
It uses the R-package ChIPQC to do QC on ChIP data.

Mode 1; does stats of one bam-file:

ChIPQC_wrapper.pl 1 sample.sorted.bam genome_annotation <added stuff passed to the ChIPQCsample command>

Ex:  ", annotation=hg38, blacklist_file.bed"

Mode 2; does stats of one bam-file with peaks


ChIPQC_wrapper.pl 1 sample.sorted.bam peaks.bed genome_annotation <added stuff passed to the ChIPQCsample command>



Mode 3; does stats of an experiment:


2 experiment.tab


Valid annotations:  hg19 hg38



Sample experiment.tab example:

  SampleID  Tissue Factor Replicate            bamReads
1   CTCF_1    A549   CTCF         1 reads/SRR568129.bam
2   CTCF_2    A549   CTCF         2 reads/SRR568130.bam
3   cMYC_1    A549   cMYC         1 reads/SRR568131.bam
4   cMYC_2    A549   cMYC         2 reads/SRR568132.bam
5   E2F1_1 HeLa-S3   E2F1         1 reads/SRR502355.bam
6   E2F1_2 HeLa-S3   E2F1         2 reads/SRR502356.bam



' . "\n";

}


my $mode = shift;


# open the output file
open (R, ">xxx.R") || die "Cannot write output file xxx.R\n"; 


# copy the packages to the tmp directory
print "cp -r /mnt/lustre/groups/groupso/bin/R-packages/tmp/* /tmp\n";
print "source activate py2.7\n";

if ($mode=~/1/) {

my $bam = shift;
my $anno=shift;
my $added = shift;


print "\n";
print R "library(ChIPQC)\n";


# index the bam file if needed
unless (-e "$bam.bai") {
	print "samtools index $bam\n";
}



# make the R file


#ChIPQCsample(reads, peaks, annotation, chromosomes = NULL,
#     mapQCth = 15, blacklist, profileWin = 400, fragmentLength = 125,
#     shifts = 1:300, runCrossCor = FALSE) ’

print R "sample = ChIPQCsample(\"$bam\" $added)\n";
print R "sample\n";
print R "ChIPQCreport(sample)\n";


# peaksFile <- "file.bed"
# BlackListFile <- "/data/ChIPQC/mm9-blacklist.bed"
#exampleExp = ChIPQCsample(bamFile,peaks=peaksFile,annotation="mm9",blacklist=BlackListFile,chromosomes="chr11")

}


else {

print "This is an experiment \n";

my $exp=shift;

print R "";

print R "samples = read.table(\"$exp\")\n";


print "\n";
print "\n";
print "\n";
print "\n";
print "\n";
print "\n";


}





exit;


