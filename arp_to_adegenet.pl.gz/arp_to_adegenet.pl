#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

    die '


Usage: arp_to_adegenet.pl file.arp <haplotypes>

<haplotypes> - put 1 if it is single haplotype
                2 if it is diploid and the allelles for each specimen are consequitive (as in Arelquin)




' . "\n";
}


my $arp = shift;
my $dip = shift;


my @res;
open (IN, "<$arp")|| die;
open (OUT, ">$arp.txt")|| die;
open (OUT2, ">$arp.params")|| die;
open (OUT3, ">$arp.matrix")|| die;

my $len;
my $inpop=0;
my $res;
my @poparray;
my $poparr;
my $temp1;
my $guys=1;
my @keys;
my @keys2;

my %heads;


while (<IN>) {
    chomp;


    #print "$_\n";



        if ($_=~/SampleName/) {
            $_=~s/\"//g;
            $_=~s/ //g;
            ($temp1,$poparr)=split(/\=/, $_);
            #print "$poparr\n";
        }
        elsif ($_=~/SampleSize/) {
            #print "$_\n";

        }
        elsif ($_=~/\{/) {
        
            # start population
            #print "start $_\n";
            $inpop=1;
            $guys=1;
        }
        elsif ($_=~/\}/) {
        
            # end population
            #print "end $_\n";
            $inpop=0;
            print OUT2 "rep\.int\(\'$poparr\'\,$guys\),";


            #print $res;
            #push(@res,$res);
          
        }

        elsif ($inpop=~/1/ and $dip =~/^2$/ ) {
            #print "diploid\n";
            my ($id,$gen,$seq) = split(/\t/,$_);
            my $two = <IN>;
            #print "$two\n"; 
            unless( $two=~/\}/ ) {
                #print "YES\n"; 
                my ($id2,$gen2,$seq2) = split(/\t/,$two);
                $seq=~tr/atgcn/ATGCN/;
                $seq2=~tr/atgcn/ATGCN/;

                $seq=~s/A/1/g;
                $seq=~s/C/2/g;
                $seq=~s/G/3/g;
                $seq=~s/T/4/g;
                $seq=~s/-/NA/g;
                $seq2=~s/A/1/g;
                $seq2=~s/C/2/g;
                $seq2=~s/G/3/g;
                $seq2=~s/T/4/g;
                $seq2=~s/-/NA/g;


                my @seq = split(//, $seq);            
                my @seq2 = split(//, $seq2);
            
                $len = scalar(@seq);


            
                push (@keys, "$id\t$poparr\_$guys\n");
                push (@keys, "$id2\t$poparr\_$guys\n");

                $id = "$poparr\_$guys";
                $res = "$id\t";
                $guys++;

                my $in=0;
                foreach my $char (@seq) {
                    if ($char=~/\w+/) {
                        #print "\"$char\"\|\"@seq2[$in]\"\t";
                        #$res = $res . "\t\"$char\"";
                        $res = $res . "\"$char$seq2[$in]\"\t";
                        print OUT3 "\"$char$seq2[$in]\"\t";
                    }
                    $in++;

                }

                #$res = $res . "\n";
                #print "\n";
                chomp $res;
                $res=~s/\t$//;
                push(@res,$res);
            }


        }

        elsif ($inpop=~/1/) {
            #push(@poparray,$poparr);          
            # end population
            #print "seq $_\n";


            
            my ($id,$gen,$seq) = split(/\t/,$_);
            $seq=~tr/atgcn/ATGCN/;

            $seq=~s/A/1/g;
            $seq=~s/C/2/g;
            $seq=~s/G/3/g;
            $seq=~s/T/4/g;
            $seq=~s/-/NA/g;

            my @seq = split(//, $seq);
            
            $len = scalar(@seq);            


            #if (exists $heads{$id}) {
                #$res = "$id\_$guys";
                #}

            push (@keys, "$id\t$poparr\_$guys\n");

            $id = "$poparr\_$guys";
            $res = "$id";
            $guys++;

            foreach my $char (@seq) {
                if ($char=~/\w+/) {
                    #print "\"$char\"\t";
                    $res = $res . "\t\"$char\"";
                }

            }

            #$res = $res . "\n";
            #print "\n";
            chomp $res;
            $res=~s/\t$//;
            push(@res,$res);

        }
        





}

my $i=0;

$res = "\t";

#print "len $len\n";
for( $i=0 ;$i < ($len-1); $i++) {

    #print "Loc$i\t";
    $res = $res . "Loc$i\t";

}


#print "i $i\n";

#$res = $res . "\n";
$res=~s/\t$//;
chomp $res;
unshift(@res,$res);


foreach my $line (@res) {
    print OUT "$line\n";
}


print OUT2 "\n";
foreach my $line (@keys) {
    print OUT2 "$line";
}



#print scalar(@poparray);

#my $pop2 = join("x", @poparray);
#my $pop2 =  join("\t", @poparray);
#print "POPS $pop2";
#print OUT2  join("\n", @poparray) .  "\n";


close(IN);
close(OUT);
close(OUT2);
close(OUT3);


exit;

