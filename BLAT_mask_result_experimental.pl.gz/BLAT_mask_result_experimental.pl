#!/usr/bin/perl -w

use strict;

unless (@ARGV > 3) {
        &USAGE;
}


sub USAGE {

    die '


Usage: blat_mask_result.pl blatout.psl file_1.fastq file_2.fastq  <type>

Takes a blat-output, and retrieves the hits from a fastq file.

Then masks the hits with low-quality Ns and outputs new balanced fastq-files


<type> -s which species or type of sequence this is from:
valid choices; miRNa, HYM, EGU, SMA and EMU



Warning: psl-files should have no header


' . "\n";
}


my $blat = shift;
my $fastq1 = shift;
my $fastq2 = shift;
my $type = shift;


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$blat")|| die;

my %blat;
my %hits;


while (<IN>) {
    chomp;

    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if ($_=~/^\d+/) {
        # an alignment length of at least 12 nucleotides and one or no mismatches
        if ($arr[0]> 11 and $arr[1] < 2 and $arr[5] < 2 and $arr[7] < 2   ) {
        #print "$arr[9]\t$arr[11]\t$arr[12]\n";
            if (exists $blat{$arr[9]}) {

                my ($s,$e) = split(/\t/, $blat{ $arr[9] } );   
                my $min = ($arr[11], $s)[$arr[11] > $s];
                my $max = ($arr[12], $e)[$arr[12] < $e];

                #print "$arr[9]\t$arr[11]\t$arr[12]\t$s\t$e\t$max\t$min\n";

                $blat{ $arr[9] } = "$min\t$max\t$arr[8]" ;

            }
            else {
                $blat{ $arr[9] } = "$arr[11]\t$arr[12]\t$arr[8]" ;
                #print "$arr[9]\t$arr[11]\t$arr[12]\n";                
                # make a hit-match - hit just has the read, not forward or rev info
                $arr[9] =~s/\/1$//;
                $arr[9] =~s/\/2$//;
                #print "$arr[9]\n";
                $hits{$arr[9]}=1;
            }
        }
    }
}



# read the fastq-files line by line, and print the reads with a match to another file


if ($fastq1 =~ /\.gz$/) {
    open(FAS1, "gunzip -c $fastq1 |") || die "can't open pipe to $fastq1";
}
else {
    open(FAS1, $fastq1) || die "can't open $fastq1";
}

if ($fastq2 =~ /\.gz$/) {
    open(FAS2, "gunzip -c $fastq2 |") || die "can't open pipe to $fastq2";
}
else {
    open(FAS2, $fastq2) || die "can't open $fastq2";
}

open (OUT1, ">$fastq1.chosen.fastq")|| die;
open (OUT2, ">$fastq2.chosen.fastq")|| die;

#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "$_";
            my $seq = <FAS1>;
            my $mid = <FAS1>;
            my $qual = <FAS1>;
            print OUT1 "$_$seq$mid$qual";
        }

    }
}


while (<FAS2>) {

    if ($_=~/^@/) {
        my $head = $_;
        $head=~s/^@//;
        $head =~s/\/2$//;
        chomp $head;
        #print "match $head\n";

        if (exists $hits{$head}) {
            #print "$_";
            my $seq = <FAS2>;
            my $mid = <FAS2>;
            my $qual = <FAS2>;
            print OUT2 "$_$seq$mid$qual";
        }

    }
}

close (FAS1);
close (FAS2);
close (OUT1);
close (OUT2);




# read in the temp-fastqs, and trim them according to the best BLAT-hit


open (IN1, "<$fastq1.chosen.fastq")|| die;
open (IN2, "<$fastq2.chosen.fastq")|| die;

my %final;

while (<IN1>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1 =~s/\/1$//;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }

            # now choose if the read had indeed a splice-leader in it by looking at the out-take
            if ($type=~/EMU/) {
                if ($new_seq =~/TGTATG$/i ) {
                #if ($new_seq =~/CAGTTTTGTATG/i or $new_seq =~/GCACTCTTGTATG/i or $new_seq =~/GCACTTTTGTATG/i or $new_seq =~/CACTTCTGTATG/i ) {
                    #print "$head\t$ori_seq\n$new_seq\n1\t$out_seq1\n2\t$out_seq2\n\n";
                    #print "$new_se7745_8#3_2q\n";
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    #print "$seq, $m7745_8#3_2in, $len, $polyN\n";
                    #print OUT1 "$_$seq$mid$qual";
                    $final{$head1}{$head}="$_$seq$mid$qual";
                    #
                }
                else {
                    print "This is not a real EMU splice-leader $new_seq \n";
                    }

            }
            elsif ($type=~/miRNA/ ) {

                # or choose a primer if this is miRNAs with the NEB protocol
                if ( $new_seq =~/AGATCGGAAGAGCACACGTCTGAACTCCAGTCACTAGCTTAT/i or $new_seq =~/AGATCGGAAGAGCACACGTCTGAACTCCAGTCACTAG/i or $new_seq =~/TTTTTTTTTTCAAGCAGAAGACGGCATACGAGATAAGCTAGTG/i or $new_seq =~/TCGTATGCCGTCTTCTGCTTGAAAAAAAAAA/i or $new_seq =~/TCACTAGCTTATCTCGTATGCCGTCTTCTGCTTGAAAAA/i ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    $final{$head1}{$head}="$_$seq$mid$qual";
                }
                else {
                    print "This is not a real miRNA $new_seq \n";
                }
            }
            elsif ($type=~/EGU/ ) {

                # now choose if the read had indeed a splice-leader in it by looking at the out-take
                if ( $new_seq =~/TGTATG$/i ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    $final{$head1}{$head}="$_$seq$mid$qual";            
                }
                else {
                    print "This is not a real EGU splice-leader $new_seq \n";
                }

            }
            elsif ($type=~/HYM/  ) {

                # now choose if the read had indeed a splice-leader in it by looking at the out-take
                if ( $new_seq =~/TTGTATG$/i or $new_seq =~/TTTATG$/i  ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    $final{$head1}{$head}="$_$seq$mid$qual";            
                }
                else {
                    print "This is not a real HYM splice-leader $new_seq \n";
                }

            }
            elsif ($type=~/SMA/  ) {

                # now choose if the read had indeed a splice-leader in it by looking at the out-take
                if ( $new_seq =~/GTTGCATG$/i or $new_seq =~/TTGTGATTT/i  ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    $final{$head1}{$head}="$_$seq$mid$qual";            
                }
                else {
                    print "This is not a real SMA splice-leader $new_seq \n";
                }

            }

            else {
                print "You have to specify which type of sequence you are filtering $type \n";
                die;
            }
        }
        else {
            my $seq = <IN1>;
            my $mid = <IN1>;
            my $qual = <IN1>;
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print OUT1 "$_$seq$mid$qual";
        }

    }
}




while (<IN2>) {

    if ($_=~/^@/) {
        my $head = $_;
        chomp $head;
        $head=~s/^@//;
        my $head1 = $head;
        $head1=~s/\/2$//;
        #print "match $head\n";
        if (exists $blat{$head}) {
            #print "$_";
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print  "$_$seq$mid$qual";

            my ($min,$max,$ori) = split(/\t/,$blat{$head});
            my $len = $max - $min;
            #my $polyN ="N" x $len;
            #my $polyI ="!" x $len;
            my $polyN ="";
            my $polyI ="";
            my $ori_seq = $seq;
            #print "$head\t$min\t$max\t$ori\t$len\t$polyN\t$seq\n";
            my $new_seq = substr($seq, $min, $len, $polyN );
            my $out_seq1 = substr($ori_seq, 0, $min);
            my $out_seq2 = substr($ori_seq, $max, -1);

            # the splice-leader is new_seq, and comprev it if necessary
            if ($ori =~/-/) {
                $new_seq =~tr/ACGT/tgca/;
                $new_seq =reverse($new_seq);
            }
            #print "$new_seq\n";
            # now choose if the read had indeed a splice-leader in it by looking at the out-take

            if ($type=~/EMU/ ) {

                #if ($new_seq =~/CAGTTTTGTATG/i or $new_seq =~/GCACTCTTGTATG/i or $new_seq =~/GCACTTTTGTATG/i or $new_seq =~/CACTTCTGTATG/i  ) {
                if ($new_seq =~/TGTATG$/i ) {

                    #print "$head\t$ori_seq\n$new_seq\n1\t$out_seq1\n2\t$out_seq2\n\n";
                    #print "$new_seq\n";
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    #print "$seq, $min, $len, $polyN\n";
                    #print OUT1 "$_$seq$mid$qual";
                    $final{$head1}{$head}="$_$seq$mid$qual";
                    #
                }
            }

            elsif ($type=~/EGU/ ) {
                if ( $new_seq =~/TGTATG$/i ) {
                    #print "$head\t$ori_seq\n$new_seq\n1\t$out_seq1\n2\t$out_seq2\n\n";
                    #print "$new_seq\n";
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    #print "$seq, $min, $len, $polyN\n";
                    #print OUT1 "$_$seq$mid$qual";
                    $final{$head1}{$head}="$_$seq$mid$qual";
                    #
                }
            }
            elsif ($type=~/HYM/ ) {
                if ($new_seq =~/TTGTATG$/i or $new_seq =~/TTTATG$/i  ) {
                    #print "$head\t$ori_seq\n$new_seq\n1\t$out_seq1\n2\t$out_seq2\n\n";
                    #print "$new_seq\n";
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    #print "$seq, $min, $len, $polyN\n";
                    #print OUT1 "$_$seq$mid$qual";
                    $final{$head1}{$head}="$_$seq$mid$qual";
                    #
                }
                else {
                    print "This is not a real HYM splice-leader $new_seq \n";
                }
            }

            elsif ($type=~/SMA/  ) {

                # now choose if the read had indeed a splice-leader in it by looking at the out-take
                if ( $new_seq =~/GTTGCATG$/i or $new_seq =~/TTGTGATTT/i  ) {
                    my $new_qual = substr($qual, $min, $len, $polyI );
                    $final{$head1}{$head}="$_$seq$mid$qual";            
                }
                else {
                    print "This is not a real SMA splice-leader $new_seq \n";
                }

            }
            else {
                #print "This is not a real splice-leader $new_seq \n";
                print "This shouldnt happen, splice leader unknown.\n";
            }
        }







        else {
            my $seq = <IN2>;
            my $mid = <IN2>;
            my $qual = <IN2>;
            #print "$_$seq$mid$qual";
            $final{$head1}{$head}="$_$seq$mid$qual";
            #print OUT2 "$_$seq$mid$qual";
        }
        

    }
}



# now finally report the paired full output


open (OUT1, ">$fastq1.trimmed.fastq")|| die;
open (OUT2, ">$fastq2.trimmed.fastq")|| die;


foreach my $key (sort keys %final) {
    #print "$key\n";
    my $sca = scalar  keys %{$final{$key}};
    #print "$sca\n";
    if ($sca =~/2/) {
        my $first = $key . "/1";
        my $second = $key . "/2";
        #print "$first\t$second\n";
        print OUT1 "$final{$key}{$first}";
        print OUT2 "$final{$key}{$second}";

    }
}


close (IN1);
close (IN2);
close (OUT1);
close (OUT2);

# system "rm -f $fastq1.chosen.fastq $fastq2.chosen.fastq ";

__END__

TGCAGCTCAGGCTCTGCCTACGAGC
ACTCCTTCGAACACCA

TGGTGTTCGAAGGAGT
ACTCCTTCGAACACCA


>Emu.SL2c
GTTACCGATA
AATCGGTCCT
TACCTGCACT
TTTGTATGGT
GAGTATC

>SL
GATGCAGCTCAGGCTCTG CCTACGAG

CTGACAGTATTTGGCTGGTCCGACGAGGGCC


CGAAGATGTA
CTCGGCCTCG
TAGGCCTGCA
TCACTCCCGT
CCAGTTAGGC
CATGTCCAGC
CACTGGATTG
GTGTTCGAAG
GAGTACAGAA
AAACCTGACT

>SL
GATGCAGCTC  AGGCTCTG CCTACGAG

>fw reversed
GATGCAGG             CCTACGAG


>fw
       CTCGTAGGCCTGCA TC

>rev
TGGTGTTCGAAGGA GT

AC TCCTTCGAACACCA

