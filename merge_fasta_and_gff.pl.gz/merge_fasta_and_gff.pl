#!/usr/local/bin/perl -w

use strict;

unless (@ARGV > 0 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl merge_fasta_and_gff.pl file.fas file.gff new_scaffol_name


Takes a fasta and a gff-file, and merges them, and gives them new coordinates


'


}

my $fas = shift;
my $gff = shift;
my $prefix = shift;



# Read in fasta and make a new merged fasta


system "cat $fas | grep -v '>' > $fas.temp ";

open (IN, "<$fas.temp") or die "Cant find $fas.temp\n" ;
my @in = <IN>;
open (OUT, ">$fas.temp2") or die "Cant find $fas.temp2\n" ;


print OUT ">$prefix\n";
print OUT @in;

system "/nfs/pathogen005/mz3/mh12/python/fasta2multiline.py $fas.temp2 $fas.m.fas 300";
system "rm -f $fas.temp $fas.temp2 ";





# Make a faidx
system "samtools faidx $fas";

open (FAI, "<$fas.fai") or die "Cant find $fas.fai\n" ;


# Read in the faidx


my @farr;

while (<FAI>) {
    my @arr = split(/\s+/, $_);
    my @arh = split(/\:/, $arr[0]);   
    push (@farr, "$arh[0]\t$arr[1]\t$arh[1]");
  
}


# Read in gff

my %gash;



open (GFF, "<$gff") or die "Cant find $gff\n" ;

while (<GFF>) {
    chomp $_;

    my @arf = split(/\s+/, $_);
    push ( @{$gash{$arf[0]}}, $_ );
#    print "GFF:$arf[0]:\n";

}


# Adjust gff-coords

my $newcord = "0";

foreach my $line (@farr){

    print "New scaffold:$line:\n";
    my @ar3 = split(/\t/, $line);
    my @ar4=split(/\(/, $ar3[2]);
    my @ar5=split(/-/, $ar4[0]);
    print "$ar5[0]\t$ar5[1]\n";


# If this gene exists on a known scaffold

    if (exists $gash{$ar3[0]}) {

        print "This scaffold has genes\n"; 

        my $genstart = 300;

        foreach my $elem (  @{$gash{$ar3[0]}} ) {

            print "$elem\n";
            my @gf = split(/\t/, $elem );

#   if this is the first gene on a new scaffold         
#            if () {
#            }

            my $new_end =  $gf[4] - $ar5[0]  ;
            my $new_start =  $gf[3] - $ar5[0]  ;

            my $start = ($new_start , $new_end )[$new_start  > $new_end ];
            my $end = ($new_start , $new_end )[$new_start  < $new_end ];

            $gf[3] = $start + $newcord  ;
            $gf[4] = $end + $newcord ;

#            $gf[3] = "0";
#            $gf[4] = "0";

            print join("\t", @gf) . "\n";

        }
    }
    else {
        print "Not exists\n";

    }

    $newcord = $newcord + $ar3[1];

    print "New:$newcord:\n";
}









exit;








