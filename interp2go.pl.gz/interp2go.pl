#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~mz3/bin/perl/interpro2GO.pl gff  databases

databases - list databases you want to get the GO-term from

Possible alternatives:

Gene3D
Hamap
PANTHER
Pfam
PIRSF
PRINTS
ProSitePatterns
ProSiteProfiles
SMART
SUPERFAMILY
TIGRFAM


Example:


perl ~mz3/bin/perl/interpro2GO.pl interpro.gff  Pfam  PANTHER



';

}




my $gff = shift;
my %db;

foreach my $ele (@ARGV) {
    chomp $ele;
    #print "$ele\n";
    $db{$ele}=1;

}

open (GFF, "<$gff") || die "Cant find file $gff\n";
#open (OUT, ">$gff.pfam") || die "Cant open file $gff.pfam\n";
open (OUT2, ">$gff.go") || die "Cant open file $gff.go\n";
#open (OUT3, ">$gff.prod") || die "Cant open file $gff.prod\n";

# read in Pfam info

#open (PFAM, "</nfs/users/nfs_m/mz3/bin/perl/Pfam.index.txt") || die "Cant find file  ~mz3/bin/perl/Pfam.index.txt - ask Magdalena about it\n";


my %go;

# process gff

while (<GFF>) {
    my @arr = split(/\t/,$_);
    if ( exists $db{$arr[1]}  ) {
        #print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[8]\n";

        my @ann = split(/;/,$arr[8]);


        my $id = $arr[0];


        foreach my $line (@ann) {


                #    }
            if ($line=~/^Ontology_term="/) {
                my $go=$line; 
                $go=~s/Ontology_term=//;
                $go=~s/"//g;
                if ($go!~/NA/) {
                    my @terms = split(/\,/,$go);

                    foreach my $term (@terms) {
                        #print "$id\t$term\n";
                        $go{$id}{$term}=1;
                    }

                }
            }



        }


        #       print OUT "$id\t$start\t$end\t$start\t$end\t$pfam\t$desc\t$source\t$no1\t$no2\t$no1\t$no2\t$no3\t$no4\t$no5\t$no6\t$na\n";
    
    }
    else {
        # ignore
    }


}



foreach my $gene ( sort keys %go) {
        print OUT2 "$gene ";
        my @ga;
    foreach my $gos ( sort keys %{$go{$gene}}) {
        #print "$gos,";
        push(@ga, $gos);
    }
    print OUT2  join(",",@ga) . "\n";
}


=pod
TMUE_s0071000800    125    192    124    193 PF00542.14  Ribosomal_L12     Domain     2    67    68     62.3     3e-17   1 No_clan
TMUE_s0071000900     54     99     54     99 PF00095.16  WAP               Domain     1    43    43     37.1   2.2e-09   1 CL0454
TMUE_s0071000900    106    149    106    149 PF00095.16  WAP               Domain     1    43    43     35.4   7.6e-09   1 CL0454
TMUE_s0071001000    305    382    298    395 PB013406    Pfam-B_13406      Pfam-B   340   416   452     19.2   0.00056  NA NA
=cut

exit;





