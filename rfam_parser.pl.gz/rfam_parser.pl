#!/usr/bin/perl -w


use strict;


unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: rfam_parser.pl  rfam.results trna.results


'
}



	my $in = shift;
	my $in2 = shift;

my @rfam;
my @trna;

if ($in=~/trnas\.results/) {
	open (IN, "<$in") || die "I can't open $in\n";
	@trna = <IN>;
	close (IN);
    print "Opening trna-file $in\n";

}

elsif ($in2=~/trnas\.results/) {

	open (IN2, "<$in2") || die "I can't open $in2\n";
	@trna = <IN2>;
	close (IN2);
    print "Opening trna-file $in2\n";
}

if ($in=~/rfam\.results/) {
	open (IN, "<$in") || die "I can't open $in\n";
	@rfam = <IN>;
	close (IN);
    print "Opening rfam-file $in\n";

}

elsif ($in2=~/rfam\.results/) {

	open (IN2, "<$in2") || die "I can't open $in2\n";
	@rfam = <IN2>;
	close (IN2);
    print "Opening rfam-file $in2\n";


}
else {
    print "Don't know what file $in or $in2 is\n";
    exit;
}


    open (OUT, ">$in.out") || die "I can't open $in.out\n";


# read rfam and make table

my %rfams;

foreach my $line ( @rfam) {
    chomp $line;
    my @arr = split(/;/,$line);
        $arr[2]=~s/id=//;
        $arr[5]=~s/rfam-acc=//;
        my @arr2 = split(/\./, $arr[5]);
        $rfams{"$arr[2]\t$arr2[0]"}+=1;
    }


# print rfam res
#
foreach my $key (sort  keys %rfams) {
    unless ($key =~/^MIR/ || $key =~/^mir-/ || $key =~/^Dictyoglomi/ || $key =~/^Clostridiales/ || $key =~/^Bacteria_large/ || $key =~/^SSU_rRNA_archaea/ || $key =~/^SSU_rRNA_bacteria/ || $key =~/^S_pombe/ || $key =~/^ciona-mir/ ||  $key =~/^lactis-plasmid/ || $key =~/^Plant_SRP/ || $key =~/^Archaea_SRP/  || $key =~/^tRNA/ || $key =~/^Afu_254/ || $key =~/^PK-G12rRNA/ || $key =~/^His_leader/ || $key =~/^Protozoa/ || $key =~/^PRUF6-5/ || $key =~/^Dd/ || $key =~/^mraW/ || $key =~/^Xist/ || $key =~/^rli/ || $key =~/^Parecho_CRE/ ||  $key =~/^Fungi/ ||  $key =~/^lsy/  ||  $key =~/^C4/ ||  $key =~/^bantam/ ||  $key =~/^ceN/ || $key =~/^let-7/ ||  $key =~/^ctRNA_/  ||  $key =~/^F6/  ||  $key =~/^CRISPR/  ||  $key =~/^isrG/  ||  $key =~/^Pedo-repair/ ||  $key =~/^plasmodium/ ||  $key =~/^RUF6/ ||  $key =~/^SprD/  ||  $key =~/^sroB/ ||  $key =~/^SprD/ ||  $key =~/^SVLPA/  ||  $key =~/^SVLPA/ ||  $key =~/^sxy/ ||  $key =~/^TB10/ ||  $key =~/^SVLPA/ ) {
    print OUT "$key\t$rfams{$key}\n";
    }
}



# read trna-file and make a table

my %tres;

foreach my $line ( @trna) {
    chomp $line;
    my @arr = split(/\s+/,$line);
        $tres{$arr[4]}+=1;
    }


# print trna res
#
foreach my $key (sort keys %tres) {
    print OUT "tRNA-$key\t$tres{$key}\n";
}


close (OUT);
