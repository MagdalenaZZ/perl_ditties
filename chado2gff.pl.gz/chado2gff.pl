#!/usr/local/bin/perl -w

use strict;
use Cwd;
use File::Slurp;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado2gff.pl folder out-prefix 

Takes Chado output of gff-files from a particular organism, and when it has it, take those gff-files and makes them sensible

Give it the folder where folders 1/ and 2/ from GFF is

'
}


my $folder = shift;
my $out = shift;



#=pod

system "rm -fr all.tmp.gff";

system "gunzip -r $folder";
# print  "gunzip -r $folder\n";
print "\n\nUnzipping finished...\n\n";

# put those folders in an array

my @paths = read_dir( "$folder", prefix => 1 ) ;

#system "rm -f all.tmp.gff";

foreach my $elem (@paths) {
    system "cat $elem/*.gff >> all.tmp.gff\n";
}

#=cut



my $in="all.tmp.gff";

open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;
close (IN);


open (OUT, ">$out.raw.gff") || die "I can't open $out.raw.gff\n";



# fix the merged file
my @gff;

foreach my $line (@in) {
    chomp $line;
    my @arr = split(/\t/,$line);
    #print "%%% $arr[0]\n";
    my $len = scalar(@arr);
    if ($len > 8 ) {
        push (@gff, $line);
    }

}

foreach my $ele (@gff) {
    chomp $ele;
    if ($ele=~/CDS/ or $ele=~/gene/ or $ele=~/mRNA/ or $ele=~/polypeptide/  ) {
        print OUT "$ele\n";
    }
}

close(OUT);



# correct it


open (IN2, "<$out.raw.gff") || die "I can't open $out.raw.gff\n";
my @in2 = <IN2>;
close (IN2);

open (AA, ">$out.aa") || die "I can't open $out.aa\n";
open (GO, ">$out.go") || die "I can't open $out.go\n";
open (EC, ">$out.EC") || die "I can't open $out.EC\n";
open (MER, ">$out.MER") || die "I can't open $out.MER\n";
open (GI, ">$out.GI") || die "I can't open $out.GI\n";
open (RFAM, ">$out.rfam") || die "I can't open $out.rfam\n";
open (GB, ">$out.gb") || die "I can't open $out.gb\n";
open (CC, ">$out.cc") || die "I can't open $out.cc\n";
open (IP, ">$out.ip") || die "I can't open $out.ip\n";
open (PR, ">$out.previous_ID") || die "I can't open $out.previous_ID\n";
open (OT, ">$out.other") || die "I can't open $out.other\n";
open (CM, ">$out.comm") || die "I can't open $out.comm\n";
open (NM, ">$out.gene_name") || die "I can't open $out.gene_name\n";
open (LT, ">$out.litt") || die "I can't open $out.litt\n";


open (OUT3, ">$out.gff") || die "I can't open $out.gff\n";
open (OUT4, ">$out.nice.gff") || die "I can't open $out.nice.gff\n";



foreach my $line (@in2) {
    chomp $line;
    #print "$line\n";
        $line=~s/\%3D/ /g;
        $line=~s/\%3B/ /g;
        $line=~s/\%2C/ /g;
        $line=~s/\%2B/ /g;
        $line=~s/\%09/ /g;
        $line=~s/\%28/ /g;
        $line=~s/\%29/ /g;
        $line=~s/\%5H/ /g;
        $line=~s/\%5C/ /g;
    my @arr = split(/\t/, $line);
    my @ar2 =  split(/\;/, $arr[-1]);
    #print "$arr[-1]\t$ar2[1]\n";

    my $id="";
    my $parent="";
    my $product="";
    my $obsolete="";
    my $stops="";
    my $colour="";
    my $partial="";

    my @ipr;
    my @go;
    my @comment;

    foreach my $el (@ar2) {
        
        if ($el=~/^ID=/) {
            #print "ID $el\n";
            $id = $el;
            #print OT "$id\t/$el\n";
        }
        elsif ($el=~/^colour=/) {
            #print "Colour $el\n";
            $colour = $el;
            print OT "$id\t/$el\n";
        }
        elsif ($el=~/^Dbxref/) {
            if ($el=~/Rfam:/) {
                #print "IF $el\n";
                print RFAM "$id\t/$el\n";
            }
            elsif ($el=~/MEROPS:/) {
                #print "IF $el\n";
                my $ids=$id;
                $ids=~s/ID=//;
                $ids=~s/\.\d+:pep$//;
                $ids=~s/\.\d+$//;
                my @arm = split(/\,/, $el);
                print MER "$ids\t/$arm[0]\n";
                if (scalar(@arm)>1) {
                    print EC "$ids\t/$arm[1]\n";
                }
            }
            elsif ($el=~/GenBank:/) {
                #print "IF $el\n";
                print GB "$id\t/$el\n";
            }
            elsif ($el=~/GI:/) {
                #print "IF $el\n";
                my $ids=$id;
                $ids=~s/ID=//;
                $ids=~s/\.\d+:pep$//;
                $ids=~s/\.\d+$//;
                print GI "$ids\t/$el\n";
            }
            elsif ($el=~/EC:/) {
                my $ids=$id;
                $ids=~s/ID=//;
                 #print "EC_number $el\n";
                #$parent = $el;
                print EC "$ids\t/$el\n";
            }
            else {
                print "Warning: contains unknown Dbxref database $el\n";
            }
            #print "timelastmodified $el\n";
            #$parent = $el;
        }
        elsif ($el=~/^Derives_from=/) {
            #print "timelastmodified $el\n";
            $parent = $el;
            #print OT "$id\t/$el\n";
        }
        elsif ($el=~/^eC_number=/) {
            #print "parent $el\n";
            #$parent = $el;
                print EC "$id\t/$el\n";
            }
        elsif ($el=~/^feature_id=/) {
            #print "Feat_ID $el\n";
            #$parent = $el;
            print OT "$id\t/$el\n";
        }
        elsif ($el=~/^Ontology_term=/) {
            #print "GO $el\n";
            $el=~s/Ontology_term=//;
            #$parent = $el;
            push (@go, $el);
        }
        elsif ($el=~/^full_GO=/) {
            #print "Feat_ID $el\n";
            #$parent = $el;
            #print OT "$el\n";
        }
        elsif ($el=~/^polypeptide_domain=/) {
            #print "Domain $el\n";
            #$parent = $el;
            my $ids=$id;
            $ids=~s/ID=//;
            $ids=~s/\.\d+:pep$//;
            $ids=~s/\.\d+$//;

            $el=~s/polypeptide_domain=//;
            $el=~s/InterPro:/\nInterPro:/g;
            $el=~s/Pfam:/\nPfam:/g;
            $el=~s/PRINTS:/\nPRINTS:/g;
            $el=~s/SMART:/\nSMART:/g;
            $el=~s/Superfamily:/\nSuperfamily:/g;
            $el=~s/Prosite:/\nProsite:/g;
            $el=~s/PANTHER:/\nPANTHER:/g;
            $el=~s/TIGR_TIGRFAMS:/\nTIGR_TIGRFAMS:/g;
            $el=~s/iprscan//g;
            chomp $el;
            $el=~s/ $//;
            $el=~s/\,$//;

            #print "$el\n";
            my @ar3 = split(/\n/, $el);
            #my $i=0;

            foreach my $term (@ar3) {
                if ($term=~/\w+/) {
                    print IP "$ids\t$term\n";
                    #push (@ipr, $term);
                }
            #    else {
                    #print "$term\n";

            }
                    #    $i++;
                    #}
            #print IP "$el\n";
        }
        elsif ($el=~/^controlled_curation=/) {
            #print "Domain $el\n";
            print CC "$id\t/$el\n";
        }
        elsif ($el=~/^gO=/) {
            $el=~s/%3D/\t/g;
            $el=~s/%3B/\t/g;
            my @ar3 = split(/\t/, $el);

            foreach my $term (@ar3) {
                if ($term=~/^GO:\d+$/) {
                    #print "GO $term\n";
                    push (@go, $term);
                }
                else {
                    #print "$term\n";

                }
            }
            #$parent = $el;
        }



        elsif ($el=~/^isObsolete=/) {
            $el=~s/isObsolete=//;
            $obsolete = $el;
            print OT "$id\t/obsolete=$el\n";
        }
        elsif ($el=~/^literature=/ or $el=~/^citation=/ ) {
            #print "parent $el\n";
            #$parent = $el;
            my $ids=$id;
            $ids=~s/ID=//;
            $ids=~s/\.\d+:pep$//;
            $ids=~s/\.\d+$//;
            print LT "$ids\t/$el\n";
        }
        elsif ($el=~/^Name=/) {
            my $ids=$id;
            $ids=~s/ID=//;
            #print "parent $el\n";
            #$parent = $el;
            print NM "$ids\t/$el\n";
        }
        elsif ($el=~/^Parent=/) {
            #print "parent $el\n";
            $parent = $el;
            #print OT "$id\t/$el\n";
        }
        elsif ($el=~/^previous_systematic_id=/) {
            my $ids=$id;
            $ids=~s/ID=//;
            #print "timelastmodified $el\n";
            #$product = $el;
            print PR "$ids\t/$el\n";
        }
        elsif ($el=~/^product=/) {
            $el=~s/term%3D//g;
            $el=~s/%3B//g;
            $el=~s/%2C//g;
            $el=~s/\+/ /g;
            #print "P $el\n";
            $product = $el;
        }
        elsif ($el=~/^synonym=/) {
            #print "timelastmodified $el\n";
            #$parent = $el;
            print OT "$id\t/$el\n";
        }
        elsif ($el=~/^citation=/) {
            #print "timelastmodified $el\n";
            #$parent = $el;
            print OT "$id\t/$el\n";
        }
        elsif ($el=~/^Start_range=/ or $el=~/^End_range=/) {

            if ( $el=~/^Start_range=/ and $el=~/^End_range=/ ) { 
                $partial="5prime and 3prime partial";
            }
            elsif ($el=~/^Start_range=/ ) {
                #print "timelastmodified $el\n";
                #$parent = $el;
                $partial="5prime partial";
            }
            elsif  ($el=~/^End_range=/ ) {
                #print "timelastmodified $el\n";
                #$parent = $el;
                $partial="3prime partial";
            }
            else {
                print "Warning: this should not happen!!!\n";
            }

        }
        elsif ($el=~/^timelastmodified=/) {
            #print "timelastmodified $el\n";
            #$parent = $el;
            print OT "$id\t/$el\n";
        }
        elsif ($el=~/^translation=/) {
            $el=~s/translation=//;
            $el=~tr/a-z/A-Z/;
            
            my $ids = $id;
            $ids=~s/ID=//;
            my @ids=split(/\:/,$ids);
            #print "timelastmodified $el\n";
            #$parent = $el;
            print AA ">$ids[0]\n$el\n";

            if ($el=~/\*/ or $el=~/\+/ or $el=~/\#/  ) {
                    $stops = "YES";
            }
            else {
                    $stops = "NO";
            }
        }

        elsif ($el=~/^comment=/) {
            $el=~s/%2C\+/\+/g;            
            $el=~s/%2C/\t/g;
            my $ids=$id;
            $ids=~s/ID=//;
            $ids=~s/\.\d+:pep$//;
            $ids=~s/\.\d+$//;
            print CM "$ids\t/$el\n";

            my @ar4 = split(/\t/, $el);

            foreach my $term (@ar4) {
                if ($term=~/^iprscan/) {
                    #print "IPR $term\n";
                }
                elsif ($term=~/^comment=/) {
                    push (@comment, $term);
                }
                elsif ($term=~/^trans_spliced/) {
                    #
                }
                elsif ($term=~/^term%3D/) {
                    #
                }
                elsif ($term=~/^tRNA\+/ or $term=~/^tRNA\-/ ) {
                    #
                }
                elsif ($term=~/^locus_tag\+doesn\'t\+have\+stop\+codon/) {
                    #
                }
                else {

                    $term=~s/\+/ /g;
                    $term=~s/%3D/,/g;
                    $term=~s/%3B/,/g;
                    
                    push(@comment, $term);
                    #print "ELSE $term\n";

                }
            }

        }



        else {
            print "Warning: unknown feature on gene $el \n";
        }

    }
    my $new_line =  "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$id;$parent;$colour;$product;$partial";
    $new_line=~s/\;\;/\;/g;
    $new_line=~s/\;\;/\;/g;
    $new_line=~s/\;\;/\;/g;
    $new_line=~s/\;\;/\;/g;
    print OUT3 "$new_line\n";


    if ( scalar(@go) > 0 ) { 
        my $idgo = $id;
        $idgo=~s/ID=//;
        my @ar = split(/\:pep/,$idgo);
        $idgo=$ar[0];
        $idgo=~s/\.\d+$//;
        print GO "$idgo\t" . "@go"  . "\n";
    }
=pod
    if ( scalar(@ipr) > 0 ) {
        #print "not 0 " . "@ipr" ."\n";
        my $idipr = $id;
        $idipr=~s/ID=//;
        my @ar = split(/\:pep/,$idipr);
        $idipr=$ar[0];
        foreach my $el2 (@ipr) {
            print IP "$idipr\t" . $el2  . "\n";
        }
    }
=cut

}


open (IN3, "<$out.gff") || die "I can't open $out.gff\n";
my @in3 = <IN3>;



foreach my $lin  (@in3) {
    chomp $lin;

    my @arr= split(/\t/, $lin);

    if (scalar(@arr)< 8) {
        print "Skipped line $lin\n";
    }
    elsif ($arr[2]=~/gap/ or $arr[2]=~/contig/ ) {
        # ignore
        #print "cut1 $arr[2]\t$lin\n";
    }
    elsif ($arr[2]=~/ncrna/i  ) {
        # ignore
        #print "cut2 $arr[2]\t$lin\n";
    }
    elsif ($arr[2]=~/patho/  ) {
        # ignore
        #print "cut3 $arr[2]\t$lin\n";
        }
    else {
        print OUT4 "$lin\n";
    }

}


close(OUT3);
close(OUT4);


# fix for new GO-terms
system "cat $out.go | sort | uniq > $out.gos  ";
system "rm -f $out.go";


exit;

__END__


