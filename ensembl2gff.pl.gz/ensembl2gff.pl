#!/usr/bin/perl -w

# mz3 script for changing ensembl to gff

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/ensembl2gff.pl input.gff input.fas.fai


input.gff	Input gff-file, which can have additional features
input.fas.fai	Fasta.fai with all sequences to which the gff belongs


Output:
.exon transcripts
.gexon  genes
.gff all with correct parents


'
}


my $in = shift;
my $in2 = shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (IN2, "<$in2") || die "I can't open $in2\n";
	my @in2 = <IN2>;
	close (IN2);

	open (OUTE, ">$in.exon") || die "I can't open $in.exon\n";
	open (OUTGE, ">$in.gexon") || die "I can't open $in.gexon\n";
	open (OUTG, ">$in.gff") || die "I can't open $in.gff\n";


my $last=0;
my $ts=0;
my $gene=0;

foreach my $l (@in) {
	chomp $l;

	if ($l=~/^#/) {
		#ignore ;
		next;
	}

	my @a=split(/\t/, $l);
	my @f=split(/\;/, $a[8]);

	if ($a[2]=~/^exon$/) {
		$f[0]=~s/ID=transcript://;
		$f[1]=~s/Name=//;
		print OUTGE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$gene\n";
		print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts\n";
 		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[1];Parent=$ts\n";
	}
	elsif ($a[2]=~/^aberrant_processed_transcript$/) {
		$f[0]=~s/ID=transcript://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";
		$ts=$f[0];
	}
	elsif ($a[2]=~/^CDS$/) {
		# ignore;
	}
	elsif ($a[2]=~/^C_gene_segment$/) {
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		if ($f[0]=~/gene:/) {
			$f[0]=~s/ID=gene://;
			$gene=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$gene\n";
		}
		elsif ($f[0]=~/transcript:/) {
			$f[0]=~s/ID=transcript://;
			$ts=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts;Parent=$gene\n";
		}
		else {
			print "Complain: $l\n";
		}
	}
	elsif ($a[2]=~/^chromosome$/) {
		# ignore ;
	}
	elsif ($a[2]=~/^five_prime_UTR$/) {
		# ignore;
	}
	elsif ($a[2]=~/^gene$/) {
		$f[0]=~s/ID=gene://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		$gene=$f[0];
	}
	elsif ($a[2]=~/^J_gene_segment$/) {
		#$f[0]=~s/ID=gene://;
		#
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		#print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		if ($f[0]=~/gene:/) {
			$f[0]=~s/ID=gene://;
			$gene=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$gene\n";
		}
		elsif ($f[0]=~/transcript:/) {
			$f[0]=~s/ID=transcript://;
			$ts=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts;Parent=$gene\n";
		}
		else {
			print "Complain: $l\n";
		}
	}
	elsif ($a[2]=~/^lincRNA$/) {
		$f[0]=~s/ID=transcript://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";
		$ts=$f[0];
	}
	elsif ($a[2]=~/^lincRNA_gene$/) {
		$f[0]=~s/ID=gene://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		$gene=$f[0];
	}
	elsif ($a[2]=~/^miRNA$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^miRNA_gene$/) {
		$f[0]=~s/ID=gene://;
		$gene=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";

	}
	elsif ($a[2]=~/^mt_gene$/) {
		$f[0]=~s/ID=gene://;
		$gene=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";

	}
	elsif ($a[2]=~/^nc_primary_transcript$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^NMD_transcript_variant$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^processed_pseudogene$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^processed_transcript$/) {
		#$f[0]=~s/ID=transcript://;
		#$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		#print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";
		if ($f[0]=~/gene:/) {
			$f[0]=~s/ID=gene://;
			$gene=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$gene\n";
		}
		elsif ($f[0]=~/transcript:/) {
			$f[0]=~s/ID=transcript://;
			$ts=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts;Parent=$gene\n";
		}
		else {
			print "Complain: $l\n";
		}
	}
	elsif ($a[2]=~/^pseudogene$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^pseudogenic_transcript$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^RNA$/) {
		$f[0]=~s/ID=gene://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		$gene=$f[0];
	}
	elsif ($a[2]=~/^rRNA$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^rRNA_gene$/) {
		$f[0]=~s/ID=gene://;
		$gene=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";

	}
	elsif ($a[2]=~/^snoRNA$/) {
		$f[0]=~s/ID=transcript://;
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";
		$ts=$f[0];
	}
	elsif ($a[2]=~/^snoRNA_gene$/) {
		$f[0]=~s/ID=gene://;
		$gene=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";

	}
	elsif ($a[2]=~/^snRNA$/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";

	}
	elsif ($a[2]=~/^snRNA_gene$/) {
		$f[0]=~s/ID=gene://;
		$gene=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";

	}
	elsif ($a[2]=~/^supercontig$/) {
		# ignomre;
	}
	elsif ($a[2]=~/^three_prime_UTR$/) {
		# ignore;
	}
	elsif ($a[2]=~/^transcript/) {
		$f[0]=~s/ID=transcript://;
		$ts=$f[0];
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0];Parent=$gene\n";
	}
	elsif ($a[2]=~/VD_gene_segment/) {
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		if ($f[0]=~/gene:/) {
			$f[0]=~s/ID=gene://;
			$gene=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		}
		elsif ($f[0]=~/transcript:/) {
			$f[0]=~s/ID=transcript://;
			$ts=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts;Parent=$gene\n";
		}
		else {
			print "Complain: $l\n";
		}
	}
	elsif ($a[2]=~/^V_gene_segment$/) {
		#print OUTE "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		#print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$f[0]\n";
		if ($f[0]=~/gene:/) {
			$f[0]=~s/ID=gene://;
			$gene=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$gene\n";
		}
		elsif ($f[0]=~/transcript:/) {
			$f[0]=~s/ID=transcript://;
			$ts=$f[0];
			print OUTG "$a[0]\t$a[1]\t$a[2]\t$a[3]\t$a[4]\t$a[5]\t$a[6]\t$a[7]\t$ts;Parent=$gene\n";
		}
		else {
			print "Complain: $l\n";
		}
	}
	else {
		print "Unknown feature ignored:$l\n";
	}

}


system "cat $in.exon | sort -k1,1 -k4,4n | uniq > $in.exon2";
system "mv $in.exon2 $in.exon";
system "cat $in.gexon | sort -k1,1 -k4,4n | uniq > $in.gexon2";
system "mv $in.gexon2 $in.gexon";



exit;


