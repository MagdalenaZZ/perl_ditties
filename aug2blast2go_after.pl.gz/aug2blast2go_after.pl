#!/usr/local/bin/perl -w
# mz3 script for changing augustus-output to blast2go-input
use strict;

unless (@ARGV==5) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/aug2blast2go_after.pl 



'
}


	my $gtf = shift;
	my $start = shift;
	my $end = shift;
	my $foldername = shift;
	my $cwd = shift;
#$start--;
#$end--;



open (LIST, "<$gtf.sl.faa.list.$foldername.cut") || die "I can't open $gtf.sl.faa.list.$foldername.cut\n";

my @cutlist = <LIST>;
chomp @cutlist;

#check that ipr-jobs ran well

foreach my $elem (@cutlist) {
chomp $elem;

	unless (-e  "$foldername/IPR/$elem.ipr.xml" )	{
		print "IPR ERROR: The file $foldername/IPR/$elem.ipr.xml does not exist. Maybe something went wrong with the iprscan? Or maybe the scan hasn't finished?\n";
	}

}

##### delete files that don't have 

foreach my $elem (@cutlist) {
chomp $elem;

open (TMP, "<$foldername/IPR/$elem.ipr.xml") || die "I can't open $foldername/IPR/$elem.ipr.xml\n";

my @temp = <TMP>;
chomp @temp;

if ($temp[3] =~ "interpro_matches") {
# system "rm -f $foldername/IPR/$elem.ipr.xml";
print "$foldername/IPR/$elem.ipr.xml has no contents\n";
}

else {
print "$foldername/IPR/$elem.ipr.xml has contents\n";
}


close (TMP);

}

#check that blast-jobs ran well

unless (-e "$foldername/BLAST/all.blast") {
print "BLAST ERROR: The file $foldername/BLAST/all.blast does not exist. Maybe something went wrong with the blastall? Or maybe it hasn\'t finished?\n";
}

#my $success = system "cat $foldername/BLAST/*.o | grep Sucessfully";
#print "Successful jobs: $success\n";

#unless ($success ==2) {
#print "BLAST ERROR: No all blast-jobs ended successfully. Maybe something went wrong with the blastall? Or #maybe it hasn\'t finished?\n";
#}

############################################################################

# run blast2go

system "cp /software/pathogen/external/apps/blast2go_pipeline/b2gPipe.properties $foldername";

my $blast2go = "team133-bsub.pl basement 20 $foldername.b2g.o $foldername.b2g.e $foldername.b2g java -jar /software/pathogen/external/apps/blast2go_pipeline/blast2go.jar -in $cwd/$foldername/BLAST/all.blast -out $foldername.b2g.out -ipr $cwd/$foldername/IPR -a  $cwd/$foldername.annot -d $cwd/$foldername.dat";


open (SH3, ">$foldername.b2g.sh") || die "I can't open $foldername.b2g.sh\n";
print SH3  "$blast2go\n";

close (SH3);

print   "FINISHED. Your next commandline has been written to $foldername.b2g.sh\n";