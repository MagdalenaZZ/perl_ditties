#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: pfam2GO_genes.pl  topGO.Rout topGO.pfam Species.pfam

The first file is a file with domains, and their GO-terms:

Fer2 GO:0009055,GO:0051536
DPM2 GO:0009059,GO:0030176
zf-RAG1 GO:0016788,GO:0016881
UBX GO:0005515

The second file is regular Pfam output



'
}

	my $in = shift;
    my $in2 = shift;

    my $out = "$in2.out";

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (IN2, "<$in2") || die "I can't open $in2\n";
	my @in2 = <IN2>;
	close (IN2);

    open (OUT, ">$out") || die "I can't open $out\n";


# read in the go-terms
    
my %go;

foreach my $line (@in) {
chomp $line;
    if ($line =~/GO/ ) {
        my @arr = split(/\s+/, $line); 
        $go{ $arr[0]} = $arr[1];
    }

}

# read in the pfam

my %pfam;


foreach my $line2 (@in2) {
chomp $line2;
    if ($line2 =~/\w+/ and $line2 !~/#/ ) {
#        print "LINE:$line2:\n";
        my @arr2 = split(/\s+/, $line2);
        $arr2[0]=~s/\.1\.\.pep//;
        $pfam{ $arr2[0]}{$arr2[6]}=1;

        if ( exists $go{$arr2[6]}) {
              $pfam{ $arr2[0]}{$arr2[6]} = $go{ $arr2[6] };
#              print "$go{$arr2[6]}\n";
        }

#        print "$arr2[0]\t$arr2[6]\n";
    }

}


foreach my $gene ( sort keys %pfam) {

    print OUT  "$gene ";

    my %h;

    foreach my $dom ( keys %{ $pfam{$gene}} ) {

#        print "$pfam{$gene}{$dom} \n";
        my @ah = split (/\,/,  $pfam{$gene}{$dom} );
        
        foreach my $elem (@ah) {
            if ($elem =~/GO/) {
                $h{$elem}=1;
#                print "$elem\n";
            }
        }
    
        foreach my $go ( sort keys %h) {
            print OUT  "$go,";
        }
 

    }
    print OUT "\n";
}





close (OUT);

exit;
