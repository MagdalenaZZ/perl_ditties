#!/usr/local/bin/perl -w

use strict;


unless (@ARGV > 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: table_compare.pl table1 table2  output

Takes two tab-delimited tables with headers and row-names, and performs a calculation on them 



'
}



my $data = shift;
my $data2 = shift;
my $out = shift;


open(DATA, "<$data") or die "Cant find file $data\n  $!";
open(DATA2, "<$data2") or die "Cant find file $data2\n  $!";
open(OUT, ">$out") or die "Cant find file $out\n  $!";
open(OUT2, ">$out.pw") or die "Cant find file $out.pw\n  $!";


my @data2 = <DATA2>;

my @head = split(/\t/, shift(@data2));
shift(@head);
chomp @head;
push(@head, "off");

my $first = 1;


# get the matching rows 

while ( <DATA> ) {
    chomp;
    my @arr = split("\t", $_);

    # remove header
    if ($first =~/1/) {
        print OUT "$_\n";
        $first =0;
        next;
    }

    else {

        my @arr2 = split("\t",  shift(@data2));
        chomp @arr2;
        my $i=0; 

        my $row1 = shift (@arr);
        my $row2 = shift (@arr2);

        unless ($row1=~/$row2/ and $row2=~/$row1/) {
            print "Elements in different order $row1 $row2\n";
            exit;
        }

        print OUT "$row1\t";

        foreach my $el (@arr) {
       
            my $x = $el;
            my $y = $arr2[$i];
            #my $e = eval { $cal } ;
            my $res;

            # remove instances where they are not numbers
            unless ( ( $x =~ /^\d+$/ or $x =~ /^[+-]?\d+$/ or $x  =~ /^[+-]?\d+\.?\d*$/ ) and  ( $y =~ /^\d+$/ or $y =~ /^[+-]?\d+$/ or $y  =~ /^[+-]?\d+\.?\d*$/ ) ) {
                print "Not number $head[$i]\t$row1\t:$x:\t:$y:\n";
                $i++;
                next;
            }
            # if (  ($x!~/^\d+$/ || $x!~/^\d+\.\d+$/ )  and  ($y!~/^\d+$/ || $y!~/^\d+\.\d+$/ )   ) {
            #}
            if ($x!~/^0$/) {
            #if ($x!~/^0$/ and $y!~/^0$/) {
            # CALCULATION STATEMENT
                $res = $y  / $x ;
            }
            else {
                $res = 0;
            }

            print OUT2 "$head[$i]\t$row1\t$x\t$y\t$res\n";
            print OUT "$res\t";
            $i++;

        }


    }
    print OUT "\n";


}


close(OUT);
close(OUT2);

exit;


__END__


