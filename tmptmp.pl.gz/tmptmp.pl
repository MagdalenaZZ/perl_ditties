#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado_dump_annotation.pl genome.fas GFF/EMBL



'
}



	my $in = shift;
	my $file = shift;

    my $out = "$in2.outR";

	open (IN, "<$in") || die "I can't open $in\n";

my @cont;

my $line;
my $i;


    while (<IN>) {
        if ($_ =~/^>/) {
            chomp;
            my $head =$_;
            $head =~s/>//;

            if ($i > 100) {
                push (@cont, $line);
                $line = $head;

            }
            else {
                $line = $line . " " . $head ;
                print "$line\n";
            }

        }
    }


foreach my $con (@contigs) {

}


print " writedb_entry -Djava.awt.headless=true -f y -c pgsrv1:5432/pathogens?mz3@sanger.ac.uk -o $file -u script -p KL37m_X7 -fp EXPORT_FOLDER/artemis/GFF/Egranulosus/1 -s " 



print "bsub.py -q yesterday 1 ";
