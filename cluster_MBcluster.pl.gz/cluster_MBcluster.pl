#!/usr/local/bin/perl -w
use strict;
use Getopt::Long;

my $clust_num = 20;
my $outfile = 'out';
my $treat = 0 ;

my $go_cut = 0.01;
my $skip_clustering = 0;
my $save = 0;

my @go_class = ('BP', 'MF', 'CC');

my($help, $data, $rpkms, $go_file, $go_res, $go_prod  ) = ();

GetOptions (
	"h|help"	=> \$help,
	"c|counts:s"	=> \$data,
	"r|rpkms:s"	=> \$rpkms,
	"g|go:s"	=> \$go_file,
	"p|product-list:s"	=> \$go_prod,
	"o|out:s"	=> \$go_res,
	"n|nclust:i"	=> \$clust_num,
	"t|gocut:f"	=> \$go_cut,
	"s|skip_clust"	=> \$skip_clustering,
	"d|own_treatment_definition:s" => \$treat,
	"save"		=> \$save,

);

if($help || !$data || !$rpkms || !$go_file) {
	print_usage();
	exit;
}



#if(!$go_res){
#	$go_res = "results.dat";
#}


if(!$go_res){
	$outfile = "results.dat";
}
else {
    $outfile= $go_res;
}

print "d $treat\t\t default 0\n";

print "RPKMs $rpkms\n";
print "nclust $clust_num\n";
print "s $skip_clustering \t\t default 0\n";
print "c $data \t\t default ''\n";
print "o $outfile \t\t default 'results.dat'\n";

#__END__

open(DAT, "<$data") or die "$!";

my @treatment = ();
my %treatments = ();
my %data = ();
my @ids = ();

my %samples = ();
my @samples = ();

# work with the data

while(<DAT>){
	chomp;

	my($id, @cols) = split(/\t/, $_);

    #print "ID\t $id\n";

	if($id=~/^id$/ || $id=~/^ID$/ ) {
		my $c = 1;
		my $col_num = 1;
		my %seen = ();

		foreach my $col (@cols){
            #my @temp =~ split(/\./, $col);
            #$col=$temp[0];
            #print "col\t $col\n";

			my $treatment = $col;
            #print "T $treatment\n";
			$samples{$col_num} = $col;
			push @samples, $col;

			if(exists $seen{$treatment}) {
				push @treatment, $seen{$treatment};
			}
			else {
				$seen{$treatment} = $c;
				push @treatment, $seen{$treatment};

				$treatments{$c} = $treatment;
				$c++;
			}

			$col_num++;
		}
	}
	else
	{
		$data{$id} = \@cols;
		push @ids, $id;
	}
}
close DAT;

#__END__


# work with the rpkms
open(RPKM, "<$rpkms") or die "Cant find file $rpkms\n$!";

my %rpkms = ();

while(<RPKM>){
	chomp;

	next if ($_=~/^id$/ || $_=~/^ID$/ );

	my($id, @cols) = split /\t/;

	my $c = 0;

	my %collection = ();

	foreach my $col (@cols){
		#push @logs, (log($col + 1) / log(2));
		push @{$collection{$treatment[$c]}}, $col;
		$c++;
	}

	my @logs = ();
	my $log_sum = 0;
	my $treat_num = 0;

	foreach my $treatment (sort {$a<=>$b} keys %collection)
	{
		my $sum = 0;
		my $n = 0;

		foreach my $val (@{$collection{$treatment}}){
            if ($val=~/^\d+$/ or $val=~/^\d+\.\d+$/ ) {
			$sum += $val;
			$n++;
            }
            else {
                #print "not number $val\n";
            }
		}

        my $mean = 0;
        unless ($sum=~/^0$/ and $n=~/^0$/ ) {
		    $mean = $sum / $n;
        }

		my $log_mean = log($mean+1) / log(2);

		push @logs, $log_mean;

		$log_sum += $log_mean;
		$treat_num++;


		#print "$id\t$log_mean\n";
	}

	my $mean_of_logs = $log_sum / $treat_num;

	foreach my $log (@logs)
	{
		my $norm_log = $log - $mean_of_logs;

		#print "$log\t$mean_of_logs\t$norm_log\n";

		push @{$rpkms{$id}}, $norm_log;
	}

}
close RPKM;





#print "@treatment\n";
my $treat_string = join ",", @treatment;



# make my own treatment string

#print "Treatment $treat_string\t$treat\n";

unless ($treat=~/^0$/) {
    $treat_string = $treat;
    print "Updated Treatment to $treat_string \nwhich should look something like 1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8,9,9,9,10,10,10\n";
}





#__END__


unless($skip_clustering)
{
	cluster($data, $treat_string, $clust_num, $outfile);
}

open(CLUST, "<$outfile") or die "$!";

my %clusters = ();

my $row_num = 0;

while(<CLUST>)
{
	chomp;

	$clusters{$_}->{$ids[$row_num]} = 1;

	#print "$ids[$row_num]\t$_\n";

	$row_num++;
}
close CLUST;




open(RES, ">$go_res\n") or die "$!";

foreach my $n (sort {$a<=>$b} keys %clusters) {
	#print "$n\n";

	open(OUT, ">cluster$n\.prof") or die "$!";

	my @header = ();

	foreach my $treatment (sort {$a<=>$b} keys %treatments)
	{
		push @header, $treatments{$treatment};
	}

	#my $header = "id\t". join "\t", @header;

	#print OUT "$header\n";

	my @matrix = ();

	foreach my $id (sort keys %{$clusters{$n}})
	{
		push @{$matrix[0]}, $id;

		for(0..scalar @{$rpkms{$id}} - 1)
		{
			push @{$matrix[$_+1]}, $rpkms{$id}->[$_];
		}

	}

	my $c = 0;

	foreach my $row (@matrix)
	{
		my $data = join "\t", @$row;

		if(!exists $treatments{$c})
		{
			$treatments{$c} = "";
		}

		#print "$c\t$treatments{$c}\n";

		$data = $treatments{$c} . "\t" . $data;

		print OUT "$data\n";

		$c++;
	}
	close OUT;

	profile_plot("cluster$n\.prof");

	my @ids = @{$matrix[0]};

	my $ids = join "\n", @ids;

	my $cluster_size =  scalar @ids;

	#print "IDS: $ids\n";

	open(OUT, ">cluster$n\.list") or die "$!";
	print OUT "$ids\n";
	close OUT;

	print RES "Cluster $n\t$cluster_size members\n";

	foreach my $class (@go_class)	{

        #my $res = go_enrichment("cluster$n\.list", $class);
	    print STDERR "Running ~mz3/bin/perl/topGO_starter.pl  cluster$n\.list $go_file BP  $go_prod cluster$n \n";
	    system  "perl ~mz3/bin/perl/topGO_starter.pl  cluster$n\.list $go_file BP  $go_prod cluster$n ";
	    #system("~mz3/bin/perl/topGO_starter.pl $file $go_file $type") == 0 or die "$!";


        #foreach my $term (@$res) {
        #	print RES "$term\n";
        #}
	}

	print "\n";

}

close RES;

=pod

sub go_enrichment {
	my($file, $type) = @_;

	my @dat = ();

	print STDERR "Running ~mz3/bin/perl/topGO_starter.pl $file $go_file $type\n";
	system("~mz3/bin/perl/topGO_starter.pl $file $go_file $type") == 0 or die "$!";

	open(IN, "<clust1") or die "$!";

	while(<IN>) {
		chomp;
		#"GO.ID" "Term"  "Annotated"     "Significant"   "Expected"      "topGO"
		next unless /^"\d/;
		s/\"//g;

		my($n, $id, $term, $ann, $sig, $exp, $score) = split /\t/;

		if($score <= $go_cut)
		{
			push @dat, "$id\t$type\t$term\t$ann\t$sig\t$score";
		}
	}
	close IN;

	return \@dat;
}

=cut



sub profile_plot {
	my($file) = @_;

	open(IN, "<$file") or die "$!";

	my @cols = split /\t/, <IN>;
	my $ncols = scalar @cols - 1;

	close IN;

	open(R_CODE, ">$file\.$clust_num\.plot\.R") or die "$!";

	print R_CODE "x<-read.table(\"$file\", header=TRUE, row.names=1)\n";
	print R_CODE "g_range <- range(0, x)\n";
	print R_CODE "png(\"$file\.png\")\n";

	for(1..$ncols)
	{
		if($_ == 1)
		{
			print R_CODE "par(xaxt=\"n\")\n";
			print R_CODE "plot(x[,1], type = 'l', col=(rgb(1,0,0,1)), ylim=g_range, ylab=\"Mean-normalised log2 RPKM\", xlab=\"Stage\")\n";
			print R_CODE "text(x = seq(1, 10, by=1), par(\"usr\")[3] - 0.2, labels = row.names(x), pos = 1, xpd = TRUE)\n";
		}
		else
		{
			print R_CODE "lines(x[,$_], col=(rgb(1,0,0,1)))\n";
		}

	}
	print R_CODE "dev.off()\n";

	print R_CODE "pdf(\"$file\.$clust_num\.plot\.pdf\")\n";

	for(1..$ncols)
        {
                if($_ == 1)
                {
                        print R_CODE "par(xaxt=\"n\")\n";
                        print R_CODE "plot(x[,1], type = 'l', col=(rgb(1,0,0,1)), ylim=g_range, ylab=\"Mean-normalised log2 RPKM\", xlab=\"Stage\")\n";
                        print R_CODE "text(x = seq(1, 10, by=1), par(\"usr\")[3] - 0.2, labels = row.names(x), pos = 1, xpd = TRUE)\n";
                }
                else
                {
                        print R_CODE "lines(x[,$_], col=(rgb(1,0,0,1)))\n";
                }

        }
        print R_CODE "dev.off()\n";


	close R_CODE;
	close IN;

	system("R-3.0.0 --no-save < $file.$clust_num.plot.R") == 0 or die "$!";
  }

sub cluster {
	my ($dat, $treat_string, $clusters, $outfile) = @_;

	my $save_string = "";

	if($save)
	{
		$save_string = "save(cls2, file=\"cls.RData\")";
	}

	open(R_CODE, ">$data.$clust_num.clust.R") or die "$!";

	print R_CODE "

	library(MBCluster.Seq)

	Count<-read.table(\"$dat\", header=TRUE, row.names=1)
	GeneID=row.names(Count)

	Treatment=c($treat_string)
    warnings()
	Normalizer=rep(1,ncol(Count))
	mydata=RNASeq.Data(Count,Normalize=NULL,Treatment,GeneID)
	c0=KmeansPlus.RNASeq(mydata,nK=$clusters)\$centers
	cls2=Cluster.RNASeq(data=mydata,model=\"nbinom\",centers=c0,method=\"EM\")
	cls=cls2\$cluster
	$save_string
	tr=Hybrid.Tree(data=mydata,cluster=cls,model=\"nbinom\")
	pdf(\"$outfile\.clustering.pdf\")
	plotHybrid.Tree(merge=tr,cluster=cls,logFC=mydata\$logFC,tree.title=NULL)
	dev.off()

	write(cls, file=\"$outfile\",sep=\"\\n\")
	dev.off()
    quit()\n
    ";

	close (R_CODE);

    system("R-3.0.0 --no-save < $data.$clust_num.clust.R") == 0 or die "$!";
      print "\n R-3.0.0 --no-save < $data.$clust_num.clust.R \n\n ";
      exit;

}


sub print_usage 
{
	print <<USAGE;

	# cluster_expression.pl

	Mandatory:
	"c|counts:s"	Read counts for each gene (see below for format)
	"r|rpkms:s"	RPKMs for each gene (see below for format)
	"g|go:s"	GO annotations (see below for format)

	Optional:
	"h|help"	Help
	"o|out:s"	Outfile for cluster descriptions
	"n|clust:i"	Number of clusters (20)
	"t|gocut:f"	Cutoff q-value for go term enrichment (default: 0.05)
	"s|skip_clust"	Skip clustering
	"save"		Save clustering object as cls.RData

	# Read count/RPKM file format
	n.b. Header format for count/RPKM data should include timecourse/treatment
	info in the following format: <treatment>.<unique_id> e.g. J2.1234_1 where
	J2 is the treatment and 1234_1 is the lane id. So J2.1234_1 and J2.4321_1
	will be interpreted as biological replicates. this line should also begin
	"id" for the gene id column:

	id	J2.1234_1	J2.4321_1	J4.2345_2	J4.5432_1
	GeneA	12	43	1000	2000
	GeneB	45	90	3	1

	# Go annotation file format
	<Id>\t<go1,go2,go3,go4...>

USAGE

}


exit;


__END__

    cprob=Cluster.RNASeq(data=mydata,model="nbinom",centers=c0,method="EM")$cluster
    cprob2=Cluster.RNASeq(data=mydata,model="nbinom",centers=c0,method="EM")$probability
    ccentres=Cluster.RNASeq(data=mydata,model="nbinom",centers=c0,method="EM")$centres

    

cprob2=Cluster.RNASeq(data=mydata,model="nbinom",centers=c0,method="EM")$probability

head(cprob2)
[1] "--->>>> iteration stops after 30 steps"
>
>
> head(cprob2)
             [,1]         [,2]         [,3]         [,4]         [,5]
[1,] 5.109061e-01 7.315834e-05 2.173367e-05 7.979401e-04 1.387577e-07
[2,] 2.110930e-02 1.716446e-02 2.177568e-03 7.996201e-02 5.472071e-06
[3,] 4.845261e-02 8.836009e-02 4.579981e-02 6.166916e-02 2.167961e-02
[4,] 9.166813e-03 3.431882e-03 1.147469e-03 2.548670e-02 7.946525e-06
[5,] 1.313396e-14 1.118802e-01 2.509512e-01 5.787251e-03 7.112412e-02
[6,] 4.573600e-81 5.928776e-01 1.587137e-05 2.001945e-05 1.981007e-26
             [,6]         [,7]         [,8]         [,9]        [,10]
[1,] 2.956502e-04 1.042179e-03 1.425665e-03 1.665604e-02 5.358707e-06
[2,] 2.255955e-03 1.277325e-01 3.912623e-02 1.662188e-01 5.105140e-03
[3,] 3.878295e-02 2.744529e-02 6.571563e-02 3.928438e-02 7.973662e-02



    cls=cls2$cluster
	cprob=cls2$probability
	centres=cls2$centers



