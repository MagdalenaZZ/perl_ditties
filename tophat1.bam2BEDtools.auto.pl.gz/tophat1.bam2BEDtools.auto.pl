#!/usr/bin/perl
use strict;


unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die ' 

USAGE: tophat1.bam2BEDtools.auto.pl <in.sorted.bam>


DESCRIPTION: This script prepares a BAM file for subsequent intersection with a GFF file using BEDtools via Jasons other script tophat2.bam2RPKM_BEDtools.sh

    It does the following:
    * filter for minimum mapping quality of 30
    * adjust the CIGAR string of split reads (split reads spanning an intron), e.g.:
     -  73M850N27M  is changed to  73M27S
     - 40M2500N60M  is changed to  40S60M, plus the left-most mapping position POS of the read (4th column in the BAM file) is adjusted
    [ example: POS=1001 and CIGAR=40M2500N60M  are changed to  POS=3541 and CIGAR=40S60M ]
    Notes:
    * the length of the sequence reads is determined automatically
    * output is to file in_bam.forBedtoolsOnly.UNsorted.raw_mapQ30.bam
    * for a 2GB BAM file this script may take ~20min and ~1GB memory: with SORTing
    * for a 2GB BAM file this script may take ~10min and <100MB memory
    * the resulting BAM file will be UNsorted (some match starting positions are changed!)
    * the resulting BAM file will contain inconsistencies because some match starting positions are changed but neither corresponding read mates nor template lengths are changed! But this should not impact the GFF file intersection with BEDtools.

'

}


my $in = shift;
my $out = $in . ".forBEDToolsOnly.UNsorted.raw_mapQ30" ;


# filter only 30 or more

open IN, " samtools  view -h -q 30 $in | ";
open OUT, "> $out ";

#print "Hix\n " ;

while (<IN>) {
    #chomp;
#    print "Hi" . $_;

    my @ar=split(/\t/, $_);
    my $readlen=length($ar[9]);

# check for split reads 
    if ($ar[0] !~ /\w+/) {
            print join("\t",@ar); 
            print "\n"; 
            next;
    }


    if ($ar[5] =~ /(\d+)M(\d+)N(\d+)M/) { 
        
        my $n1=$1;
        my $n2=$2;
        my $n3=$3; 

# adjust them to one side        
        if ($n1>=$n3) {
            my $n3=($readlen-$n1);$ar[5]=$n1."M".($n3)."S";

# or to the other side, if that is longer
        } 
        else { 
            $n1=($readlen-$n3);
            $ar[5]=($n1)."S".$n3."M";
            $ar[3]=$ar[3]+$n1+$n2;  

            #print join("\t",@ar); 
            #print "\n"; 
        } 


    }

#
    print OUT join("\t",@ar); 

}

# make BAM

system "samtools view -Sb  $out > $out.bam ";

system "rm -f $out";

#print "Hix2\n " ;


__END__


samtools view -h -q 30 $bam_in | perl -nle '@ar=split(/\t/); if ($ar[5] =~ /(\d+)M(\d+)N(\d+)M/){ $n1=$1;$n2=$2;$n3=$3; $readlen=length($ar[9]); if ($n1>=$n3) {$n3=($readlen-$n1);$ar[5]=$n1."M".($n3)."S"} else { $n1=($readlen-$n3);$ar[5]=($n1)."S".$n3."M";$ar[3]=$ar[3]+$n1+$n2;  } print join("\t",@ar)} else {print }'  | samtools view -Sb - > $bam_out

# Jason's original: samtools view -h -q 30 $bam_in | perl -nle '@ar=split(/\t/); if ($ar[5] =~ /(\d+)M(\d+)N(\d+)M/){ $n1=$1; $n3=$3; if ($n1>$n3) {$n3=(100-$n1);$ar[5]=$n1."M".($n3)."S"} else { $n1=(100-$n3);$ar[5]=($n1)."S".$n3."M } print join("\t",@ar)} else {print }'  | samtools view -Sb - > $bam_in.parsed.forBedtools.raw_mapQ30.bam

