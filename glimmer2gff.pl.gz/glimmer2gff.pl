#!/usr/bin/perl -w
# mz3 script for changing glimmer into gff
# Usage: perl ~/bin/perl/glimmer2gff.pl file.gff > file.gtf.gff

use strict;

my @newlines = '';
my @array = '';

while (<>) {

push (@newlines, $_);

}

=pod

my @lines = system(" grep -v '#' $ARGV[0] >temp");
chomp @lines;

if (open(MYFILE, "temp")) {
#print "opened temp\n";	
} 

else {
    print "Cannot open mydatafile!\n";
    exit 1;
}

# # # # # # # # # # # # # # # # # 


my @cleanlines=<MYFILE>;
# print $cleanlines[0];
my @first = split (/\s+/, $cleanlines[1]);
# print "$first[0]\n";
my $first = $first[0];

close (MYFILE);

system("rm -f temp");

# # # # # # # # # # # # # # # # # # # # # 

my @newlines = "";

# my $howmany = scalar(@cleanlines);

# print "This many $howmany \n";




foreach my $elem (@cleanlines)  {
	
	
	if ($elem=~ $first)  {
# 	print "okay\n";
	push (@newlines, $elem);
	}
	
	else {
# 	print "not okay\n";
	last;	
	}
	
}

# print "$newlines[163]\n"; 
# print scalar(@newlines),"\n";

#  print "@newlines";

chomp @newlines;

=cut

# my $notetrans = "";

 foreach my $line (@newlines) {

 	 my @line = split (/\s+/, $line);
 	 
# print "@line";
		my $name = $line[0];
		my $method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
		my $end = $line[4];
		my $score = $line[5];
		my $strand = $line[6];
		my $trans = $line[7];
		my $noten = $line[8];
		my ($notegene, $a, $b, $c)= split (/;/, $noten);
		my $note = $notegene.";".$a;
		my ($first, $second)= split (/=/, $notegene);
		my $notetrans = $notegene.";Parent="."$second";
		
# print "great\n";
# take out transcripts -> gene and CDS

		if ($tag=~"mRNA") {
		my $newline = "$name\t$method\tgene\t$start\t$end\t.\t$strand\t.\t$notegene;\n";
		push (@array, $newline);
		#print "$newline"; #  <STDIN>;
		}
		if ($tag=~"mRNA") {
		my $newline = "$name\t$method\tmRNA\t$start\t$end\t.\t$strand\t.\t$notetrans;\n";
		push (@array, $newline);
# 		print "$newline"; <STDIN>;
		}

		elsif ($tag=~"CDS") {
		my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t.\t$note;\n";
		push (@array, $newline);
#		print "$newline"; <STDIN>;
		}
		
 }

# print "$lite\n";

# print "@array";
 
#my $size = @array;
#my $lite = length(@array);
# print "$size\n";

print "@array";

