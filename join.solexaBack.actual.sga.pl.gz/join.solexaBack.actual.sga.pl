#! /usr/bin/perl -w
#
# File: join.solexa2pairs.pl
# Time-stamp: <19-Oct-2011 16:30:14 tdo>
# $Id: $
#
# Copyright (C) 2008 by Pathogene Group, Sanger Center
#
# Author: Thomas Dan Otto
#
# Description: Will get the two solexa files \1 and \2 and join them,
# replacing the name to .F and .R of each read name
#

use strict;


my $name1=shift;
my $name2=shift;

my $resultName = shift;

if (!defined($resultName)) {
  die "
  
  Parameter:  join.solexa2pairs.pl reads_1.fq reads_2.fq result_prefix
  
  \n";
  
}


open (F1,$name1) or die "couldn't find file $name1: $!\n";
open (F2,$name2) or die "couldn't find file $name2: $!\n";

my $count=0;
my $res='';
my $resR='';
my $resSE='';

open (F, "> ".$resultName."_1.fastq" ) or die "probs";
open (R, "> ".$resultName."_2.fastq" ) or die "probs";
open (SE, "> ".$resultName."SE.fastq" ) or die "probs";

my $seqtmp;
my $qualtmp;

my $first;
my $resFirst='';
while (<F1>) {
  if (/\S+\..*w/) {
	print "ignore $_\n";
	<F1>;<F1>;<F1>;
  }
  else {
	
  ### change /1 to .F
  $count++;
  s/\.F$/\/1/g;
  s/\.R$/\/2/g;
	
## for capillary
s/\.p.*$/\/1/g;
s/\.q.*$/\/2/g;
	
  ### if forward
  if (/\/1/){
	#### if resFirst has entry, forward again
	 if ($resFirst ne ''){
	 	$resSE.=$resFirst;
	 }
  	$resFirst = $_;
  
    ($first)= $resFirst =~ /^.(.+)\/1/;
  	$count++;
#		print "$count \t $resFirst \t $first\n";
  
  	$resFirst.=<F1>;
  	$resFirst.=<F1>;
  	#qual
  	$resFirst.=<F1>;
   }
   ### if reverse
   elsif(/^.(.+)\/2/) {
	### is second, first must set
	my ($second) = $_ 	=~ /^.(.+)\/2/;
	if ($second eq $first){
		$res.=$resFirst;
		$resR .= $_;
 	    $resR.=<F1>;
  	    $resR.=<F1>;
  	    $resR.=<F1>;
		$resFirst='';
	}
	else {
		### it is reverse, but not machting mate pair;
		if ($resFirst ne ''){
	 	   $resSE.=$resFirst;
	 	   $resFirst='';
	 	}
	 	### it cannot have a mate anymore!
		$resSE .= $_;
 	    $resSE.=<F1>;
  	    $resSE.=<F1>;
  	    $resSE.=<F1>;
		}
   } # end if reverese
   else {
   	print "ignore cannot be error! $_ !!\n";
	<F1>;
<F1>;<F1>;   
die;
  }
  
}
  
  
  if (($count%200000)==0) {
	print F $res;
	$res='';
	print R $resR;
	$resR='';
	print SE $resSE;
	$resSE='';
  }
}

print F $res;
close(F);
print R $resR;
close(R);
print SE $resSE;
close(SE);
