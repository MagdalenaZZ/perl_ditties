#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLAT2gff.pl blat-out

Gives Gff-file with the BLAT-hits

'
}


	my $blat = shift;
	open (IN, "$blat") || die "I can't open $blat\n";
	my @blat = <IN>;
	close (IN);

#print "$blat[0]\n";
shift @blat;
shift @blat;
shift @blat;
shift @blat;
shift @blat;
#print "$blat[0]\n";

my $old_qseqid=0;
my $old_sseqid=0;

my %h;
my $let = "a";

foreach my $line (@blat) {
my @res = split (/\t/, $line);

=pod
my $match = $res[0];
my $mismatch = $res[1];
my $repmatch = $res[2];
my $Ns = $res[3];
my $QgapCount = $res[4];
my $QgapBases = $res[5];
my $TgapCount = $res[6];
my $TgapBases = $res[7];
my $strand = $res[8];
my $Qname = $res[9];
my $Qnameold = $res[9];
my $Qsize = $res[10]; # Qsize
my $Qstart = $res[11];
my $Qend = $res[12];
my $Tname = $res[13];
my $Tsize = $res[14]; # Tsize
my $Tstart = $res[15];
my $Tend = $res[16];
my $block = $res[17];
my $blockSizes= $res[18];
my $Qstarts= $res[19];
my $Tstarts= $res[20];
=cut
my $match = $res[0];
my $mismatch = $res[1];
my $repmatch = $res[2];
my $Ns = $res[3];
my $TgapCount = $res[4];
my $TgapBases = $res[5];
my $QgapCount = $res[6];
my $QgapBases = $res[7];
my $strand = $res[8];
my $Tname = $res[9];
my $Qnameold = $res[9];
my $Tsize = $res[10]; # Qsize
my $Tstart = $res[11];
my $Tend = $res[12];
my $Qname = $res[13];
my $Qsize = $res[14]; # Tsize
my $Qstart = $res[15];
my $Qend = $res[16];
my $block = $res[17];
my $blockSizes= $res[18];
my $Tstarts= $res[19];
my $Qstarts= $res[20];


if (exists $h{$Qname}) {

#    print "Exists $Qname\n";
    if (exists $h{$Qname} , $Qname = "$Qnameold\.$let" ) {
        $let++;
#        $Qname = "$Qnameold\.$let";
#        print "\nNew exist $Qname\n";
         my $num_keys = keys %h; 
#         print "$num_keys\n";
    }
    $h{$Qname}=1;
}

else {
# unless (exists $h{$Qname})  {
    $h{$Qname}=1;
#     print "Make  $Qname\n";
    $let="a";
}




#__END__

# GFF format 

#Transfer.ordered_Pf3D7_05.final	b2h	exon	129133	129184	0	.	.	mult=2;src=E "1;1;1:0"
#Transfer.ordered_Pf3D7_05.final	b2h	exon	187609	187620	0	.	.	mult=3;src=E "1;1;2:16"
#Transfer.ordered_Pf3D7_05.final	b2h	exon	187609	187638	0	.	.	mult=4;src=E "1;1;3:24"

my $gff = "$Tname ";
$Qname=~s/\//_/g;


if ($block == 1) {

print "$Tname\tBLAT\tgene\t$Tstart\t$Tend\t\.\t$strand\t\.\tID=$Qname\n";
print "$Tname\tBLAT\tmRNA\t$Tstart\t$Tend\t\.\t$strand\t\.\tID=$Qname.1;Parent=$Qname\n";
print "$Tname\tBLAT\tCDS\t$Tstart\t$Tend\t\.\t$strand\t\.\tID=$Qname.1:exon1;Parent=$Qname\n";
}

elsif ($block > 1) {

print "$Tname\tBLAT\tgene\t$Tstart\t$Tend\t\.\t$strand\t\.\tID=$Qname\n";
print "$Tname\tBLAT\tmRNA\t$Tstart\t$Tend\t\.\t$strand\t\.\tID=$Qname.1;Parent=$Qname\n";

# split the blast blocks
my @sizes = split(/\,/,$blockSizes);
my @starts = split(/\,/,$Tstarts);

my $index = "0";

#print "START:$index\t$block\n";

while (  $block > $index ) {
#    print "$sizes[$index]\t$starts[$index]\n";
#    print "WHILE:$index:$block:\n";
    
    
    if (  $starts[$index]=~/\d+/  and  $sizes[$index]=~/\d+/   ) {
        my $startt = $starts[$index];
        my $end =  $starts[$index] + $sizes[$index] ;

#        print "SE:$startt:$end:\n";

        print "$Tname\tBLAT\tCDS\t$startt\t$end\t\.\t$strand\t\.\tID=$Qname.1:exon:$index;Parent=$Qname.1\n";

    }
    else {
        # do nothing
    }
 $index++;
}



}



}




__END__


my $length = $match;
#print "Res20 $res[20]\n";
#print "Block $res[17]\n";
#print "Name $Qname\n";
#print "Size $Qsize\n";
my $Qhit_length = ($Qend- $Qstart);
#print "Qhit  $Qhit_length bp\n";
my $pident = 100*(($match-($mismatch+$repmatch+$Ns))/$match) ;
my $hitlength= 100*($match/$Qsize) ;  # the length of the hit on the query
#my $length = $match;



if ($Qname=~/$old_qseqid/) {
	if ($Qname=~/$Tname/ && $Tname=~/$Qname/) {
#	print "Self-match $Qname vs $Tname\n";
	}
	else {
#	print "$pident and  $length\n";
		if ($pident > 95 and $hitlength > 80) {
#	print "SIGNIFICANT: $pident and  $length\n";
			if ($old_sseqid=~/$Tname/){
				print  "Identity $pident and length $length Query $Qsize  Hitlength  $hitlength\n";
			}
			else {
				print  "$Qname vs $Tname\n";
				print  "Identity $pident and length $length Query $Qsize Hitlength $hitlength\n";
			}
		}
	}
}

=pod

else {
#start anew for each new query sequence
# filter lines where there is a new query
		if ($pident > 95 and $hitlength > 80) {
#	print "SIGNIFICANT: $pident and  $length\n";
#			if ($old_sseqid =~/$Tname/){
				print  "$Qname vs $Tname\n";
				print  "Identity $pident and length $length start $Tstart end $Tend Hitlength  $hitlength\n";
			}


# print "$Qname is not $old_qseqid\n";
# print "Identity $pident and length $length\n";
		}
=cut

$old_qseqid=$Qname;
$old_sseqid=$Tname;

}
