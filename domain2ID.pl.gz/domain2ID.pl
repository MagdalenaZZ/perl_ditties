#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

if (@ARGV < 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: domain2ID.pl pfam.results domain-list product-names

Takes a pfam domain and get all the products for that domain

'
}

my $pfam = shift;
my $doms = shift;
my $prod = shift;


        open (IN, "<$doms") || die "I can't open $doms\n";
    	my @doms= <IN>;
    	close (IN);

        open (IN2, "<$pfam") || die "I can't open $pfam\n";
    	my @pfams= <IN2>;
    	close (IN2);
       
        open (IN3, "<$prod") || die "I can't open $prod\n";
    	my @prods= <IN3>;
    	close (IN3);


my %doms;



# TAKE THE LIST OF DOMAINS AND MAKE A HASH #


foreach my $line ( @doms) {
    chomp $line;
    $line=~s/^ZZZ_//;

    $doms{$line}{"0"}=1;
}


# take the pfam-list and add genes with that domain



foreach my $lin2 (@pfams) {
chomp $lin2;
    my @arr =split (/\s+/, $lin2);
    $arr[0]=~s/\.1\.\.pep//;
    $arr[0]=~s/\.2\.\.pep//;
    $arr[0]=~s/\.\d+\.\.pep//;
    $arr[0]=~s/\.1{pep}//;
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");
    push (@arr, " ");


    if (exists $doms{$arr[6]} ) {
        $doms{ $arr[6] }{$arr[0]}=1;
#        print "$arr[0]\t$arr[6]\n";
    }
}


# take the product names and associate them with the gene
open (OUT, ">$doms.$prod") || die "I can't open $doms.$prod\n";

foreach my $lin3 (@prods) {
    chomp $lin3;
    my @arr = split(/\t/, $lin3);
    push(@arr, " ");
    $arr[0]=~s/ID=//;
#    print "LIN3:$arr[0]:\n";

    foreach my $dom ( keys %doms) {
        if (exists $doms{$dom}{$arr[0]} ) {
            print OUT "$dom\t$arr[1]\n";
        }

    }

}

system "cat $doms.$prod | sort > $doms.$prod.sort";

system "perl ~/bin/perl/product_mangler.pl $doms.$prod.sort $doms.$prod.sort.mangled";


exit;
