#!/usr/local/bin/perl -w
# mz3 script for creating a folder structure for Tim's web-view Artemis for the incubator

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

## parse infile

my $infile = shift;
my $prefix = shift;
my $bamfile = shift;
 
# my $infile = "/lustre/scratch101/sanger/mz3/EMU_Transcriptome/EMU.fas.1.3.11.headers.txt" ;

open (IN, "$infile");

my @list = <IN>;

# make a folder for each scaffold

foreach my $scaffold (@list) {
chomp $scaffold;
# my $scaffold = $_;


 # make a directory with scaffold name, unless it already exists
system ("mkdir $scaffold") unless (-d $scaffold);


## fill the folder with bam and bai files

# print "samtools view -b $bamfile $scaffold -o ./$scaffold/$scaffold.$bamfile && samtools index ./$scaffold/$scaffold.sorted.bam ./$scaffold/$scaffold.sorted.bai\n";

system ("samtools view -b $bamfile $scaffold -o ./$scaffold/$scaffold.$prefix.sorted.bam && samtools index ./$scaffold/$scaffold.$prefix.sorted.bam ./$scaffold/$scaffold.$prefix.sorted.bam.bai");

}

close (IN);


sub USAGE {

die 'Usage: bsub split_BWA.pl file prefix bamfile

bamfile: must also have an index file before start: samtools index sorted.bam sorted.bam.bai

file = tab delimited file with names of contigs or scaffolds being mapped


Ex:
pathogen_EMU_contig_2361
pathogen_EMU_contig_2362
pathogen_EMU_contig_2367
pathogen_EMU_contig_2372
pathogen_EMU_contig_2375

cat file.fasta | grep > |tr -d > > file


'
}

__END__

For contigs:

team133-bsub.pl normal 1 split.o split.e split perl ~/bin/perl/split_BWA.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/list_scaffolds_file.txt 5477_3 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/EMU_5477_3/sorted.bam

team133-bsub.pl normal 1 split.o split.e split perl ~/bin/perl/split_BWA.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/list_scaffolds_file.txt 5817_1 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/EMU_5817_1/sorted.bam

team133-bsub.pl normal 1 split.o split.e split perl ~/bin/perl/split_BWA.pl /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/list_scaffolds_file.txt 5817_2 /nfs/helminths/users/mz3/EMU/MAPPING/EMU_Chado/EMU_Chado_BWA/EMU_5817_2/sorted.bam


 team133-bsub.pl normal 10 spla.o spla.e spla perl ~/bin/perl/split_BWA.pl EMUcontigs.tab  EMU2_BWA_5477_3 /nfs/helminths/users/mz3/EMU/EMUv2/EMUv2_BWA/EMU_5477_3/sorted.bam

 team133-bsub.pl normal 10 splb.o splb.e splb perl ~/bin/perl/split_BWA.pl EMUcontigs.tab  EMU2_BWA_5817_1 /nfs/helminths/users/mz3/EMU/EMUv2/EMUv2_BWA/EMU_5817_1/sorted.bam

 team133-bsub.pl normal 10 splc.o splc.e splc perl ~/bin/perl/split_BWA.pl EMUcontigs.tab  EMU2_BWA_5817_2 /nfs/helminths/users/mz3/EMU/EMUv2/EMUv2_BWA/EMU_5817_2/sorted.bam


