#!/usr/local/bin/perl -w

use strict;


# artemis_blast2EMBL - takes a list of blast results file names
# and extracts the best blast hit (by Pvalue) for each file.  The
# best blast hit for each file is converted to an EMBL feature.
# Output is written to standard output.  

# Modified from Todd Smith's Blast2table by James D. White to 
# produce an EMBL format entry for Artemis. (Aug 12, 1999)

# Modified on May 11, 2000 to handle the new fasta sequence file headers
# from Artemis version 3.0.  Also added '-a' and '-t' flags; '-minscore'
# replaced with '-p' - JDW

# Modified on Aug 28, 2001 to add '-e' flag to write out every hit with
# P-value < 'max_P' as a separate EMBL feature, not just the top hit
# for each file - JDW
#
# Completely rewritten to use the BioPerl Bio::SearchIO module, instead
# of Todd Smith's Blast.pm - JDW (August 19, 2005).  Also changed to use
# Expect values, instead of P-values, because P-values are not always
# available.  '-p' option renamed to '-m', but '-p' is retained for
# backwards compatibility.  Added '-s' option to specify the minimum
# Blast Score value.
#
# Corrected on Aug 24, 2005 to remove a temporary debugging message
# which had not been taken out - JDW
#
# Rewritten on Aug 31, 2005 to parse each query line in a file for
# feature location, to allow multiple Artemis Blast queries per Blast
# output file - JDW
#

$::Date_Last_Modified = "August 31, 2005";

use strict;

($::my_name) = $0 =~ m"[\\/]?([^\\/]+)$";
$::my_name ||= 'artemis_blast2EMBL';

$::ALL_FILES = 0;
$::EVERY_HIT = 0;
$::MAX_EXPECT = 0.0001;
$::MIN_SCORE = 50;
$::FEATURE_TYPE = 'BLASTCDS';
$::SORT_SUB = \&byPvalDescScore;

$::USAGE = <<ENDHELP;

$::my_name - takes a list of blast results file names and
extracts the best blast hit (by Pvalue) for each query in a file.
The best blast hit is converted to an EMBL feature.  The '-a' flag
can be specified to force the creation of a dummy EMBL feature for
queries which do not have a hit meeting the requested criteria.
The  '-e' flag can be specified to write out every hit with Expect
value < 'max_expect' as a separate EMBL feature, instead of just
the top hit for each file.  The program uses the Artemis Blast
"Query=" lines or the Artemis fasta sequence file headers to find
feature locations for the EMBL feature file.  Output is written to
standard output.


usage:  $::my_name [-a] [-e] [-m 'max_expect'] [-s 'min_score']
                 [-t 'feature_type'] [-v]
                            blast_file1 [blast_file2...]
          or
        $::my_name -h    <-- what you are reading

where 'blast_file1', 'blast_file2', ... are the names of Blast results
         files to be processed.

      'max_expect' is the maximum Blast Expect value for which
         information about the best blast hit is returned.  The default
         value for 'max_expect' is $::MAX_EXPECT.

      'min_score' is the minimum Blast Score value for which
         information about the best blast hit is returned.  The default
         value for 'min_score' is $::MIN_SCORE.

      'feature_type' is the name of the feature_type to be created.
         The default is: '$::FEATURE_TYPE'.

OPTIONS:

  -a  Create an EMBL feature for ALL input queries processed.  If no
      Blast hits were found, then a feature is created as '***no hits***'.
      If the Blast Expect value is greater than 'max_expect', then the
      feature is created as '***no significant hits***'.  If '-a' is not
      specified, then EMBL features are created only for those queries
      having a best hit Expect value less than or equal to 'max_expect'.

  -e  Output a feature for every hit with Expect value < 'max_expect' as
      a separate EMBL feature, not just the top hit for each query.

  -m  Specifies the maximum Expect value.  See 'max_expect' above.  This
      option may also be specified as '-p max_expect' for backwards
      compatibility.

  -s  Specifies the minimum Score value.  See 'min_score' above.

  -t  Specifies the feature type to be created.  See 'feature_type'
      above.

  -v  Verbose mode -- write out some statistics and progress messages
      to STDERR.


LAST_MODIFIED: $::Date_Last_Modified

ENDHELP

use Bio::SearchIO;
use Bio::Search::Result::GenericResult;
use Getopt::Std;

die $::USAGE unless( getopts('aehm:p:s:t:v') );
if (defined $::opt_h && $::opt_h)
  {
  print STDOUT $::USAGE;
  exit 1;
  }

$::ALL_FILES    = $::opt_a if defined $::opt_a;
$::EVERY_HIT    = $::opt_e if defined $::opt_e;
$::MAX_EXPECT   = $::opt_p if defined $::opt_p;
$::MAX_EXPECT   = $::opt_m if defined $::opt_m;
$::MIN_SCORE    = $::opt_s if defined $::opt_s;
$::FEATURE_TYPE = $::opt_t if defined $::opt_t;
$::VERBOSE      = $::opt_v if defined $::opt_v;

die "Missing filename(s)\n$::USAGE" unless @ARGV;

$::total_hsps = $::dummy_hsps = $::total_hits = $::total_queries =
    $::total_files = $::total_features_output = 0;

my ($file, $searchin, $query);
# create the blast object and get the parsed list
foreach $file (@ARGV)
    {
    $::total_files++;

    print STDERR "\nParsing blast input file: $file\n" if $::VERBOSE;
    $searchin = new Bio::SearchIO( -format => 'blast', -file => $file );
    unless ($searchin)
      {
      print STDERR "Call to new Bio::SearchIO failed for file: '$file'\n";
      process_blast(undef, $file) if $::ALL_FILES;
      next;
      }
    my $no_query = 1;
    while ( $query = $searchin->next_result() ) # next query within output file
      {
      # $query is a Bio::Search::Result::ResultI object
      process_blast($query, $file);
      $no_query = 0;
      }
    process_blast(undef, $file) if $::ALL_FILES && $no_query;
    $searchin = $query = undef;
    } # end foreach $file (@ARGV)

if ($::VERBOSE)
  {
  print STDERR "\n$::total_files files containing $::total_queries queries were found with $::total_hsps HSPs for $::total_hits hits\n";
  print STDERR "$::dummy_hsps additional dummy HSPs were created for non-matching queries\n"
    if ($::dummy_hsps);
  print STDERR "\n$::total_features_output EMBL features were written\n";
  }


###########################################################################
# process blast object from query
###########################################################################

sub process_blast
    {
    #  $bl is a Bio::Search::Result::ResultI object or undef
    my ($bl, $file) = @_;
    my ($program, $seq1name, $seq1description, $seq1len, $seq2name, $seq2len,
        $base_type, $acc, $description, $score, $evalue, $identity,
        $similarity, $hsps, $hits, $fake_hsp, $good_msg) = ();
    my ($seqfile, $id, @rest, $entry, $loc, $dir, $orf_start, $orf_end,
        $feature_location, $fasta_line, $fasta_line2, $gene) = ();
    my $good_query = 0;
    my (@temp_hsp_list, @sorted_hsps) = ();
    $hsps = $hits = $fake_hsp = 0;
    $::total_queries++;
    $base_type = '';
    if (defined $bl)
      {
      my $hit;
      $program  = $bl->algorithm();	# BLASTN, BLASTP, ...
      $program = "\L$program";
      $program = 'blast' unless (defined $program && $program ne '');
      $base_type = $program eq 'blastp' ? 'aa' :
                   $program eq 'blastn' ? 'nt' :
                   $program eq 'tblastn' ? 'nt' : '';
#      my $DB       = $bl->database_name();
      # Short or long query name?  query_accession is first word of query_name
      $seq1name = $bl->query_name();
      $seq1description = $bl->query_description();
      $seq1len  = $bl->query_length();

      # get location of feature from query line
      ($feature_location, $id, $gene) = parse_query("$seq1name $seq1description");

      while (defined($hit = $bl->next_hit()))
        {
        # $hit is a Bio::Search::Hit::HitI object
       	# max num of hits/query before sorting and limiting
        last if (scalar @temp_hsp_list) && ! $::EVERY_HIT;
        $hits++;

        $seq2name    = $hit->name();
        $seq2len     = $hit->length();
        $acc         = $hit->accession();
        $description = $hit->description() || $acc;
        $score  = $hit->raw_score();
#        my $bits   = $hit->bits();	# There is no bits() for a Hit
        $evalue = $hit->significance();
        $evalue =~ s/^([eE][-+]?\d+)$/1$1/;		# 'E-123' => '1E-123'
#        $evalue =~ s{(\d+)\.[5-9]\d*([eE])}
#                    {sprintf"%d$3", $2 + 1}e;	# '6.78e-90' => '7e-90'
#        $evalue =~ s/\.\d*([eE])/$1/e;		# '1.23E-45' => '1E-45'

#        next if ($evalue > $::MAX_EXPECT || $score < $::MIN_SCORE);
#       don't check score here, because HSP scores can be better than
#         hit scores?
        next if ($evalue > $::MAX_EXPECT);

        my $hsp;
        while (defined($hsp = $hit->next_hsp()))
            {
            # $hsp is a Bio::Search::HSP::HSPI object
	    $hsps++;
            $score  = $hsp->score();
#            my $bits   = $hsp->bits();
            $evalue = $hsp->evalue();
            $evalue =~ s/^([eE][-+]?\d+)$/1$1/;	# 'E-123' => '1E-123'
#            $evalue =~ s{(\d+)\.[5-9]\d*([eE])}
#                        {sprintf"%d$3", $2 + 1}e;	# '6.78e-90' => '7e-90'
#            $evalue =~ s/\.\d*([eE])/$1/e;		# '1.23E-45' => '1E-45'
            # filter out poor hsps
            next if ($score < $::MIN_SCORE || $evalue > $::MAX_EXPECT);

#            my $query_object = $hsp->query(); # a Bio::SeqFeature::Similarity object,
#            my $hit_object = $hsp->hit();     # is also a Bio::SeqFeature::Generic obj
#            my $seq1beg = $query_object->start();
#            my $seq1end = $query_object->end();
#            my $qstrand = $query_object->strand();
#            my $qframe  = $query_object->frame();
#            my $seq2beg = $hit_object->start();
#            my $seq2end = $hit_object->end();
#            my $strand  = $hit_object->strand();
#            my $frame   = $hit_object->frame();
#            $query_object = $hit_object = undef;

            $identity   = sprintf "%.0f", $hsp->frac_identical * 100;
            $similarity = sprintf "%.0f", $hsp->frac_conserved * 100;
            push @temp_hsp_list,
                [$evalue, $score, $identity, $similarity,
                 $seq1len, $seq2len, $base_type, $seq2name,
                 $description, $feature_location, $gene, $file, $program];
            last unless $::EVERY_HIT;	# skip remaining HSPs
            } # end while (defined($hsp = ... ))
        last if (scalar @temp_hsp_list) && ! $::EVERY_HIT;
        } # end while (defined($hit =  ... ))
      }
    else # (! defined $bl)
      {
      $seq1len = 0;
      $program = 'blast';
      $seqfile = $file;
      if (!open(SEQ, $file))
        {
        print STDERR "Cannot open blast output file '$file'.\n  $!. Skipping this file.\n";
        return;
        }
      $fasta_line = '';
      while (defined $fasta_line && $fasta_line !~ /^Query=\s+/)
        {
        $fasta_line = <SEQ>;
        chomp($fasta_line) if defined $fasta_line;
        }
      if (defined $fasta_line && $fasta_line =~ /^Query=\s+/)
        {
        $fasta_line2 = <SEQ>;
        chomp($fasta_line2) if defined $fasta_line2;
        while (defined $fasta_line2 && $fasta_line2 !~ /^\s+\(\d+\s+letters\)\s*$/)
         {
          $fasta_line .= ' ' . $fasta_line2;
          $fasta_line2 = <SEQ>;
          chomp($fasta_line2) if defined $fasta_line2;
          }
        }
      close SEQ;
      if (defined $fasta_line && $fasta_line =~ s/^Query=\s+//)
        {
        $good_query = 1;
        }
      else
        {
        if ($seqfile !~ s/\.[^\.]+$//)
          {
          print STDERR "Cannot find sequence file for '$file'.\n  Skipping this file.\n";
          return;
          }
        if (!open(SEQ, $seqfile))
          {
          print STDERR "Cannot open sequence file '$seqfile'.\n  $!. Skipping this file.\n";
          return;
          }
        chomp($fasta_line = <SEQ>);
        close SEQ;
        $good_query = 1 if (defined $fasta_line && $fasta_line =~ s/^>//);
        }

      if ($good_query)
        {
        # get location of feature from query line
        ($feature_location, $id, $gene) = parse_query($fasta_line);
        }
      else # (! $good_query)
        {
        print STDERR "Invalid artemis blast file '$file'.\n  Skipping this file.\n";
        return;
        } # end if ($good_query)
      } # endif (defined $bl)

    if ($::ALL_FILES && ! @temp_hsp_list)
      {
      # if $::ALL_FILES and we found no HSPs, fake up a dummy, very
      # bad, HSP to record the fact that $seq1name was searched for in
      # the database, but no match was found.
      $seq2name    = '-No-Hit-';
      $description = $hits ? '***no significant hits***' :
                     $bl ? '***no hits***' :
                     '***invalid Blast output file***';
#     push @temp_hsp_list,
#                [$evalue, $score, $identity, $similarity,
#                 $seq1len, $seq2len, $base_type, $seq2name,
#                 $description, $feature_location, $gene, $file, $program];
      push @temp_hsp_list,
                 [99, 0, 0, 0,
                  $seq1len, 0, $base_type, $seq2name,
                  $description, $feature_location, $gene, $file, $program];
      $fake_hsp = 1;
      }
    $bl = undef;
    if ($::SORT_SUB)
      {
      @sorted_hsps = sort $::SORT_SUB @temp_hsp_list;
      }
    else
      {
      @sorted_hsps = @temp_hsp_list;
      }
    @temp_hsp_list = ();

    # print the table
    output_HSP($_) foreach (@sorted_hsps);
   
    $::total_hits += $hits;
    $::total_hsps += $hsps;
    if ($fake_hsp)
      {
      $good_msg = '1 fake HSP was created for';
      $::dummy_hsps++;
      }
    else
      {
      $good_msg = sprintf "%d good HSPs were found of", scalar @sorted_hsps;
      }
    print STDERR "  For query=$seq1name, $good_msg $hsps HSPs in $hits hits\n"
      if ($::VERBOSE);
    } # end process_blast


###########################################################################
# parse_query($query_line) - Parse the query line for the feature
#   location, id, and gene.  Returns ($feature_location, $id, $gene) or
#   ('', '', '') if the query line cannot be parsed for feature location.
###########################################################################

sub parse_query
    {
    my ($query_line) = @_;
    my ($id, @rest, $gene, $loc, $dir, $orf_start, $orf_end,
        $feature_location) = ();
    # get location of feature from query line
    ($id, @rest) = split(' ', $query_line);
    if ($id =~ /;([^,]+),$/)
      {
      $gene = $1;
      }
    else
      {
      $gene = '';
      }
    while (defined $rest[0] && $rest[0] !~ /^\d+:\d+$/)
      {
      shift @rest;
      }
    ($loc, $dir) = @rest;
    if (! defined $dir || $dir !~ /^forward|reverse$/)
      {
      print STDERR "Invalid query in artemis blast file '$file'.\n";
      print STDERR "  Skipping this query='$query_line'\n";
      return ('', '', '');
      }
    ($orf_start, $orf_end) = split(':', $loc);
    if ($dir eq 'reverse')  	# if the sequence is complemented
        {
        $feature_location = "complement(${orf_start}..${orf_end})";
        }
      else # ($dir eq 'forward')  	# if the sequence is forward
        {
        $feature_location = "${orf_start}..$orf_end";
        }
    return ($feature_location, $id, $gene);
    } # end parse_query


#######################################################################
# output_HSP - write out an EMBL feature from the blast information
# gathered from one HSP.
#######################################################################

sub output_HSP
  {
  my($hsp) = @_;
  my($expect, $score, $identity, $similarity,
     $seq1len, $seq2len, $base_type, $seq2name,
     $description, $feature_location, $gene, $file, $program) = @{ $hsp };
  my $feature_pad = ' ' x (15 - length($::FEATURE_TYPE));

  print STDOUT "FT   $::FEATURE_TYPE$feature_pad $feature_location\n";

  printf STDOUT "FT                   /note=\"%5.0e %4.0f %1.0f%%/%1.0f%% %d/%d%s %s %s\"\n",
    $expect, $score, $identity, $similarity,
    $seq1len, $seq2len, $base_type, $seq2name, $description;

  print STDOUT "FT                   /gene=\"$gene\"\n"
    if (defined $gene && $gene ne '' && $gene ne 'none');

  print STDOUT "FT                   /${program}_file=\"$file\"\n";

  $::total_features_output++;
  } # end output_HSP


#######################################################################
# byPvalDescScore - Sort by pval, then descending score
#######################################################################

sub byPvalDescScore
  {
  my($ap, $bp, $as, $bs);
  ($ap, $as) = @{ $a };
  ($bp, $bs) = @{ $b };
  return ($ap <=> $bp) || ($bs <=> $as);
  } # end byPvalDescScore


#######################################################################
# byDescScorePval - Sort by descending score, then pval
#######################################################################

sub byDescScorePval
  {
  my($ap, $bp, $as, $bs);
  ($ap, $as) = @{ $a };
  ($bp, $bs) = @{ $b };
  return ($ap <=> $bp) || ($bs <=> $as);
  } # end byDescScorePval
