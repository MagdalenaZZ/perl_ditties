#!/usr/bin/perl -w



use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff2embl.pl input.merops output.fas 

# mz3 script for changing merops fasta to regular fasta


'
}


my $in = shift;
my $out= $in . "\.fas";

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";


my @seq='';

foreach my $line (@in) {
    chomp $line;

    if ($line =~/^>/) {

        # print last seq
       my $seq = join("", @seq);
       if ($seq =~m/\w/) {
            print OUT "$seq\n";
        }
        @seq='';
#      print "Header:$line\n";
    my @arr = split (/\(/, $line);
       print OUT "$arr[0]Emultilocularis\n";
    }
    elsif ($line =~/^\d+/) {
        #        print "Seq:$line\n";
         my @arr = split (/\s+/, $line);
#         print "Seq:$arr[1]\n";
         push (@seq, $arr[1] );

    }
    else {
        #  print "Crap:$line\n";
    }

}


#print last sequence

       my $seq = join("", @seq);
        print OUT "$seq\n";


	close (OUT);


