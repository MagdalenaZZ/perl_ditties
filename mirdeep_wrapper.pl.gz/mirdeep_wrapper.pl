#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==6) {
        &USAGE;
}


sub USAGE {

die 'Usage: mirdeep_wrapper.pl reference_genome.fa mature_ref_this_species.fa mature_ref_other_species.fa precursors_ref_this_species.fa reads.fa species

Takes various inputs and runs mirdeep

# make sure the fasta is single-line


Preliminary files:



cel_cluster.fa:                     a fasta file with the reference genome (this file is in fact a ~6 kb region of the C. elegans chromosome II).
mature_ref_this_species.fa:         a fasta file with the reference miRBase mature miRNAs for the species (C. elegans miRBase v.14 mature miRNAs)
mature_ref_other_species.fa:        a fasta file with the reference miRBase mature miRNAs for related species (C. briggsae and D. melanogaster miRBase v.14 mature miRNAs)
precursors_ref_this_species.fa:     a fasta file with the reference miRBase precursor miRNAs for the species (C. elegans miRBase v.14 precursor miRNAs)
reads.fa:                           a fasta file with the deep sequencing reads.



Reference genome - no spaces in headers

Files with mature mRNAs and precursors you can make from miRBase. Download and parse out your favourite species
Make sure ther are no spaces in headers

Reads.fa - your trimmed reads

species - the name fo your species, i.e. C.elegans or E.multilocularis

NOT FINISHED!!!!



'
}


my $in = shift;
my $m_this_sp = shift;
my $m_oth_sp = shift;
my $pre_this_sp = shift;
my $reads = shift;
my $species = shift;


#Step 1: build an index of the genome (in this case the ~6 kb region):

system "ln -s $in ref.fa";
system "bowtie-build $in ref";


#Step 2: process reads and map them to the genome.

#The -c option designates that the input file is a fasta file (for other input formats, see the README file). The -j options removes entries with
#non-canonical letters (letters other than a,c,g,t,u,n,A,C,G,T,U,N). The -k option clips adapters. The -l option discards reads shorter than 18 nts.
#The -m option collapses the reads. The -p option maps the processed reads against the previously indexed genome (cel_cluster). The -s option
#designates the name of the output file of processed reads and the -t option designates the name of the output file of the genome mappings. Last,
#-v gives verbose output to the screen.
#mapper.pl reads.fa -c -j -k TCGTATGCCGTCTTCTGCTTGT  -l 18 -m -p cel_cluster -s reads_collapsed.fa -t reads_collapsed_vs_genome.arf -v

system "ln -s $reads reads.fa";
system "~mz3/bin/mirdeep2/mapper.pl reads.fa  -c -l 17  -p ref -s -q -r 5 -s reads_collapsed.fa -t reads_collapsed_vs_genome.arf -v";






#Step 3:

#fast quantitation of reads mapping to known miRBase precursors.
#(This step is not required for identification of known and novel miRNAs in the deep sequencing data when using miRDeep2.pl.)
#quantifier.pl -p precursors_ref_this_species.fa -m mature_ref_this_species.fa -r reads_collapsed.fa -t cel -y 16_19

#The miRNA_expressed.csv gives the read counts of the reference miRNAs in the data in tabular format. The results can also be browsed by opening
#expression_16_19.html with an internet browser.

system "~/bin/mirdeep2/quantifier.pl -p  precursors_ref_this_species.fa  -m Echinococcus.mature.fa -r reads_collapsed.fa ";



#Step 4: identification of known and novel miRNAs in the deep sequencing data:
#--More--Searched 2700 bases in 45 sequences
#~/bin/mirdeep2/miRDeep2.pl reads_collapsed.fa cel_cluster.fa reads_collapsed_vs_genome.arf mature_ref_this_species.fa mature_ref_other_species.fa precursors_ref_this_species.fa -t C.elegans 2>
# report.log


system "~mz3/bin/mirdeep2/miRDeep2.pl reads_collapsed.fa ref.fa reads_collapsed_vs_genome.arf Echinococcus.mature.fa mature_ref_other_species.fa precursors_ref_this_species.fa -t $species 2>  report.log";





__END__



my $in = shift;
open (IN, "<$in") || die "I can't open $in\n";
close (IN);


howto_mirDeep2




Preliminary files:



cel_cluster.fa:                     a fasta file with the reference genome (this file is in fact a ~6 kb region of the C. elegans chromosome II).
mature_ref_this_species.fa:         a fasta file with the reference miRBase mature miRNAs for the species (C. elegans miRBase v.14 mature miRNAs)
mature_ref_other_species.fa:        a fasta file with the reference miRBase mature miRNAs for related species (C. briggsae and D. melanogaster miRBase v.14 mature miRNAs)
precursors_ref_this_species.fa:     a fasta file with the reference miRBase precursor miRNAs for the species (C. elegans miRBase v.14 precursor miRNAs)
reads.fa:                           a fasta file with the deep sequencing reads.




















