#!/usr/local/bin/perl -w
# mz3 script for making scaffolds from an agp-file and contigs

# use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: agp_explore_overlaps.pl <final.stats> <file.agp> 

one sequence per line for the fasta-files

'
}


open (IN, "<$ARGV[0]");
my @input = <IN>;
chomp @input;

# print @input;

### How to pull out scaffolds which are not merged?


# Get names of scaffolds

my @scaffolds; 
my @sspace_scaf; 

foreach my $line (@input) {

my @array = split (/([ _])/,  $line );

	if ($array[2] =~ m/\./) {
		 print "$array[2]_$array[4]\t$array[14]_$array[16]", "\n";
		push (@sspace_scaf, "$array[2]_$array[4]\t$array[14]_$array[16]");
		# do nothing
	}

	elsif ($array[2] =~ m/s/)  {
# get names of all merged contigs that belong to each scaffold
#		 print "$array[2]\t$array[12]_$array[14]", "\n";
		push (@scaffolds, "$array[2]\t$array[12]_$array[14]");
	}

}

# make a hash of sspace scaffold values
my %second;
foreach my $elem (@sspace_scaf) {
my @array = split(/\t/,$elem);
$second{$array[1]}=$array[0];
}

$test = $second{'merged_contig1906'};
print "Test res: $test \n";  <STDIN>;

# make a hash of hashes key 1 = scaffold, key 2 = merged_contig
my %hash; 
foreach my $elem (@scaffolds) {
my @array = split(/\t/,$elem);
# print "$array[0]\t$array[1]","\n";
$hash{$array[0]}{$array[1]}=$array[1];
# $hash{$array[0]}=$array[1];
}

# foreach my $k (sort keys %hash) { print "$k => $hash{$k}\n"; }
# foreach my $k (sort keys %sspace_scaf) { print "$k => $sspace_scaf{$k}\n"; }
# foreach my $k (sort keys %hash{$h}) { print "$k => $hash{$h}{$k}\n"; }



foreach my $key1 (keys %hash) {
    print "key1 $key1"; <STDIN>;
    foreach my $key2 (keys %{$hash{$key1}}) {
        print "key2 $key2"; <STDIN>;
        if ($second{$key2}) {
            print "EXIST and the value is $second{$key2}!!!"; <STDIN>;
            my $valofsecond = $second{$key2};
            $hash{$key1}{$key2} = $valofsecond;
            print "my new value is $hash{$key1}{$key2}"; <STDIN>;
        } else {
            print "the key $key2 does not exist in second hash"; <STDIN>
        }
    }
}


test

merged_contig1906

__END__



foreach my $key (%hash) {

	foreach my $key2 (%{$hash{$key}}) {
		if ($key2 {$sspace_scaf{$key2}) {
		$hash{$key}{$key2}=$sspace_scaf{$key2};
		}
	}

}






__END__


foreach my $key1 (keys %first) {
    print "key1 $key1"; <STDIN>;
    foreach my $key2 (keys %{$first{$key1}}) {
        print "key2 $key2"; <STDIN>;
        if ($second{$key2}) {
            print "EXIST and the value is $second{$key2}!!!"; <STDIN>;
            my $valofsecond = $second{$key2};
            $first{$key1}{$key2} = $valofsecond;
            print "my new value is $first{$key1}{$key2}"; <STDIN>;
        } else {
            print "the key $key2 does not exist in second hash"; <STDIN>
        }
    }
}


 my @temp = %hash;

foreach my $line (@temp) {
print "$line\n";
}


__END__

foreach my $key (%hash) {
print $hash{$key} , "\n";
}






__END__



foreach my $key (%hash) {

	foreach my $key2 (%{$hash{$key}}) {
		if ($key2 {$sspace_scaf{$key2}) {
		$hash{$key}{$key2}=$sspace_scaf{$key2};
		}
	}

}

# __END__


foreach my $key (%hash) {

print $hash{$key} , "\n";

}






__END__

# @array = ('Apple', 'Orange', 'Apple', 'Banana');
# my %hashTemp = map { $_ => 1 } (@scaffolds);
my %hashTemp = map { $_ => 1 } (@scaffolds= split(/\t/,$_ ));
my @array_out = sort keys %hashTemp;
# @array_out contains ('Apple', 'Banana', 'Orange')
print @array_out;

# get names of all merged contigs that belong to each scaffold

__END__

foreach my $line (@input) {

my @array = split (/([ _])/,  $line );

	if () {
#
	}

}



# get all members of the merged contigs


# if the scaffold contains several SSPACE-contigs we are missing a mergning link



# find that merging link


# insert it