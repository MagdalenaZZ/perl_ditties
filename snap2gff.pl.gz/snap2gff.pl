#!/usr/bin/perl -w
# mz3 script for changing SNAP into gff

use strict;


# get rid of all the lines that starts with #




my %genes;
my %cds;
my $flag = 0;



while (<>) {

	my @line = split (/\s+/, $_);


	my $method = $line[1];
	my $name = $line[0];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $trans = $line[7];
	my $note = $line[8];
	($start, $end) = sort {$a <=> $b} ($start, $end);




	if ($strand eq "-") {
		if ($tag eq "Einit") {
			push (@{$genes{"$note $strand $name"}}, $start); 
		} 
		elsif  ($tag eq "Eterm") {
			unshift (@{$genes{"$note $strand $name"}}, $end);
		}
	} else {
		if ($tag eq "Einit") {
			push (@{$genes{"$note $strand $name"}}, $start); 
		} 
		elsif  ($tag eq "Eterm") {
			push (@{$genes{"$note $strand $name"}}, $end);
		}
	}
	my $newline = "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.";
	push (@{$cds{$note}}, $newline);
}



foreach my $gene (sort {(split /\./, (split /\s+/, $a)[0])[1] <=> (split /\./, (split /\s+/, $b)[0])[1]} keys %genes) {
	my $name = (split /\s+/, $gene)[2];
	my $strand = (split /\s+/, $gene)[1];
	my $tag = (split /\s+/, $gene)[0];
	my $range = join("\t", @{$genes{$gene}});
	print "$name\tSNAP\tgene\t$range\t.\t$strand\t.\tID=$tag;\n"; #<STDIN>;
	print "$name\tSNAP\tmRNA\t$range\t.\t$strand\t.\tID=$tag.1;Parent=$tag;\n"; #<STDIN>;
	my $conta = 1;
	if ($strand eq "-") {
		$conta = scalar @{$cds{$tag}};
	}
	foreach my $cd (@{$cds{$tag}}) {
		if ($strand eq "-") {
			print "$cd\tID=$tag.1:exon:$conta;Parent=$tag.1;\n"; #<STDIN>;	
			$conta--;
		} else {
			print "$cd\tID=$tag.1:exon:$conta;Parent=$tag.1;\n"; #<STDIN>;
			$conta++;
		}
	}
}
