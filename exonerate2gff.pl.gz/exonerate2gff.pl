#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/exonerate2gff.pl exonerate.out 

';

}


my $in = shift;
my $out = "$in.gff";

 open (IN, "<$in") or die 'Cant find infile  ';

 open (OUT, ">$out") or die 'Cant find outfile $out ';


 my @in = <IN>;

my $gene = "1";
my $exon = "1";
my %genes;
my $ind = "A";
my @exons = '';
my %cig;

my $a;
my $que  = "0";
my $gene2;

my $command = shift @in;

 foreach my $line (@in) {
    chomp $line;
    if ($line=~/Command/) {
    }
    elsif ($line=~/cigar/){
        unless (exists $cig{$line}) {
            $cig{$line}=1;
        }
    }
    elsif ($line=~/Query:/) {
#        print "Query: $line\n";
        $que = $line;
        $que =~s/Query: //;
        $que =~s/\s+//g;

    }
    elsif ($line=~/exonerate/ and $line!~/^#/) {
#        print "$line\n";
        
        my @arr = split(/\s+/, $line);

#        print "$arr[2]\n";
        $arr[1]=~s/exonerate:est2genome/exonerate/;
        
        if ($line =~/analysis/) {
            # do nothing
        }
        elsif ($arr[2]=~/gene/) {

            my @sorted = sort { $exons[0] cmp $exons[1] } @exons;
            shift @sorted;
            foreach my $lin (@sorted) {
                print OUT "$lin\n";
            }
            @exons='';

            print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr[12]:$ind;Query=$que\n";
            print OUT "$arr[0]\t$arr[1]\tmRNA\t$arr[3]\t$arr[4]\t.\t$arr[6]\t$arr[7]\tID=$arr[12]:$ind.1;Parent=$arr[12]:$ind\n";
            $gene = "$arr[12]:$ind.1";
            $genes{"$arr[12]:$ind"}= 1;
            $ind++;
            $exon=1;
            $gene2= 1;
            
        }
        elsif  ($arr[2]=~/exon/) {
#            print "$arr[0]\t$arr[1]\tCDS\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$gene.exon:$exon;Parent=$gene.1\n";
           push ( @exons ,"$arr[0]\t$arr[1]\tCDS\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$gene:exon:$exon;Parent=$gene");
           $exon++;

        }
        elsif ($arr[2]=~/utr/) {

        }
        elsif ($arr[2]=~/similarity/ and $gene2 = 0) {
            #print "$line\n";
            print OUT "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\tID=$arr[12]:$ind;Query=$que\n";
        }


        else {
            # ignore
        }


    }

 }

 
 # Empty last seq
            my @sorted = sort { $exons[0] cmp $exons[1] } @exons;
            shift @sorted;
            foreach my $lin (@sorted) {
                print OUT "$lin\n";
            }


close (OUT);



__END__

# make reference and query right

# print "$command\n";

#my $string =~ /Total Successful Transactions = (\d+)/;
#print $command =~ /-q (\w+)/;
#my $string3 =~ /-t (\w+)/;

my $que = 0;
my $refs = 0;


if ($command =~/\-q(\X+\-)/) {
    $que = $1;
    $que =~s/ $//g;
    $que =~s/-$//g;
    $que =~s/ $//g;

}

else {
    print "Cant read query\n";
}

if ($command =~/\-t(\X+\])/) {
    $refs = $1;
    $refs =~s/ $//g;
    $refs =~s/]$//g;
    $refs =~s/ $//g;
}

else {
    print "Cant read reference\n";
}

print "\n\nQUERY FILE $que\nREFERENCE FILE $refs\n\n";

system "samtools faidx $que";
system "samtools faidx $refs";


open (FAS, "<$que.fai") || die "I can't open $que.fai\n";
my %ques;

while (<FAS>) {
    my @arr = split(/\s+/, $_);
    $ques{$arr[0]} = $arr[1];
    #print "$arr[0]\t$arr[1]\n";

}
close (FAS);

open (FAS, "<$refs.fai") || die "I can't open $refs.fai\n";
my %refs;

while (<FAS>) {
    my @arr = split(/\s+/, $_);
    $refs{$arr[0]} = $arr[1];
    #print "$arr[0]\t$arr[1]\n";

}
close (FAS);




my %match;
my %partial;

# read cigar-strings

foreach my $cigar ( sort keys %cig) {

    #my @cign = split (/\D+/, $cigar );
    #my @cigt = split (/\d+/, $cigar );
    #print "$cigar\n";
    my @arr = split (/\s+/, $cigar );
    my $query = $arr[1];
    my $qstart = $arr[2];
    my $qend = $arr[3];
    my $dot = $arr[4];
    my $ref = $arr[5];
    my $sstart = $arr[6];
    my $send = $arr[7];
    my $sdot = $arr[8];
    my $dunno = $arr[9];
    #my $m = $arr[10];
    my $lens = scalar(@arr);
    #print "$lens\n";
    my @mlen = @arr[10..$lens];

    my $m = join(" ", @mlen);

    my $mlen = 0;
    my $dlen = 0;
    my $ilen = 0;

    my $mm = 0;

    foreach my $elem (@mlen) {
        if ($elem=~/M/) { 
            #print "$elem\n";
            $mm = "M";
        }
        elsif ($elem=~/D/) { 
            #print "$elem\n";
            $mm = "D";
        }
        elsif ($elem=~/I/) { 
            #print "$elem\n";
            $mm = "I";
        }
        elsif ($elem=~/\d+/) { 
            #print "$elem\n";
            if ($mm =~/M/) {
                $mlen +=$elem;
            }
            elsif ($mm =~/D/) {
                $dlen +=$elem;
            }
            elsif ($mm =~/I/) {
                $ilen +=$elem;
            }
            else {
                print "Warning: Unaccounted for $elem\n";
            }

        }
        elsif ($elem=~/^\S+$/) { 
            print "Warning: Unaccounted for $elem\n";
        }
        else {
            #print "ELSE:$elem\n";
        }
    }
    #print "$mlen\t$dlen\t$ilen\n";


    my $qlen = 0;
    my $rlen = 0;
    my $ori = 0 ;



    if (exists $ques{$query}) {
        $qlen = $ques{$query};
    }
    if (exists $refs{$ref}) {
        $rlen = $refs{$ref};
    }
    #print "$query\t$ref\t$m\t$mlen\t$qlen\t$rlen\n";
    #print "$qlen\t$rlen\t$sstart\t$send\n";
    
    if ( ($mlen*1.1) > $qlen ) {
        $match{$query} = $ref;
        #print "WHOLE: $query\t$ref\t$m\t$mlen\t$qlen\t$rlen\t$sstart\t$send\n";  
    }
    elsif ($qlen > $mlen ) {
        # print "ORI: $sstart\t$send\n";
        # calculate the hit
        # if positive
        if ($sstart < $send) {
            #print "I'm positive\n";
            $ori = '+';
        }
        # if negative
        else {
            #print "I'm negative\n";
            $ori = '-';

            # reverse coordinates
            #my $ssstart = $sstart;
            $send = ($rlen-$send);
            $sstart = ($rlen-$sstart);
            #print "REV: $sstart\t$send\n";

        }
       
        # add margin
        $sstart -= 1000;
        $send += 1000;
        if ( 0 >= $sstart ) {
                $sstart = 1;
        }
        if ($rlen < $send) {
            $send = $rlen;
        }

            $partial{$query} = "$ref\t$sstart\t$send\t$ori";
            #print "PARTIAL: $query\t$ref\t$m\t$mlen\t$qlen\t$rlen\t$sstart\t$send\n\n";   

    }
    else {
        print "WARNING $query\t $ref\n";
    }



}

#__END__

### print complete hits

open (OUT, ">$in.match") || die "I can't open $in.match\n";


foreach my $key (keys %match) {
    print OUT "$key\n";

}

close (OUT);

system "perl ~mz3/bin/perl/fasta_retrieve_subsets.pl $que $in.match";



### print partial hits and align them

system "fasta2singleLine.py $que $que.sl";
system "fasta2singleLine.py $refs $refs.sl";


# read in sequences
open (FAS, "<$que.sl") || die "I can't open $que.sl\n";
my %que_seq;

while (<FAS>) {

    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $que_seq{$head} = $seq;
    }
    else {
        print "Warning, unparsed line $_\n";
    }

}


close (FAS);

open (FAS, "<$refs.sl") || die "I can't open $refs.sl\n";
my %ref_seq;

while (<FAS>) {

    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $ref_seq{$head} = $seq;
        #print "$head\t$seq\n";
    }
    else {
        print "Warning, unparsed line $_\n";
    }

}
close (FAS);


mkdir "$in\_alns";



foreach my $key (keys %partial) {
    #print "$key\n";
    my $key2 = $key;
    $key2=~s/\//_/g;
    open (OUT, ">$in\_alns/$key2.fas") || die "I can't open $in\_alns/$key2.fas\n";
    print OUT ">$key\n$que_seq{$key}\n";

    # retrieve sequence
    my @arr = split(/\t/, $partial{$key}  );
    my $len = $arr[2] - $arr[1];
    my $seq = substr $ref_seq { $arr[0] }, $arr[1], $len ;

    # if negative reverse complement
    if ($arr[3] =~/\-/) {
        $seq = reverse($seq);
        $seq = lc($seq);
        $seq =~s/a/T/g;
        $seq =~s/t/A/g;
        $seq =~s/c/G/g;
        $seq =~s/g/C/g;
    }
    
    print  OUT ">$partial{$key}\n$seq\n";

    #print  ("/software/pubseq/bin/mafft --quiet --anysymbol --maxiterate 10 --localpair --clustalout alns/$key.fas  > alns/$key.fas.clu");<STDIN>;
    system  "muscle -clw -in $in\_alns/$key2.fas -out $in\_alns/$key2.fas.clu\n";
}



# report the assemblies with no hit

open (OUT, ">$in.nomatch") || die "I can't open $in.nomatch\n";

foreach my $ele (keys %que_seq) {
    unless (exists $match{$ele}) {
        unless  (exists $partial{$ele}) {
            #print "FOUND NO MATCH: $ele\n";
            print OUT ">$ele\n$que_seq{$ele}\n";
        }
    }
}



close (OUT);




