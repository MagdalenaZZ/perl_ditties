#!/usr/bin/perl -w

# mz3 script for changing gff to embl

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff2embl.pl input.gff input.fasta


input.gff	Input gff-file, which can have additional features
input.fasta	Fasta with all sequences to which the gff belongs (sequence on single line, more than 2 sequences)



Please check that the fasta-file is correct (sorted, no overlapping CDSs, right orientation e.t.c.)
in every way before converting it to an embl-file!



'
}


my $gff = shift;
my $fas = shift;
my  $logfile = "$gff\.error";


open (STDERR, ">$logfile") || die "I can't open $logfile\n";

	open (IN, "<$gff") || die "I can't open $gff\n";
	my @gff = <IN>;
	close (IN);


# read in the sequences and lengths

my %lengths;
my %genes;
my %pos;
my @contam;
my $key = 0;


system "samtools faidx $fas";
	open (IN2, "<$fas.fai") || die "I can't open $fas.fai\n";
	my @fas = <IN2>;
	close (IN2);
	
foreach my $line (@fas) {
chomp $line;
# filter headers
	my @ln = split(/\t/,$line);
	my $key = $ln[0];
	my $count=$ln[1];
	$lengths{$key} = $count;
	#print "$key\t$count\n";
}

print STDERR "Finished parsing fasta-file\n";


# read in the contigs in a hash

foreach my $ele (@gff) {
	chomp $ele;
	$ele=~s/ID=//;
	my @arr= split(/\t/, $ele);

	if ( exists $lengths{$arr[0]} ) {
	    #print "$ele\n";
	
		if ($arr[2]=~/gene/) {
		  push(@{$genes{$arr[0]}}, "$ele");
		  #print "## gene $ele\n";
		}
		elsif ($arr[2]=~/mRNA/) {
		    #print "## mRNA\n";
		}	
		elsif ($arr[2]=~/exon/ || $arr[2]=~/CDS/) {
		    #print "## CDS $arr[8]\n";
		    my @elements=split(/\;/,$arr[8]);
		    my $exon="0";    
		    foreach my $el (@elements) {
 		      chomp $el;
		      #print "EL $el\n";
			if ($el=~/Parent=/) {
				$el=~s/Parent=//;
				$exon=$el;
			}
		    }
		    my @exon=split(/\./, $exon);
		    #print "### CDS $exon\t$arr[3]\t$arr[4]\n";    
		    push ( @{$pos{$exon[0]}}, "$arr[3]\.\.$arr[4]");
		}	
		else {
		  print "## Not catched\t$ele\n";
		}
	}
	else {
	  print "Gene has belongs on no scaffold: $ele\n";
	}
	
}




print "Hi\n";


foreach my $scaf ( keys  %lengths ) {
	#print "$scaf\t$lengths{$scaf}\n";

	unless ( exists $genes{$scaf}) {
	  print STDERR  "$scaf has no genes: length $lengths{$scaf}\n";
	  delete $lengths{$scaf};  
	}
	else {
		print "$scaf has genes \n";
## For each new contig open a new file
		my $out = "$scaf" . ".embl";
		open (OUT, ">$out") || die "I can't open $out\n";
		print STDERR "Started writing to file $out\n";
# print header
		print  OUT  "ID   $scaf; SV 1; linear; genomic DNA; HTG; INV; $lengths{$scaf} BP.\n";
		# ID   CD789012; SV 4; linear; genomic DNA; HTG; MAM; 1000 BP. 
# write FH lines
		print OUT  "FH   Key             Location/Qualifiers\n";
		print OUT  "FH\n";
		
		my @arr = @{$genes{$scaf}};
		
		my @ar;
		
		my @pos='';
		my $ori='';
		
		foreach my $li (@arr) {
			chomp $li;
			#print "$li\n";
		  
			# split the line
			@ar = split(/\t/,$li); 
			my @notes= split(/\;/,$ar[8]); 
			my $gene = $notes[0];
			$gene=~s/systematic_id=//;
			# first print CDS
		
			if (exists $pos{$gene}) {
# 				#print "Exists\n";

#my @sortedSkno = sort { (split ' ', $a)[1] cmp (split ' ', $b)[1] } @array;

				my @cds = sort { (split '\.\.', $a)[0]  <=> (split '\.\.', $b)[0] } @{$pos{$gene}};
				my $cds = join("\,", @cds);
				
				
				# if is reverse
				if ($ar[6]=~/\-/ and scalar(@cds) > 1) {
					print OUT "FT   CDS              complement(join($cds))\n";
				}
				# if is forward or naught
				elsif (scalar(@cds) > 1 ) {
					print OUT "FT   CDS              join($cds)\n";  
				}
				elsif ($ar[6]=~/\-/) {
					print OUT "FT   CDS              complement($cds)\n";
				}
				elsif ($ar[6]=~/\+/) {
					print OUT "FT   CDS              $cds\n";
				}
				else {
				  print "cant parse this line: $li\n";
				}
			}
			else {
			  print "Gene doesn't exist $gene";
			  next;
			}
			
			
			# now print additional info
			my $sys = shift(@notes);
			chomp $sys;
			  
			  print  OUT "FT                   /systematic_id=\"$sys\"\n";
			
			foreach my $note (@notes) {
			  chomp $note;
			  print OUT "FT                   /$note\n";
			}
		  }
		  
		print OUT "//\n";
		close(OUT);
	}
}
exit;


__END__


############################################
# Remove keys which don't have values

#foreach my $key ( keys  %lengths ) {

#	unless ($lengths{$key}[1]) {
        #print STDERR "Contig $key has no genes: length $lengths{$key}[0]\n";
        #delete $lengths{$key};	
#	}
#
#}


foreach my $scaf ( keys  %lengths ) {
	#print "$scaf\t$lengths{$scaf}\n";

	unless ( exists $genes{$scaf}) {
	  print STDERR  "$key has no genes: length $lengths{$scaf}\n";
	  delete $lengths{$scaf};  
	}
	else {
		print "$scaf has genes \n";
## For each new contig open a new file
		my $out = "$scaf" . ".embl";
		open (OUT, ">$out") || die "I can't open $out\n";
		print STDERR "Started writing to file $out\n";
# print header
		print  OUT  "ID   $scaf; SV 1; linear; genomic DNA; HTG; INV; $lengths{$scaf} BP.\n";
		# ID   CD789012; SV 4; linear; genomic DNA; HTG; MAM; 1000 BP. 
# write FH lines
		print OUT  "FH   Key             Location/Qualifiers\n";
		print OUT  "FH\n";
		
		my @arr = @{$genes{$scaf}};
		
		my @ar;
		
		my @pos='';
		my $ori='';
		
		foreach my $li (@arr) {
			chomp $li;
			print "$li\n";
		  
			# split the line
			@ar = split(/\t/,$li);  
		  }
		  
=pod	
		
		#my @arr = split(/\t/,$genes{$scaf});
		
		# if is gene
		if ($ar[2]=~/gene/) {
		 #print "gene $li\n";
		}
		elsif ($ar[2]=~/exon/ || $ar[2]=~/CDS/) {
		}
		elsif ($ar[2]=~/mRNA/ ) {
		}
		else {
		  print "Dont know what line is (only accept CDS,exon,mRNA and gene): $li\n";
		}
		
		
		# now print the result if finished
		
		}
		
	
=cut
	
	
	
	}

}






