#!/usr/local/bin/perl -w

# mz3 script for taking tophat output accepted_hits.sam and turning it into cufflinks-ready file


use strict;

unless (@ARGV == 1) {
        &USAGE;
}

my $ref = shift;

print "Reference sequence: $ref \n";

# test if a .fai already exists
if (-e "$ref.fai") {
print "$ref.fai", "\n";
print "if \n";
#print CMD "$step1 && $step3 && $step4 && $step5 \n";
}
else {
print "$ref.fai", "\n";
print "else \n";
#print CMD "$step1 && $step2 && $step3 && $step4 && $step5 \n";
}

sub USAGE {

die 'Usage: tophat2cufflinks.pl <reference-genome.fas>

Put files or softlinks to all .sam files you want to include in the working directory. The prefix given to them will be whatever is before the first  .  (dot)

The out-file is called aln-sorted.bam and this is the input for cufflinks

Do not bsub - it bsubs itself 



'
}
__END__
