#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: boxplot_in_R.pl  file(s)

i.e.
boxplot_in_R.pl   *.numbers.txt


This program takes one or several files with a column with numbers and draws boxplots from it.
Using perl module, not R





    ' . "\n";
}


my @files = @ARGV;

open (R, ">$files[0].boxplot.R") || die "I can't open $files[0].boxplot.R\n";
#open (OUT, ">$files[0].out") || die "I can't open $files[0].out\n";


my $i = "1";


# make the file to print to

#print R "file = \"$files[0]\.histo\.pdf\"";
print R "pdf(\"$files[0]\.boxplot\.pdf\", useDingbats=FALSE)\n";

print R '
ylab = "Y-values"
mfrow = c(1,1)
dcol = 1
lcol = 1

par(mar=c(5.1,4.1,30,2.1)

';

my $a = scalar(@files);

#print R " col<-rgb(runif($a),runif($a),runif($a))\ncol \n";

# read in data

my @vectors ;


foreach my $file (@files) {

        # read in table
        print R " x$i<-read.table(\"$file\",header=F) \n";
        print R " x$i <- unlist(x$i)  \n";
        print R " length(x$i)\n";
        print R " x$i <-  x$i\[  x$i > 0  \] \n";
        print R " length(x$i)\n";
        push (@vectors, "x$i");
        
        if ($i=~/^1$/) {
            #print R "plot(d$i, col=col[$i], main=\"Frequency density plot of $files[0]\", axes = T)  \n";
            #print R "axis(side = 1, at = c(1:50)) \n";
            #print R "axis(side = 2, las = 1) \n";
        }
        # y and y max automatically calculated by R
        else {
            #print R "lines(d$i, col=col[$i])  \n";
        }
        
        $i++;
}


my $vec = join(",", @vectors);
my $fil =  join("\"\,\"", @files);
$fil = "\"" . $fil . "\""; 

#print "$vec \t $fil\n";
my $legend = join("\",\"", @files);
$legend = '"' . $legend . '"';

foreach my $el2 (@vectors) {

    foreach my $el (@vectors) {
        print R "t.test($el2,$el)\n";
    }
}

#print "$legend\n";
print R "boxplot( $vec , log=\"y\", names=c($fil), las=2 )\n";
#print R "abline(h=0.001, col=\"red\") \n";
print R "abline(h=1, col=\"red\") \n";

#print R " legend(\"topright\", inset=.05, title=\"Legend\",   c($legend), fill=col)\n";
print R "dev.off()\n";
	

system "R CMD BATCH $files[0].boxplot.R";
####

__END__
 x<-read.table("test2.hist",header=F)
 y<-read.table("test3.hist",header=F)
 coly<-y[,1]
 colx<-x[,1]
 dx <-density(colx)
 dy <-density(coly)
 plot(dx)
 lines(dy)



 In plot.window(xlim = xlim, ylim = ylim, log = log, yaxs = pars$yaxs) :
  nonfinite axis limits [GScale(-inf,2.51848,2, .); log=1]
>
> boxplot( c(x1,x2), log="y")
Warning message:
In plot.window(xlim = xlim, ylim = ylim, log = log, yaxs = pars$yaxs) :
  nonfinite axis limits [GScale(-inf,2.51848,2, .); log=1]
> boxplot( c(x1,x2) )
> boxplot( c(x1,x2), names=c("aPS.ratio","naPS.ratio") )
>
>



boxplot( c(x1,x2), log="y")
Warning message:
In plot.window(xlim = xlim, ylim = ylim, log = log, yaxs = pars$yaxs) :
  nonfinite axis limits [GScale(-inf,2.51848,2, .); log=1]
> boxplot( c(x1,x2) )
> boxplot( c(x1,x2), names=c("aPS.ratio","naPS.ratio") )
>
>
> boxplot( c( x1[is.finite(x1)],x2), names=c("aPS.ratio","naPS.ratio") )
Error in is.finite(x1) : default method not implemented for type 'list'
>
> is.finite(x1)
Error in is.finite(x1) : default method not implemented for type 'list'
>
> x <- c(0, NA, NaN, 1 , 10, 20, 21, Inf)
> x[!is.na(x) & x >=1 & x<= 20]
[1]  1 10 20
>
> boxplot( c(is.na(x1),x2), names=c("aPS.ratio","naPS.ratio") )
Error in axis(side = 1, at = 1:6373, labels = c("aPS.ratio", "naPS.ratio" :
  'at' and 'labels' lengths differ, 6373 != 2

> boxplot( x1,x2, log="y")
> boxplot( x1,x2, log="y" , names=c("aPS.ratio","naPS.ratio") )




