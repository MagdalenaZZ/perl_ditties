#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

my $blast = shift;
my $list = shift;
my $out = shift;

sub USAGE {

die 'Usage: BLAST_hit_chooser.pl BLASTinput list outputname

Takes a list of genes and retrieves BLAST-hits from those genes only



'
}



	open (IN, "<$blast") || die "I can't open $blast\n";
	my @blast = <IN>;
	close (IN);


	open (IN, "<$list") || die "I can't open $list\n";
	my @list = <IN>;
	close (IN);


	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">$out.errors") || die "I can't open $out.errors\n";

foreach my $line (@list) {
chomp $line;
my $index = 0;
	foreach my $elem (@blast) {
		my @arr = split(/\s+/, $elem);
		if ($arr[0]=~/$line/ and $line=~/$arr[0]/) {
			print OUT "$elem";
			$index = 1;
#			shift @list;
		}
		else {
#			print OUT2 "$arr[0] is not in gff-file\n";
#			shift @blast;
		}

	}

	if ($index==1) {
		shift @list;
	}
}

foreach my $line (@list) {
print OUT2 "$line does not have a BLAST-hit\n";
}

close (OUT);
close (OUT2);

