#!/bin/perl
use strict;
use warnings;


my $coordsfile = shift;
open(CO,"<$coordsfile") or die("cannot find coords file - does deltafile ".$ARGV[0]." exist? is nucmer properly installed\n");

while (<CO>) { 
    my $line = $_;
    # correct font
    if ($line=~/CMUBright-Roman/) {
        $line=~s/ font-family\=\"CMUBright-Roman\"//;
        print "$line";
    }
    elsif  ($line=~/^<svg/) {
        #print "$line";
        print '<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="3000px" height="3000px" xml:space="preserve">' . "\n";
    }
    elsif ($line=~/<g id="track_0">/) {
        #print "$line";
    }
    else {
        print "$line";
    }

}

#print "<\/svg>\n";






