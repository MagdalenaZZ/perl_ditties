#!/usr/local/bin/perl -w
# mz3 script for splitting a protein-file to several pfamscan jobs

use strict;

unless (@ARGV == 1) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: oma_drugs.pl <input>


'
}

### this is the splitter-part of the script ####

my $in = shift;

my %h;


open (IN, "<$in");
#my @in = <IN>;

while (my $line = <IN>)  {

  chomp($line);
#  print "LINE:$line:\n";

  my @arr = split (/\t/, $line);

#  print "$arr[8]\n";
    unless (exists $h{$arr[8]}) {
        $h{$arr[8]} = 0;
    }

  if ($line =~/DrugBank/ ) {
        $h{$arr[8]} = ($h{$arr[8]} +1 );
  }
  if ($line =~/ChEMBL/ ) {
        $h{$arr[8]} = ($h{$arr[8]} +1 );
  }
  if ($line =~/RCDB/ ) {
        $h{$arr[8]} = ($h{$arr[8]} +1 );
  }

} 

foreach my $gene (sort keys %h) {

    print "$gene\t$h{$gene}\n";
}

