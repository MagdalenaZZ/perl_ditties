#!/usr/bin/perl -w


use strict;


unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: topGO_parser.pl  topGO.Rout   R.input.list   R.output.table

topGO.Rout - the output from topGO
R.input.list  - a list of genes and product names, produced by topGO-starter.pl
R.output.table - a table produced by topGO



'
}

	my $in = shift;
	my $in2 = shift;
	my $in3 = shift;

    	my $out = "$in2.outR";

	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;
#	close (IN);

	open (IN2, "<$in2") || die "I can't open $in2\n";
	my @in = <IN2>;
	close (IN2);

    open (OUT, ">$out") || die "I can't open $out\n";
    open (OUT2, ">$out.txt") || die "I can't open $out.txt\n";


my %h;

# read in topGO output GO rows

while (<IN>) {
chomp $_;

    if ($_ =~/^\$\`GO/) {
#        print "$_\n";
        my $head = $_;
        $head =~s/\$\`//;
        $head =~s/\`//;
        my $line = "hi";
        while ( $line =~/\w+/) {
            $line = <IN>;
            chomp $line;
#            print "$line";
            chomp $line;
            my @arr = split (/\s+/, $line);
            foreach my $key ( @arr) {
                $key =~s/\"//g;
		if ($key=~/\w+/) {
                	unless ($key=~/\[/) {
                	    $h{$key}{$head}=$head;
                	    #print "$key\t$head\n";
                	}
		}
            }
        }
    }
    elsif ($_ =~/resultFisher/) {
        last;
    }

}

#__END__

# read in list, and annotation if there is

my %h2;

foreach my $lin (@in) {
    chomp $lin;
    $lin=~s/ID=//;
    $lin=~s/\/product=//;

    my @lin2 = split (/\t/, $lin);
    push (@lin2, " ");

    if (exists $h{$lin2[0]} ) {
        foreach my $no ( sort keys %{$h{$lin2[0]}} ) {
            print OUT "$lin2[0]\t$no\n";
            #print "$no\t$lin2[0]\t$lin2[1]\n";
            $h2{$no}{$lin2[0]}=$lin2[1];
        }
    }

}


# get only significant GO-terms



	open (IN3, "<$in3") || die "I can't open $in3\n";
	my @in3 = <IN3>;
	close (IN3);
    shift @in3;

foreach my $elem ( @in3 ) {
    chomp $elem;
    my @arr2 = split(/\"/, $elem);
    $arr2[7]=~s/\<//g;

    if ( $arr2[7] < 0.05 ) {
	$elem=~s/\"/\t/g;
	$elem=~s/\t\t/\t/g;
	$elem=~s/\t\t/\t/g;
	$elem=~s/\t\t/\t/g;
	$elem=~s/^\t//g;
	my @tmp = split("\t", $elem);
	#print "$tmp[0]\t$tmp[1]\t$tmp[2]\t$tmp[3]\t$tmp[4]\t$tmp[5]\t$tmp[6]\n";
        #print OUT2 "$elem\t";
        print OUT2 "$tmp[0]\t$tmp[1]\t$tmp[2]\t$tmp[3]\t$tmp[4]\t$tmp[5]\t$tmp[6]\t";
	#print "1 $arr2[3]\t$elem\n";

        if ( exists $h2{$arr2[3]}) {
		#sprint "Exists $arr2[3]\n";
            foreach my $key2 (sort keys %{ $h2{$arr2[3]} }) {
                print OUT2 "$key2,";
                print OUT "$arr2[3]\t$key2\n";
		#print "2 $key2,\n";
            }
            print OUT2 "\t";
            foreach my $key2 (sort keys %{ $h2{$arr2[3]} }) {
#                foreach my $key3 ( keys %{ $h2{$arr2[3]}{$key2} }  ) {
                    print OUT2 "$h2{$arr2[3]}{ $key2 },";
                    #print "3 $h2{$arr2[3]}{ $key2 },\n";
                    #print "$arr2[3]\t$key2\n";
                    #print "$h2{$arr2[3]}{ $key2 },";

#                }
            }
        }
	else {
		#print "No ex $arr2[3]\n";
	}

        print OUT2 "\n";
        #print "4 \n";
    }

}





close (IN);
close (OUT);
close (OUT2);

__END__

foreach my $line (@in) {
chomp $line;

if ($line =~/^\$\`GO/) {
    while ( $line !~/^$/) {

        print "$line\n";
    }
}

}

