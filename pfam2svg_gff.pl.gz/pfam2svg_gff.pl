#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV >1) {
        &USAGE;
}

sub USAGE {

die 'Usage: gff2svg.pl Pfam.out fasta <fai>


Parses output from Pfam, and makes and svg-file with the proteins in it

'
}



my $gff = shift;
my $fasta = shift;
my $fai = shift;
my $scale = 50000;


	open (PFAM, "<$gff") || die "I can't open $gff\n";
	my @gff = <PFAM>;
	close (PFAM);

    open (FAS, "<$fasta") || die "I can't open $fasta\n";
#	my @fas = <FAS>;
#	close (FAS);

    open (FAI, "<$fai") || die "I can't open $fai\n";
    #my @fai = <FAI>;



    # calculate the length of the protein
my %h;

my $head;

# read in fasta

while  ( <FAS> ) {

    if ($_ =~/^>/){
        my $head = $_;
        my $seq = <FAS>;
        $head =~s/>//;
        chomp $head;
        chomp $seq;
        my $len = length($seq);
        $h{$head} = ($len/$scale);

#        print "$head\t$len\n";
    }
    else {
         }
}


# read in fai

my @faipos;
my $pos = 0;

while  ( <FAI> ) {
    chomp;
    my @arr = split(/\s+/,$_);
    #$fai{$arr[0]}=($arr[1]/$scale);
    #print "$arr[0]\t$arr[1]\n";
    $pos =( $arr[1]/$scale) + $pos;
    push (  @faipos,  $pos);
}

pop @faipos;

close (FAI);

# make svg header

my $pix = "1000"; 

    open (OUT, ">$gff.svg") || die "I can't open $gff.svg\n";

    print OUT '<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="50000px" height="1000px" viewBox="0 0 50000 1000" enable-background="new 0 0 50000 1000" xml:space="preserve">
   <!-- this is a comment that gets ignored -->
    ';
    
# make a list of coordinates for each point

my $hi = "20";
my $x =10;
my $y = 10;







#__END__


my %seen;
my %doms;
my $first = 0;

foreach my $line (@gff) {
    chomp $line;
#    print "$line\n";
    my @arr = split(/\s+/,$line);
    #print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[8]\n";
    #$arr[8]=~s/ID=//;
# print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[6]\n";


    # print gene-name
    if (exists $h{$arr[0]}) {
#        print "$arr[0]\t$h{$arr[0]}\n";
        print OUT "\t<text x=\"$x\" y=\"$y\" fill=\"black\">$arr[0]</text>\n";
        $y = $y+$hi;        
        print OUT "\t <rect x=\"$x\" y=\"$y\" width=\"$h{$arr[0]}\" height=\"$hi\"  style=\"fill:rgb(255,255,255);stroke-width:1;stroke:rgb(0,0,0)\"/>\n";
        #print OUT "\t <rect x=\"$x\" y=\"$y\" width=\"100\" height=\"30\"  style=\"fill:rgb(255,255,255);stroke-width:1;stroke:rgb(0,0,0)\"/>\n";

        delete $h{$arr[0]};
        my $x1000 = ($x/$scale);
        my $y1000 = ($y/$scale);
        $seen{$arr[0]}= "$x\t$y";

        $y = $y+$hi+$hi+$hi;

             }

    

    # make tick-marks for chromosomes

    if ($first =~/0/) {
    foreach my $fa (@faipos) {
        #print "$fa\n";
        #$y = $y+$hi;     
        my $x1 = $fa + $x ;
        my $x2 = $fa + $x ;
        my $y1 =$y-2-$hi-$hi-$hi;
        my $y2 =  $y1+2;
        print OUT "\t <rect x=\"$x2\" y=\"$y1\" width=\"1\" height=\"2\"  style=\"fill:rgb(0,0,0);stroke-width:1;stroke:rgb(0,0,0)\"/>\n";
        #print OUT "\t <line x=\"$x1\" y=\"0\" x2=\"$x1\" y2=\"$y2\"  fill=\"none\" stroke=\"#000000\" />\n";
        $first = 1;


       }
   }


#    else {
#        print "missing $line\n";
#    }

    # make domain colours

    unless (exists $doms{$arr[2]}) {
        my $r = 255 - int(rand(100));
        my $g = 255 - int(rand(100));
        my $b = 255 - int(rand(100));
        $doms{$arr[2]} = "$r,$g,$b";
    }


    # now print the domain
    if (exists $seen{$arr[0]}) {
#        print "SEEN $arr[3]\t$arr[4]\n";
        my ($nx, $ny) = split (/\t/, $seen{$arr[0]});
        #print "SEEN $nx\t$ny\n";
        my $y1 = ($ny);
        my $x1 = ($arr[3]/$scale)+$x;
        my $ry = ($hi);
        my $len2 = ($arr[4] - $arr[3])/$scale;
        my $tx = ($arr[3])/$scale;
        my $ty = ($ny + $hi );
        print OUT "\t  <rect x=\"$x1\" y=\"$y1\" width=\"$len2\" height=\"$ry\"   style=\"fill:rgb($doms{$arr[2]});stroke:black;stroke-width:0\"/>\n";
        #print "\t  <text x=\"$tx\" y=\"$ty\" fill=\"black\">$arr[6]</text>\n";
    }

    else {
        print "This domain: $line\nhas no length, check if it exists in fasta\n";

    }
        
   

}






foreach my $key (sort keys %doms ) {
    #print "$key\t$doms{$key}\n";
    my $ry = ($hi );
    my $len2 = 10;
    my $x1 = ($x + 14);

    print OUT "\t  <rect x=\"$x\" y=\"$y\" width=\"$len2\" height=\"$ry\"    style=\"fill:rgb($doms{$key});stroke:black;stroke-width:1\"/>\n";
    $y = $y+$hi-1;
    print OUT "\t  <text x=\"$x1\" y=\"$y\" fill=\"black\">$key</text>\n";
    $y = $y+2;
}



    print OUT '
</svg>
    ';


close (OUT);




exit;

__END__


stats for scaffoldLG1.fa.sorted.fa
sum = 27672102, n = 63, ave = 439239.71, largest = 1488969
N50 = 578970, n = 16
N60 = 415577, n = 22
N70 = 340235, n = 29
N80 = 290432, n = 37
N90 = 216246, n = 49
N100 = 124139, n = 63
N_count = 162400
-------------------------------
stats for scaffoldLG2.fa.sorted.fa
sum = 21186241, n = 50, ave = 423724.82, largest = 1774400
N50 = 468852, n = 14
N60 = 401558, n = 18
N70 = 332026, n = 24
N80 = 288514, n = 31
N90 = 224738, n = 39
N100 = 124558, n = 50
N_count = 117400
-------------------------------
stats for scaffoldLG3.fa.sorted.fa
sum = 17459908, n = 38, ave = 459471.26, largest = 1581338
N50 = 517640, n = 11
N60 = 474789, n = 15
N70 = 371114, n = 19
N80 = 304017, n = 24
N90 = 255771, n = 30
N100 = 169223, n = 38
N_count = 115600


 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG1.gff | grep other | wc -l
2090
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG2.gff | grep other | wc -l
1918
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG3.gff | grep other | wc -l
1051


 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG1.gff | grep ladies | wc -l
534
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG2.gff | grep ladies | wc -l
546
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG3.gff | grep ladies | wc -l
464


 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG1.gff | grep gents | wc -l
867
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG2.gff | grep gents | wc -l
704
 /lustre/scratch108/parasites/mz3/Tmuris/Fig1 >cat scaffoldLG3.gff | grep gents | wc -l
441




