#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}



# housekeeping

my $f1 = shift;
my $f2 = shift;
my $pfx = $f1 ;
$pfx =~s/_1\.fastq//;

print "\nMaking file $pfx.SGA.wrapper.sh\n";

open (OUT, ">$pfx.SGA.wrapper.sh");

print OUT   "\necho \"DOING PREPROCESSING\" ; \n";
print OUT  "~js18/bin/sga-current preprocess  -m 51 --permute-ambiguous -f 3 -q 3 -p 1 -o $pfx.tmp.fastq $f1 $f2 ; \n"; #original 
#print OUT  "~js18/bin/sga-current preprocess  -m 51 --permute-ambiguous -f 3 -q 37 -m 70 -p 1 -o $pfx.tmp.fastq $f1 $f2\n"; # hard filtering


print OUT  "\necho \"DOING INDEXING\" ;\n";
print OUT   "~js18/bin/sga-current index -a ropebwt -t 1 $pfx.tmp.fastq ;\n";

print OUT   "echo \"DOING CORRECTION\" ;\n";
print OUT   "~js18/bin/sga-current correct -t 1 -a kmer --metrics=$pfx.metrics -k 31 -x 3 --discard -o $pfx.corr.fastq $pfx.tmp.fastq ;\n";

print OUT "~js18/bin/sga-current index -a ropebwt -t 1 $pfx.corr.fastq ;\n ";
print OUT "~js18/bin/sga-current filter --no-kmer-check -o $pfx.corr.fastq.fil $pfx.corr.fastq ;\n";


#print OUT   "echo \"NON-STANDARD: SPLIT READS TO TWO FILES\"\n";
#print OUT   "perl ~tdo/Bin/join.solexaBack.actual.sga.pl  $pfx.corr.fastq $pfx.CORR \n";

print OUT   "rm -f $pfx.tmp.fastq ;\n";

print OUT   "perl ~tdo/Bin/join.solexaBack.actual.sga.pl $pfx.corr.fastq.fil $pfx.corr.fastq.fil.CORR ;\n";



system "\nbsub.py 2  $pfx.corr sh $pfx.SGA.wrapper.sh\n\n";




close (OUT);


sub USAGE {

die ' 

Usage:

perl ~/bin/perl/SGA_wrapper_read_correction.pl fastq_1.fastq fastq_2.fastq

Dont worry about bsubbing, this program will output a shellscript and a bsub-command.


';

}

__END__


#Atlernatively:

# index resulting file
bsub.py 20 index2 ~js18/bin/sga-current index -a ropebwt -t 1 5817_1.corr.fastq


bsub.py 20 DjA2index2 ~js18/bin/sga-current index -a ropebwt -t 1 DjA2_PZQ_294733_1hr.9234_7#1.fastq.10.80.no_polyA_1.corr.fastq
bsub.py 20 DjF3index2 ~js18/bin/sga-current index -a ropebwt -t 1 DjF3_294733_whole.9233_8#11.fastq.10.80.no_polyA_1.corr.fastq
bsub.py 20 DjD3index2 ~js18/bin/sga-current index -a ropebwt -t 1 DjD3_DMSO_294733_24hr.9233_8#8.fastq.10.80.no_polyA_1.corr.fastq

# get rid of duplicates
bsub.py 10 fi1 ~js18/bin/sga-current filter --no-kmer-check --substring-only 5817_1.corr.fastq -o 5817_1.corr.fastq.sub

bsub.py 10 fi2 ~js18/bin/sga-current filter --no-kmer-check 5817_1.corr.fastq -o 5817_1.corr.fastq.fil

bsub.py 10 DjA2fi2 ~js18/bin/sga-current filter --no-kmer-check DjA2_PZQ_294733_1hr.9234_7#1.fastq.10.80.no_polyA_1.corr.fastq
bsub.py 10 DjF3fi2 ~js18/bin/sga-current filter --no-kmer-check  DjF3_294733_whole.9233_8#11.fastq.10.80.no_polyA_1.corr.fastq
bsub.py 10 DjD3fi2 ~js18/bin/sga-current filter --no-kmer-check  DjD3_DMSO_294733_24hr.9233_8#8.fastq.10.80.no_polyA_1.corr.fastq





########


print "bsub.py --threads=12 long 10 $pfx.corr ~js18/bin/sga-current  \n";

## Try sga read correction again

~js18/bin/sga-current preprocess  -m 51 --permute-ambiguous -f 3 -q 3 -p 1 -o DjA1_PZQ_294733_1hr.9221_8.tmp.fastq DjA1_PZQ_294733_1hr.9221_8#1_1.fastq  DjA1_PZQ_294733_1hr.9221_8#1_2.fastq 

~js18/bin/sga-current index -a ropebwt -t 12 --disk=28000000 DjA1_PZQ_294733_1hr.9221_8.tmp.fastq

bsub -q long -o out.Stats1.$tmp.o -e out.Stats1.$tmp.e -J Stats1.$tmp -R "select[type==X86_64 && mem > 5000] rusage[mem=5000]" -M5000000 -n12 -R "span[hosts=1]" ~js18/bin/sga-0.9.9 stats -n 5000  --kmer-distribution   -t 12 $read.$result.$tmp.fastq

~js18/bin/sga-current correct -k 31  -x 5 -t 12 --discard -o $read.corrected.$result.$tmp.fastq $read.$result.$tmp.fastq

perl ~tdo/Bin/join.solexaBack.actual.sga.pl  $read.corrected.$result.$tmp.fastq $read.CORR31_3.$tmp


~js18/bin/sga-current preprocess  -m 51 --permute-ambiguous -f 3 -q 3 -p 1 -o $read.$result.$tmp.fastq "$read"_1.fastq "$read"_2.fastq  
~js18/bin/sga-current index -a ropebwt -t 12 --disk=28000000  $read.$result.$tmp.fastq
bsub -q long -o out.Stats1.$tmp.o -e out.Stats1.$tmp.e -J Stats1.$tmp -R "select[type==X86_64 && mem > 5000] rusage[mem=5000]" -M5000000 -n12 -R "span[hosts=1]" ~js18/bin/sga-0.9.9 stats -n 5000  --kmer-distribution   -t 12 $read.$result.$tmp.fastq
~js18/bin/sga-current correct -k 31  -x 5 -t 12 --discard -o $read.corrected.$result.$tmp.fastq $read.$result.$tmp.fastq
perl ~tdo/Bin/join.solexaBack.actual.sga.pl  $read.corrected.$result.$tmp.fastq $read.CORR31_3.$tmp

