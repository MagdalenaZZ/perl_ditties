#!/usr/bin/perl -w
# mz3 script for making taking mergeBED output and make it to an Artemis-file

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage:  perl ~/bin/perl/bed2merge.pl  <mergebed ouput> 

perl ~/bin/perl/bed2merge.pl  temp.test6.UTR.gff 

# mz3 script for making taking mergeBED output and make it to an Artemis-file

'
}

my $infile = shift;

open (IN, "$infile");
my @list = <IN>;
my $counter = 1;

foreach my $line (@list) {

 	 my ($scaffold, $start, $end, $strand) = split (/\s+/, $line);
print "$scaffold\thint\tCDS\t$start\t$end\t.\t$strand\t.\tID=hint$counter;\n";

$counter++;

}
