#!/usr/local/bin/perl -w
#
use strict;
#use List::Util;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die '
Usage: 
perl ~/bin/perl/freq_hist.pl in  


mz3 script takes a list of 

thing1  <TAB>    value
thing2   <TAB>   value

and makes it into frequency histogram


'
}

# open the file

my $in = shift;

my $roundup;

#my $in = shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

    	open (OUT, ">$in.out") || die "I can't open $in.out\n";

        print OUT "ID\tmin-max\tavg\tmedian\n";
#	my @in = <in>;




# parse the array


my %h;

foreach my $line (@in) {
chomp $line;
# print "$line\n";

 my @arr = split (/\t/, $line);

    if (exists $h{$arr[0]}{$arr[1]} ) {
            $h{$arr[0]}{$arr[1]} = ( $h{$arr[0]}{$arr[1]} +1)  ;
    }
    else {
            $h{$arr[0]}{$arr[1]} = 1  ;
    }
}

# empty array of freqs

foreach my $key (sort keys %h) {

    foreach my $key2 (sort keys %{$h{$key}}) {
#        print "$key\t$key2\t$h{$key}{$key2}\n";
    }

}

foreach my $id (sort keys %h) {

  my @arr;  
  my $sum;
#    foreach my $key2 (sort keys %{$h{$key}}) {

#    my $max_key = 0;
    my $max_value = 0;
#    my $min_key = 0 ;
    my $min_value = 100;

#    while ((my $key2, my $value) = each %{$h{$id}} ) {

    foreach my $key2 ( sort {$a <=> $b} keys  %{$h{$id}}) {

        #print  "LINE: $id\t$key2\t$h{$id}{$key2}\n";

#    while ((my $key, my $value) = each %h ) {
        if ($key2 > $max_value) {
            $max_value = $key2;
#            $max_key = $id;
        }
        if ($min_value > $key2 ) {
            $min_value = $key2;
#            $min_key = $id;
        }

    for (my $count =  $h{$id}{$key2} ; $count >= 1; $count--) {
        push (@arr, $key2);
#        $sum = $sum + $key2;
#        print "ARR: $id\t$key2\n";
    }
        

    }

    # calculate the average
    $sum += $_ for(@arr);
    my $avg = $sum / scalar(@arr);

    # calculate median
    my $median;
    my $mid = int @arr/2;
    my @sorted_values = sort by_number @arr;
    if (@arr % 2) {
        $median = $sorted_values[ $mid ];
    } 

    else {
        $median = ($sorted_values[$mid-1] + $sorted_values[$mid])/2;
    } 


    #    print "MAX: $id\t$max_value\n";
    print OUT "$id\t$min_value-$max_value\t$avg\t$median\n";
    

    ## Determine X-bins max


    sub roundup {
        my $n = shift;
        return(($n == int($n)) ? $n : int($n + 1))
    }

    my $max = $max_value / 100;
    $roundup = 100* roundup($max);

    # print "$max_value\t$roundup\n";


    ## make suitable bins

my %res;

for (my $start = 0; $start < $roundup; $start += 10 ) {
    #print "$start\t$roundup\n";
    foreach my $key (keys %h  ) {
        foreach my $key2 (keys %{$h{$key}}  ) {

            #print "key $fas{$key}\n";
            if ( $h{$key} >= $start and $h{$key} < ($start+10) ) {
                #print "Match $start $fas{$key} \n";
                $res { $start } += 1;
            }
        
            unless (exists $res{ $start }) {
                $res { $start } = 0;
            }
        }
    }
}




open (OUT2, ">$in.txt") || die;
foreach my $key2 (sort {$a <=> $b} keys %res ) {
    print OUT2 "$key2\t$res{$key2}\n";
}
close (OUT2);









}




close (OUT);




######## SUBROUTINES ###########################################################


sub by_number {
    if ($a < $b){ -1 } elsif ($a > $b) { 1 } else { 0 }
}






use GD;
use GD::Graph::hbars;
use GD::Graph::lines;
use GD::Graph::points;
use GD::Graph::linespoints;
use GD::Graph::histogram;


# now actually calculate the value

my @res;

foreach my $line (@in) {
chomp $line;
# print "$line\n";

 my @arr = split (/\t/, $line);
 push (@res, $arr[1]);
 
}
 

use List::Util qw( min max );
my $min = min @res;
my $max = max @res;


 
draw_graph( "$in.png" , @res );

sub draw_graph {
    my ( $filename, @fas ) = @_;
    my $graph = new GD::Graph::histogram( 100000, 100000 );
    $graph->set(
        x_label           => 'Data',
        y_label           => 'Count',
        title             => 'A Histogram Chart',
        x_labels_vertical => 1,
        bar_spacing       => 1,
        shadow_depth      => 0,
        shadowclr         => 'dred',
        transparent       => 0,
        histogram_type => 'count',
        histogram_bins => 200 ,
        x_max_value       => $roundup,
        y_min_value       => 0,
        x_min_value       => 0,
        #x_ticks           => 18,

      )
      or warn $graph->error;

    my $gd = $graph->plot( \@res ) or die $graph->error;

    open( IMG, '>' . $filename ) or die $!;
    binmode IMG;
    print IMG $gd->png;
}


exit;


