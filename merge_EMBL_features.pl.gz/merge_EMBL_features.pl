#!/usr/local/bin/perl
use strict;


# merge_EMBL_features - takes multiple EMBL feature files, which describe
# the same sequence file and merge the features into one EMBL feature file.
# The features are sorted by "leftmost" beginning or ending position.
# Output is written to standard output.

# Written by James D. White, University of Oklahoma, Advanced
# Center for Genome Technology, on Aug 4, 2000.

$Last_Modified = 'Sep 19, 2001';

$DEBUG = 0;

$full_command_name = $0;
if ($full_command_name =~ m"(^|\/)([^\/]*)$")
  {
  $my_name = $2;
  }
else
  {
  $my_name = 'merge_EMBL_features';
  }

$USAGE = <<ENDHELP;

$my_name - takes EMBL feature files, which describe the
same sequence file and merges the features into one EMBL feature file.
The features are sorted by "leftmost" beginning or ending position.
Output is written to standard output.  $my_name does not
support remote entry identifiers (data base and accession number info)
in feature locations. 

USAGE:  $my_name [-v] EMBL_file1 [EMBL_file2 [EMBL_file3 ...]] > EMBL_output_file
            or
        $my_name -h
           

where 'EMBL_file1', 'EMBL_file2, 'EMBL_file3', etc.
         are the names of the input EMBL feature files to be processed.

      'EMBL_output_file' is the name of the output EMBL feature file to be
         created.

OPTIONS:

  -h  Help message -- what you are reading.
  -v  Verbose mode.  Print messages during processing.


PROGRAM LAST MODIFIED: $Last_Modified

ENDHELP

use Getopt::Std;

die $USAGE unless( getopts('vh') );
$VERBOSE = $opt_v;
if ($opt_h)
  {
  print STDOUT $USAGE;
  exit 0;
  }

die $USAGE if (scalar @ARGV) < 1;

$features_files = 0;
$total_features_found = 0;
@FEATURES = ();
foreach $file (@ARGV)
  {
  if (! defined open(EMBLIN, $file))
    {
    print STDERR "ERROR: Cannot open EMBL feature file '$file'\n";
    exit 1;
    }
  print STDERR "Processing EMBL feature file '$file'\n" if $VERBOSE;
  $features_files++;
  $features_found = 0;
  $line_num = 0;
  $feature_status = 0;
  while (<EMBLIN>)
    {
    my($line);
    $line = $_;
    $line_num++;
    $line_front = substr($line, 0, 21);
    if ($line_front =~ /^FT\s{19}$/)		# body of feature
      {
      if (! $feature_status)
        {
        chomp($line);
        print STDERR "ERROR: Invalid EMBL feature file '$file', line $line_num, missing feature header\n  line='$line'\n";
        exit 1;
        }
      $feature .= $line;
      }
    elsif ($line_front =~ /^FT   (\S+)\s+$/)	# feature header (type and location)
      {
      $feature_type_save = $1;
      &save_feature($min_left, $max_right, $direction, $feature_type, $features_files, $feature) if $feature_status;
      $feature_type = $feature_type_save;
      $feature = $line;
      $feature_status = 1;
      $features_found++;
      $feature_loc = &get_feature_loc(substr($line, 21));
      if (! defined $feature_loc)
        {
        chomp($line);
        print STDERR "ERROR: Invalid EMBL feature file '$file', line $line_num, invalid location\n  line='$line'\n";
        exit 1;
        }
      ($min_left, $max_right, $direction, $num_segments, $feature_locations_ref) = @{ $feature_loc };
      }
    elsif ($line =~ /^\s+$/)			# ignore blank lines
      {
      next;
      }
    else					# not an EMBL feature line
      {
      chomp($line);
      print STDERR "ERROR: Invalid EMBL feature file '$file', line $line_num invalid\n  line='$line'\n";
      exit 1;
      }
    } # end while (<EMBLIN>)
  close EMBLIN;
  print STDERR "  $features_found features found in file\n" if $VERBOSE;
  $total_features_found += $features_found;
  if ($feature_status)
    {
    &save_feature($min_left, $max_right, $direction, $feature_type, $features_files, $feature);
    }
  else
    {
    print STDERR "Warning: No features found in EMBL feature file '$file'\n";
    }
  } # end foreach $file (...)
print STDERR "$total_features_found total features read in $features_files files\n" if $VERBOSE;

print STDERR "sorting features by location\n" if $VERBOSE;
@FEATURES_OUT = sort by_location @FEATURES;
print STDERR "sorted\n" if $VERBOSE;

$features_written = 0;
foreach $feature_entry (@FEATURES_OUT)
  {
  ($min_left, $max_right, $direction, $feature_type, $features_files, $feature) = split("\t", $feature_entry, 6);
  print STDOUT $feature;
  $features_written++;
  }
print STDERR "$features_written features written to output\n\n" if $VERBOSE;

exit 0;


#########################################################################
# get_feature_loc - parse input feature location
#########################################################################
sub get_feature_loc
  {
  my($feature_location) = @_;
  chomp($feature_location);
  print STDERR "entering get_feature_location($feature_location)\n" if $DEBUG > 0;
  $feature_location =~ s/\s+$//;
  my $direction = 1;
  my (@feature_locations) = ();
  my ($feature_sub_loc, $min_left, $left, $max_right, $right, $begin, $end, $num_segments);
  if ($feature_location =~ s/^complement\((.+?)\)$/$1/)	# complement
    {
    $direction = -1;
    }
  if ($feature_location =~ s/^(join|order)\((.+?)\)$/$2/)	# joined segments
    {
    while ($feature_location =~ s/([\d\.\^\(\)\<\>complent]+)(,|$)//)
      {
      $feature_sub_loc = &get_feature_sub_loc($1, $direction);
      return undef if (! defined $feature_sub_loc);
      ($left, $right, $begin, $end, $direction) = split("\t", $feature_sub_loc);
      $min_left = $left if ((! $min_left) || ($min_left > $left));
      $max_right = $right if ((! $max_right) || ($max_right < $right));
      push @feature_locations, $feature_sub_loc;
      }
    return undef if ($feature_location ne '');
    }
  else
    {
    $feature_sub_loc = &get_feature_sub_loc($feature_location, $direction);
    return undef if (! defined $feature_sub_loc);
    ($left, $right, $begin, $end, $direction) = split("\t", $feature_sub_loc);
    $min_left = $left;
    $max_right = $right;
    push @feature_locations, $feature_sub_loc;
    }
  $num_segments = scalar @feature_locations;
  print STDERR "leaving  get_feature_loc='$min_left, $max_right, $direction, $num_segments'\n" if $DEBUG > 0;
  return [$min_left, $max_right, $direction, $num_segments, \@feature_locations];
  } # end get_feature_loc


#########################################################################
# get_feature_sub_loc - parse input feature sub-location (range)
#########################################################################
sub get_feature_sub_loc
  {
  my($feature_sub_location, $direction) = @_;
  my($begin, $begin_base, $begin_low, $begin_high, $begin_ext,
     $end, $end_base, $end_low, $end_high, $end_ext,
     $left, $right, $return_val);
  print STDERR "  entering get_feature_sub_loc($feature_sub_location,$direction)\n" if $DEBUG > 0;
  if ($feature_sub_location =~ s/^complement\((.*?)\)$/$1/)	# complement( )
    {
    $direction *= -1;
    }
  if ($feature_sub_location =~ /^([\d\<\>\^\(\.\)]+?)\.\.([\d\<\>\^\(\.\)]+)$/)
    {							# location is range
    if ($direction > 0)					#   (123..456)
      {
      $begin = $1;
      $end = $2;
      }
    else
      {
      $begin = $2;
      $end = $1;
      }
    $begin_base = &get_feature_base($begin);
    return undef if (! defined $begin_base);
    ($begin_low, $begin_high, $begin_ext) = split("\t", $begin_base);
    $end_base = &get_feature_base($end);
    return undef if (! defined $end_base);
    ($end_low, $end_high, $end_ext) = split("\t", $end_base);
    if ($direction > 0)				# forward
      {
      $begin  = $begin_ext . $begin_low;
      $end    = $end_ext   . $end_high;
      $left   = $begin_low;
      $left  -= 0.1 if ($begin_ext eq '<');
      $left  += 0.1 if ($begin_ext eq '>');
      $right  = $end_high;
      $right -= 0.1 if ($end_ext   eq '<');
      $right += 0.1 if ($end_ext   eq '>');
      }
    else					# complement
      {
      $begin  = $begin_ext . $begin_high;
      $end    = $end_ext   . $end_low;
      $left   = $end_low;
      $left  -= 0.1 if ($end_ext   eq '<');
      $left  += 0.1 if ($end_ext   eq '>');
      $right  = $begin_high;
      $right -= 0.1 if ($begin_ext eq '<');
      $right += 0.1 if ($begin_ext eq '>');
      }
    }
  elsif ($feature_sub_location =~ /^[\d\<\>\^\(\.\)]+$/)
    {						# location is single base
    $begin_base = &get_feature_base($feature_sub_location);
    return undef if (! defined $begin_base);
    ($begin_low, $begin_high, $begin_ext) = split("\t", $begin_base);
    $left   = $begin_low;
    $left  -= 0.1 if ($begin_ext eq '<');
    $right  = $begin_high;
    $right += 0.1 if ($end_ext   eq '>');
    if ($direction > 0)				# forward
      {
      $begin = $begin_ext . $begin_low;
      $end   = $begin_ext . $begin_high;
      }
    else					# complement
      {
      $begin = $begin_ext . $begin_high;
      $end   = $begin_ext . $begin_low;
      }
    }
  else					# invalid sub-location
    {
    return undef;
    }
  $return_val = join("\t", $left, $right, $begin, $end, $direction);
  print STDERR "  leaving  get_feature_sub_loc='$return_val'\n" if $DEBUG > 0;
  return $return_val;
  } # end get_feature_sub_loc


#########################################################################
# get_feature_base - parse input feature base location (begin or end)
#########################################################################
sub get_feature_base
  {
  my($feature_base_loc) = @_;
  my($left, $right, $ext, $pos1, $pos2, $return_val);
  print STDERR "    entering get_feature_base($feature_base_loc)\n" if $DEBUG > 0;
  $ext = '';
  if ($feature_base_loc =~ /^([\<\>]?)(\d+)$/) 	# single base position
    {						#  123	(return(123,123,''))
    $left = $right = $2;			#  <123	(return(123,123,'<'))
    $ext = $1;					#  >123	(return(123,123,'>'))
    }
  elsif ($feature_base_loc =~ /^\((\d+)\.(\d+)\)$/)	# boundary range
    {							#   (135.123)
    $pos1 = $1;						# (return(123,135,''))
    $pos2 = $2;
    if ($pos1 < $pos2)
      {
      $left = $pos1;
      $right = $pos2;
      }
    else
      {
      $left = $pos2;
      $right = $pos1;
      }
    }
  elsif ($feature_base_loc =~ /^(\d+)\^(\d+)\)$/)	# site between bases
    {							#   135^123
    $pos1 = $1;						# (return(123,135,''))
    $pos2 = $2;
    if ($pos1 < $pos2)
      {
      $left = $pos1;
      $right = $pos2;
      }
    else
      {
      $left = $pos2;
      $right = $pos1;
      }
    }
  else							# invalid base location
    {
    return undef;
    }
  $return_val = join("\t", $left, $right, $ext);
  print STDERR "    leaving  get_feature_base='$return_val'\n" if $DEBUG > 0;
  return $return_val;
  } # end get_feature_base


#########################################################################
# save_feature - save input feature in the array @FEATURES
#########################################################################
sub save_feature
  {
  if ($DEBUG > 0)
    {
    my($left, $right, $direction, $feature_type, $features_files, $feature) = @_;
    print STDERR "save_feature='l=$left, r=$right, d=$direction, ft=$feature_type, f#=$features_files'\n'$feature'\n";
    }
  push @FEATURES, join("\t", @_);
  } # end save_feature


#########################################################################
# by_location - sort input features by location, feature type, and file
#########################################################################
sub by_location
  {
  my($lefta, $righta, $dira, $ftypea, $filea) = split("\t", $a);
  my($leftb, $rightb, $dirb, $ftypeb, $fileb) = split("\t", $b);
  return ($lefta  <=> $leftb  	# leftmost base
       or $righta <=> $rightb	# else rightmost base
       or $dira   <=> $dirb	# direction
       or $ftypea cmp $ftypeb	# feature type
       or $filea  <=> $fileb);				# feature file number
  } # end by_location

