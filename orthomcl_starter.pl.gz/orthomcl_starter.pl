#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: orthomcl_starter.pl fasta

Takes a fasta input-file and does all necessary job to run orthoMCL

'
}


my $fasta = shift;

	open (FAS, "<$fasta") || die "I can't open $fasta\n";


# read infile

my %seqs;

while (<FAS>) {
chomp;
    # print "$_" ;

    if (/^>(\w+)/) {

    	my $seq_name = $_;
        chomp $seq_name;
	    $seq_name=~s/>//;
        my @head = split (/[_ ]/, $seq_name);
        $head[0] =~s/>//;
	    my $seq = <FAS> ;
	    chomp($seq) ;

        $seqs{$head[0]}{$seq_name} = $seq ;
#       print "$head[0]\t$seq_name\t$seq\n";
    }
    else {
        # nothing
    }
}

	close (FAS);

# run blast-splitter

system "blast_splitter.py --protein_ref $fasta $fasta blast9 25000 -p blastp -m 8 -b 100000 -v 100000 ";

mkdir "OMCL_$fasta";
chdir "OMCL_$fasta";

# make separate fasta-files

my @fas;

    foreach my $species (sort keys %seqs) {

        push (@fas, "$species.fa" );

	open (OUT, ">$species.fa") || die "I can't open $species.fa \n";

        foreach my $gene ( sort keys %{$seqs{$species}}  ) {
#            print  "$species\n";
#          print  "S:$gene:\n";
            print  OUT ">$gene\n$seqs{$species}{$gene}\n";

        }

    close (OUT);
    }

# make orthomcl mode1 line

my $fa = join (",", @fas );


open (OUT, ">../$fasta.commands") || die "I can't open ../$fasta.commands \n";

print OUT "\n\ncd OMCL_$fasta ";
print  OUT "\n\n orthomcl.pl --mode 1 --fa_files $fa\n\n";   

# get gg-file
#
sleep(5);

 print  OUT  "cp orthomcl*/tmp/all.gg ..\n";
 print  OUT  "rm -fr  orthomcl* formatdb.log\n";


# make orthomcl mode3 line

print OUT "bsub.py -q basement 5 omcl orthomcl.pl --mode 3 --inflation=1 pv_cutoff=0.001 --m8blast --blast_file blast9/all.blast --gg_file all.gg \n\n";










