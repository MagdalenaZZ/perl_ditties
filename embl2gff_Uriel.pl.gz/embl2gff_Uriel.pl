#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: embl2gff_Uriel.pl in.embl out.gff

After finished run fix_children4Artemis.pl

Works on standard embl-files where all parts of the CDS is in one line.



'
}


## parse infile

my $infile = shift;
my $outfile = shift;
 
open (IN, "<$infile") || die "Cant find file $infile";
#my @embl = <IN>;

open (OUT, ">$outfile");
open (FAS, ">$outfile.fasta") || die "cant open file $outfile.fasta";

	my $method = "manual";
	my $tag;
	my $start = "0";
	my $end = "0";
	my $score = ".";
	my $strand;
	my $id;
my @arr2;


my @features;
my $seq;
my $name;
my $index = 0;
my $first = 99999999999999;
my $last = 0;


while (<IN>) {
    my $line = $_;
#foreach my $line (@embl) {
    chomp $line;
	my @arr=split(/\s+/, $line);

    # get name
	if ($arr[0]=~/^>/) {
		$name = $line;
        $name =~s/\>//;
        $name =~s/ to /-/;
        $name =~s/\s+/_/;
        #print "Name:$name\n"
	}
	elsif ($arr[0]=~/^FT/) {
		if ($arr[1] =~/CDS/ or $arr[1] =~/LTR/ or $arr[1] =~/mRNA/ or $arr[1] =~/misc_feature/  ) {
            $index++;
            $tag = $arr[1];

			if ($arr[2] =~/complement/) {
				$strand = "-";
				$arr[2] =~s/complement\(//g;
				$arr[2] =~s/join\(//g;
				$arr[2] =~s/\)\)//g;
				$arr[2] =~s/\)//g;
                #print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
#				foreach my 
#				split(//,);
			}
			else {
				$strand = "+";
				$arr[2] =~s/join\(//;
				$arr[2] =~s/\)//;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
			}
		}
		elsif ($arr[1] =~/note/) {
            #$arr[1]=~s/\/locus_tag="//;
			$id = $line;
            $id=~s/FT                   //;
            $id=~s/\/note="//;
			$id=~s/\"//;
			if ($id=~/^3/ and $id=~/CA$/ ) {
                $id="3CA";
            }
			if ($id=~/^5/ and $id=~/TG$/ ) {
                $id="5TG";
            }
#			/locus_tag="KOG0450.57"
#			print "ID:$arr[1]\n";
			
            #my $note = <IN>;
            #chomp $note;
            #print "$id\n";
			foreach my $pos (@arr2) {
				($start,$end)=split(/\.\./, $pos);
                $start = $start-1;
				my $res = "$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$tag\_$index;note=$id";
                push (@features, $res); 


                # save max and min
                if ($start < $first) {
                    $first = $start;
                }
                if ($end > $last) {
                    $last = $end;
                }

			}

		}
		else {
            #print "Filter 2:$line\n";
		}
	
	}
	elsif ($arr[0]=~/\/\//) {
#		foreach my $pos (@arr2) {
#				($start,$end)=split(/\.\./, $pos);
#			print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#		}
	}
	else {
        #print "Filter 1:$line\n";
        $seq= $seq . $line;
	}


# print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\n";

}


chomp $name;
$name=~s/\s+//g;
print OUT "$name\tmanual\tgene\t$first\t$last\t\.\t$strand\t\.\tID=gene\_$name\n";
#print "$name\tmanual\tmRNA\t$first\tlast\t\.\t$strand\t\.\tID=gene\_$name\_$first\n";

foreach my $elem (@features) {

    print OUT "$name\t$elem;parent=gene\_$name\n";
}


print FAS ">$name\n$seq\n";

close (IN);
close (OUT);
close (FAS);


system "perl ~/bin/perl/fasta_from_CDS.pl $outfile.fasta  $outfile";

exit;

