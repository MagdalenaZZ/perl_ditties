#!/usr/local/bin/perl -w
use strict;


unless (@ARGV == 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: R_single_gene_expression.pl read.counts groups gene.list 




'
}


my $rpkms=shift;
my $cols=shift;
my $gl = shift;

open (R, ">$gl.$rpkms.R") || die "I can't open $gl.$rpkms.R\n";

print R "library(plyr)\nlibrary(ggplot2)\n";

# Read in values
print R "df <- read.table( \"$rpkms\", header=TRUE, row.names=1 )\n";


# Read in columns and make groups

print R "de <-  read.table( \"$cols\", header=TRUE )\n";

# Read in list

print R "ud <- read.table( \"$gl\", header=FALSE )\n";


# Do gene plot

print R '

for (i in 1:length(ud$V1)) {

gene <- as.vector(ud[i,])

de$Expression<- as.vector(t(df[gene,]))

colnames(de) <- c("Group","Expression")

dec <- summarySE(de, measurevar="Expression", groupvars="Group")

';

print R "fn <- paste(\"$gl\",ud[i,],\"scat.pdf\", sep=\".\")\n";

print R '
pdf(file=fn, useDingbats=FALSE)


print(ggplot()+
  geom_jitter(aes(Group, Expression), data = de, size=5, colour = I("red"),  position = position_jitter(width = 0.2)) +  scale_x_discrete(breaks=de$Group,labels=de$Group) +  geom_crossbar(data=dec,aes(x=Group,y=Expression,ymin=Expression, ymax=Expression,group=Group), width = 0.5) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) ) 

dev.off()

}


';

system "R CMD BATCH $gl.$rpkms.R > $gl.$rpkms.Rout";

exit;

