#!/usr/local/bin/perl -w

use strict;




unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: tab_merger.pl <PREFIX> *files



'
}



# print "@ARGV\n";

my $prefix = shift;

my @files = @ARGV;
my @files3;

foreach my $file (@files) {

    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$4}' > $file.1  ";
    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$3}' > $file.2  ";

}


my %h;

foreach my $file (@files) {

    open (IN , "<$file.1") || die;

    while (<IN>) {
        chomp;
        my @arr = split("\t", $_);
        
        push ( @{$h{$arr[0]}} , $arr[1] ); 
        #print "$arr[0]\t$arr[1]";

    }

    close (IN);
}


my %h2;

foreach my $file (@files) {

    open (IN , "<$file.2") || die;

    while (<IN>) {
        chomp;
        $_=~s/^ID=//;
        my @arr = split("\t", $_);
        
        push ( @{$h2{$arr[0]}} , $arr[1] ); 
        #print "$arr[0]\t$arr[1]";

    }

    close (IN);
    system "rm -f $file.1 $file.2";
}






open ( OUT , ">$prefix.merged.RPKM") || die;
open ( OUT2 , ">$prefix.merged.reads") || die;



print OUT "ID\t";
print OUT2 "ID\t";



foreach my $file (@files) {

    $file=~s/\.notCombined\.out\.sorted\.markdup\.BEDcoverage\.final\.count//g;
    $file=~s/\.extendedFrags\.out\.sorted\.markdup\.BEDcoverage\.final\.count//g;
    $file=~s/\.BEDcoverage\.final\.count//g;
    $file=~s/\.bam//g;
    $file=~s/\.count//g;
    $file=~s/HYMtophat//g;

    my @arr = split("\/", $file);
    $file=$arr[-1];
    #print "$file\n";
    #$file =~s/#/-/g;

    if ($file=~/^9887_8#7$/ || $file=~/^9887_7#7$/ ) {
        $file = "MCanaerob.1";
    }
    elsif ($file=~/^9887_6#7$/ || $file=~/^9887_5#7$/ ) {
        $file = "MCanaerob.2";
    }
    elsif ($file=~/^9887_4#8$/ || $file=~/^9887_3#8$/ ) {
        $file = "MCanaerob.3";
    }
    elsif ($file=~/^9887_8#8$/ || $file=~/^9887_7#8$/  ) {
        $file = "MCu.1";
    }
    elsif ($file=~/^9887_5#8$/ || $file=~/^9887_6#8$/  ) {
        $file = "MCu.2";
    }
    elsif ($file=~/^9887_4#9$/ || $file=~/^9887_3#9$/ ) {
        $file = "MCu.3";
    }
    elsif ($file=~/^9887_8#11$/ || $file=~/^9887_7#11$/  ) {
        $file = "aPS.1";
    }
    elsif ($file=~/^9887_6#11$/ || $file=~/^9887_5#11$/  ) {
        $file = "aPS.2";
    }
    elsif ($file=~/^9887_4#12$/ || $file=~/^9887_3#12$/ ) {
        $file = "aPS.3";
    }
    elsif ($file=~/^9887_8#10$/ || $file=~/^9887_7#10$/  ) {
        $file = "naPS.1";
    }
    elsif($file=~/^9887_6#10$/ || $file=~/^9887_5#10$/  ) {
        $file = "naPS.2";
    }
    elsif ($file=~/^9887_3#11$/ || $file=~/^9887_4#11$/ ) {
        $file = "naPS.3";
    }
    elsif ($file=~/^9887_8#6$/ || $file=~/^9887_7#6$/  ) {
        $file = "MCvivo.1";
    }
    elsif ($file=~/^9887_6#6$/ || $file=~/^9887_5#6$/  ) {
        $file = "MCvivo.2";
    }
    elsif ($file=~/^9887_4#6$/ || $file=~/^9887_3#6$/ ) {
        $file = "MCvivo.3";
    }
    elsif ($file=~/^9887_3#4$/ || $file=~/^9887_4#4$/ ) {
        $file = "MCnoBC.1";
    }
    elsif ($file=~/^9887_5#4$/ || $file=~/^9887_6#4$/ ) {
        $file = "MCnoBC.2";
    }
    elsif ($file=~/^9887_7#4$/ || $file=~/^9887_8#4$/ ) {
        $file = "MCnoBC.3";
    }
    elsif ($file=~/^9887_8#5$/ || $file=~/^9887_7#5$/ ) {
        $file = "MCvitro.1";
    }
    elsif ($file=~/^9887_6#5$/ || $file=~/^9887_5#5$/ ) {
        $file = "MCvitro.2";
    }
    elsif ($file=~/^9887_4#5$/ || $file=~/^9887_3#5$/ ) {
        $file = "MCvitro.3";
    }
    elsif ($file=~/^9887_8#1$/   ||   $file=~/^9887_7#1$/) {
        $file = "PC1-2";
    }
    elsif ($file=~/^9887_3#1$/  ||     $file=~/^9887_4#1$/) {
        $file = "PC1-2";
    }
    elsif ($file=~/^9887_5#1$/  ||   $file=~/^9887_6#1$/) {
        $file = "PC1-2";
    }
    elsif ($file=~/^9887_3#2$/ ||  $file=~/^9887_4#2$/  ) {
        $file = "PC2-7";
    }
    elsif ($file=~/^9887_5#2$/ || $file=~/^9887_6#2$/) {
        $file = "PC2-9";
    }
    elsif ($file=~/^9887_8#2$/ || $file=~/^9887_7#2$/) {
        $file = "PC2-11";
    }
    elsif ($file=~/^9887_3#3$/ || $file=~/^9887_4#3$/) {
        $file = "PC3-22";
    }
    elsif ($file=~/^9887_5#3$/ || $file=~/^9887_6#3$/) {
        $file = "PC3-16";
    }
    elsif ($file=~/^9887_8#3$/ || $file=~/^9887_7#3$/) {
        $file = "PC3-21";
    }


    # miRNAs
    
    elsif ($file=~/^11440_1#12$/ || $file=~/^11449_1#24$/ || $file=~/^11450_1#12$/ ) {
        $file = "aPS";
    }
    elsif ($file=~/^11440_1#7$/ ) {
        $file = "Cyst_wall";
    }
    elsif ($file=~/^11440_1#10$/ || $file=~/^11449_1#22$/ || $file=~/^11450_1#10$/ ) {
        $file = "EGU_naPS";
    }
    elsif ($file=~/^11440_1#13$/ || $file=~/^11449_1#1$/ || $file=~/^11450_1#13$/ ) {
        $file = "Larvae";
    }
    elsif ($file=~/^11440_1#8$/ || $file=~/^11449_1#20$/ || $file=~/^11450_1#8$/ ) {
        $file = "MCana";
    }
    elsif ($file=~/^11440_1#4$/ || $file=~/^11449_1#17$/ || $file=~/^11450_1#5$/ ) {
        $file = "MCnoBC";
    }
    elsif ($file=~/^11440_1#9$/ || $file=~/^11449_1#21$/ || $file=~/^11450_1#9$/ ) {
        $file = "MCu";
    }
    elsif ($file=~/^11440_1#5$/ || $file=~/^11449_1#18$/ || $file=~/^11450_1#6$/ ) {
        $file = "MCvitro";
    }
    elsif ($file=~/^11440_1#6$/ || $file=~/^11449_1#19$/ || $file=~/^11450_1#7$/ ) {
        $file = "MCvivo";
    }
    elsif ($file=~/^11440_1#11$/ || $file=~/^11449_1#23$/ || $file=~/^11450_1#11$/ ) {
        $file = "naPS";
    }
    elsif ($file=~/^11440_1#1$/ || $file=~/^11449_1#14$/ || $file=~/^11450_1#2$/ ) {
        $file = "PC1";
    }
    elsif ($file=~/^11440_1#2$/ || $file=~/^11449_1#15$/ || $file=~/^11450_1#3$/ ) {
        $file = "PC2";
    }
    elsif ($file=~/^11440_1#3$/ || $file=~/^11449_1#16$/ || $file=~/^11450_1#4$/ ) {
        $file = "PC3";
    }


    # EGU

    elsif ($file=~/^9887_5#9$/ || $file=~/^9887_6#9$/     ) {
        $file = "EGU_naPS.1";
    }
    elsif ($file=~/^9887_7#9$/ || $file=~/^9887_8#9$/     ) {
        $file = "EGU_naPS.2";
    }
    elsif ($file=~/^9887_3#10$/ || $file=~/^9887_4#10$/     ) {
        $file = "EGU_naPS.3";
    }
    elsif ($file=~/^9887_3#7$/ || $file=~/^9887_4#7$/  ) {
        $file = "EGU_MCvivo";
    }

    # HYM

    elsif ($file=~/^7893_5#10$/ ) {
        $file = "Hym_ww.1";
    }   
    elsif ( $file=~/^7893_5#11$/ ) {
        $file = "Hym_ww.2";
    }
    elsif ($file=~/^7893_5#12$/ ) {
        $file = "Hym_ww.3";
    }


    elsif ($file=~/^7893_5#1$/  ) {
        $file = "Hym_s.1";
    }
    elsif ($file=~/^7893_5#2$/  ) {
        $file = "Hym_s.2";
    }
    elsif ($file=~/^7893_5#3$/ ) {
        $file = "Hym_s.3";
    }

    elsif ($file=~/^7893_5#4$/ ) {
        $file = "Hym_m.1";
    }
    elsif ( $file=~/^7893_5#5$/  ) {
        $file = "Hym_m.2";
    }
    elsif (    $file=~/^7893_5#6$/ ) {
        $file = "Hym_m.3";
    }

    elsif ($file=~/^7893_5#7$/ ) {
        $file = "Hym_p.1";
    }
    elsif (    $file=~/^7893_5#8$/ ) {
        $file = "Hym_p.2";
    }
    elsif (    $file=~/^7893_5#9$/ ) {
        $file = "Hym_p.3";
    }

    elsif ($file=~/^9887_3#13$/  ) {
        $file = "Hym_l.1";
    }
    elsif ($file=~/^9887_4#13$/ ) {
        $file = "Hym_l.2";
    }
        elsif ($file=~/^9887_5#12$/ ) {
        $file = "Hym_l.3";
    }
        elsif ($file=~/^9887_6#12$/ ) {
        $file = "Hym_l.4";
    }
        elsif ($file=~/^9887_7#12$/  ) {
        $file = "Hym_l.5";
    }
        elsif ($file=~/^9887_8#12$/  ) {
        $file = "Hym_l.6";
    }
    else {
        $file=~s/#/-/;
    }

    $file =~s/PC2-7/PC2/;
    $file =~s/PC2-9/PC2/;
    $file =~s/PC2-11/PC2/;
    $file =~s/PC3-21/PC3/;
    $file =~s/PC3-16/PC3/;
    $file =~s/PC3-22/PC3/;
#    my @arr2 = split(/\./,$file);
  #    $file=$arr2[0];
    $file=~s/\.forBEDToolsOnly\.UNsorted\.raw_mapQ30//g;
    push(@files3, $file);
    #print "FILE :$file:\n";
}


# make header
my $files = join ("\t", @files3);

print OUT "$files\n";
print OUT2 "$files\n";
#print  "$files\n";

# print data

foreach my $gene (sort keys %h) {
    my $exp = join ("\t", @{$h{$gene}});
    print OUT "$gene\t$exp\n";
}

foreach my $gene (sort keys %h2) {
    my $exp = join ("\t", @{$h2{$gene}});
    print OUT2 "$gene\t$exp\n";
}



close (OUT);
close (OUT2);

exit;


=pod	
11440_1#12	aPS
11449_1#24	aPS
11450_1#12	aPS
11440_1#7	Cyst wall
11440_1#10	EGU_naPS
11449_1#22	EGU_naPS
11450_1#10	EGU_naPS
11440_1#13	Larvae
11449_1#1	Larvae
11450_1#13	Larvae
11440_1#8	MCana
11449_1#20	MCana
11450_1#8	MCana
11440_1#4	MCnoBC
11449_1#17	MCnoBC
11450_1#5	MCnoBC
11440_1#9	MCu
11449_1#21	MCu
11450_1#9	MCu
11440_1#5	MCvitro
11449_1#18	MCvitro
11450_1#6	MCvitro

11440_1#6	MCvivo
11449_1#19	MCvivo
11450_1#7	MCvivo
11440_1#11	naPS
11449_1#23	naPS
11450_1#11	naPS
11440_1#1	PC1
11449_1#14	PC1
11450_1#2	PC1

11440_1#2	PC2
11449_1#15	PC2
11450_1#3	PC2
11440_1#3	PC3
11449_1#16	PC3
11450_1#4	PC3

=cut





