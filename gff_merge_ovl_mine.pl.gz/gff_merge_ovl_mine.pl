#!/usr/bin/perl -w

# mz3 script for merging overlapping exons from the same transcript/gene,
# but not from different ones

use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff_merge_ovl.pl input.gff mode


input.gff.exon	Input gff-file, where exons belonging to same gene/transcrip have the same name


Output:
overlapped  .gff


Mode = "whatever you say, "


'

}


my $in = shift;
my $mode=shift;


system "cat $in | sort -k1,1 -k9,9 -k4,4n > $in.tmp";

open (IN, "<$in.tmp") || die "I can't open $in.tmp\n";
	my @in = <IN>;
	close (IN);


open (OUT, ">$in.novls.gf") || die "I can't open $in.novls.gf\n";

my @res;

my $start="0\t0\t0\t0\t0\t0\t0\t0\t0\t0";

my $wip = shift(@in);
chomp $wip;

foreach my $line (@in) {
	chomp $line;

	#print "$wip\n";
	my @a=split(/\t/, $line);
	my @b=split(/\t/, $wip);

	# is same chromosome
	if ( $a[0]=~/$b[0]/ ) {

#=pod
		# is overlapping with feature in memory and is same gene
		if ($a[3]<$b[4] and $a[8]=~/$b[8]/) {

			# if it is longer extend
			if ($a[4]> $b[4]) {
				$b[4]=$a[4];
				print "ovl $b[0]\t$b[3]\t$b[4]\t$a[0]\t$a[3]\t$a[4]\n";
			}
		}

		# is overlapping with feature in memory and is not same gene
		elsif ($a[3]<$b[4]) {
			print "dvl $b[0]\t$b[3]\t$b[4]\t$a[0]\t$a[3]\t$a[4]\n";
			# just start the new gene, no trim
			if ($mode=~/\w+/) {
				print OUT "@b\n";
				@b=@a;				
			}
			else {
				print OUT "@b\n";
				@b=@a;			
			}
		}

		# is not overlapping with feature in memory
		# write previous feature
		# update b
		else {
			print "nvl $b[0]\t$b[3]\t$b[4]\t$a[0]\t$a[3]\t$a[4]\n";		
			print OUT "@b\n";
			@b=@a;
		}
#=cut
	}
	else {
		# is not same chromosome
		# write previous feature

		print OUT "@b\n";
		@b=@a;
	}

	$wip=join("\t",@b);
	#print "WIP:$wip:\n";

}

print OUT "$wip\n";

close(OUT);

system "cat $in.novls.gf | sort -k1,1 -k4,4n > $in.novls.gff";
system "rm -f $in.tmp";
system "rm -f $in.novls.gf";

exit;






