#!/usr/local/bin/perl -w
# mz3 script for choosing sequence length of fastq

# use List::Util qw(max);

sub USAGE {
die '

Perl-program for choosing DNA sequences over a certain length.

Usage <input-file> <output-filename> <filter length>
Ex. choose_length.pl input.fas output.fas 500

Written by: mz3@sanger.ac.uk

'
}

unless (@ARGV == 3) {
        &USAGE;
}

    my $input_file = shift;
    my $output_file =shift;
    my $size = shift;


open(F, "<$input_file") or die "$!";
# open(OUT, ">$output_file") or die "$!";

my @input = <F>;

# my @lengths = '';
# my $count= 0;
#for ($count = 0; $count < 10; $count++)  {

foreach my $string (@input) {
chomp $string;
print "$string"; <STDIN>;
print substr $string,0,100; <STDIN>;
}

__END__

=pod

foreach my $line (@input) {
 chomp $line;
   # skip the first line of every chunk
   if ($line =~/^\@F*$/)   	{
#	print "$line\n";<STDIN>;
  	 }
   elsif ($line =~/^\+$/)   {
#	print "$line\n"; <STDIN>;
 	 }
   else {
		print "Line_start: $line \n";  #<STDIN>;
		# Make a note of all lengths
		my $length = (length $line);
		push (@lengths, $length);
#		print "Length: $length \n"; <STDIN>;		
			if ($length > 100) {
				chomp $line;
				print "Line_finish: $line \n"; #<STDIN>;
			}
	}


#}

}



__END__



    print the remaining lines
   elsif ($line > 100) {
        print "$line\n";
   }

}
my @lengths = '';

foreach my $line (@input) {
	my $length = length $line;
	push (@lengths, $length);
}

print "@lengths \n";
$lengths_length = ($#lengths + 1);
print "no number $lengths_length \n";
my $max_value = 0;
my $max_index = 0;

for (my $i = 0; $i < $lengths_length; $i ++) {
	 if ($lengths[$i] > $max_value) {
		$max_index = $i;
		$max_value = $lengths[$i];
	}
}

print "Max $max_index\n"; # or $max_value, or an array with both in either order. 

close (OUT);

__END__

my $tmp= $lengths[0];

map {$tmp=$_ 
	if ($_>$tmp and $_=~/^-?\d*.?\d*$/s and $_=~ /\d/}  @lengths
die("The array doesn/'t contain any numbers ") 
	unless ($tmp=~ /\d/);
print "Temp: $tmp \n";

__END__

my $counter = 

foreach my $line (@input) {

if length $line > 100 {
	chomp;
}


}




__END__


$\ = "@";
foreach my $row (@input) {
next unless (/^\@(.*)$/);
#next unless (/^\@/);
my $line = @input;
print OUT $line;
my $important_stuff = $1;
push (@sequences, $important_stuff); 
}

#print "$input[0]\n\n";
#print "$input[1]\n\n";







__END__

