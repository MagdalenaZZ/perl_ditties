#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~/bin/perl/interpro2pfam.pl gff





';

}




my $gff = shift;

open (GFF, "<$gff") || die "Cant find file $gff\n";
open (OUT, ">$gff.pfam") || die "Cant open file $gff.pfam\n";
open (OUT2, ">$gff.go") || die "Cant open file $gff.go\n";
open (OUT3, ">$gff.phobius.tm") || die "Cant open file $gff.phobius.tm\n";
open (OUT4, ">$gff.phobius.sp") || die "Cant open file $gff.phobius.sp\n";


#open (OUT3, ">$gff.prod") || die "Cant open file $gff.prod\n";

# read in Pfam info

open (PFAM, "</nfs/users/nfs_m/mz3/bin/perl/Pfam.index.txt") || die "Cant find file  ~mz3/bin/perl/Pfam.index.txt - ask Magdalena about it\n";


my %pfam;

while (<PFAM>) {
    chomp;
    my @line = split(/\t/, $_);

    $pfam{$line[1]}=$line[0];
    #print "$line[0]\t$line[1]\n";
}


# process gff

my %goterm;
my %phobius;

while (<GFF>) {
    my @arr = split(/\t/,$_);
    if ($arr[1]=~/Pfam/) {
        #print "$arr[0]\t$arr[3]\t$arr[4]\t$arr[8]\n";

        my @ann = split(/;/,$arr[8]);


        my $id = $arr[0];
        my $start = $arr[3];
        my $end = $arr[4];
        my $pfam;
        my $desc;
        my $source = "Domain";
        my $no1 = "1";
        my $no2 = "1";
        my $no3 = "1";
        my $no4 = "1";
        my $no5 = "1";
        my $no6 = "1";
        my $na = "NA";
        my $go = "NA";



        foreach my $line (@ann) {

            if ($line=~/^Name/) {
                $pfam=$line;   
                $pfam=~s/Name=//;

                # get right Pfam ID
                if (exists $pfam{$pfam}) {
                    $desc=$pfam{$pfam};
                }
            }
            # elsif ($line=~/^signature_desc=/) {
                #$desc=$line; 

                #    }
            elsif ($line=~/^Ontology_term="/) {
                $go=$line; 
                $go=~s/Ontology_term=//;
                $go=~s/"//g;
                if ($go!~/NA/) {
                    my @argo = split(/\,/, $go);
                    foreach my $elem (@argo) {
                        #print OUT2 "$id $go\n";
                        #print "PRINT $id $elem\n";
                        $goterm{$id}{$elem}=1;
                    }
                }
            }



        }


        print OUT "$id\t$start\t$end\t$start\t$end\t$pfam\t$desc\t$source\t$no1\t$no2\t$no1\t$no2\t$no3\t$no4\t$no5\t$no6\t$na\n";
    
    }
    elsif ($arr[1]=~/Phobius/) {

        if ($arr[8]=~/TRANSMEMBRANE/) {
            $phobius{$arr[0]}{"TM"} +=1;
        }
        elsif ($arr[8]=~/SIGNAL_PEPTIDE/) {
            $phobius{$arr[0]}{"SP"} =1;
        }



    }
    else {
        # ignore
    }


}


foreach my $es (sort keys %phobius) {

    if (exists $phobius{$es}{TM}) {
        print OUT3 "$es\t$phobius{$es}{TM}\n";
    }
    if (exists $phobius{$es}{SP}) {
        print OUT4 "$es\t$phobius{$es}{SP}\n";
    }

}


foreach my $gene2 (sort keys %goterm) {
    print OUT2 "$gene2\t";
    my $gotm;
    foreach my $gos (sort keys %{$goterm{$gene2}}) {
        $gotm = $gotm . ",$gos";
    }
    $gotm =~s/\,//;
    print OUT2 "$gotm\n";

}




=pod
TMUE_s0071000800    125    192    124    193 PF00542.14  Ribosomal_L12     Domain     2    67    68     62.3     3e-17   1 No_clan
TMUE_s0071000900     54     99     54     99 PF00095.16  WAP               Domain     1    43    43     37.1   2.2e-09   1 CL0454
TMUE_s0071000900    106    149    106    149 PF00095.16  WAP               Domain     1    43    43     35.4   7.6e-09   1 CL0454
TMUE_s0071001000    305    382    298    395 PB013406    Pfam-B_13406      Pfam-B   340   416   452     19.2   0.00056  NA NA
=cut

close(OUT1);
close(OUT2);
close(OUT3);
close(OUT4);

exit;

__END__

x  39323 Phobius
x  16550 Pfam
  15803 PANTHER
  15623 Gene3D
  14836 SUPERFAMILY
  14306 .
  11724 TMHMM
  11045 SMART
  10079 PRINTS
   9585 ProSiteProfiles
   4393 Coils
   4376 ProSitePatterns
   1388 SignalP_EUK
    727 TIGRFAM
    641 SignalP_GRAM_POSITIVE
    465 PIRSF
    295 SignalP_GRAM_NEGATIVE
    178 Hamap





