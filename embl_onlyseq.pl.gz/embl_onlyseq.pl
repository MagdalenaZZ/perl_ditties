#!/usr/bin/perl -w

use strict;
use File::Slurp;
use Cwd;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/embl_onlyseq.pl input-folder


Input needs top be a folder of embl-files with annotation and sequences 
The output is a file not containing the sequence -only the annotation


'
}

my $folder = shift;

# Get the right info for the folder

my $cwd = cwd();

my @paths = read_dir( "$folder", prefix => 1 ) ;

if ($folder =~m/\//) {	
	if (-d "$folder") {
#		print "If: $folder\n";
		foreach my $elem (@paths) {
			$elem = "$folder\/$elem";
		#	print "$elem\n";
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
#		print "Else: $cwd\/$folder\n";
		foreach my $elem (@paths) {
			$elem = "$cwd\/$folder\/$elem";
#			print "$elem\n";
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

open (OUT, ">temp") || die "I can't open temp\n";


foreach my $elem (@paths) {
chomp $elem;
# print "$elem\n";
#}

#__END__
	if ($elem =~/\.embl/)  {
# chomp $elem;
#	print "Elem:$elem:\n";
		my @arr = split(/\// ,$elem);
#	print "Arr1:$arr[-1]:\n";
		my $outfile = $arr[-1];
		$outfile =~s/short\.//;
		$outfile =~s/more\.//;
#		print "Out:$outfile:\n";
		open (IN, "<$elem") || die "I can't open $elem\n";
		open (OUT, ">$outfile") || die "I can't open $outfile\n";
		my @arr2 = <IN>;

		foreach my $line (@arr2) {
			chomp $line;
#			print "$line\n";
			if ($line=~/ID/) {
				$line=~s/short\.//;
				$line=~s/more\.//;
				$line=~s/\.final//;
				print OUT "$line\n";
			}
			elsif ($line=~/FH/) {
				print OUT "$line\n";
			}
			elsif ($line=~/FT/) {
				$line=~s/gene/locus_tag/;
				print OUT "$line\n";
				if ($line=~/CDS/) {
					print OUT "FT                   /colour=1\n";
				}
			}
#			elsif ($line=~/SQ/) {
#				print OUT "$line\n";
#			}
			elsif ($line=~/\/\//) {
				print OUT "$line\n";
			}

		}

	close (IN);
	close (OUT);
#		unless ()  { # OUT exists and has a value
#		}

# Check that the file really contains a CDS
		open (TEST, "<$outfile") || die "I can't open $outfile\n";
		my @test = <TEST>;
		close (TEST);
		my $element = "CDS";
		my @found;
		if (@found = grep(/\b$element\b/,@test)) {
  			   # $output = join(",",@found);
 #   			  $output =~s/,*$//; # just in case of empty elements at the end of the array
#			system "rm -f $outfile";
   # 			  print "CDS in $outfile\n";
		}
		else {
			system "rm -f $outfile";
   #			   print "Sorry, \"$element\" not found in $outfile\n";
		}
	


	}

}

system "rm -f temp";



__END__

ID                   short.pathogen_HYM_scaffold_33_9.final ; ; ; ; ; 82146 BP.
FH   Key             Location/Qualifiers
FH 
FT                  
SQ   Sequence 82146 BP; 26578 A; 16253 C; 15701 G; 23614 T; 0 other;
