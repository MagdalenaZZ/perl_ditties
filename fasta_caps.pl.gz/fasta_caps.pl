#!/usr/local/bin/perl -w




use strict;

unless (@ARGV == 1) {
        &USAGE;
}

my $fasta = shift;

open (IN, "<$fasta") || die "I can't open $fasta\n";
open (OUT, ">$fasta.caps") || die "I can't open $fasta.caps\n";


my @fasta = <IN>;

my $final_N = 0;
my $final_AT = 0;
my $final_GC = 0;
my @contam;

foreach my $line (@fasta) {
chomp $line;
# filter headers

	if ($line =~ m/>/) {
	print OUT "$line\n";
	}
	else {
        $line =~ tr/Nn/N/;
        $line =~ tr/Aa/A/;
        $line =~ tr/Gg/G/;
        $line =~ tr/Tt/T/;
        $line =~ tr/Cc/C/;
	    print OUT "$line\n";
	}

}


close (OUT);


sub USAGE {

die '
Usage: 
perl ~/bin/perl/fasta_caps.pl fasta 

mz3 script for making DNA-sequences all caps

'
}




