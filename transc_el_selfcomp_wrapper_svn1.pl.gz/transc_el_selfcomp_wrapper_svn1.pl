#!/usr/bin/perl -w
#converts BLAST outfmt 6 to Artemis-style gff entries.
#Usage BLAST2joined_fasta.pl <input_BLAST_outfmt6> >output-file

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: transcriptome_eliminate_self-complimentary_wrapper.pl fasta

Takes a fasta-file, blasts each sequence against itself and determines wether it is self-complimentary.
If it is, the programme tries to break it.

NOT FINISHED!!!!!

'
}

# read the fasta and make blasts against itself 
my $in =shift;

#system "perl ~mz3/bin/perl/transcriptome_eliminate_self-complimentary.pl $in"; wait;


# pick the output, and run against itself again

#system "perl ~mz3/bin/perl/transcriptome_eliminate_self-complimentary.pl $in.res.list.in_list.all_split.fasta"; wait;


# read in the fasta
open (FAS, "<$in.res.list.in_list.all_split.fasta.res.list.in_list") || die "I can't open $in.res.list.in_list.all_split.fasta.res.list.in_list\n";

my %fas;
$/ = ">";

while (<FAS>){
    my @arr = split(/\s+/,$_);
    #print "$arr[0]\t$arr[1]\n";
    $fas{$arr[0]}="$arr[1]";
}

$/ = "\n";


# read in the blast

open (BLA, "<$in.res.list.in_list.all_split.fasta.tmp.all.blast") || die "I can't open $in.res.list.in_list.all_split.fasta.tmp.all.blast\n";



# figure out what is going on with the sequence
# store in a hash containing:  $res {$query} {errors} = "coordinates";

my $seen = 0;
my %res;

while (<BLA>){
    my @line = split(/\s+/,$_);
    #print "\n $line[0]\n";
    #$fas{$arr[0]}="$arr[1]";
    my $query = $line[0];
    my $target = $line[1];
    my $similarity = $line[2];
    my $bitscore = $line[3];
    my $basechanges = $line[4];
    my $indels = $line[5];
    my $querystart = $line[6];
    my $queryend = $line[7];
    my $targetstart = $line[8];	
    my $targetend = $line[9];
    my $evalue = $line[10];	
    my $score = $line[11];
    my $qdiff = $queryend - $querystart;
    my $tdiff = $targetend - $targetstart;

    # length of sequence
    my $len = length(  $fas{$query}  );
    # now test what is wrong with the sequences
    
    # filter
   if ( $evalue > 0.0001) {
      # ignore
   }
    
    
    # primary complement
    elsif ($querystart==$targetstart and $queryend==$targetend ) {
        # do nothing
        #print "\nSAME: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
        #print "$len\t$fas{$query}\n";
        #$right{$query}{"$ele"}=1;
        $seen = "0";
        $res{$query}{"SAME"}= "$_";
    }
    # prefect palindrome
    #my @same = split(/\t/,$res{$query}{"SAME"});

    
    elsif ( "$querystart" == "$targetend" and "$queryend" == "$targetstart" ) {    
             
    # if it is full length, see by input
    
        if ( $querystart=~/^1$/ and $queryend=~/^$len$/ ) {
            $res{$query}{"PER_PAL"}= "$_";
            # else do sth else 
            #print "PER PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";

        }
        else {
            #print "PAL: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
            $res{$query}{"PAL"}= "$_";
        }
    }
    # reverse complement complete - second hit
    elsif ( $qdiff>0 and $tdiff<0 and $seen=~/$query/ ) {    
        #print "2ND REV: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"2ND"}= "$_";
    }
    # reverse complement complete - first hit
    elsif ( $qdiff>0 and $tdiff<0  ) {    
        #print "1ST REV: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"1ST"}= "$_";
         $seen = $query;
    }
    elsif ( $qdiff>0 and $tdiff<0  ) {    
        #print "DIFF: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
         $res{$query}{"DIFF"}= "$_";
    }
    else {
        #print "ELSE: $querystart\t$queryend\t$targetstart\t$targetend\t$query\n";
        $res{$query}{"ELSE"}= "$_";
    }


#    $seen = $query ;

}




# deal with the sequences

my %nseq;

foreach my $gene (keys %res ) {
    
    my @arr;

    foreach my $key (keys %{$res{$gene}} ) {

        push ( @arr, $key);

    }

    my @sorted = sort(@arr);
    my $string = join(" ", @sorted);
    #print "$gene\t$string\n";

    my $seq = "$fas{$gene}";
    my $len = length($fas{$gene});

# if there is a perfect palindrome covering the whole length, split in two and keep both parts
# recognise by keys: SAME amd PERPAL

    if ($string =~/^PER_PAL SAME$/){ 

        my $half = int($len/2);
        #print "ORI: $gene\t$len\t$half\t$seq\n";
        print "ORI: $gene\t$seq\n";

        my $seq1 = substr($seq, 0 ,($half-1) );
        my $seq2 = revcomp(substr($seq, $half, -1 ));
        my $gene1 = $gene . "_1"; 
        my $gene2 = $gene . "_2";
        print "RES: $gene1\t$seq1\n$gene2\t$seq2\n";
        $nseq{$gene1}="$seq1";
        $nseq{$gene2}="$seq2";
    }

# if there is a perfect palindrome, but a sticky-out bit, then ....
# recognise by SAME and PERPAL2
    #elsif {
    #}
    else {
        print "Warning, don't know how to deal with: $string\n";
        $nseq{$gene}="$seq";
    }


}

print "\n\n";




# now print your lovely new sequences

open (OUT, ">$in.tmp.fas") || die "I can't open $in.tmp.fas\n";


foreach my $gen (sort keys %nseq) {
    print OUT ">$gen\n$nseq{$gen}\n";
}

close (OUT);

# clean up things
system "cat $in.res.list.in_list.all_split.fasta.res.list.not_in_list $in.tmp.fas > $in.norevcomp.fas ";
#system "rm -f $in.res.list.not_in_list";
system "rm -f $in.tmp.fas";

exit;


sub revcomp {
        my $dna = shift;

	# reverse the DNA sequence
        my $revcomp = reverse($dna);

	# complement the reversed DNA sequence
        $revcomp =~ tr/ACGTacgt/TGCAtgca/;
        return $revcomp;
}



__END__

#ghsfghsfdghsdh
