#!/usr/bin/perl -w

use strict;

unless (@ARGV == 1 or @ARGV == 2 ) {
        &USAGE;
}


sub USAGE {

    die '


Usage: qc_pipeline.pl file.fastq (file2.fastq)


This pipeline makes a shell script which it submits as a job.
It subsamples 1.000.000 reads from the sample and

-Calculates length
-Does fastqc

If two files are given they are assumed to be PE reads

' . "\n";

}


#print OUT "Hi2\n";

# If only one file


my $in=shift;

open (OUT, ">$in.qc.sh") || die "I can't open $in.qc.sh\n";

# Make a job for subsampling 1 million PE reads
#system "qsub  -q short.q -l h_vmem=1G -pe multi_thread 1 -b y  -V -cwd  -N seqtksub \"~/bin/seqtk/seqtk sample -s1000 $in 1000000 > $in.sub1000000.fq\"";
print OUT "~/bin/seqtk sample -s1000 $in 1000000 > $in.sub1000000.fq";
print OUT "\n";

# Do initial read length histogram

print OUT "head -1000 $in.sub1000000.fq | awk '{if(NR%4==2) print OUT length}' | textHistogram -maxBinCount=310 stdin > $in.len";
print OUT "\n";
# gzip

print OUT "gzip -r $in.sub1000000.fq";
print OUT "\n";
# Do fastqc on them
my $fol = "$in" . ".FQC";
print OUT "mkdir $fol";
print OUT "\n";
print OUT "fastqc --extract --o $fol   $in.sub1000000.fq.gz";
print OUT "\n";
print OUT "echo \"Read the full FastQC report:\"\n";
print OUT  "echo \"firefox $fol/$in.sub1000000.fq_fastqc.html &\" > $in.docu\n";
print OUT "\n";
print OUT "cat $fol/$in.sub1000000.fq_fastqc/fastqc_data.txt | grep '>>' | grep -v END_MODULE";
print OUT "\n";
# clean up after fastqc
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc/fastqc.fo\n";
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc/fastqc_report.html\n";
print OUT "rm -fr  $fol/$in.sub1000000.fq_fastqc/Icons/\n";
print OUT "rm -fr  $fol/$in.sub1000000.fq_fastqc/Images/\n";
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc.zip\n";
print OUT "gzip -r $fol\n";
print OUT "mv $fol/*/* $fol\n";
print OUT "rm -fr $fol/$in.sub1000000.fq_fastqc/\n";


# if two files
my $in1;
my $in2;
$in1=$in;


if (@ARGV==1) {

my $in=shift;
$in2 = $in;

open (OUT, ">$in.qc.sh") || die "I can't open $in.qc.sh\n";

# Make a job for subsampling 1 million PE reads
#system "qsub  -q short.q -l h_vmem=1G -pe multi_thread 1 -b y  -V -cwd  -N seqtksub \"~/bin/seqtk/seqtk sample -s1000 $in 1000000 > $in.sub1000000.fq\"";
print OUT "~/bin/seqtk sample -s1000 $in 1000000 > $in.sub1000000.fq";
print OUT "\n";

# Do initial read length histogram

print OUT "head -1000 $in.sub1000000.fq | awk '{if(NR%4==2) print OUT length}' | textHistogram -maxBinCount=310 stdin > $in.len";
print OUT "\n";
# gzip

print OUT "gzip -r $in.sub1000000.fq";
print OUT "\n";
# Do fastqc on them
my $fol = "$in" . ".FQC";
print OUT "mkdir $fol";
print OUT "\n";
print OUT "fastqc --extract --o $fol   $in.sub1000000.fq.gz";
print OUT "\n";
print OUT "echo \"Read the full FastQC report:\"\n";
print OUT  "echo \"firefox $fol/$in.sub1000000.fq_fastqc.html &\" > $in.docu\n";
print OUT "\n";
print OUT "cat $fol/$in.sub1000000.fq_fastqc/fastqc_data.txt | grep '>>' | grep -v END_MODULE";

print OUT "\n";

#print OUT "Hi\n";

# clean up after fastqc
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc/fastqc.fo\n";
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc/fastqc_report.html\n";
print OUT "rm -fr  $fol/$in.sub1000000.fq_fastqc/Icons/\n";
print OUT "rm -fr  $fol/$in.sub1000000.fq_fastqc/Images/\n";
print OUT "rm -f  $fol/$in.sub1000000.fq_fastqc.zip\n";
print OUT "gzip -r $fol\n";
print OUT "mv $fol/*/* $fol\n";
print OUT "rm -fr $fol/$in.sub1000000.fq_fastqc/\n";

}
else {
	$in2 ="SINGLE";
}






# Now do mapping







# Map those reads to human, mouse and fusion proteins


# Count up where they map



# count insert size


# Do overlap merging


# Do full read length histogram

#print OUT "cat  $1.sub1000000.fq.gz#### | awk '{if(NR%4==2) print OUT length}' | textHistogram -maxBinCount=110 stdin";
#print OUT "\n";



if ($in2=~/SINGLE/) {
print  "qsub  -l h_vmem=1G -b y  -V -cwd  -N qc bash $in1.qc.sh\n";
system  "qsub  -l h_vmem=1G -b y  -V -cwd  -N qc bash $in1.qc.sh";
}
else {
# submit jobs
print  "qsub -l h_vmem=1G -b y  -V -cwd  -N qc bash $in1.qc.sh\n";
print  "qsub -l h_vmem=1G -b y  -V -cwd  -N qc bash $in2.qc.sh\n";
system  "qsub -l h_vmem=1G -b y  -V -cwd  -N qc bash $in1.qc.sh";
system "qsub -l h_vmem=1G -b y  -V -cwd  -N qc bash $in2.qc.sh";

}


# Make a summary-file of all data


exit;


