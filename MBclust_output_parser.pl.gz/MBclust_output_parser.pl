#!/usr/bin/perl
use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV > 1) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~/bin/perl/mbclust_output_parser.pl reference-list <condition-size> <group-size>


reference-list  - list of all genes in your genome
<condition-size>  - integer - the fewest number of groups you want the cluster to be retrieved in
<group-size> - integer - the groups with smallest number of genes you want to retrieve

A condition size larger than half the amount of tried cluster numbers (k) guarantees that not the same gene appears in many different clusters.

Takes an output from MBclust, where lots of different cluster numbers have been tried, and are in folders

clust_1
clust_2
clust_n

It merges the results from each clustering to one file, and then merges them together.


Example:
perl ~/bin/perl/mbclust_output_parser.pl  EMU.list 5 30


If you don\'t get any output try relaxing the parameters


';

}

my $ref = shift;
my $condition_size = shift;
my $group_size = shift;
my $fasta = shift;


# get a list of cluster files



my $cwd = cwd();
my $cwd2;

my @paths = read_dir( "$cwd", prefix => 1 ) ;

my $i = 0;

#=pod

# read in folders and file and process to file tot.list

foreach my $folder (@paths) {

# find right folder
    if ( $folder =~/clust_(\d+)/ ) {
        chdir "$folder";
        #print "$folder\n";
        my $fol = $1;

        my $cwd2 = cwd();
        my @path2 = read_dir( "$cwd2", prefix => 1 ) ;

        # find right files

        foreach my $file (@path2) {
            if ($file=~/cluster\d+\.list$/ and (!-f "$fol.tot.lis") ) {

                #print "$file\t1\t$fol\n";
                my @arr = split (/\//, $file);
                my $fil=$arr[-1];
                $fil=~s/\.list//;
                system "cat $file | awk '{print \$1\"\\t$fol$fil\"}' >> $fol.tot.lis";
                #print  "cat $file | awk '{print \$1\"\\t\"$fol$fil}' >> tot.lis\n";

            }
        }

        chdir "cd ..";

    }
}

chdir "$cwd";


#=cut 

# make output
#
open (OUT, ">$ref.sh") || die "Cant open file $ref.sh  \n  $!";
#print "Made $ref.sh\n";

my $res = $ref;

my $cwd3 = cwd();

#print "cwd $cwd3\n";

foreach my $folder (@paths) {

# find right folder
    if ( $folder =~/clust_(\d+)/ ) {
        #chdir "$folder";
        #print "$folder\n";
        my $fol = $1;
        #print "$folder/$fol.tot.lis\n";

        if ( -e  "$folder/$fol.tot.lis" ) {
            system "perl /nfs/users/nfs_m/mz3/bin/perl/tab_list_co-ordinator.pl $res 1 $folder/$fol.tot.lis 1 1  $res\_$fol ";wait;
            #print OUT "perl /nfs/users/nfs_m/mz3/bin/perl/tab_list_co-ordinator.pl $res 1 $folder/$fol.tot.lis 1 1  $res\_$fol ;\n";
            #print "perl /nfs/users/nfs_m/mz3/bin/perl/tab_list_co-ordinator.pl $res 1 $folder/$fol.tot.lis 1 1  $res\_$fol ;\n";

            $res =  "$res\_$fol";
        }
        else {
            #print "$folder/$fol.tot.lis \n";
        }
    }
}

close (OUT);

#system "bash $ref.sh";wait;

print  " $res \n";


open (RES, "<$res") || die "Cant open file $res\n" ;

my %res;


while (<RES>) {
    chomp;
    #print "$_\n";

    my @arr = split(/\t/,$_);
    my $gene = shift @arr;

    @arr = grep { $_ =~/\w+/ } @arr;

    #foreach my $ele (@arr) {

        #unless ($ele=~/\w+/) {
        #    delete
        #}
        # print "$ele\n"; 
        #}

    my $len = scalar(@arr);

    
    #print "$len\n";
    if ( $len > $condition_size  ) {
        my $group = join("_", @arr);
        $group=~s/cluster/-/g;
        $group=~s/^_//g;
        $group=~s/ _//g;

        #print "$gene\t$group\n";

        $res{$group}{$gene}=1;
    }


}



# now dump files with all the group sizes and fasta

foreach my $gr (sort keys %res) {

    my $len = scalar( keys %{$res{$gr}} );

    if ( $group_size < $len) {
        open (OUT, ">$gr.group") || die "$!";
        foreach my $gen (sort keys %{$res{$gr}}) {
            print OUT "$gen\n";
        }
        close (OUT);
        system "perl ~mz3/bin/perl/fasta_retrieve_subsets.pl $fasta $gr.group";
        system "perl ~/bin/perl/topGO_starter.pl $gr.group clust_10/EMU_2013_06_09.gff.GOtop BP clust_10/EMU_2013_06_09.prod $gr.group ";

    }

}

system "rm -f *.group.not_in_list";



# now calculate go-terms for them









exit;



