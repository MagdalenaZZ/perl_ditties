#!/usr/bin/perl
use strict;
#use Clone qw(clone);

unless (@ARGV > 3) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/wiggleJunkie.pl bam-file file.fas <coverage int>  <anchor length>




It will only output features present in <converage int> reads or more
and features with an anchor length of <anchor length> or more for all mapped fragments

The anchor length is how much of a read is present on either side of a splice-junction.
If the anchor length is 10, a read which is 100bp long and split with 95 bp on one side of the junction and 5 bp on the other side will be filtered away.
The same read with 25 bp on one side and 75 bp on the other side will be kept




';

}


my $in = shift;
my $fas = shift;
my $cov = shift;
my $anc = shift;
my $maxim = 20000;
my $depth = 5;
my $merge = 20;

print "\nSuccessful 1\n";


# run bump-caller and junction-finder on bam-file
  
print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc\n"; 
unless (-s "SAM_extract_junctions/pathogens_HYM_contig_0013.bam.$in.$cov") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc"; wait;
}

print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in $fas $cov $maxim $depth\n"; 
unless (-s "pathogens_HYM_contig_0013.bam.PE.$cov.$maxim.gff") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in $fas $cov $maxim $depth";  wait;
}

print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas\n";
system "/nfs/users/nfs_m/mz3/bin/overlappingperl/wj_make_genome.pl $fas"; wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split\n";  
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split";  wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;

print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 5 $merge\n"; 
system "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 5 $merge";  wait;

print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED 10 $merge\n";
system "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED 10 $merge";  wait;


print "\nSuccessful 2\n";



# Test if all files are made like they should
print "\n\n";


unless (-s "$in.$cov.$anc.gff") {
    print "You file $in.$cov.$anc.gff is not getting produced as expected, check the script SAM_extract_junctions.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff") {
    print "You file $in.$cov.$anc.gff.genomeCoverageBed.bga.gff is not getting produced as expected, check the script coverage2feature.pl to make sure it is working\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 5 $merge";
    print "\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED 10 $merge";
    print "\n";
    die;
}

unless (-s "$fas.genome") {
    print "You genome-file is not getting produced as expected, check the script wj_make_genome.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.split" or -s "$in.genomeCoverageBed.bga") {
    print "You file $in.$cov.$anc.gff.genomeCoverageBed.bga.split is not getting produced as expected, check the BEDtools genomeCoverageBed  to make sure it is working\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split  ";
    print "\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga  ";
    print "\n";
    die;
}


print "\nSuccessful 3\n";





# read the junctions file, and make groups of junctions

system "perl ~/bin/perl/junctions2feature.pl $fas $in.$cov.$anc.gff";
print "perl ~/bin/perl/junctions2feature.pl $fas $in.$cov.$anc.gff\n";


print "\nSuccessful 4\n";





__END__





# now merge in free-floating CDS to closest gene

system "cat $in.trans.gff | grep -w gene > $in.trans.gene.gff ";
system "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/closestBed -a  $in.trans.left.gff -b $in.trans.gene.gff -d -t first > $in.trans.left.merged.gff ";
print "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/closestBed -a  $in.trans.left.gff -b $in.trans.gene.gff -d -t first > $in.trans.left.merged.gff \n";

open(IN3, "<$in.trans.left.merged.gff") || die "Cant read file $in.trans.left.merged.gff";



while (<IN3>) {
    chomp ;
    my @arr = split(/\t/,$_);

    # check if the distance is small to closest gene

    if ($arr[18] < 2000) {

    # if it is, add it to the right gene

    #print "Shorter than 2000 $arr[18]\n";
        
        my $i2 = $arr[17];
        $i2=~s/ID=//;
        if (exists $groups{$arr[0]}{$i2}{"F"}) {
            my $line = "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]";
            push (@{$groups{$arr[0]}{$i2}{F}},"$line");

        }
        else {
            print "Warning: Can't find gene $arr[17]\n";
        }
    }
    # if not - make a new gene
    else {
        #print "Too long $i $arr[18]\n";
        
        # add feature to group
        $groups{$arr[0]}{$i}{SE}="$arr[3]\t$arr[4]";
        $groups{$arr[0]}{$i}{ORI}="\.";
        my $line = "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]";
        push (@{$groups{$arr[0]}{$i}{F}},"$line");
        $i++;


    }


}





#### print the results out #######


# print the resulting intron-groups


open(OUT3, ">$in.final.gff") || die "Cant read file $in.final.gff";

foreach my $scaf (sort keys %groups) {

    #print "$scaf\n";
    
    foreach my $i (sort { $a <=> $b }  keys %{$groups{$scaf}}) {



        #foreach my $key (sort { $a <=> $b }  keys %{$groups{$scaf}{$i}}) {
        my $coord =$groups{$scaf}{$i}{"SE"};
        my $ori =$groups{$scaf}{$i}{"ORI"} ;
        #print "$scaf\t$i\t$coord\n";


        my @int = @{ $groups{$scaf}{$i}{"F"} };


        #foreach my $ele (@int) {
            #print "$ele\n";
            #}

        if (scalar(@int)> 0) { 
            #my $first = @int[0];
            my $last = @int[-1];
            #my @min = split(/\t/,$first);
            my @max = split(/\t/,$last);
            #my $min = $min[3];
            #my $max = $max[4];
            if ($ori=~/^\.$/) {
                $ori = $max[6];
            }

            if ($ori=~/^$/) {
                #print "No ori\n";
                $ori="\.";
            }    
    
            print OUT3  "$scaf\tassigned\tgene\t$coord\t.\t$ori\t.\tID=$i\n";
            print OUT3 "$scaf\tassigned\tmRNA\t$coord\t.\t$ori\t.\tID=$i.1;Parent=$i\n";

            foreach my $ele (@int) {
                # find min
                # find max
                


                if ($ele=~/$max[0]/ and $ele=~/CDS/) {

                    #my @arx = split(/\t/, $ele);
                    #$arx[6]=$ori;
                    #my $el = join("\t",@arx);
                    $ele=~s/\t\+\t/\t$ori\t/;
                    $ele=~s/\t\-\t/\t$ori\t/;
                    $ele=~s/\t.\t.\t.\t/\t.\t$ori\t.\t/;
                    print OUT3 "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }
                else {
                    #print OUT3 "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }

            }
        }
        else {
            # print leftovers in separate file
            print  "Warning: @int\n";
        }
    }

}

$i++;
close (OUT3);










exit;



#### sub for translating non-spliced genes
#
#
#
#
