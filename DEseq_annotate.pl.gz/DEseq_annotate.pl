#!/usr/local/bin/perl -w

use strict;
use Math::Round;
use Sort::Fields;  
#use Data::Dumper;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: DEseq_annotate.pl folder pval MER-index KO-index TF-index



'
}


my $folder= shift;
my $pval= shift;
my $mer= shift;
my $ko= shift;
my $tf= shift;


my %h;

# read in scores file

#perl ~/bin/perl/tab_list_co-ordinator.pl X 1 X 1 3 X.score" */lib.dat.down.list.prod | sed 's/lib.dat.down.list.prod/scores.dat3/' > scores.down.sh
#"perl ~/bin/perl/tab_list_co-ordinator.pl X 1 X 1 3 X.score" */lib.dat.up.list.prod | sed 's/lib.dat.up.list.prod/scores.dat3/' > scores.up.sh

open (IN , "<$folder/scores.dat2") || die "\nCant open file $folder/scores.dat2 \n\n ";
open (OUT , ">$folder.annotated.txt") || die "\n Cant open file for output $folder.annotated.txt\n\n";

while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    if ( $_!~/^id/ ) {
        #print "$arr[1]\t$arr[6]\t$arr[8]\n";
        #my $rounded = sprintf "%.0f", $float;

        if ($arr[3]=~/\d+/) {
                $arr[3] = sprintf("%.1f", $arr[3]);
        }
        if ($arr[4]=~/\d+/) {
            $arr[4] = sprintf("%.1f", $arr[4]);
        }
        if ($arr[6]=~/\d+/) {
            $arr[6] = sprintf("%.1f", $arr[6]);        
        }
        if ($arr[8]=~/\d+/) {
        #$arr[6]=~s/Inf/10000000000/;
            $arr[8] = sprintf("%.1e ", $arr[8]);
        }
        #print "$arr[1]\t$arr[6]\t$arr[8]\n";

        # fold change - Padj - Mean A   - Mean B
        $h{$arr[1]}="$arr[6]\t$arr[8]\t$arr[3]\t$arr[4]";
    }
}
close (IN);

my %hup;
my %hdown;

open (IN , "<$folder/lib.dat.up.list.prod") || die;
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    if (exists $h{$arr[0]}){
        #print "$arr[0]\t$arr[1]\t$h{$arr[0]}\n";
        $hup{$arr[0]}="$arr[1]\t$h{$arr[0]}";
    }
    else {
        print "This should NOT happen!!!\n";
    }
}
close (IN);

open (IN , "<$folder/lib.dat.down.list.prod") || die;
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    if (exists $h{$arr[0]}){
        #print "$arr[0]\t$arr[1]\t$h{$arr[0]}\n";
        $hdown{$arr[0]}="$arr[1]\t$h{$arr[0]}";
    }
    else {
        print "This should NOT happen!!!\n";
    }
}
close (IN);




### make output with all read-counts


open (IN , "<$folder/lib.dat.up.list.prod") || die;
#open (IN , "<$folder/lib.dat.up") || die;
open (OUT3 , ">$folder/lib.dat.diff.prod.txt") || die;

print OUT3 "Direction\tGene\tLog2fold change\tPvalue\tAverage count A\tAverage count B\tProduct name\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    push (@arr, " ");
    if (exists $h{$arr[0]}){
        print OUT3  "UP\t$arr[0]\t$h{$arr[0]}\t$arr[1]\n";
        #$hup{$arr[0]}="$arr[1]\t$h{$arr[0]}";
    }
    else {
        print "3. This should NOT happen!!!\n";
    }
}

#close (OUT3);
close (IN);




open (IN , "<$folder/lib.dat.down.list.prod") || die;
#open (IN , "<$folder/lib.dat.up") || die;
#open (OUT3 , ">$folder/lib.dat.down.prod.txt") || die;

#print OUT3 "Direction\tGene\tLog2fold change\tPvalue\tAverage count A\tAverage count B\tProduct name\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    push (@arr, " ");
    if (exists $h{$arr[0]}){
        print OUT3  "DOWN\t$arr[0]\t$h{$arr[0]}\t$arr[1]\n";
        #$hup{$arr[0]}="$arr[1]\t$h{$arr[0]}";
    }
    else {
        print "4. This should NOT happen!!!\n";
    }
}

close (OUT3);
close (IN);








#__END__

my @sorted;

# make output with mers

my @mers;

open (IN , "<$mer") || die "\nCant open file $mer\n\n";

print OUT "\n\nProteases/protease inhibitors up-regulated\t\n\n";
print OUT "Merops\tGene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hup{$arr[0]} and $arr[1]=~/\w+/) {
        #print "$arr[1]\t$arr[0]\t$hup{$arr[0]}\n";
        #$h{$arr[1]}="$arr[6]\t$arr[8]";
        push (@mers, "$arr[1]\t$arr[0]\t$hup{$arr[0]}");
    }
}
close (IN);


@sorted = fieldsort '\t', [  '-4n' ], @mers; 

foreach my $ele (@sorted) {
    $ele=~s/\t-inf\t/\tInf.\t/; 
    print OUT "$ele\n";
}

# DOWN

@sorted='';

@mers='';

open (IN , "<$mer") || die;

print OUT "\n\nProteases/protease inhibitors down-regulated\t\n\n";
print OUT "Merops\tGene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hdown{$arr[0]} and $arr[1]=~/\w+/) {
        #print "$arr[1]\t$arr[0]\t$hup{$arr[0]}\n";
        #$h{$arr[1]}="$arr[6]\t$arr[8]";
        push (@mers, "$arr[1]\t$arr[0]\t$hdown{$arr[0]}");
    }
}
close (IN);


@sorted = fieldsort '\t', [ '4n' ], @mers; 

foreach my $ele (@sorted) {
    $ele=~s/\t-inf\t/\tInf.\t/; 
    print OUT "$ele\n";
}

@sorted='';






# make output with kos



# get ko
#
my %KEGG;

open (IN , "</nfs/users/nfs_m/mz3/bin/perl/KEGG_paths.tab") || die;
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    my $kohead = shift(@arr);
    $KEGG{$kohead }=join("\t", reverse(@arr));
}

close (IN);




my @kos;

open (IN , "<$ko") || die;

print OUT "\n\nGenes in pathways up-regulated, (up to 100 with largest fold-changes) \t\n\n";
print OUT "Process\tContext\tPathway\tPathway ID\tGene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hup{$arr[0]} and $arr[1]=~/^ko\w+/ and exists $KEGG{$arr[1]} ) {
        #print "$KEGG{$arr[1]}\t$arr[1]\t$arr[0]\t$hup{$arr[0]}\n";
        #$h{$arr[1]}="$arr[6]\t$arr[8]";
        push (@kos, "$KEGG{$arr[1]}\t$arr[1]\t$arr[0]\t$hup{$arr[0]}");
    }
    elsif (exists $hup{$arr[0]} and $arr[1]=~/\w+/) {
        #print "Missing $_\n";
    }
}
close (IN);

my @sorted2 = fieldsort '\t', [ '-7n' ], @kos; 
@kos = splice @sorted2, 0, 100;

@sorted = fieldsort '\t', [ '1', '2' , '3' ], @kos; 

foreach my $ele (@sorted) {
    $ele=~s/\t-inf\t/\t\'Inf.\t/;   
    print OUT "$ele\n";
}

@sorted2='';
@sorted='';
@kos='';

## DOWN
#

open (IN , "<$ko") || die;

print OUT "\n\nGenes in pathways down-regulated, (up to 100 with largest fold-changes) \t\n\n";
print OUT "Process\tContext\tPathway\tPathway ID\tGene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hdown{$arr[0]} and $arr[1]=~/^ko\w+/ and exists $KEGG{$arr[1]} ) {
        push (@kos, "$KEGG{$arr[1]}\t$arr[1]\t$arr[0]\t$hdown{$arr[0]}");
    }
    elsif (exists $hdown{$arr[0]} and $arr[1]=~/\w+/) {
        #print "Missing $_\n";
    }
}
close (IN);

@sorted2 = fieldsort '\t', [ '7n' ], @kos; 
@kos = splice @sorted2, 0, 100;

@sorted = fieldsort '\t', [ '1', '2' , '3' ], @kos; 

foreach my $ele (@sorted) {
    $ele=~s/\t-inf\t/\tInf.\t/;
    print OUT "$ele\n";
}

@sorted='';
@kos='';







# make output with TFs



my @tfs;

open (IN , "<$tf") || die;

print OUT "\n\nTranscription factors up-regulated, (up to 100 with largest fold-changes) \t\n\n";
print OUT "Gene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\tDomain(s)\tDomain description(s)\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hup{$arr[0]} and $arr[1]=~/\w+/ ) {
        #print "$arr[0]\t$hup{$arr[0]}\t$arr[1]\t$arr[2]\n";
        #$h{$arr[1]}="$arr[6]\t$arr[8]";
        push (@tfs, "$arr[0]\t$hup{$arr[0]}\t$arr[1]\t$arr[2]");
    }
    elsif (exists $hup{$arr[0]} and $arr[1]=~/\w+/) {
        #print "Missing $_\n";
    }
}
close (IN);



@sorted2 = fieldsort '\t', [ '-3n' ], @tfs; 
@tfs = splice @sorted2, 0, 100;

#@sorted = fieldsort '\t', [ '1', '2' , '3' ], @tfs; 

foreach my $ele (@tfs) {
    $ele=~s/\t-inf\t/\tInf.\t/; 
    print OUT  "$ele\n";
}

@sorted='';
@tfs='';


##DOWN

open (IN , "<$tf") || die;

print OUT "\n\nTranscription factors down-regulated, (up to 100 with largest fold-changes) \t\n\n";
print OUT "Gene_ID\tProduct name\tlog2fold change\tP-value\tExpr A\tExpr B\tDomain(s)\tDomain description(s)\n";
while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (exists $hdown{$arr[0]} and $arr[1]=~/\w+/ ) {
        push (@tfs, "$arr[0]\t$hdown{$arr[0]}\t$arr[1]\t$arr[2]");
    }
    elsif (exists $hdown{$arr[0]} and $arr[1]=~/\w+/) {
        #print "Missing $_\n";
    }
}
close (IN);



@sorted2 = fieldsort '\t', [ '3n' ], @tfs; 
@tfs = splice @sorted2, 0, 100;

#@sorted = fieldsort '\t', [ '1', '2' , '3' ], @tfs; 

foreach my $ele (@tfs) {
    $ele=~s/\t-inf\t/\tInf.\t/; 
    print OUT  "$ele\n";
}

@sorted='';
@tfs='';












exit;



__END__

#system "perl ~/bin/perl/tab_list_co-ordinator.pl X 1 Hmic.hyper.TF.anno 1 3 X.TF */*list.prod.score";
#system "perl ~/bin/perl/tab_list_co-ordinator.pl X 1 Hmic.hyper.TF.anno 1 3 X.TF */*list.prod.score";

#system "cat Hym_l_vs_Hym_ww/lib.dat.up.list.prod.score.TF | grep HmN | cut -f1,2,3,4,5,6 | sort -t$'\t' -k2gr";
#system "cat Hym_l_vs_Hym_ww/lib.dat.down.list.prod.score.TF | grep HmN | cut -f1,2,3,4,5,6 | sort -t$'\t' -k2g";



# print "@ARGV\n";

my $prefix = shift;

my @files = @ARGV;

foreach my $file (@files) {

    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$4}' > $file.1  ";
    system "cat $file | grep -v RPKM | awk '{print \$1\"\t\"\$3}' > $file.2  ";

}




my $folder= shift;

