#!/usr/local/bin/perl -w
# mz3 script 


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV == 1 ) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: remove_N_fasta.pl folderlist

'
}

my $prefix = shift;


open (IN, "<$prefix") || die;


    my $N_tot = 0 ;


while (<IN>) {
    chomp;


    open (TMP, "<$_") || die;
    my @tmp = <TMP>;
    shift @tmp;
    my $N_count ;

    foreach my $line (@tmp) {
    #system "cat $_ > test.fa";
      $N_count = $line =~ tr/Nn//;
      $N_tot = $N_tot +$N_count  ;

    }

    #system "fasta2singleLine.py test.fa  test.fa.sl ";
    #system "stats test.fa.sl  ";
    print "$_\t$N_tot\n";
    $N_tot = 0 ;
}



   22948.pts-86.farm3-head3        (24/10/13 16:15:42)     (Attached)
        18923.pts-29.farm3-head3        (24/10/13 16:09:25)     (Attached)


select * from progress;
show tables;
select * from job where status='FAILED';
update job set status='READY' where analysis_id=3;

