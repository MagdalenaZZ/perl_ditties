#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: go_parent_children_finder.pl list_of_GOs

Finds children and parents of a list of GO-terms

'
}

	my $go = "/nfs/users/nfs_m/mz3/bin/perl/gene_ontology_ext.obo";
#    print "\nReading $go\n";

	open (IN, "<$go") || die "\nI can't open $go\nDownload it from http://www.geneontology.org/ontology/obo_format_1_2/gene_ontology_ext.obo\n\n";
	my @go = <IN>;
	close (IN);


# parse the file

my %rel;
my $id = 0;
my $name = 0;
my $namespace = 0;
my $isa = 0;


foreach my $line (@go) {
    chomp $line;

    if ($line =~/^id:/) {
        $line =~s/id://;
        $line=~s/\s//g;
        $id = $line;
    }
    elsif ($line =~/^name:/) {

        $name = $line;
    }
    elsif ($line =~/^namespace:/) {
        $namespace = $line;
    }
    elsif ($line =~/^is_a:/) {
        my @arr = split(/!/, $line);
        $arr[0]=~s/\s//g;
        $arr[0]=~s/is_a://;
        $isa = $arr[0];
        $rel{$id}{"child"}{$isa} = $arr[1];
        $rel{$id}{"term"}{$namespace} = $name;
#        print "$id\t$isa\t$arr[1]\n";
    }
    elsif ($line =~/^$/) {
        $id = 0;
        $name = 0;
        $namespace = 0;
        $isa = 0;
    }
    else {
        # do nothing
    }

}


# make whole tree
my %tree;
    
$tree{"GO:0008150"};
$tree{"GO:0005575"};    
$tree{"GO:0003674"};



# read in list
    my $in = shift;
	open (IN, "<$in") || die "\nI can't open $in\n";
	my @in = <IN>;
	close (IN);


   # find children

foreach my $term (@in) {
    chomp $term;
#    print "Term: $term\n";
    
#    foreach my $go (keys %rel) {
        if (exists $rel{$term}) {
            print "\n$term\t";
            foreach my $key (keys %{$rel{$term}{"child"}} ) {
                print "$key\t";
                push ( @in, $key);
            }
        }
#    }
 

}

# find parents


foreach my $term (@in) {
    chomp $term;
#    print "Term: $term\n";

 

}





__END__


my $start = 0;
my $end = 0;
my $last_line = 0;

my @out;

foreach my $line (@in) {


my $last_start =$start ;
my $last_end =$end;

my @arr =split (/\s+/, $line);

$start = $arr[3];
$end = $arr[4];
my $cont = $arr[0];

if ($last_line=~/$cont/) {
#	if ($last_start <= $start ) {
#	print "Start in right order\n";
#	}
#	elsif ($last_end <= $end ) {
#	print "End in right order\n";
#	}
	if ($last_end >= $start ) {
#		if ($last_line=~/$cont/) {
	print "Cont $cont\n";
	print "Overlapping features: $line";
	print "Overlapping features: $last_line";
	print "$last_end bigger than $start \n";

    # take the last line and merge with this one if they are the same
    #
    #
    #
    #
    

		}
    else {
        push ( @out,  $line);
    }
}


$last_line = $line;


}

