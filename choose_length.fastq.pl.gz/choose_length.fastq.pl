#!/usr/local/bin/perl -w
# mz3 script for sorting and choosing sequence length

use strict;
    use Bio::SeqIO::fastq;

sub USAGE {
die '

Perl-program for choosing DNA sequences over a certain length.

Usage <input-file> <output-filename> <filter length>
Ex. choose_length.pl input.fas output.fas 500

Nor working because of Bio::SeqIO::fastq

Written by: mz3@sanger.ac.uk

'
}

unless (@ARGV == 3) {
        &USAGE;
}


    my $input_file = shift;
    my $output_file =shift;
    my $size = shift;

my %hash;
my $key;

open (INFILE, "$input_file");
open (OUTFILE, ">$output_file");
open (TEMP, ">temp");

my @array = <INFILE>;
my $prefix = substr $array[0],1,9;
# print "Prefix: $prefix\n";<STDIN>;

my $count = 0;

foreach my $line (@array) {
	chomp $line;
	if ($line =~/$prefix/) {
#	tr />//d;
#	print "matching prefix", $line; <STDIN>;
	$key = $line;
#	$count ++;
	}
	elsif ($line =~/^\+$/) {
	$line=$line."x".$count;
	$key = $line;
#	print "plus",  $line; <STDIN>;
	$count ++;
	}
	else {
	$hash{$key} = $line;
#	print "sequence",  $line; <STDIN>;	
	}
	
}

foreach my $sequence (keys %hash)  {
	
	my $length = length ($hash{$sequence});
		if ($length >= $size) {
	print TEMP "$sequence\n$hash{$sequence}\n";
	}

}

close (TEMP);

open (TEMP2, "<temp");

my @temp = <TEMP2>;

foreach my $row (@temp) {
	if ($row =~ /$prefix/) {
	print OUTFILE "NAME:  ", $row;
	}
	elsif ($row =~ /\+/) {
	my ($var, $var2 )= split (/x/, $row );
	print OUTFILE "PLUS:  ", $var, "\n";
	}
	else {
	print OUTFILE "SEQ:  ", $row;
	}


}

# system `rm -f temp`;


# system `cat temp | awk -F x '{print $1}' > $output_file`;


# system "rm -f temp" ; 
# system "rm -f temp2" ; 

close (INFILE);
close (OUTFILE);
close (TEMP);
close (TEMP2);

__END__


=pod

    my $input_file = shift;
    my $output_file =shift;
    my $size = shift;

    my $seq_in  = Bio::SeqIO->new( -format => 'fastq',
                                   -variant   => 'solexa',
                       -file => $input_file);

    # loads the whole file into memory - be careful
    # if this is a big file, then this script will
    # use a lot of memory

    my $seq;
    my @seq_array;
    while( $seq = $seq_in->next_seq() ) {
       push(@seq_array,$seq);
    }

    # now do something with these. First sort by length,
    # find the average and median lengths and print them out

    @seq_array = sort { $a->length <=> $b->length } @seq_array;

    my $total = 0;
    my $count = 0;
    foreach my $seq ( @seq_array ) {
       $total += $seq->length;
       $count++;
    }

 #   print "Mean length ",$total/$count," Median ",$seq_array[$count/2]->length,"\n";



#         my $outfile = shift or die $usage;
#         my $outfileformat = shift or die $usage;

      # create one SeqIO object to read in,and another to write out
         my $seq_out = Bio::SeqIO->new('-file' => ">temp",
                                       '-format' => 'fastq',
                                        '-variant'   => 'solexa',
					);

        # write each entry in the input file to the output file
         foreach my $seq (@seq_array) {
         $seq_out->write_seq($seq);
         }

# choose of a certain length


system '/nfs/helminths/users/mz3/mh12/python/fasta2singleLine.py temp temp2';
open (INFILE, "temp2");
open (OUTFILE, ">$output_file");

my %hash;
my $key;

while (<INFILE>) {
	chomp;
	if (/^\>/) {
	tr />//d;
	$key = $_;
	}

	else {
	$hash{$key} .= $_;
	}
	
}

foreach my $sequence (keys %hash)  {
	
	my $length = length ($hash{$sequence});
		if ($length >= $size) {
	print OUTFILE "\>$sequence\n$hash{$sequence}\n";
	}


}

system "rm -f temp" ; 
system "rm -f temp2" ; 

close (INFILE);
close (OUTFILE);



__END__


	my $line = $_;
	push $line ;

#	if (scalar($_) > $size)  {
#	print "$_ /n";
#	}

}


         exit;


__END__

         # create one SeqIO object to read in,and another to write out
         my $seq_in = Bio::SeqIO->new('-file' => "<$infile",
                                      '-format' => $infileformat);


 
