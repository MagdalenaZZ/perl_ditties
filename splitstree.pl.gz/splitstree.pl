#!/usr/bin/perl
use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~mz3/bin/perl/splitstree.pl alignment.mfa



';

}


my $in = shift;
my $cu = 0;

open(IN, "<$in") || die;
open(OUT, ">$in.out") || die;

my %seqs;
my $len = "X";


while (<IN>) {

    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/\>//;
        my $seq = <IN>;
        chomp $seq;
        if (length($seq)==$len or $len=~/X/){
            $len = length($seq);
            #$seqs{$head}=$seq;

            my @arr = split(//, $seq);
            foreach my $char (@arr) {
                push(@{$seqs{$head}}, $char);
            }


        }
        else {
            die 'unequal lengths';
        }
    }
}

my $i = 0;

my %dist;
my %uniq;

# %dist{tax1}{$tax2}= dist;

while ($i < $len ) {

    my @arr;
    # get the character for that taxa
    foreach my $key (sort keys %seqs) {
        #print "$key\t$seqs{$key}[0]\n";
        unless (exists $uniq{$key}) {
            $uniq{$key}="0";
        }
        my $uniq="yes";

        # find out if it is unique
        foreach my $prev (@arr) {
            my($tax1, $cha1)=split(/\t/,$prev);

            if ($seqs{$key}[0]=~/$cha1/){
                #print "same $seqs{$key}[0] $cha1 $key $tax1\n";
                #$dist{$key}{$tax1}+=1;
                $uniq="no";
            }
            else {
                #print "diff $seqs{$key}[0] $cha1 $key $tax1\n";
                #$dist{$key}{$tax1}+=0;
            }
        }
        #print "Uniq? $uniq\n";

        # compare that with the character for every other taxa

        foreach my $prev (@arr) {
            my($tax1, $cha1)=split(/\t/,$prev);

            if ($seqs{$key}[0]=~/$cha1/ and $uniq=~/no/){
                #print "same $seqs{$key}[0] $cha1 $key $tax1\n";
                $dist{$key}{$tax1}+=1;
            }
            elsif ($uniq=~/no/) {
                #print "diff $seqs{$key}[0] $cha1 $key $tax1\n";
                $dist{$key}{$tax1}+=0;
            }
            else {
                $uniq{$key}+=1;
            }

        }

        # add an internal distance for unique

        push(@arr, "$key\t$seqs{$key}[0]");
        shift @{$seqs{$key}};
    }

    $i++;
}


print OUT "graph graphname {\n";
#print OUT "\tnode [shape = circle];\n\tsize=\"3\"\n";

# print nodes
foreach my $key (keys %uniq){
        print OUT "\t$key"."X [label=\"$key\",fontsize=24, color=white]\n"; 
        print OUT "\t$key -- $key" . "X [penwidth = $uniq{$key}]\n";
        print OUT "\t$key [label=\"x\",fontsize=1 , color=white, style=filled, fillcolor=black, shape = circle,size=\"3\" ]\n"; 
    }


# print edges
foreach my $key (keys %dist){

    foreach my $key2 (keys %{$dist{$key}} ){

        if ($dist{$key}{$key2} > $cu) {
            print OUT "\t$key -- $key2 [penwidth = $dist{$key}{$key2}]\n";
            print "$key\t$key2\t$dist{$key}{$key2}\n";
        }
    }
    
}

print OUT "}\n\n";


exit;


__END__

1 1 1 1
2 1
3 1
4 1 1 1 1 1



 cat HYM.fRNA.psl | cut -f10,14 | grep pathogen | tr '|' '\t'| cut -f1,4  > Hmic.fRNA.list
 cat EMU.fRNA.psl | cut -f10,14 | grep pathogen | tr '|' '\t'| cut -f1,4  > Emul.fRNA.list
 cat EGU.fRNA.psl | cut -f10,14 | grep pathogen | tr '|' '\t'| cut -f1,4 > Egran.fRNA.list


