#!/usr/local/bin/perl -w
# serial.pl - the gene product annotator
#
use strict;
use Getopt::Long;
use lib '/nfs/team81/ar11/scripts';
use Seq;

# Given BLAST against Uniprot and orthoMCL run against comparative, annotated
# genome, annotate gene products first with known proteins from that species,
# secondly with annotation from one-to-one orthologues in comparative species
# and thirdly with similar proteins from uniprot.
#
# Annotations follow the following convention, where x is some annotation
#
# "x"			Annotation derived from Uniprot protein in organism of interest
# "x, putative"		Annotation derived from orthologue in comparative genome
# "x, related"		Annotation from best BLAST hit in Uniprot (E < cutoff e.g. 1e-10)
# "hypothetical protein, conserved"	Orthologue exists in comparative genome, but
# 			has no annotation
# "hypothetical protein" 		No homologue with sufficiently low evalue

# should check out how annotation looks without using orthoMCL data



my $help;
my $blast_hits;
my $blast_hits_ann;
my $orthomcl_run;
my $target_ann;
my $query;
my $query_fasta;
my $known;
my $e_cutoff = 1e-10;

GetOptions
(
	"h|help"		=> \$help,
	"k|known:s"		=> \$known,
	"b|blast:s"		=> \$blast_hits,
	"a|blast_ann:s"		=> \$blast_hits_ann,
	"o|ortho:s"		=> \$orthomcl_run,
	"t|target:s"		=> \$target_ann,
	"q|query:s"		=> \$query,
	"f|query_fasta:s"	=> \$query_fasta
);

if($help)
{
	print_usage();
	exit;
}

#unless (@ARGV) {
#        print_usage();
#}

# Selection of annotations that are really non-annotations
my %not_ann = 
(
        "Putative_uncharacterized_protein"      => 1,
	"Predicted_protein"			=> 1,
        "hypothetical_protein"                  => 1,
        "hypothetical protein"                  => 1,
        "hypothetical protein,"                  => 1,
        "undefined_product"                     => 1,
        "hypothetical_protein,_conserved"       => 1,
        "conserved_hypothetical_protein"        => 1,
        "Putative_uncharacterized_protein_precursor"    => 1,
        "Expressed_protein"    => 1,
        "hypothetical"    => 1,
        "mz3"    => 1,
        "=>"    => 1,
        "###########################"    => 1,
	""                                      => 1

);

####################################
# Get query proteins for annotating
# ##################################
open(Q, "<$query_fasta") or die "$!";
my @seqs = <Q>;
close Q;
my $seqs = Seq::parse_fasta(\@seqs);

my %ann = ();
my %ann_note = ();

foreach my $head (sort keys %$seqs)
{
	my @head = split /\s+/, $head;
	$ann{$head[0]} = '';
}

###################################
# Annotate with known proteins
# #################################
if(defined $known)
{
	open(K, "<$known") or die "$!";

	while(<K>)
	{
		chomp;

		my($id, $ann) = split /\t/;

		$ann{$id} = $ann;
		$ann_note{$id} = 'Gene product name based on known protein from Uniprot';
	}
	close K;
}

###################################
# Annotate one-to-one orthologues
# #################################
open(T, "<$target_ann") or die "$!";

my %target_ann = ();

while(<T>)
{
	chomp;

	my($id, $ann) = split /\t/;
	$ann =~ s/\s$//;

	$target_ann{$id} = $ann;
}
close T;

open(CLUST, "<$orthomcl_run") or die "$!";

while(<CLUST>)
{
        chomp;

        my($clust_data, $mems) = split /\t /;

        $clust_data =~ /^\w+\((\d+) genes,(\d+) taxa\)/;
        my $gene_num = $1;
        my $taxa_num = $2;

	next unless $gene_num == $taxa_num;

	my @mems = split / /, $mems;

	my $query_id = '';

	foreach my $mem (@mems)
	{
		my($id, $taxon) = split /\(/, $mem;	
		$taxon =~ s/\)//;

		if ($taxon eq $query)
		{
			$query_id = $id;
		}
		else
		{
			#print "$query_id\t$id\t$target_ann{$id}\n";

			if(exists $target_ann{$id} && exists $not_ann{$target_ann{$id}})
			{
				$ann{$query_id} = "hypothetical protein, conserved";
				$ann_note{$query_id} = "one-to-one orthologue";

				#print "hypothetical protein, conserved\n\n";
			}
			elsif (exists $target_ann{$id})
			{
				my $new_ann = $target_ann{$id};

				$new_ann .= ', putative' unless $new_ann =~ /[pP]utative/;
				$ann{$query_id} = $new_ann;
				$ann_note{$query_id} = "Annotation transferred based on one-to-one orthology with gene $id";
			}
		}
	}
}
close CLUST;

#######################################################
# Annotate as yet unannotated proteins and hypothetical
# conserved proteins based on BLAST hits
# #####################################################

if(defined $blast_hits)
{
open(BLAST, "<$blast_hits") or die "$!";

my %best_blast_hit = ();
my %best_blast_evalue = ();
my %best_blast_ann = ();

while(<BLAST>)
{
	chomp;

	my($q, $t, $seq_id, $alignment_length, $mismatches, $gap_openings, $query_start, $query_stop, $target_start, $target_stop, $evalue, $score) = split /\s+/;

	next unless $evalue <= $e_cutoff;

	# gather best BLAST hits for each query sequence
	if(!exists $best_blast_evalue{$q})
	{
		$best_blast_evalue{$q} = $evalue;
		$best_blast_hit{$q} = $t;
		$best_blast_ann{$t} = '';
	}
	elsif($best_blast_evalue{$q} < $evalue)
	{
		$best_blast_evalue{$q} = $evalue;
		$best_blast_hit{$q} = $t;
		$best_blast_ann{$t} = '';
	}
}
close BLAST;

open(B_ANN, "<$blast_hits_ann") or die "$!";

while(<B_ANN>)
{
	chomp;

	my($id, $ann) = split /\t/;

	if(exists $best_blast_ann{$id})
	{
		$best_blast_ann{$id} = $ann;
	}
}
close B_ANN;

foreach my $id (sort keys %ann)
{
	# If protein is not so far annotated use best BLAST hit if there is one and it is not a useless annotation
	if(exists $not_ann{$ann{$id}})
	{
		if(exists $best_blast_hit{$id})
		{
			if(!exists $not_ann{$best_blast_ann{$best_blast_hit{$id}}})
			{
				# ad hoc lines to exclude problem/uninformative annotation
				next if $best_blast_ann{$best_blast_hit{$id}} =~ /[Ff]ragment/;
				next if $best_blast_ann{$best_blast_hit{$id}} =~ /[Pp]utative/;
				next if $best_blast_ann{$best_blast_hit{$id}} =~ /[Uu]ncharacteri[sz]ed/;
				next if $best_blast_ann{$best_blast_hit{$id}} =~ /[Uu]ndetermined/;
				next if $best_blast_ann{$best_blast_hit{$id}} =~ /whole genome shotgun sequence/;

				#print "BLAST ($best_blast_evalue{$id}) Changing $ann{$id} for $best_blast_ann{$best_blast_hit{$id}}, related\n";
				$ann{$id} = $best_blast_ann{$best_blast_hit{$id}} . ', putative';
				$ann_note{$id} = "Annotation based on BLAST hit to $best_blast_hit{$id} in Uniprot with Evalue $best_blast_evalue{$id}";
			}
		}
	}
	else
	{
		#print "Not changing $id $ann{$id}\n";
	}
}
}


# For those proteins not yet annotated
# annotate with "hypothetical protein"

foreach my $id (sort keys %ann)
{
	if($ann{$id} eq '')
	{
		$ann{$id} = 'hypothetical protein';
		$ann_note{$id} = '';
	}
}

###################################
# Print final annotations
################################
foreach my $id (sort keys %ann)
{
	print "$id\t$ann{$id}\t$ann_note{$id}\n";
}

sub print_usage
{
	my $err_msg = shift;

	print <<USAGE;

	#######################
	# serial.pl
	# #####################
	# Annotation of gene products
	# ###########################
	# AUTH: Adam Reid
	# DATE: 7/5/09
	# ###########################

	"h|help"		=> Print this message
	"k|known:s"		=> Known proteins from query organism (e.g. swissprot)
	"b|blast:s"		=> -m 8 blast report against e.g. Uniprot
	"a|blast_ann:s"		=> Annotation for prots in Uniprot
	"o|ortho:s"		=> orthomcl output between query and comparator
	"t|target:s"		=> Annotation for comparator
	"q|query:s"		=> Name of query in orthomcl
	"f|query_fasta:s"	=> File of query proteins to annotate

USAGE

	print "$err_msg\n" if defined $err_msg;
}	
