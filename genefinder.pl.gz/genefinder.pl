#!/usr/local/bin/perl
#!/usr/bin/perl -w
# GeneFinder program
################################################################################

print "---------------------------------------------------------------\n" ;
print "Ruben T. Almaraz\n" ;
print "ECS 189K, Assigment 1\n" ;
print "GeneFinder program\n" ;
print "---------------------------------------------------------------\n\n" ;

################################################################################

 

 

################################################################################

# I tried different things and I think the easier way for the user and

# programmer is to cut and the paste the seq of interest here. If a server is

# available, HTML can be used to interface with perl and summit the seq that way.

$DNA_seq = "ATGTCAATGTAACGCGCTACCCGGAGCTCTGGGCCCAACCGTGGTACTAATTTCATCCACT" ;

################################################################################

 

################################################################################

# This sentence prints the original sequence.

print "Here is the starting DNA(5'->3'):\n$DNA_seq\n\n" ;

################################################################################

# Original DNA to complementary DNA (template).

# all bases are substituted by their complements,

# A->T, T->A, G->C, C->G

$DNA_seq =~ tr/ ACGTacgt / TGCAtgca / ;

# This sentence reverses the sequence to 5'->3'

$comDNA = reverse $DNA_seq ;

print "Here is the complementary DNA(5'->3'):\n" ;

print "$comDNA\n\n" ;

 

################################################################################

# The next set of commands transcribe the complementary DNA seq into mRNA

# the resulting mRNA should be the same to the original (non template seq)

# but with Us instead of Ts.

$comDNA =~ tr/ ACGTacgt / UGCAugca / ;

print "Here is the mRNA sequence:\n" ;

# This sentence reverses the sequence to 5'->3'

$RNA_seq = reverse $comDNA ;

print "$RNA_seq\n" ;

 

################################################################################

# The next sets of commands search the largest open reading frame.

# The gene starts at the first ATG codon and ends at the first stop codon.

print "\nHere is the largest ORF(5'->3')\n" ;

local $_ = $RNA_seq ;
print "var $_ \n";

while ( / AUG /g ) {

my $start = pos () - 2 ;
print "start $start \n";

if ( / UGA|UAA|UAG /g ) {

my $stop = pos ;
print "stop $stop \n";

$gene = substr ( $_ , $start - 1 , $stop - $start + 1 ), $/ ;

print "Gene: $gene \n" ;

}

}

 

################################################################################

# The next set of commands translates the ORF found above for an amino acid seq.

print "\nTranslated sequence: \n" ;

 

%protein = translate( $gene );

print "\nThe largest reading Frame is:\n\t\t\t" . $protein { "gene" } . "\n" ;

 

print "\n---------------------------------------------------------------\n\n" ;

 

################################################################################

# Input: open reading frame

# Output: each amino acid in the sequence

 

sub translate {

my ( $gene , $reading_frame ) = @_ ;

my %protein = ();

for ( $i = $reading_frame ; $i < length ( $gene ); $i += 3 ) {

$codon = substr ( $gene , $i , 3 );

$amino_acid = translate_codon( $codon );

$protein { $amino_acid }++;

$protein { "gene" } .= $amino_acid ;

}

return %protein ;

}

 

 

################################################################################

# Input: tri-nucleotide codon that tRNA reads

# Output: the 3 letter symbolic representation of the corresponding amino acid.

sub translate_codon {

if ( $_ [ 0 ] =~ / GC[AGCU] /i ) { return Ala;} # Alanine;

if ( $_ [ 0 ] =~ / UGC|UGU /i ) { return Cys;} # Cysteine

if ( $_ [ 0 ] =~ / GAC|GAU /i ) { return Asp;} # Aspartic Acid;

if ( $_ [ 0 ] =~ / GAA|GAG /i ) { return Glu;} # Glutamine;

if ( $_ [ 0 ] =~ / UUC|UUU /i ) { return Phe;} # Phenylalanine;

if ( $_ [ 0 ] =~ / GG[AGCU] /i ) { return Gly;} # Glycine;

if ( $_ [ 0 ] =~ / CAC|CAU /i ) { return His;} # Histine (start codon);

if ( $_ [ 0 ] =~ / AU[AUC] /i ) { return Ile;} # Isoleucine;

if ( $_ [ 0 ] =~ / AAA|AAG /i ) { return Lys;} # Lysine;

if ( $_ [ 0 ] =~ / UUA|UUG|CU[AGCU] /i ) { return Leu;} # Leucine;

if ( $_ [ 0 ] =~ / AUG /i ) { return Met;} # Methionine;

if ( $_ [ 0 ] =~ / AAC|AAU /i ) { return Asn;} # Asparagine;

if ( $_ [ 0 ] =~ / CC[AGCU] /i ) { return Pro;} # Proline;

if ( $_ [ 0 ] =~ / CAA|CAG /i ) { return Gln;} # Glutamine;

if ( $_ [ 0 ] =~ / AGA|AGG|CG[AGCU] /i ) { return Arg;} # Arginine;

if ( $_ [ 0 ] =~ / AGC|AGU|UC[AGCU] /i ) { return Ser;} # Serine;

if ( $_ [ 0 ] =~ / AC[AGCU] /i ) { return Thr;} # Threonine;

if ( $_ [ 0 ] =~ / GU[AGCU] /i ) { return Val;} # Valine;

if ( $_ [ 0 ] =~ / UGG /i ) { return Trp;} # Tryptophan;

if ( $_ [ 0 ] =~ / UAC|UAU /i ) { return Tyr;} # Tyrosine;

if ( $_ [ 0 ] =~ / UAA|UGA|UAG /i ) { return "***" ;} # Stop Codons;

}

################################################################################ 