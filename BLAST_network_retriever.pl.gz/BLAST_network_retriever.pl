#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

if (@ARGV < 3) {
        &USAGE;
}


sub USAGE {

die 'Usage: blast_network_retriever.pl network.pl-output blastDB.fas  query-file

Takes a networked BLAST-result and the database
and retrieves all the hits
and aligns the ones in the same network


'
}

my $blast= shift;
my $db = shift;
my $query = shift;

#my $eval = 0;
#if ( scalar(@ARGV) > 0 ) {
#	$eval = shift;
#}
system "cat $db $query > temp.fas"; 


        open (IN, "<$blast") || die "I can't open $blast\n";
    	my @blast= <IN>;
    	close (IN);

#        open (IN3, "<$in") || die "I can't open $in\n";
#    	my @in= <IN3>;
#    	close (IN3);

        


#    	my @db= <IN2>;

my %hits;
foreach my $line (@blast) {
    chomp $line;
    my @arr = split(/\t/,$line);
    my $net = shift(@arr);
    my $no = shift(@arr);
    foreach my $lx (@arr) {  
    	$hits{$net}{$lx}= 1;
#        print "$net\t$lx\n";
    }
#    print "$arr[1]\n" ;

}

open (IN2, "<temp.fas") || die "I can't open temp.fas\n";

print "\nReading fasta-file\n";

my %files;
mkdir "res";

while (<IN2>) {

    #    print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $1;
	 $seq_name=~s/>//;
	my $seq = <IN2> ;
	chomp($seq) ;
#	print "SEQname:$seq_name:\n";

    foreach my $xs ( keys %hits ) {

        open (OUT, ">>res/$xs.ret.fas") || die "I can't open res/$xs.ret.fas\n";
        
        $files{"res/$xs.ret.fas"}=1;

    	if ($hits{$xs}{$seq_name} ) {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;

    	}
        else {
#			print OUT2 ">$seq_name\n" ;
#			print OUT2 "$seq\n" ;

        }
        close (OUT);
    }


    }
    	
}

close (IN2);

system "rm -f temp.fas";


# do alignment
#

foreach my $ele (keys %files) {

#    print "bsub.py 10 $ele muscle -in $ele  -out $ele.mfa\n";
#    system "bsub.py 10 $ele muscle -in  $ele -out $ele.mfa";

# system ("/software/pubseq/bin/mafft --anysymbol  --retree 2 --reorder $ele > $ele.mfa");  

    system "bsub.py 10 $ele perl ~/bin/perl/phylogenize_me.pl $ele prot aln";

}



