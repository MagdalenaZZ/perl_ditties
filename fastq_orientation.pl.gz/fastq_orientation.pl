#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage:  fastq_orientation.pl fastq_1.fastq fastq_2.fastq

Takes forward and reverse fastq-files, and orients them with the shorter read on the forward strand

The fastq files have to be in the same order


'
}

	my $in = shift;
	my $in2 = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	open (IN2, "<$in2") || die "I can't open $in2\n";
	open (OUT, ">$in.oriented.fq") || die "I can't open $in.oriented.fq\n";
	open (OUT2, ">$in2.oriented.fq") || die "I can't open $in2.oriented.fq\n";



# open the fasta files


while (<IN>) {
chomp;

    # read in
    if ( $_ =~/^@/ and $_=~/\/1$/ ) {

        my $head = $_;
        my $seq = <IN>;
        chomp $seq;
        my $mid = <IN>;
        chomp $mid;
        my $qual = <IN>;
        chomp $qual;

        my $head2 = <IN2>;
        chomp $head2;
        my $seq2 = <IN2>;
        chomp $seq2;
        my $mid2 = <IN2>;
        chomp $mid2;
        my $qual2 = <IN2>;
        chomp $qual2;

        #print "$head\t$seq\t$qual\n";
        #print "$head2\t$seq2\t$qual2\n";        

        my $len1 = length($seq);
        my $len2 = length($seq2);

        # if the first is shorter
        if ($len1 < $len2) {
            
            # these guys are already in forward orientation
            #print "1\n";

            print OUT "$head\n$seq\n+\n$qual\n";
            print OUT2 "$head2\n$seq2\n+\n$qual2\n";  
            
        }

        # if the second is shorter
        elsif ($len1 > $len2) {
            #print "2\n";

            #print  "$head\t$seq\t+\t$qual\n";
            #print  "$head2\t$seq2\t+\t$qual2\n";  

            # these guys need to be reversed
            $seq = reverseComplement($seq);
            $seq2 = reverseComplement($seq2);
            $qual = reverse($qual);
            $qual2 = reverse($qual2);

            print  OUT "$head\n$seq\n+\n$qual\n";
            print OUT2 "$head2\n$seq2\n+\n$qual2\n";  


        }

        else {
            #print "SAME\n";

        }
        

    }


}


close(IN);
close(IN2);
close(OUT);
close(OUT2);



sub reverseComplement{
   $_ = shift;
   tr/ATGC/TACG/;
   return (reverse());
}




exit;


__END__

/nfs/users/nfs_m/mz3/bin/tophat-2.0.9/bin/tophat -o  3_mapped_stranded/test --library-type fr-firststrand -r 300 --mate-std-dev 100 -i 10 -I 40000 -g 40 -a 4 -m 0 emu.v4.ref testOG_1.trimmed.fq2.oriented.fq testOG_2.trimmed.fq2.oriented.fq




--library-type fr-firststrand



bsub.py -q yesterday 5 grep1 
"zcat 0_links/9887_6#8_1.fastq.gz | grep -A 3 -f test01.list > test01_1.fq "
bsub.py -q yesterday 5 grep2 
"zcat 0_links/9887_6#8_2.fastq.gz | grep -A 3 -f test01.list > test01_2.fq "
bsub.py -q yesterday 5 grep3
"zcat 1_trimmed_seqs/9887_6#8_2.fastq.gz.trimmed.fastq.gz | grep -A 3 -f test01.list > test01_2.trimmed.fq "
bsub.py -q yesterday 5 grep4 
"zcat 1_trimmed_seqs/9887_6#8_1.fastq.gz.trimmed.fastq.gz | grep -A 3 -f test01.list > test01_1.trimmed.fq "


bsub.py -q yesterday 5 grep1 bash 1.sh
bsub.py -q yesterday 5 grep2 bash 2.sh 
bsub.py -q yesterday 5 grep3 bash 3.sh
bsub.py -q yesterday 5 grep4  bash 4.sh



 /nfs/users/nfs_m/mz3/bin/tophat-2.0.9/bin/tophat -o  3_mapped_stranded/test --library-type fr-firststrand -r 300 --mate-std-dev 100 -i 10 -I 40000 -g 40 -a 4 -m 0 emu.v4.ref test01_1.trimmed.fq2.oriented.fq test01_2.trimmed.fq2.oriented.fq








