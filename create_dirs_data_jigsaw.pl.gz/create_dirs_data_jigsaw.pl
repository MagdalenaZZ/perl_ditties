#!/usr/local/bin/perl -w

use strict;

my $path = "/lustre/scratch101/sanger/as9/gene_pred/EMU/";

my $snapf = "$path/SNAP/genome/EMU_snap_preds.gff";
my $augf = "$path/augustus/curatedEMU/genome/EMU.fas.27-7-2010_augustus.preds";
my $blastf = "$path/blastp/genome/pathogen_EMU_scaffold_1.blastx";

my %snap = LOAD($snapf);
my %aug = LOAD($augf);
my %blast = LOAD($blastf);

my $psnap = "~ar11/scripts/snap2jigsaw_gff.pl";
my $paug = "~ar11/scripts/augustus2jigsaw.pl";
my $pblast = "~ar11/scripts/blast2jigsaw.pl";

open IN,  "$path/jigsaw/lists/dirs2create.txt";
my $dir = "$path/jigsaw/dirs";
while (<IN>) {
	chomp;
	my $contig = $_;
	mkdir ("$dir/$contig");
	if ($snap{$contig}) {
		open SNAP, ">$dir/$contig/$contig.snap.gff";
		foreach my $line (@{$snap{$contig}}) {
			print SNAP "$line";
		}
		close SNAP;
		system("$psnap $dir/$contig/$contig.snap.gff > $dir/$contig/$contig.snap.gp");
	} 
	if ($aug{$contig}) {
		open AUG, ">$dir/$contig/$contig.aug.gff";
		foreach my $line (@{$aug{$contig}}) {
			print AUG "$line";
		}
		close AUG;
		system("$paug $dir/$contig/$contig.aug.gff > $dir/$contig/$contig.aug.gp");
	}
	if ($blast{$contig}) {
		open BLAST, ">$dir/$contig/$contig.blastx";
		foreach my $line (@{$blast{$contig}}) {
			print BLAST "$line";
		}
		close BLAST;
		system("$pblast $dir/$contig/$contig.blastx > $dir/$contig/$contig.blastx.ph");
	}

}



sub LOAD {
open FILE, "$_[0]";
my %hash;
while (<FILE>) {
	next if (/\#/);
	my $contig = (split /\s+/, $_)[0];
	push (@{$hash{$contig}}, $_);
}
return %hash;
}


