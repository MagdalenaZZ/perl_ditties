#!/usr/bin/perl -w

use strict;



if (@ARGV > 0) {
	print "\n\nUsage: ia_job.pl \n\n" ;

    print " mz3 script for starting an interactive job \n\n";

	exit ;
}



print "qrsh -verbose -pe gpu-mpi 1  > tmpfile\n";
open (IN, "<tmpfile") or die "oops!\n";
my $jobid = 0;
system "cd /users/k1470436/sharedscratch";

while (<IN>) {
    chomp;
    if ($_=~/could not be scheduled/) {
        print "Could not start interactive session because of scheduling\n\n";
    }
    elsif ($_=~/QRLOGIN/) {
        $jobid =(split /\s+/, $_)[2];
        print "export JOB_ID=$jobid\n";
        print "source /opt/apps/scripts/set-int-env\n";
    }
    else {
        print "Could not start interactive session\n\n";
    }

}

exit;


