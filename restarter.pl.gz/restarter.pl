#!/usr/bin/perl -w
use strict;
use Cwd;
use POSIX ();

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die '


Usage: restarter.pl folder

script to restart failed jobs

'
}

my $cwd = cwd();
# print "CWD: $cwd\n";
my @failed;

my $folder = shift;
my $prefix = shift;

chdir $folder ;

my @status = `bsub-out2stats.py *.o.*`;

foreach my $line (@status) {
    chomp $line;
#print "$line\n";

my @arr = split(/\s+/, $line);
    unless ($arr[1]=~m/exit_code/) {
        push (@failed, "$arr[1]\t$arr[7]");
        # print "$arr[1]\t$arr[6]\n";
         }
}

# Restart the failed job
# 
#
my @newjobs;
my %hash;
my $key = 0;

foreach my $line (@failed) {

my @arr = split (/\t/, $line);
#    print "ARR0:$arr[0]\n";
    if ($arr[0] !~m/^0$/) {
        my @out = `cat $arr[1]`;
        print "FAILED:$arr[0]\t$arr[1]\n";
        $hash{$key}{PREFIX}=  $arr[1];


        foreach my $elem (@out) {
            chomp $elem;
#           print "$elem\n";
            if ($elem=~m/Job was executed on host/) {
                    my @arr2=split(/[\<\>]/, $elem);
#                   print "Q:$arr2[3]\n";
                    push (@newjobs, $arr2[3]);
                    $hash{$key}{QUE}=  $arr2[3];
            }
             elsif ($elem=~m/Max Memory/) {
                        my @arr3 = split(/\s+/, $elem);
                        my $mem2 =  $arr3[4]/1000 ;
                         my $mem = POSIX::ceil($mem2);
                         $mem++;
                         push (@newjobs, $mem);
                    $hash{$key}{MEM}=  $mem;
                }

#            Max Memory
            elsif ($elem=~m/Need to reset job with longer time/) {
                #         print "JOB:$elem\n";
            }
            elsif ($elem=~/\// & $elem !~m/>/) {
#                    print "JOB:$elem\t$key\n";
                    push (@newjobs, $elem);
                    $hash{$key}{JOB}=  $elem;
            }
        }


        # Determine error
        if ($arr[0] =~m/^135$/) {
        $hash{$key}{ERR}= "Redo job without bus error"  ;
        }
        elsif ($arr[0] =~m/^140$/) {
           $hash{$key}{ERR}= "Reset job with longer time"  ;
#        print "Need to reset job with longer time \n";
#
                    if ( $hash{$key}{QUE}=~m/normal/) {
                         $hash{$key}{QUE} = "long";
                    }
                    elsif ( $hash{$key}{QUE}=~m/long/) {
                         $hash{$key}{QUE} = "basement";
                    }

        }
        elsif ($arr[0] =~m/^130$/) {
            $hash{$key}{ERR}= "Job killed by owner, resubmit job as is"  ;
        }

        else {
            print "Job with unknown error: $line\n";
            $hash{$key}{ERR}= "Job with unknown error, resubmitted as is"  ;
        }
        $key++;
    }
    else {
        print "WORKED:  $line\n";
    }
}
 print "\n\n";


# my $LSB_JOBINDEX = 0;

foreach my $keys (keys %hash) {
    print "\n\n";
    my $queue =  $hash{$keys}{QUE};
    my $memory =  $hash{$keys}{MEM};
    my $job =  $hash{$keys}{JOB};
    my $err =  $hash{$keys}{ERR};

    my $prefix =  $hash{$keys}{PREFIX};
    my ($a, $b , $jobarray) = split(/\./, $prefix);
    #   print ":$jobarray:$job:\n";

    $job =~s/\$LSB_JOBINDEX/$jobarray/g;


     print "$err:\n bsub.py -q $queue $memory $prefix  $job\nProceed? [y/n]\n";

     if (<STDIN> =~m/y/ ) {
         system "bsub.py -q $queue $memory  $prefix  $job\n";
    }
    else {
        print "Job not relaunched\n";
    }

#my @arr = split(/\t/, $line);
#print "team133-bsub.pl $arr[0] $arr[1] $prefix.o $prefix.e $prefix $arr\n"; 

}
