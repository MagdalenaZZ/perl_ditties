#!/usr/local/bin/perl -w
# mz3 script for making scaffolds from an agp-file and contigs

use strict;

unless (@ARGV == 4) {
        &USAGE;
}

sub USAGE {

die 'Usage: agp_explore_overlaps.pl <final.stats> <file.agp> 

one sequence per line for the fasta-files

'
}

# Read final.stats file

    my $finalstats_file = shift;
    my $agp_file =shift;
    my $input_fasta =shift;
    my $prefix = shift;

open (STATS, "<$finalstats_file");
my @stats = <STATS>;
chomp @stats;

open (AGP, "<$agp_file");
my @agp = <AGP>;
chomp @agp;

open (INFAS, "<$input_fasta");
my @infas = <INFAS>;
chomp @infas;

foreach my $line (@agp) {

# print "$line\n";

# print $line;
# print "\n";
}

#### Get overlap stats from final.stats file
# gives me from scaffold1 to scaffold2 what is the length of the overlap

my @overlaps;
my @scaffolds;
# my @first_mergers = '';
# open (LIST, ">mergers.list");

my $counter2 = 0;

foreach my $line2 (@stats) {

	if ($line2 =~/Merge/) {
		if ($line2 =~/\-veGap/) {
		my($Merge, $veGap, $overlap_length)= split (/\s+/, $line2);
		push (@overlaps, $line2);
#		print "$stats[$counter2-1]\n";
#		print  "$line2\n";
#		print "$stats[$counter2+1]\n";
		my($contig, $scaf1, $scaf2)= split (/\s+/, $stats[$counter2+1]);
		my $newline = "$scaf1\t$scaf2\t$overlap_length";
		push (@scaffolds, "$overlap_length\t$scaf2");	
#		push (@overlaps, "$overlap_length\t$scaf2");
#		print "$newline\n";	
		}
		else {
#		nothing
		}
	}
	else {
	# do nothing
	}
$counter2++;
# print "$counter2\n";
}
### make a list of contigs involved in negative gaps
##### find all the intermediate scaffolds involved too

my @get_scaffolds ;
my @scaffoldno ;

foreach my $line (@scaffolds) {

unless (! defined $line) {
# print "$line\n";
my ($overlap_length, $t1, $prefix1, $dot, $prefix2, $underscore, $prefix3)= split (/([._\t])/, $line);
# $, = "\n";
# print split (/([_\t])/, $line);
#print "End\n";

# print "$overlap_length\t$prefix1\t$dot\t$prefix2\t$underscore\t$prefix3\n";

	if ($overlap_length =~m/\d+/) {
	my $prefix31 = ($prefix3-1);
	my $prefix11 = "$prefix1-1";
 #	my $prefix111 = printf '%05s', ($prefix1-1);   # prints "<000012>"
#	print "$dot$prefix2$underscore$prefix31\t";
# 	my $prefix111 = printf '%05s', ($prefix1);  
#        print "$prefix1$dot$prefix2$underscore$prefix3\t$overlap_length\n";

#	print "$prefix2$underscore$prefix31\t$prefix2$underscore$prefix3\t$overlap_length\n";
	push (@scaffoldno, "$prefix2$underscore$prefix31\t$prefix2$underscore$prefix3\t$overlap_length");
	}

}
}

foreach my $item (@scaffoldno) { 

# print "$item\n";
}


##### Take the line from the agp-file
#### Get overlap stats from agp-file

my $index3=0;
my @new_agp;
my @neg_stat;

# print @agp;

foreach my $line (@agp) {
# print "Line: $line \n";
	my ($scaf, $start, $end, $no, $WN, $contig, $t7, $t8)=split (/\s+/, $line);
#	print scalar(@uniq), "\n";
	if (scalar(@scaffoldno)> 0) {
#		print $uniq[0] , "\n";
#		my ($scaffold0, $dot, $scaffold1, $scaffold2) =  split (/([.\s+])/, $scaffoldno[0]);
		my ($contig1, $contig2, $overlap) =  split (/\t/, $scaffoldno[0]);
# print "$scaffold2\n";
#			print "t6 = $t6 \n";
#			print "s1 = $scaffold1 \n";

			if ($contig=~/$contig1/) {
#				print "If \n";
				push (@new_agp, $line);
#				print "$line\n";
# Make new line			
				my $newline = $agp[$index3+1];
					if ($newline=~/\w/) {
						my ($Nscaf, $Nstart, $Nend, $Nno, $Nn , $Nlength, $Nfragment, $Nyes)=  split (/\s+/, $newline);
#						my $newline2 = "$s1\t$s2\t$s3\t$s4\tW\t$merger\t1\t$length\t+\n";
						my $newline2 = "$Nscaf\t$Nstart\t$Nend\t$Nno\t$Nn\t$overlap\t$Nfragment\t$Nyes";
						my $newline3 = "$Nscaf\t$contig1\t$contig2\t$overlap\t$Nlength";
#						my $newline2 = "$merger\t1\n";
#						my $newline2 = "$length\t+\n";
#						print "$newline3";
#						print "$agp[$index3+2]\n";
						push (@new_agp, $newline2);
						push (@neg_stat, $newline3);
						}
# Move on
				shift (@scaffoldno);
				shift (@agp);			
			}
			else {
			push (@new_agp, $line);
#				print "Else \n";
			}
	}
	else {
		push (@new_agp, $line);
	}
$index3++;	
# print "($index3+1)\n";
}

foreach my $line (@neg_stat) {
# print "$line\n";
}

foreach my $line (@new_agp) {
# print "$line\n";
}


#&# this section needs to be tested!!!!

###### re-calculate lengths
my $start = 1;
my $new_start = 1;
my $end = 0;
my $new_end = 0;
my $length = 0;
my @final_agp ;
my @new_names ;

open (FINAL_AGP, ">$prefix.final.agp");

foreach my $row (@new_agp) {
	chomp ($row);
	my ($s1, $s2, $s3, $s4, $s5, $s6, $s7, $s8, $s9) = split (/\s+/, $row);

	if ($s5=~/N/) {
		$length = $s6;
		$new_start = $new_end + 1;
		$new_end = $new_start + $length-1;
		my $newline = "$s1\t$new_start\t$new_end\t$s4\t$s5\t$s6\t$s7\t$s8";
		print FINAL_AGP "$newline\n";
		push (@final_agp, "$newline");
	}

	elsif ($s5=~/W/) {
		$length = $s8;
		$new_start = $new_end + 1;
		$new_end = $new_start + $length-1;
		my $newline = "$s1\t$new_start\t$new_end\t$s4\t$s5\t$s6\t$s7\t$s8\t$s9";
		print FINAL_AGP "$newline\n";
		push (@final_agp, "$newline");
		push (@new_names, "$s6\n");
	}

	else {
		print "Error\n";
	}

}

__END__

foreach my $line (@final_agp) {
 print "$line\n";
}


###### flesh out the scaffolds again

###### make new fasta to match info

close (NEW_AGP);
close (FINAL_AGP);




__END__






=pod

perl ~/bin/perl/agp_explore_overlaps.pl <final.stats>  <file.agp>

perl ~/bin/perl/agp_explore_overlaps.pl scaffold00002.final.stats scaffold00002.agp

perl ~/bin/perl/agp_explore_overlaps.pl scaffold00002.final.stats scaffold00002.testa.final.agp

perl ~/bin/perl/agp_explore_overlaps.pl final.stats testa.final.agp


perl ~/bin/perl/IMAGE_2agp_neg.pl scaffold00002.final.stats scaffold00002.testa.final.agp new_scaffolds.edited_gt5k.fasta.contigs_sing_n_scaf.fasta prefix2