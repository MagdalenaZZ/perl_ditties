#!/usr/bin/perl
use strict;

unless (@ARGV >0) {
        &USAGE;
}

sub USAGE {

die '

perl ~/bin/perl/SNP_pattern_matcher.pl pattern-file BCF-file


';

}

my $pat = shift;
my $in = shift;


open (IN, "<$in" ) || die "Error \n";

open (PAT, "<$pat" ) || die "Error \n";

open (OUT, "> $in.$pat.match") || die "\nCannot write to file $in.$pat.match\n";
open (OUT2, "> $in.$pat.cleanpatt") || die "\nCannot write to file $in.$pat.cleanpatt\n";
open (OUT3, "> $in.$pat.cleanpatt.noindel") || die "\nCannot write to file $in.$pat.cleanpatt.noindel\n";

my %pats;


while (<PAT>) {
    chomp;
    $pats{$_}+=1;
}

close(PAT);

while (<IN>) {
    chomp;
    my @ar= split(/\t/,$_);
    push(@ar, "END");
    my @ar2 = splice (@ar,18,-1);
    my @ar2 = splice (@ar,9,-1);    
    foreach my $elem (@ar2){
        my @a= split(/\:/, $elem);
        $elem =$a[0];
    }    

    my $patt = join("\t", @ar2);
	if ($patt=~/\w+/) {
    		print OUT2 "$patt\n";
		if ($_!~/INDEL/) {
    			print OUT3 "$patt\n";			
		}	
		else {
			#print "INDEL $_\n";
		}
	}
	#print "@ar2" . "\n";
    if (exists $pats{$patt}) {
        print OUT "$_\n";
#        print "Match\n";
    }
    else {
        #print OUT2 "$_\n";
#        print "No\n";
    }

}

close(IN);

exit;

