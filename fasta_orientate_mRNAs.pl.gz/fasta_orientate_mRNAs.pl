#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

    die '


Usage: fasta_orientate_mRNAs.pl  file.fasta

Takes a fasta-file and descides if the reads are forward or reverse


' . "\n";
}



my $fastq1 = shift;


   open(FAS1, $fastq1) || die "can't open $fastq1";



open (OUT1, ">$fastq1.orientated.fasta")|| die;
open (OUT2, ">$fastq1.dubious.fasta")|| die;
#my $lr1;
#my $lr2;

my $hit = 0;

while (<FAS1>) {

    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/^>//;
        #$head =~s/\/1$//;
        chomp $head;
        #print "match $head\n";
        my $seq = <FAS1>;
        chomp $seq;

        
        my $firstsub= substr($seq,0,100);
        my $lastsub= substr($seq,-100,-1);
        
        my $ori= "";


        if ( $firstsub=~/AAAAAAAAAAA/ and $lastsub=~/TTTTTTTTTTTTT/  ) {
            #print "BOTH $ori\t:$firstsub:\t:$lastsub:\n"; 
            print OUT2 "$_$seq\n";
        }
        elsif ( $firstsub=~/TTTTTTTTTTTTT/ and $lastsub=~/AAAAAAAAAAA/  ) {
            #print "BOTH $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT2 "$_$seq\n";
        }

        elsif ( $lastsub=~/TTTTTTTTTTTTT/ ) {
            #print "CONFUSING $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT2 "$_$seq\n";

        }
        elsif ( $firstsub=~/AAAAAAAAAAA/ ) {
            #print "CONFUSING2 $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT2 "$_$seq\n";

        }
        elsif ( $firstsub=~/TTTTTTTTTTTTT/ ) {
            $seq=revcomp($seq);
            $firstsub= substr($seq,0,100);
            $lastsub= substr($seq,-100,-1);
            #print "REV $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT1 "$_$seq\n";

        }
        elsif ( $lastsub=~/AAAAAAAAAAA/ ) {
            #print "FWD $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT1 "$_$seq\n";
        }

        else {
            #print "ELSE $ori\t:$firstsub:\t:$lastsub:\n";
            print OUT2 "$_$seq\n";
        }



        # print "$_$seq";



    }
}



close (OUT1);
close (OUT2);

close (FAS1);




exit;


sub revcomp {
  my $dna = shift;
  my $revcomp = reverse($dna);

  $revcomp =~ tr/ACGTacgt/TGCAtgca/;

  return $revcomp;
}



