#!/usr/local/bin/perl -w

use strict;
use Spreadsheet::WriteExcel;
Spreadsheet::ParseExcel;
use Spreadsheet::Read;
use Data::Dumper;


unless (@ARGV ==6) {
        &USAGE;
}


sub USAGE {

die 'Usage: excel_write.pl <infile> out-prefix

This program takes an excel spreadsheet and adds hyper-links


'
}

$my $xls = ReadData ("Input/sample.xls");

my $oExcel = new Spreadsheet::ParseExcel; # reads in $ARGV[0]

my $oBook = $oExcel->Parse($ARGV[0]);
my($iR, $iC, $oWkS, $oWkC);
print "FILE  :", $oBook->{File} , "\n";
print "COUNT :", $oBook->{SheetCount} , "\n";

print "AUTHOR:", $oBook->{Author} , "\n"
 if defined $oBook->{Author};


    # Create a new workbook and add a worksheet
    my $workbook  = Spreadsheet::WriteExcel->new("hyperlink.xls");
    my $worksheet = $workbook->add_worksheet('Hyperlinks');
    
    # Format the first column
    $worksheet->set_column('A:A', 30);
    $worksheet->set_selection('B1');
    
    
    # Add a sample format
    my $format = $workbook->add_format();
    $format->set_size(12);
    $format->set_bold();
    $format->set_color('red');
    $format->set_underline();
    
    
    # Write some hyperlinks
    $worksheet->write('A1', 'http://www.perl.com/'                );
    $worksheet->write('A3', 'http://www.perl.com/', 'Perl home'   );
    $worksheet->write('A5', 'http://www.perl.com/', undef, $format);
    $worksheet->write('A7', 'mailto:jmcnamara@cpan.org', 'Mail me');
    
