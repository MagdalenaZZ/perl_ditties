#!/usr/local/bin/perl -w
# mz3 script for making augustus hint-s-file from RNAseq
# do one .psl file at a time

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

## parse infile

my $genome = shift;
my $RNAseq = shift;
my $prefix = shift;

# Run BLAT

my $step1 = "echo \"running Step1 blat\n\"; blat -noHead -maxIntron=20000 $genome $RNAseq $prefix.ali.psl"; 


# Then filter alignments for alignment quality and uniqueness (pairedness doesnt leave anything).

# my $step15 = "echo \"running Step15 blat\n\"; cat $prefix.ali.psl | /nfs/users/nfs_m/mz3/bin/augustus.2.5.5/scripts/filterPSL.pl --best --minCover=80 >  $prefix.ali.f.psl";

# sort the alignments

my $step2 = "echo \"running Step2 sorting\n\"; cat $prefix.ali.f.psl | sort -s -k 10,10 > $prefix.ali.sorted.psl";

# Sort alignments by target sequence and within target sequence by position for further processing

my $step3 = "echo \"running Step3 sorting\n\"; cat $prefix.ali.sorted.psl | sort -n -k 16,16 | sort -s -k 14,14 > $prefix.ali.fs.psl";

# and this 
my $step6 = "echo \"running Step6 hintsIntronsFile\n\"; /nfs/users/nfs_m/mz3/bin/augustus-2.4/scripts/blat2hints.pl --nomult --in=$prefix.ali.fs.psl --out=$prefix.hints.EST.gff";


open CMD, ">$prefix.aug_BLAT2hints.sh";
print CMD "$step1 && $step2 && $step3 && $step6";
close CMD;

 system ("team133-bsub.pl long 15 $prefix.augBLAThints.o $prefix.augBLAThints.e $prefix.augBLAThints sh $prefix.aug_BLAT2hints.sh");



sub USAGE {

die 'Usage: perl augustus_BLAT2hints.pl <genome-file> <RNAseq-file.fasta> <prefix>

All files need to be real - no softlinks 

RNAseq-file needs to contain both forward and reverse reads in fasta-format.

The produced ep-file is missing a line with . - fix it by 


Once you\'ve done all of the files, you can concatenate all files using

cat hints.introns.gff hints.ep.gff  [hints2.gff, hints3.gff]  > hints.gff

No need to bsub - it bsubs itself

'
}

__END__