#!/usr/local/bin/perl -w

use strict;

unless (@ARGV == 4 ) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_adjust_margins.pl ref.fas input.gff <start> <end>

Takes a gff-file and a fasta-file and makes a gff-file with adjusted margins from it.


# make sure the fasta is single-line 


'
}


	my $ref = shift;
	my $in = shift;
	my $start = shift;
	my $end = shift;

    system "samtools faidx $ref";

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (REF, "<$ref.fai") || die "I can't open $ref.fai\n";
	my @ref = <REF>;
	close (REF);

    open (OUT, ">$in.s$start.e$end") || die "I can't open $in.s$start.e$end\n";
# make hash with seq-lengths

my %ref;    
foreach my $line (@ref) {
    my @arr = split(/\t/, $line);

    $ref{$arr[0]} = $arr[1];

}

# adjust positions
foreach my $gene (@in) {
    chomp ($gene);
    my @arr = split(/\t/, $gene);
    if (exists $ref{$arr[0]}) {
        
        $arr[3] = $arr[3] - $start ;
        $arr[4] = $arr[4] + $end ;

        if ($arr[3] < 1 ) {
            $arr[3] = 1 ;
        }

        if ($arr[4] > $ref{$arr[0]} ) {
            $arr[4] = $ref{$arr[0]} ;
        }

        my $new = join("\t", @arr);
        print OUT "$new\n";

    }
    else {
        print "Warning: contig $arr[0] does not exist in the input fasta\n";
    }
}

	close (OUT);

