#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/iterative_align.pl  infile.fas

Ex:

Goes through a file, gets all the similarities, and then gradually merges sequences together

';

}



__END__


# For each pair of sequences do alignment

needle     -asequence aln1    -bsequence aln2 -gapopen 10.0 -gapextend 0.5 -outfile align 


# Create consensus


# Merge consensus with other sequences

# Do it all again



~/bin/usearch6.0.307_i86linux32 -cluster_fast unc_oases_transcripts.55.fa.sl -centroids nr.fasta -consout cons -id 0.5 -evalue 0.001 -query_cov 0.1 -target_cov 0.1 -uc userout.tab -alnout user.aln -msaout msa

# parse the msa-file to make alignments and an agp


