#!/usr/bin/perl -w

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

    die '


Usage: hyper_me.pl   <genomic annotation >    <list of genes>



Genomic annotation:

gene <TAB>  property  <TAB> prod
gene2 <TAB>  property2  <TAB> prod
gene3 <TAB>  property  <TAB> prod


Observe: it only counts each property once per gene, so one gene cannot have the same propoerty twice 
(but it can have two properties)



' . "\n";
}



my $ann = shift;
open (AN, "<$ann")|| die;


my %prop;

# read in the annotation

my $N = 0;

while (<AN>) {
    chomp;

    $_=~s/ID=//g;
    #$_=~s/\t\t/\t/g;
    #$_=~s/\t\t/\t/g;
    my @arr = split(/\t/, $_);


    if (scalar(@arr) == 1) {
        #$N++;
        #print "gene without annot $arr[0]\n ";
    }
    elsif ($arr[1]!~/\w+/) {
        #print "ignored :$arr[0]: :$arr[1]: :$arr[2]: \n ";
        next;
    }
    elsif (scalar(@arr) == 2) {
        push (@arr, " ");
        $N++;
        $prop{$arr[1]}{"$arr[0]"} = "$arr[2]";
        #print "read in :$arr[1]: :$arr[0]: :$arr[2]:\n ";
        #print "gene without annot $arr[0]\n ";
    }
    elsif (scalar(@arr) > 1 and  $arr[1]=~/\w+/ and  $arr[2]=~/\w+/  ) {
        $N++;
        $prop{$arr[1]}{"$arr[0]"} = "$arr[2]";
        #$prop{$arr[1]}{"$arr[0]\t$arr[2]"}=1;
        #print "read in2 :$arr[1]: :$arr[0]: :$arr[2]:\n ";
    }
    else {
        print "Ignored line $_\n";
    }

}

#__END__

# read in the number of genes drawn

my $in = shift;
open (IN, "<$in")|| die "Cant find file $in\n";
my $k = 0;
my @in = <IN>;

foreach my $i (@in) {

    if ($i=~/\w+/) {
        chomp $i;
        #print "i $i\n";
        $k++;
    }
}


$in=~s/\//\./g;
$ann=~s/\//\./g;

open (R, ">$in.$ann.R")|| die "cant open file $in.$ann.R\n ";



# get the vales of 
# k - the number of genes drawn
# m - the number of genes with that property in the genome
# n - the number of genes without that property in the genome
# x - the number of genes with that property drawn


# foreach property

foreach my $pro (sort keys %prop) {

    #print "Pro :$pro:\n";

    my $m = scalar keys %{$prop{$pro}};
    # count how many of those genes has that property
    my $x = 0;

    my $gen;
    my $prod;
    my @genes;
    my @prod;

    foreach my $i (@in) {

        #print "list $i\n";

        if ( $i =~/\w+/) {
        chomp $i;
        $i=~s/ID=//;
            
            if (exists $prop{$pro}{$i} ) {
                $x++;
                #print "exists $pro is in $i $prop{$pro}{$i} \n";
                push (@genes,$i);
                push (@prod,$prop{$pro}{$i}  );

            }
            else {
                #print "$pro is not in $i\n";
            }

        }
    }


    $gen = join(",", @genes);
    $prod = join(",", @prod);





    my $n = $N - $m;
    print R "# $pro \n";
    print R "## $gen  \n";
    print R "### $prod  \n";

    print R "k <- $k # k - the number of genes drawn \n";
    print R "n <- $n # n - the number of genes without that property in the genome\n";
    print R "m <- $m # m - the number of genes with that property in the genome \n";
    print R "x <- $x # x - the number of genes with that property drawn\n";
    print R "N <- $N # x - the total number of genes \n";

    print R "dhyper(x, m, n, k)\n";

}


close (IN);
close (AN);
close (R);

#__END__

system "R CMD BATCH $in.$ann.R";


open (RES, "<$in.$ann.Rout")|| die "cant open file $in.$ann.Rout\n ";
open (OUT, ">$in.$ann.prob.txt")|| die;


print OUT "Prop\tk\tn\tm\tx\tN\tProbability\n";


my $genes1;
my $prods1;

while (<RES>) {
    chomp;

    if ($_=~/^> $/) {
        last;
    }

    if ($_=~/^\[1\]/) {
        $_=~s/\[1\]//;
        print OUT "$_\t";
        print OUT "$genes1\t$prods1\n";

    }
    elsif ($_=~/^> ### /) {
        $_=~s/> ### //;
        #print OUT "$_\t";
        $prods1=$_;
        #print "$_\n";
    }
    elsif ($_=~/^> ## /) {
        $_=~s/> ## //;
        #print OUT "$_\t";
        $genes1=$_;
        #$feature1=$_;
        #print "$_\n";
    }

    elsif ($_=~/^> # /) {
        $_=~s/> # //;
        print OUT "$_\t";

        #$feature1=$_;
        #print "$_\n";
    }
    elsif ($_=~/dhyper/) {
        #print "Input $_\t";
    }
    elsif ($_=~/^>/) {
        my @arr = split(/\s+/, $_);
        print OUT "$arr[3]\t";
    }
    else {
        # ignore
    }

}

close (OUT);
close (RES);

exit;




=pod

open (AN, "<$ann")|| die "Cant find file $ann\n\n";

my %an;

while (<AN>) {
    chomp;
    my @arr = split(/\t/, $_);

    if (scalar @arr > 2 ) {
        $an{$arr[1]}{"$arr[0]\t$arr[2]"}=1;
        #print ":$arr[1]:\t:$arr[0]:\t:$arr[2]:\n";
    }
}




            #add annotation
            if (exists $an{$feat}) {
                my $gen;
                my $pro;
                my @genes;
                my @prod;
                #print "Have $feat\n";
                foreach my $ann (sort keys %{$an{$feat}}) {

                    #print "$ann\n";
                    my($gene2,$prod)=split(/\t/,$ann);
                    push (@genes,$gene2);
                    push (@prod,$prod);
                    $gen = join(",", @genes);
                    $pro = join(",", @prod);
                }
                print OUT "$gen\t";
                print OUT "$pro\t";
            }
            else {
                #print "Dont have :$feat:\n";    
            }


=cut






