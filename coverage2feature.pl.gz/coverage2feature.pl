#!/usr/bin/perl
use strict;


unless (@ARGV == 4) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/coverage2feature.pl file  file-type coverage distance

file is output from BED-tools genomeCoverageBed
file-type can be: BED or depth
coverage is the depth of coverage for breaking the feature


';

}


my $in = shift;
my $ftype= shift;
my $coverage=shift;
my $dist=shift;

my $out = "$in.gff";

open (IN, "<$in") or die 'Cant find infile $in ';

#print "Outfile: $out\n";
open (OUT, ">$out") or die 'Cant find outfile $out ';
open (OUT2, ">$out.c2f.gff") or die 'Cant find outfile $out.c2f.gff ';


my $fs=0;
my $fe=0;
my %fes;
my %cov;


# if it is a bed-file 

if ($ftype=~/B/i) {
    print "\nI think youve given me a BED-file\n\n";

    while (<IN>) {
        chomp;
        my @arr = split(/\s+/, $_);

        my $len = $arr[2]- $arr[1];

        #print OUT "$arr[0]\tFromBed\tCDS\t$arr[1]\t$arr[2]\tscore=$arr[4]\t$arr[5]\t.\tID=$arr[3]\n";
        #print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\n";
        # if the base is more than 0 start the feature
        if ($arr[3]>$coverage and $fs=~/^0$/) {
            $fs=$arr[1]+1;
            $fe=$arr[2]+1;
            #print "start\t$fs\t$fe\n";
            push(@{$cov{$arr[0]}{$fs}},"$arr[3]-$len:");
        }
        # if the base is more than 0 continue the feature
        elsif ($arr[3] > $coverage) {
            $fe=$arr[2]+1;
            #print "extend\t$fs\t$fe\n";
            push(@{$cov{$arr[0]}{$fs}},"$arr[3]-$len:");
        }
        # if the feature is 0
        else {
            $fes{$arr[0]}{$fs}=$fe;
            #print "end\t$fs\t$fe\n";
            $fs=0;
        }
    }
}


# if it is a depth-file

elsif ($ftype=~/p/i) {
    print "\nI think you\'ve given me a depth-file\n\n";
    while (<IN>) {
        chomp;
        my @arr = split(/\s+/, $_);

        #print OUT "$arr[0]\tFromBed\tCDS\t$arr[1]\t$arr[2]\tscore=$arr[4]\t$arr[5]\t.\tID=$arr[3]\n";
        #print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\n";
        # if the base is more than 0 start the feature
        if ($arr[2]>$coverage and $fs=~/^0$/) {
            $fs=$arr[1];
            $fe=$arr[1]+1;
            #print "start\t$fs\t$fe\n";
            push(@{$cov{$arr[0]}{$fs}},$arr[2]);

        }
        # if the base is more than 0 continue the feature
        elsif ($arr[2] > $coverage) {
            $fe=$arr[1]+1;
            #print "extend\t$fs\t$fe\n";
            push(@{$cov{$arr[0]}{$fs}},$arr[2]);
        }
        # if the feature is ended 
        else {
            $fes{$arr[0]}{$fs}=$fe;
            #print "end\t$fs\t$fe\n";
            $fs=0;

        }
    }
}

else {
    print "I cant read the file format, type BED or depth\n";
    die;
}


# needs code


my $i=1;
# now report features
foreach my $key (keys %fes) {
 
    #print "$key\n";
    foreach my $key2 (sort {$a<=>$b} keys %{$fes{$key}}) {
        #print "$key2\n";

        unless ($key2=~/^0$/) {
            my $cov;

            if (exists $cov{$key}{$key2}) {
                $cov= join("", @{$cov{$key}{$key2}} );
                #print "$key2\t$cov\n";
            }
            else {
                $cov="NA";
                #print "ELSE: $key2\t$cov\n";
            }

            print OUT "$key\tFromBed\tCDS\t$key2\t$fes{$key}{$key2}\t.\t.\t.\tID=feature_$i;note=\"$cov\"\n";
            $i++;

        }
    }

}


close (IN);
close (OUT);





#### read in exons, and filter the bad ones, and merge adjoining ones



my $laste;


open(EX, "<$in.gff") || die "Cant read file $in.gff, check that it has been produced";

my @ex = <EX>;

my @res1;
my $lkey=shift(@ex);

# merge features less than $dist bp apart
foreach my $k (@ex) {
    chomp $k;

    my @ar1 = split(/\t/, $k);
    my @ar2 = split(/\t/, $lkey);

    #print "Comparing $lkey to $k\n";

    # if the feature is > 20 bp apart
    if ( $ar1[0]=~/$ar2[0]/ and ($ar1[3]-$dist ) < $ar2[4]) {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "   overlapping \t $ar2[3] $ar2[4] $ar1[3]  $ar1[4] $ovl\n";
                
        # if extension happended, update the feature length
 
        my $min = $ar2[3];
        my $max = $ar2[4];
        my $min2 = ($ar1[3], $min  )[$ar1[3] > $min ];
        my $ie2 = ($max, $ar1[4])[$max < $ar1[4]];
        $ar2[3] = $min2;
        $ar2[4] = $ie2;

        # if extension happended, update the note
        
        my @old_note = split(/"/,$ar2[8]);
        my @new_note = split(/"/,$ar1[8]);
        my $bridge = "0,$ovl:";

        $ar2[8]= "$old_note[0]\"$old_note[1] $bridge $new_note[1]\"\n";

        my $newl = join("\t", @ar2);
        #print "New feature $newl\n";
        $lkey=$newl;
    }
    else {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "not overlapping \t$ar2[3] : $ar2[4] : $ar1[3]  :  $ar1[4]  :  $ovl\n";
        push(@res1, $lkey);
        
        $lkey = $k;
    }



}

# add the last one
push(@res1, $lkey);


foreach my $ke1 (@res1) {
    chomp $ke1;
    print OUT2 "$ke1\n";
}



# clean up

unless (-e "coverage2feature") {
    mkdir "coverage2feature";
}

system "mv $in.gff coverage2feature ";




exit;





__END__




foreach my $ke1 (@res1) {
    chomp $ke1;
    #$_=~s/CDS/intron/;
    push(@res, $ke1);
    #print "$ke1\n";
}



