#!/usr/local/bin/perl -w

use strict;
use Math::Round;
use Sort::Fields;  
#use Data::Dumper;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: calculate_variation.pl file


Take a matrix with row and header names and calculate average and variace for each row


'
}


my $file= shift;

#my $cutoff= 100;

my %h;


open (IN , "<$file") || die "\nCant open file $file\n\n ";

open (OUT , ">$file.var") || die "\n Cant open file for output $file.var\n\n";


print OUT "Gene\tSum\tNumber\tAverage\tVariance || values\n";

while (<IN>) {
    chomp;
    my @arr = split(/\t/, $_);
    my $sum = 0; 
    my $num = 0;
    my $ave = 0;
    my $var = 0;
    my $cu = 0;

    #print "\n\n";
# get indices    
    foreach my $el (@arr) {

        # sum the number, and calculate how many there are
        if ($el=~/^\d+$/ or $el=~/^\d+\.\d+$/  ) {
            $num++;
            $sum = $sum + $el;
        }
    }

    # if the sum of the whole row is 0 ignore it
    if ($sum=~/^0$/) {
        next;
    }

        $ave = $sum/$num;
        #print "$arr[0]\t$sum\t$num\t$ave\n";

# calculate variance
        
        #my @top;
        my $top = 0; 
        foreach my $el (@arr) {
    
        if ($el=~/^\d+$/ or $el=~/^\d+\.\d+$/  ) {
            my $temp = ($el - $ave)* ($el - $ave);
            #push (@top, $temp);
            $top = $top + $temp;
            #print "$temp\t$top\n";
        }
    }

    my $variance = $top/($num-1);
    $sum = sprintf("%.1f",  $sum); 
    $variance = sprintf("%.1f",  $variance); 
    $ave = sprintf("%.1f",  $ave); 
    #if ($cu == $num) {
    my $head = shift @arr;
    my $values = join("\t", @arr);
    print OUT "$head\t$sum\t$num\t$ave\t$variance\t||\t $values\n";
        #}
    

}




close(OUT);

exit;




