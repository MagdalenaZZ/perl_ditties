

sub getTransTable	{
		my ($gcFile,$genCode)=@_;

	#retrieve the translation table given the genetic code id.
	#more than simply reading in field #3.
	#need to add the codons represent this amino acid.
	#a set order.

	my $aaString;
	my %tt;
	open GC, $gcFile or die;
	while (<GC>)	{
		chomp;
		my @entry=split /\t\|\t/;
		if ($entry[0] == $genCode)	{
			$aaString=$entry[3];
		}
	}
	close GC;

	#The order is qw/T C A G/;
	my @ntides=qw/T C A G/;
	my @aacids=split //, $aaString;
	foreach my $first (@ntides)	{
		foreach my $second (@ntides)	{
			foreach my $third (@ntides)	{
				my $codon=join ('',($first,$second,$third));
				my $aa=shift @aacids;
				$tt{$codon}=$aa;
			}
		}
	}
	return \%tt;




}

$gcFile = "";

$genCode = "1";


####################################

my $gcTT=p4e3::taxParser::getTransTable($taxFiles->{gencode},$gcID);

print $gcTT;


print "Genetic code #".$gcID." - '$gcName' will be used\n";




