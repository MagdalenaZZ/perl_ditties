#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: pfam2gff_n_fasta.pl Pfam.out fasta.fas

Parses output from Pfam, and a fasta-file to which it belongs
It then makes a gff containing all the domains as features, extracts these domains from the fasta, and writes a separate fasta-file for each one of them.

'
}



my $pfam = shift;
my $fasta = shift;

	open (PFAM, "<$pfam") || die "I can't open $pfam\n";
	my @pfam = <PFAM>;
	close (PFAM);



my %h;
my %h2;

open (GFF, ">$pfam.gff") || die "I can't open $pfam.gff\n";

my $index = 1;
my $last = 0;
#my $lcds = 0;
#my $cdsi = 1;

foreach my $line (@pfam) {
chomp $line;
unless ($line =~/^\#/ || $line !~/\w+/ ) {
    my @arr = split (/\s+/, $line);

    if ( exists  $h{$arr[0]}{"$arr[3]\t$arr[4]"} ) {
        $h{$arr[0]}{"$arr[3]\t$arr[4]"} = "$arr[6]";
#        print "IF:$arr[0]\t$arr[3]\t$arr[4]\t$arr[6]\n";

    }
    else {
        $h{$arr[0]}{"$arr[3]\t$arr[4]"} = "$arr[6]";
#        print "ELSE:$arr[0]\t$arr[3]\t$arr[4]\t$arr[6]\n";
    }


    if ($arr[0] =~/$last/) { 
        print GFF "$arr[0]\tdomain\tgene\t$arr[3]\t$arr[4]\t.\t+\t.\tID=$arr[0]\-$arr[6]:$index\n";
        print GFF "$arr[0]\tdomain\tCDS\t$arr[3]\t$arr[4]\t.\t+\t.\tID=$arr[0]\-$arr[6]:$index:exon:1;Parent=$arr[0]\-$arr[6]:$index\n";
        $index++;
#        $cdsi++;
    }
    else {
        $index=1;
#        $cdsi=1;
        print GFF "$arr[0]\tdomain\tgene\t$arr[3]\t$arr[4]\t.\t+\t.\tID=$arr[0]\-$arr[6]:$index\n";
        print GFF "$arr[0]\tdomain\tCDS\t$arr[3]\t$arr[4]\t.\t+\t.\tID=$arr[0]\-$arr[6]:$index:exon:1;Parent=$arr[0]\-$arr[6]:$index\n";
#        $index++;


    }
     $last = $arr[0];
#     $lcds = $arr[6];       
}
}

close (GFF);

# read fasta
    open (FAS, "<$fasta") || die "I can't open $fasta\n";
    
    
    while (<FAS>) {
            chomp $_;
            if ($_=~m/\>/) {
                $_=~s/\>//;
                my $seq = <FAS>;
                chomp $seq;
                my @arrx = split ( /\s+/, $_);
                $_ = $arrx[0];
#                print "$arrx[0]\t$seq\n";
                
                if (exists $h{$_} ) {
                    foreach my $range (keys %{$h{$_}} ) {

#                        print "$_\t$range\t$seq\n";
                        my ($start, $end) = split (/\t/, $range);
                        my $len = $end - $start + 2;
                        $start--;
                        my $new_seq = substr($seq, $start, $len);
#                        print "91:$new_seq\t$h{$_}{$range}\n";
                        my $ind = 1;
                        my $new_name = $_;

                        if ( exists $h2{ $h{$_}{$range}  }{ $new_name } ) {
                            # change new_name if it is not unique
                            while ( exists $h2{ $h{$_}{$range}  }{ $new_name } ) {
                                $ind++;
                                $new_name = "$_" . "." . "$ind";
                            }

                            $h2{ $h{$_}{$range}  }{ $new_name } =$new_seq;
#                            print "IF:$h{$_}{$range}\t$new_name\t$new_seq\n";

                        }
                        else {
                            $h2{ $h{$_}{$range}  }{ $_ } =$new_seq;
#                            print "ELSE:$h{$_}{$range}\t$_\t$new_seq\n";

                        }
                    }
                }
                else {
#                    print "ELSE:$arrx[0]\t$seq\n";
                }

# $in{$line} = $file;
#                print "$file\t$line\n"; <STDIN>;
            }
            else {
            }
        }

close (FAS);

#foreach my $dom (keys %h) {

#}

#__END__

if ( -d "domain_fasta_$pfam" ) {
    system "rm -fr domain_fasta_$pfam"; wait;
    print "Deleting previous domain_fasta_$pfam\n";
}

mkdir "domain_fasta_$pfam";
chdir "domain_fasta_$pfam";
# print output

my %h3;

foreach my $dom (keys %h2) {

    open (OUT, ">>$dom.fas") || die "I can't open $dom.fas\n";


    foreach my $gene (sort keys %{$h2{$dom}}) {

#        print "$dom\t$gene\t$h2{$dom}{$gene}\n";
        print OUT ">$gene\_$dom\n$h2{$dom}{$gene}\n";
#        $h3{ ">$gene\_$dom\n$h2{$dom}{$gene}"  } = 1;

#        foreach my $site ( keys %{$h2{$gene}{$dom}} ) {
#            print "$gene\t$dom\n";
#        }
    }
}

#foreach my $dom (keys %h2) {

#    open (OUT, ">>$dom.fas") || die "I can't open $dom.fas\n";
    #
#}
