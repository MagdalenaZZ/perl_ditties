#!/usr/local/bin/perl -w

use strict;
use Cwd;
use File::Slurp;

unless (@ARGV > 0 ) {
        &USAGE;
}


sub USAGE {

die 'Usage: embl_remove_suspicious_exons.pl folder 

Takes a folder with *.embl files and removes very short exons on the edges



'
}


my $folder = shift;

# put those folders in an array

#chdir $folder;
#my @paths = read_dir( "$folder", prefix => 1 ) ;
my @paths = read_dir( "$folder", prefix => 1 ) ;

#system "rm -f all.tmp.gff";

my @files;

foreach my $elem (@paths) {
    if ($elem=~/\.embl$/) {
        #print " $elem \n";
        push (@files,$elem);
    }
}

my $warn=0;

foreach my $file (@files) {

    open (IN, "<$file") || die "I can't open $file\n";
    open (OUT, ">$file.embl") || die "I can't open $file.embl\n";
    #my @in = <IN>;

    while(<IN>) {
        chomp;

        if ($_=~/FT   CDS/ and $_=~/(\,)/ ) {
            my @matches = ( $_ =~ /(\d+\,\d+)/g );
            #$_=~/(\d+)/g;
            #print "$matches[0]\n";
            #
            foreach my $val (@matches) {
                #print "$val\n";
                my @val=split(/\,/, $val);
                if ($val[1]-$val[0] > 50000) {
                    print "Warning\t$file\t$val[0]\t$val[1]\n";
                    print "$_\t";
                    $warn=1;
                }
            }
            #print "\n";
            

        }
        elsif ($_=~/FT                   \/locus_tag\=\"/ and $warn=~/1/) {
                    print "$_\n";  
                    $warn=0;
        }
        else {
            # print the line to OUT
        }

    }
    close (IN);
    close (OUT);


}






__END__


my $in="all.tmp.gff";

open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;
close (IN);


open (OUT, ">$out.raw.gff") || die "I can't open $out.raw.gff\n";



