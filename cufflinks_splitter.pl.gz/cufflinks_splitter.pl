#!/usr/local/bin/perl -w

# mz3 script for taking tophat output aln.sorted.sam and turning it into cufflinks-ready file, and then submitting all jobs
#


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV > 2) {
        &USAGE;
}



sub USAGE {

die 'Usage: cufflinks_splitter.pl reference_genome aln-sorted.bam cufflinks-settings


-I 40000  --min-intron-length 10  

Make sure the bam-file is indexed:   samtools index  aln-sorted.bam


'
}

#my $folder = shift;
my $ref = shift;
my $bam = shift;
my $I = 40000;

# system "samtools index $bam"; wait;

print "Reference sequence: $ref \n";


# identify all folders in the genome
my $cwd = cwd();
my @paths = read_dir( "$cwd", prefix => 1 ) ;
my @dirs;

#Make sure the folder has the right path - if not a path - assume that it is in this folder

#if ($folder =~m/\//) {	
#	if (-d "$folder") {
#		print "If: $folder\n";
#		foreach my $elem (@paths) {
#			$elem = "$folder\/$elem";
#			print "$elem\n";
#		}	
#	}
#	else {
#		print "Can\'t find folder $folder. Try giving full path.\n";
#	}
#}
#else  {

foreach my $folder (@paths) {
	if (-d "$folder") {
#		print "Else: $cwd\/$folder\n";
#		foreach my $elem (@paths) {
#			$elem = "$cwd\/$folder\/$elem";
#			print "Dir: $folder\n";
#		}
		unless ($folder=~m/errors/) {
            push (@dirs, $folder);
        }
	}
	else {
#		print "Not directory $folder \n";
	}
}

print "Fishished reading files\n";

mkdir "errors";

foreach my $contig (@dirs) {

    chdir $contig;

    print "$contig\n";

    open CMD, ">$contig.sh";


    print CMD "samtools view -b ../$bam $contig > $contig.bam; wait; \n";
    print CMD "samtools sort $contig.bam $contig.sort; wait; ";
#    print CMD "samtools view $contig.bam > $contig.sam;  wait;  \n";
#    print CMD "cat ../header.sam2  $contig.sam >  $contig.head.sam;  wait;  \n";
#    print CMD "/nfs/pathogen005/mz3/mh12/python/fasta2multiline.py $contig.fasta $contig.m.fas 1000;  wait;  \n";
#    print CMD "samtools faidx $contig.m.fas ;  wait;  \n";
#    print CMD "samtools view -bt $contig.m.fas.fai $contig.head.sam  > $contig.aln.bam ;  wait;  \n";
#    print CMD "samtools sort $contig.aln.bam $contig.aln-sorted ;  wait; \n";
#    print CMD "rm -f *.sam $contig.aln.bam *m.fas* ;  wait; \n";
    print CMD "cufflinks -I $I  $contig.sort.bam;  wait; \n";
    print CMD "mv genes.fpkm_tracking genes.fpkm_tracking.o \n";
    print CMD "mv isoforms.fpkm_tracking isoforms.fpkm_tracking.o\n";
    print CMD "mv skipped.gtf skipped.gtf.o\n";
    print CMD "mv transcripts.gtf transcripts.gtf.o\n";


    close (CMD);
    
    system "bsub.py  --err=$cwd/errors/$contig.e --out=$cwd/errors/$contig.o 5 $contig sh $contig.sh ";

    sleep (2);
#    print "samtools faidx $contig.f* ";
#    print "samtools view -bt *.fai all.sam > $contig.aln.bam";


    chdir $cwd;

    #   print "bsub.py  --err=$cwd/errors/$contig.e --out=$cwd/errors/$contig.o 5 $contig cufflinks -o $contig -I $I  --min-intron-length 10 $contig/$contig.bam  \n";
}

#   chdir $cwd;


__END__

@PG	ID:TopHat	VN:1.4.1	CL:/nfs/users/nfs_m/mz3/bin/tophat-1.4.1.Linux_x86_64/tophat -o EMUtophat5817_1 -r 144 --mate-std-dev 100 -i 10 -I 40000 -g 40 -a 4 -m 0 --solexa-quals --butterfly-search /lustre/scratch101/sanger/mz3/EMU_tophat/EMU_v3_17June2011.corr /lustre/scratch101/sanger/mz3/EMU_tophat/5817_1_1.fastq /lustre/scratch101/sanger/mz3/EMU_tophat/5817_1_2.fastq


-o $output -I $I --min-intron-length 20 
