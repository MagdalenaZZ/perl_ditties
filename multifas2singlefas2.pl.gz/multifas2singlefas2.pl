#!usr/bin/perl -w
#  program to convert multifasta 2 singlefasta

# USAGE: perl multifas2singlefas.pl filename.fas

use strict;
use warnings;

local $/ = '>';


unless (scalar(@ARGV)==1){
&USAGE ;
}

my $file = $ARGV[0];
open(DATA, "$file") || die "Can't open $file\n";

my $c = 0;


while (<DATA>) {
    chomp;
    next unless length;
    my ($name, $sequence)=split(/\n/, $_);
#    print "$name\n"; 

    my $fn = $name . ".fasta";

    open my $handle, '>', $fn or die "Can't open `$fn' for writing: $!+";
    print $handle '>', $_;
    close $handle or warn $!;
#    print $_; <STDIN>;
    $c++;

	system ("mkdir $name") unless (-d $name);
	system `mv $fn $name`;
}


close(DATA);

sub USAGE {
print "Usage:\n multifas2singlefas.pl multisequence.fasta\n";
exit;
}
