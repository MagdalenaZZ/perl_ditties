#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_compare_2_fasta.pl infile.gff infile.fasta 




'
}


	my $gff = shift;
	my $fas = shift;


# Read in fasta lenghts 

system "samtools faidx $fas";


open (FAS, "<$fas.fai") || die "I can't open $fas.fai\n";
#my @fas = <FAS>;
#close (FAS);
# Open reference
my %fas;

while (<FAS>) {
    my @arr = split(/\s+/, $_);
    $fas{$arr[0]} = $arr[1];
    #print "$arr[0]\t$arr[1]\n";

}


# Read in gff-lengths


system "perl ~mz3/bin/perl/gff_Artemis_orientation.pl $gff $gff.art ";
	open (IN, "<$gff.art") || die "I can't open $gff.art\n";
	my @in = <IN>;
	close (IN);


my %ex;

foreach my $line (@in) {
	chomp $line;
    $line=~s/exon/CDS/;
#    $line=~s/five_prime_UTR/CDS/;
#    $line=~s/three_prime_UTR/CDS/;
	my @arr = split(/\t/, $line);
    if ($arr[2]=~m/^CDS$/) {
#        print "$arr[8]\n";
        my @genes = split(/[\:\;]/,$arr[8]);
        #my $gene = "$arr[0]\t$genes[0]\t$arr[6]";
        my $gene = "$genes[0]";

        my $coords = $arr[4] - $arr[3];
        #push (@{$hash{$gene}}, $coords );
        #push (@{$ex{$gene}}, $coords );
        $gene =~s/^ID=//;
        #print "$gene\t $genes[1]\t$coords\n";

        if (exists $ex{ $gene }{ $genes[1] } ) {
            $ex{ $gene }{ $genes[1] } += $coords; 
        }
        else {
            $ex{ $gene }{ $genes[1]  } = $coords; 
        }
    }

}

foreach my $fas ( keys %fas) {
    print "$fas\t$fas{$fas}\n";

    if ( exists $ex{$fas} ) {
        my $keys = scalar( keys $ex{$fas});
        print "HIT $fas\n";


        # if there is only one hit
        if ($keys == 1) {
            foreach my $elem ( keys %{$ex{$fas}}) {
                print "ONE$keys:$elem\t$ex{$fas}{$elem}\n";
            }
        }
        # if there are many hits
        else {
            foreach my $elem ( keys %{$ex{$fas}}) {
                print "MANY$keys: $elem\t$ex{$fas}{$elem}\n";
            }
        
        }

    }
    else {
        print "No hit on $fas\n";
    }
}


