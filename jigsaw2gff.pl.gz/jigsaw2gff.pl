#!/usr/bin/perl -w
# mz3 script for ading parent-children relationship to a jigsaw gtf file and make it into gff

use strict;

my %hash;


if 



while (<>) {
	chomp;

if () {

}

else {


	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $note = $line[9];
	

	my $phase = 0;
	
#	if ($tag =~ /transcript/i) {
#		my $comment = "note=$line[9];";
#		my $mrna = "note=Transcript.$line[11];Parent=$line[9];";
#		print "$name\t$method\tgene\t$start\t$end\t.\t$strand\t.\t$comment\n"; #<STDIN>;
#		print "$name\t$method\tmRNA\t$start\t$end\t.\t$strand\t.\t$mrna\n"; #<STDIN>;
#	} 
	
	my $newline =  "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t$phase";
	# counter
	push (@{$hash{$note}}, $newline); 
	
}
foreach my $key (keys %hash) {
	my $elem = scalar(@{$hash{$key}});
#	print "I'm in $key with $elem"; <STDIN>;
	my $first_line= ${$hash{$key}}[0];
	my $last_line = ${$hash{$key}}[$elem-1];
	my @firsts = split(/\s+/,  $first_line );
	my @lasts = split(/\s+/,  $last_line );
	my $first= $firsts[3];
	my $last= $lasts[4];
	my $name =$firsts[0];
	my $method = $firsts[1];
	my $strand = $firsts[6];
	my $comment = "ID=$key;";
	my $mrna = "ID=Transcript.$key;Parent=$key;";
#	print "$\t$method\tgene\t$first\t$last\t.\t$strand\t.\t$comment\n"; #<STDIN>;
	print "$name\t$method\tgene\t$first\t$last\t.\t$strand\t.\t$comment\n"; #<STDIN>;
	print "$name\t$method\tmRNA\t$first\t$last\t.\t$strand\t.\t$mrna\n"; #<STDIN>;
	my $count = 1;
	
	foreach my $line (@{$hash{$key}}) {
#		print "this is line\n$line"; <STDIN>;
		print "$line\tID=Exon.$count;Parent=Transcript.$key\n";#<STDIN>;
			$count++;
	}
}


}

=pod

  4514 initial-exon
  25212 internal-exon
      1 List
      1 Model
    346 single-exon
   4514 terminal-exon

=cut