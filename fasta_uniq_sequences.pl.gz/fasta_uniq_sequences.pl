#!/usr/bin/perl -w

use strict;




my $largest = 0;
my $contig = '';


if (@ARGV < 1) {
	print "\n\nUsage: fasta_uniq_sequences.pl fasta \n\n" ;

    print " mz3 script for eliminating duplicated sequences \n\n";

	exit ;
}

my $filenameA = shift @ARGV;
my $contig_name = shift @ARGV;
my %reads = () ;


open (OUT, ">$filenameA.uniq") or die "oops!\n" ;
open (OUT2, ">$filenameA.not_uniq") or die "oops!\n" ;
open (OUT3, ">$filenameA.all_uniq") or die "oops!\n" ;

open (IN, "$filenameA") or die "oops!\n" ;


my %new;

while (<IN>) {

    my $index = "2";
    # print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $_;
	$seq_name=~s/>//;
    chomp $seq_name;
	my $seq = <IN> ;
	chomp($seq) ;
    my $new_name;

#	print "SEQname:$seq_name:\n";	
	if ( exists $reads{$seq_name} ) {
			print OUT2 ">$seq_name\n" ;
			print OUT2 "$seq\n" ;
#            delete $reads{$seq_name};
            $new_name =  "$seq_name" . "\.$index" ;
            while ( exists $new{$new_name}) {
                $index++;
                $new_name =  "$seq_name" . "\.$index" ;
            }
            $new{$seq} = $new_name;
            print "Renamed\t$seq_name\t$new_name\n";
	}
    else {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;
            $new{$seq} = $seq_name;

    }

	$reads{$seq} = $seq_name ;

    }
	
    
    #last;


}

foreach my  $elem ( keys %new ) {
    print OUT3 "\>$new{$elem}\n$elem\n";
}

close (OUT);
close (OUT2);
close (OUT3);

#print "\#\#the largest length is: $contig with $largest bp \n" ;
