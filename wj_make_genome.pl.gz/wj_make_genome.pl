#!/usr/bin/perl
use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/wj_make_genome.pl file.fas




';

}


my $fas = shift;


#system "fasta2singleLine.py $fas $fas.sl ";

open(FAS, "<$fas") || die "Cant read file $fas";
open(OUT, ">$fas.genome") || die "Cant read file $fas.genome";

#my %fas;

while (<FAS>) {
    chomp;
    #print "$_\n";
    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/>//;
        chomp $head;
        my $seq = <FAS>;
        chomp $seq;
        #$fas{$head}= $seq;
        my $len = length($seq);
        print OUT "$head\t$len\n";
    }

}

print OUT "exit\t1\n";

close (OUT);




