#!/usr/bin/perl -w


use strict;


if (@ARGV < 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff2sam.pl gff reference.fasta 

Takes a gff-file and turns it into a SAM-file



'
}

my $gff= shift;
my $fas = shift;


open (IN, "<$gff") || die "I can't open $gff\n";
my @gff= <IN>;
close (IN);


open (IN, "<$fas") || die "I can't open $fas\n";

open (OUT, ">$gff.sam") || die "I can't open $gff.sam\n";




my %fas;

$/=">";
my @sq;

while (<IN>) {
# read in fasta and store seqs
#    if (/^>(\S+)/) {
#        my $seq_name = $1;
#        $seq_name=~s/>//;
#        my $seq = <IN> ;
#        chomp($seq) ;
#        $fas{$seq_name=}=$seq;
#    }
    my @arx=split(/\n/,$_);
    my $head = shift(@arx);
    my $seq =join("", @arx);
    #print ">$head\n$seq\n";
    $fas{$head}="$seq";
    my $len =length($seq);
    if ($len > 0) {
        push (@sq, "\@SQ\tSN:$head\tLN:$len");
    }

}

$/="\n";


# write the SAM header



print OUT "\@HD	VN:1.0	SO:coordinate\n";

# print SQ-lines
foreach my $key (@sq) {
    print OUT "$key\n";
}

print OUT "\@PG	ID:TopHat	VN:2.0.6	CL:tophat\n";


# go through gff and write each line
my %gff;
foreach my $line (@gff) {
    chomp $line;
    my @arr = split(/\t/, $line);
   
    my $seq = " ";

    my $head = "$arr[0]";
    if (exists $fas{$head}) {
                

        # check orientation
        #my $rev =0;
        
        # if it is reverse
        if ($arr[3] > $arr[4] ) {
            #$rev=1;
            my $len = $arr[3]-$arr[4];
            my $sub = substr($seq,$qe,$len);
            # reverse-complement
            #my $rev = reverse($sub);
            #$rev=~tr/ACGTactg/TGCAtgca/;
            #print OUT ">$seq_name $key-\n$rev\n";
        }
=pod
        # if it is reverese, but seqs right
        elsif ($arr[6]=~/\-/) {
            #$rev=1;
            my $len = $arr[3]-$arr[4];
            my $sub = substr($seq,$qe,$len);
            # reverse-complement
            my $rev = reverse($sub);
            $rev=~tr/ACGTactg/TGCAtgca/;
            print OUT ">$seq_name $key-\n$rev\n";
        }
=cut


        # if it is forward
        else {
            my $len = $qe-$qs;
            my $sub = substr($seq,$qs,$len);
            print OUT ">$seq_name $key+\n$sub\n";
        }






        print "$arr[8]\t1\t$arr[0]\t$arr[3]\t50\t$len" . "M\t*\t*\t0\t$fas{$head}\n";

    }



}

close (IN);
close (OUT);


