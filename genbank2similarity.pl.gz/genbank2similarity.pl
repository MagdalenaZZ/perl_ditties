#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV ==4) {
        &USAGE;
}


sub USAGE {

die 'Usage: genbank2similarity.pl folder blast.output cutoff outfile

Takes a folder which has been produced by genbank_get_products.pl
and a blast-output format 8
chooses only entries above a certain e-value
and outputs a file which you can use in gff-markup.pl

Please observe that error message "Use of uninitialized value in string at /nfs/users/nfs_m/mz3/bin/perl/genbank2similarity.pl line 324, <TMP> line 210024" is okay.

Make sure it doesn\'t insert new product-lines with an empty note:  /note="  

'
}

my $folder = shift;
my $blast = shift;
my $cutoff = shift;
my $out = shift;
my $cwd = cwd();
# print "CWD: $cwd\n";
my $dir = cwd();



my @paths = read_dir( "$folder", prefix => 1 ) ;

#Make sure the folder has the right path - if not a path - assume that it is in this folder

if ($folder =~m/\//) {	
	if (-d "$folder") {
		print "If: $folder\n";
		foreach my $elem (@paths) {
            #$elem = "$folder\/$elem";
#			print "$elem\n";
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
		print "Else: $cwd\/$folder\n";
		foreach my $elem (@paths) {
			$elem = "$cwd\/$folder\/$elem";
#			print "$elem\n";
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

print "Fishished reading files\n";





######################################################################
###### take all info which is needed from the blast-output ###########
######################################################################

open (BLAST, "<$blast") || die "I can't open $blast\n";
my @blast = <BLAST>;
close (BLAST);

open (OUT3, ">$out.filtered") || die "I can't open $out.filtered\n";

my $gbid; # genebank identifier
my $match_length; # the lenght of the blast-hit
my $idprocent;  # the precent ID of the hit
my $ungprocent; # Optional ungapped identity (percentage)
my $gene; # gene-name 
my $eval; # E-value
my $score; # Optional score
my $aaovl; # Optional overlap length (integer)
my $qstart; # blast query start 
my $qend; # blast query end  
my $sstart; # blast subject start 
my $send; # blast subject end  
my @genes;
my %blas;
my %bla;
my @bla;
my $gene_ib;

foreach my $elem (@blast) {
	chomp $elem;
	
# Make a hash with key $gbid and 2 fields: $gene and $newline
	my @arr=split(/\t/, $elem);
#	print "ONE:$arr[1]:\n";
	if ($arr[10] < $cutoff) {
#        print "$elem\n";
# make gbid
		my @name=split(/\|/, $arr[1]);

		if ($name[3] =~/\./) {
			my @fucku =  split(/\./, $name[3]);
		$gbid=$fucku[0];
#			print "Three:$gbid:\n";
		}
		elsif ($name[3] =~/\w+/) {
			my $newarr8 = "$name[3]" . "_" . "$name[4]";
			$gbid=$newarr8;
#			print "Three:$gbid:\n";
		}
		else {
#			print "Else:$name[3]:\n";
		}

	$match_length = $arr[3]; # the lenght of the blast-hit - 3	length
	$idprocent= $arr[2];  # the precent ID of the hit - 2	pident 
	$ungprocent=" ";  # Optional ungapped identity (percentage)
	$gene = $arr[0]; # gene-name -0	qseqid
	$eval= $arr[10]; # E-value
	$score= $arr[11]; # Optional score
	$aaovl=" "; # Optional overlap length (integer)
	$qstart= $arr[6]; # blast query start -6	qstart
	$qend= $arr[7]; # blast query end  - 7	qend
	$sstart= $arr[8]; # blast subject start
	$send= $arr[9]; # blast subject end	
	push(@genes, $gene);
	my $newline = "$gene\t$match_length\t$idprocent\t$ungprocent\t$eval\t$score\t$aaovl\t$qstart\t$qend\t$sstart\t$send";
	my $newline2 = "$gbid\t$gene\t$match_length\t$idprocent\t$ungprocent\t$eval\t$score\t$aaovl\t$qstart\t$qend\t$sstart\t$send";	
#	print "GID:$gbid:\n";
#	print ":$newline:\n";
	$gene_ib= "$gene" . "-" . "$gbid";

# test if this hash already exists
		if (exists $blas{$gene_ib}) {
# if it does choose the best hit - bitscore		
		my @scores =split(/\t/, $blas{$gene_ib});
#		print "Score_old:$scores[5]:\n";	
#			print "Score_new:$score:\n";
			if ($scores[5] < $score) {	
				$blas{$gene_ib}=$newline;
#				print "Right: $newline:\n";
			}
			else {
#				nothing
			}
	
		}
	# if it does not  - keep as first entry
		else {
 			$blas{$gene_ib}=$newline;
#		print "$newline\n";
		}
	}
	else {
#		print "Filtered: $elem\n";
		print  OUT3 "Filtered:$elem:\n";
	}
}

my $var2 = scalar keys %blas;

print "Fishished reading blast $var2\n";

######################################################################
# take all info which is needed from the genbank-files ###############
######################################################################

my $taxon; # full species name e.g. Trypanosoma brucei
my $product; # product name eg. variant-specific antigen ESAG3
# my $gbid; # genebank identifier
my @dbxref='';  # associated dbxrefs
my $dbxref;
my $ecnum;
my %genbank;

# for each file
foreach my $elem (@paths) {
chomp $elem;
# print "File:$elem:\n";
if ($elem =~/\.gb/) {
# open the file 
	open (TMP, "<$elem") || die "I can't open $elem\n";
	my @temp = <TMP>;
	pop(@temp);
	pop(@temp);
# print "$temp[-1]\n";
# parse the file
# Make a hash with 1 key $gbid and 3 fields; product, taxon and dbref. Each of these are keys in the next hash for which values are $product $taxon @dbxref

	foreach my $line (@temp) {
		chomp $line;
#		print "$line\n";
		my @temp2;
		if ($line =~/LOCUS/) {
			@temp2 = split (/\s+/,$line);		
			$gbid=$temp2[1];
#			print "GBid:$gbid:\n";			
		}
		# find out if line is something I want
		elsif ($line =~/\/organism=/) {
				@temp2 = split (/"/,$line);	
#				print "Temp22:$temp2[1]:\n";
				$taxon=$temp2[1];
#				print "Taxa:$taxon:\n";
			$genbank{$gbid}{"taxon"} = $taxon;
		}
		elsif ($line =~/\/db_xref=/) {
			if ($line =~/\/db_xref="taxon:/) {
				#ignore
			}
			
			elsif ($line =~/\/db_xref="CDD:/) {
				#ignore
			}
			else {
				@temp2 = split (/"/,$line);
#				print "Temp22:$temp2[1]:\n";
				$dbxref=$temp2[1];
				push (@dbxref, $dbxref);
			}
		}
		elsif ($line =~/\/product=/) {
				@temp2 = split (/"/,$line);
#				print "Temp22:$temp2[1]:\n";
				$product = $temp2[1];
				unless ($product =~m/\w+/) {
					$product = " ";
					#print ":$product:\n";
				}
				#print "Prod:$product:\n";
			$genbank{$gbid}{"product"} = $product ;

		}

		elsif ($line =~/\/EC_number=/) {
				@temp2 = split (/"/,$line);
#				print "Temp22:$temp2[1]:\n";
				$ecnum = $temp2[1];
#				print "EC:$ecnum:\n";
			$genbank{$gbid}{"ecnum"} = $ecnum ;
		}
		elsif ($line =~/ORIGIN/){
		# empty the dbxref into the hash
		my %seen = (); 
		my @unique = grep { ! $seen{$_} ++ } @dbxref;
		my $xxx = join(";",@unique);
#		print "XX:$xxx:\n";
	
			$genbank{$gbid}{"dbref"} = "$xxx" ;	
		@dbxref = '';
		}
		else {
		}
	}

}
}

my $var = scalar keys %genbank;

print "Finished reading genbank files $var\n";
# print Dumper(%genbank);


###################################################################
####### associate the info from blast and genbank #################
###################################################################

# get unique genes

my %seen = (); 
my @unique = grep { ! $seen{$_} ++ } @genes;
#my $xxx .= "@unique";
# print "XX:$xxx:\n";
@genes=@unique;

#foreach my $key () {
#
#}


open (OUT, ">$out.sim") || die "I can't open $out.sim\n";
open (OUT2, ">$out.prod") || die "I can't open $out.prod\n";


######## screen dbxrefs ###################

open (DB, "/nfs/users/nfs_m/mz3/bin/perl/Chado_databases.txt") || die "I can't open nfs/users/nfs_m/mz3/bin/perl/Chado_databases.txt\n";
my @dbs = <DB>;
my %DBs;

foreach my $line (@dbs) {
	chomp $line;
	$DBs{$line} = $line;
#	print "$line\n";
}

close (DB);

###############################

foreach my $gene (@genes) {
#print "Gene:$gene:\n";

	foreach my $gene_ib (keys %blas) {
		my($gene2, $gbid2)=split (/\-/,$gene_ib);
#			print "$gene\n";
#			print "$gene2\n";
#			print "$gene_ib\n";
#			print "val: $blas{$gene_ib}\n";
		if ($gene2=~m/^$gene$/) {
#			print "Match";
#			print "G:$gene\n";
#			print "G2:$gene2\n";
#			print "IB:$gene_ib\n";
#			print "IB:$gbid2:\n";
#			print "val: $blas{$gene_ib}\n";
			foreach my $gbid (keys %genbank) {
#				if ($gbid=~m/^$gbid2$/) {
#					print "IB2:$gbid2\n";
	#				print "IB3:$gbid:\n";					
				}
			if (exists $genbank{$gbid2}) {
#			print "Match\n";	
#			print "IB:$gene_ib:\n";
#			print "IB:$gbid2:\n";

###############################################################

#print "$genbank{$gbid2}{product}\n";
#print "$genbank{$gbid2}{taxon}\n";
#print "$genbank{$gbid2}{dbref}\n";
# print "$genbank{$gbid2}{ecnum}\n";
#print "$blas{$gene_ib}\n";

if ("$genbank{$gbid2}{taxon}" =~m/\w+/) {
$taxon = "$genbank{$gbid2}{taxon}";
}
#my @keys = keys $genbank{$gbid2};
#foreach my $line (@keys) {
#print "$line\n";
#}
#
my $temp;
if (defined "$genbank{$gbid2}{product}" ) {
	$product = "$genbank{$gbid2}{product}";
}
else {
	$product = "hypothetical protein";
}

$dbxref = "$genbank{$gbid2}{dbref}";

# print "DB:$dbxref:\n";
@dbxref = split(/;/, $dbxref);
$blast = $blas{$gene_ib};
($gene, $match_length, $idprocent, $ungprocent, $eval, $score, $aaovl, $qstart, $qend, $sstart, $send)= split(/\t/, $blast);


# $gene\t$match_length\t$idprocent\t$ungprocent\t$eval\t$score\t$aaovl\t$qstart\t$qend\t$sstart\t$send";

my $similarity;

my $sim1 = "blastp";

my $sim2 = " ";


#### check database exists

if (exists $dbxref[1] ) {
		my ($db,$number)=split(/:/, $dbxref[1]);
	if (exists $DBs{$db} ) {
#		print "dbxref_exists:$dbxref[1]:\n";
	}
	else {
		 $sim2 = "$dbxref[1]";
#		print "dbxref1:$dbxref[1]:\n";
	}
}

my $sim3 = " ";
my $sim4 = " ";
if (exists $dbxref[2] and exists $DBs{$dbxref[2]} ) {
 $sim4 = "$dbxref[2]";
 $sim2 = "$dbxref[1] \($dbxref[2]\)";
}



my $sim5 = " ";
my $sim6 = " ";
if ( $taxon=~/\w+/) {
 $sim6 = "$taxon";
}

my $sim7 = " ";
if ( $product=~/\w+/) {
 $sim7 = "$product";
}
my $sim8 = "$gbid2";
my $sim9 = "length $match_length aa";
my $sim10 = "id=$idprocent%";

my $sim11 = "ungapped id=$ungprocent%";
unless ( $ungprocent=~/\d+/) {
  $sim11 = " ";
}
my $sim12 = "E()=$eval";
unless ( $eval=~/\d+/) {
  $sim12 = " ";
}

$score=~s/ //;
my $sim13 = "score=$score";
if ( $score=~/\./) {
	my ($new_score, $after)=split(/\./,$score);
 	$sim13 = "score=$new_score";
}

my $sim14 = "$aaovl aa overlap";
unless ( $aaovl=~/\d+/) {
  $sim14 = " ";
}
my $sim15 = "query $qstart-$qend aa";
unless ( $qstart=~/\d+/ and $qend=~/\d+/) {
  $sim15 = " ";
}
my $sim16 = "subject $sstart-$send aa";
my $sim18 = " ";

 $similarity = "/similarity=\"$sim1; $sim2; $sim6; $sim7; $sim8; $sim9; $sim10; $sim11; $sim12; $sim13; $sim14; $sim15; $sim16\"";

print OUT "$gene\t$similarity\n";
# print the output in product-form - so that I can do a sanity-check on names before assigning them

my $product2 ="/product=\"$sim7\"";

if ($sim7 =~/\w+/) {
my $note = "/note=\"Product \'$sim7\' is based on blast-similarity with GenBank:$gbid2\"";
print OUT2 "$gene\t$product2\t$note\n";
}

else {
# print "$gene:$product2:\n";
}


###############################################################

			}

			#}
		}
	}

}


print "Finished\n";


close (OUT);
close (OUT2);

__END__



=pod
FT                   /similarity="blastp; SWALL:Q26723 (EMBL:M20871);
FT                   Trypanosoma brucei brucei; variant-specific antigen;
FT                   ESAG3; ; id=70%; ; E()=2e-42; score=438; ; ;"

FT                   /similarity="fasta; SWALL:P26328 (EMBL:56768); Trypanosoma
FT                   brucei brucei; variant surface glycoprotein ILTat 1.23
FT                   precursor; ; length 532 aa; id=30.35%; ungapped id=32.34%;
FT                   E()=1.2e-34; ; 537 aa overlap; query 9-528 aa; subject
FT                   10-530 aa"

1.     Algorithm, e.g. fasta, blastp
2,3.   Primary dbxref, e.g. SWALL:Q26723
4,5.   Optional secondary dbxrefs, e.g. "EMBL:M20871", "EMBL:BC002634, AAH02634"
6.     Organism name
7.     Product name
8.     Gene name
9.     Optional match length
10.    Optional degree of identity (percentage)
11.    Optional ungapped identity (percentage)
12.    E-value
13.    Optional score
14.    Optional overlap length (integer)
15,16. Optional query location
17,18. Optional subject location
