#!/usr/bin/perl -w
# mz3 script 


use strict;


unless (@ARGV > 0 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl genezilla_wrapper.pl gff-file genome-fasta



'
}






my $in = shift;
my $fas = shift;
my $splits="0 0 100";
my 


# make right gff-file

print "perl ~/bin/perl/gff2genezilla.pl $in";
print "\n";

# make iso-chores
# split-by-isochore.pl train.gff contigs.fasta . 4 0 43 51 57 100
# position indicate the split i.e. 4 split, 0-43,43-51,51-57,57-100 GC% content

print "~/bin/RSVP/c++/genezilla/split-by-isochore.pl  $in.gfz $fas . $splits ";
print "\n";


#The get-examples.pl script is used to extract the actual nucleotide sequences for each of the features in the training set:
# trim means that the transcript does not have predicted UTRs

print "~/bin/RSVP/c++/genezilla/get-examples.pl  iso0-100.gff  iso0-100.fasta  TAG,TGA,TAA notrim";
print "\n";


#If any of the exons in your training set are partial (i.e., initial or single exons lacking a start codon, final or single exons lacking a stop codon, internal or initial exons lacking a donor site, or internal or final exons lacking an acceptor site), then you must run the enforce-consensus.pl program on the start/stop codon, donor, and acceptor example files to filter out examples having an incorrect consensus. Examples for each of these are shown below:

print "~/bin/RSVP/c++/genezilla/enforce-consensus.pl stop-codons0-100.fasta TAG,TGA,TAA";
print "\n";
print "~/bin/RSVP/c++/genezilla/enforce-consensus.pl start-codons0-100.fasta ATG";
print "\n";
print "~/bin/RSVP/c++/genezilla/enforce-consensus.pl donors0-100.fasta GT,GC";
print "\n";
print "~/bin/RSVP/c++/genezilla/enforce-consensus.pl acceptors0-100.fasta AG";
print "\n";
print "~/bin/RSVP/c++/genezilla/get-consensus.pl 0-100";
print "\n";
print "~/bin/RSVP/c++/genezilla/get-negative-examples-iso.pl 0-100";
print "\n";


print "~/bin/RSVP/c++/genezilla/train-signal.pl  ";
print "\n";


# extra 0.1 added at the end - results im *.tmp files
print "~/bin/RSVP/c++/genezilla/train-signal.pl WAM start-codons0-100.fasta non-start-codons0-100.fasta start-codons0-100 1 ATG 15 3 33 0.98 1 80 0 0.1 ";
print "\n";
print "~/bin/RSVP/c++/genezilla/train-signal.pl WAM stop-codons0-100.fasta non-stop-codons0-100.fasta stop-codons0-100 1 TAG 0 3 53 0.98 1 80 0 0.1  ";
print "\n";
print "~/bin/RSVP/c++/genezilla/train-signal.pl WAM donors0-100.fasta non-donors0-100.fasta donors0-100 1 GT 20 2 63 0.98 0 400 6 0.1 ";
print "\n";
print "~/bin/RSVP/c++/genezilla/train-signal.pl WAM acceptors0-100.fasta non-acceptors0-100.fasta acceptors0-100 1 AG 25 2 43 0.98 0 80 5 0.1 ";
print "\n";

# resulting command-lines
/nfs/users/nfs_m/mz3/bin/RSVP/c++/genezilla/train-signal-sensor.pl -o 1 -s 80 WAM pos-ATG.tmp neg-ATG.tmp start-codons0-100 1 ATG 15 3 0.98  -p 0.1
/nfs/users/nfs_m/mz3/bin/RSVP/c++/genezilla/train-signal-sensor  -o 1 -s 80 WAM pos-TAG.tmp neg-TAG.tmp stop-codons0-100 1 TAG 0 3 0.98  -p 0.1
/nfs/users/nfs_m/mz3/bin/RSVP/c++/genezilla/train-signal-sensor  -o 0 -s 400 WAM pos-GT.tmp neg-GT.tmp donors0-100 1 GT 20 2 0.98 -b 6 -p 0.1
/nfs/users/nfs_m/mz3/bin/RSVP/c++/genezilla/train-signal-sensor  -o 0 -s 80 WAM pos-AG.tmp neg-AG.tmp acceptors0-100 1 AG 25 2 0.98 -b 5 -p 0.1


