#!/usr/local/bin/perl -w
# mz3 script for splitting a gff-file to contigs in different folders

use strict;

unless (@ARGV == 2) {
        &USAGE;
 }

my $infile = shift;
my $prefix = shift;

# Get a list of folders

my $directories = `ls -d */`;

# print "$directories";

my @array = split(/\n/, $directories);
# Run GlimmerHMM in the contig in all folders

# print "+++$array[2]\n"; <STDIN>;

foreach my $line2 (@array) {
#chomp $line2;
#print $line2; <STDIN>;
my $line = (split /\//, $line2)[0];

# print "----$line-----\n";

system `cat $infile | grep -w $line > $line/$line.$prefix.gff`;

# print -s "$line/$line.$prefix.gff", "\n";

if (-s "$line/$line.$prefix.gff" == 0) {
system "rm -fr $line/$line.$prefix.gff";
}

#run glimmer

# print "glimmerhmm_x86_64 $line/$line.fasta -d $trainingdir -o $line/$line.$prefix.gff -g -f && perl ~/bin/perl/" , "/n";

}


sub USAGE {

die 'Usage: split_gff.pl <input_gff> prefix

prefix = prefix for the output filename


perl ~/bin/perl/split_gff.pl test3.cuff.gff test33



'
}



__END__


perl ~/bin/perl/split_Glimmer_2_contigs.pl /lustre/scratch101/sanger/mz3/gene_pred/EMU2/glimmerHMM/TrainGlimmM2011-02-16D15:14:39 test