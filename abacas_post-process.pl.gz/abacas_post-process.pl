#!/usr/local/bin/perl -w
# mz3 script 

use strict;


unless (@ARGV == 4 ) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: abacas_post-process.pl  fasta tab crunch splitinfo


'
}

my $fas = shift;
my $tab= shift;
my $crunch= shift;
my $split= shift;




open (IN, "<$fas") or die "Cant find file $fas\n" ;

# get the fasta sequence


my $head = <IN>;
chomp $head;
local $/ = ">";

while (my $line = <IN>)  {

  chomp($line);
  next unless $line;

    

}
$/ = "\n";

my %pos;


# read the crunch-file

open (IN2, "<$crunch") or die "Cant find file $crunch\n" ;
my @in2= <IN2>;

# read the split-file


open (IN3, "<$split") or die "Cant find file $split\n" ;

while (<IN3>){

    chomp;
    my @ar3=split(/\s+/,$_);
    #print "$ar3[0]\t$ar3[1]\t$ar3[2]\n";



    foreach my $ele (@in2){
        chomp;
        my @ar2=split(/\s+/,$ele);

        if ($ar3[1] <= $ar2[5] and $ar2[6] <= $ar3[2] ) {
            #print "$ar2[2]\t$ar2[5]\t$ar2[6]\n";
            #print "INSIDE  $ar2[2] $ar2[3] $ar2[4] has $ar2[5] $ar2[6] in $ar3[0]\t$ar3[1]\t$ar3[2]\n";
            $pos{$ar2[2]}="scaf_$ar3[0]";
            #print "$ar2[2]\t$ar3[0]\n";
            #shift @in2;
        }
        elsif ( $ar2[5] <= $ar3[1] and $ar2[6] <= $ar3[1]    ) {
            # before
        }
        elsif ( $ar3[2] <= $ar2[5] and $ar3[2] <= $ar2[6]    ) {
            # after
        }

        else {
            # if it spans 2 scaffolds go with the last
            #print "ELSE $ele\n ";
            #print "ELSE  $ar2[2] $ar2[3] $ar2[4] has $ar2[5] $ar2[6] in $ar3[0]\t$ar3[1]\t$ar3[2]\n";
            $pos{$ar2[2]}="scaf_$ar3[0]";
        }
    }




}

close (IN2);
close (IN3);

#__END__

# open the tab-file

open (TAB, "<$tab") or die "Cant find file $tab\n" ;
open (AGP, ">$tab.agp") or die "Cant open file $tab.agp\n" ;

my $i=1;
my $co1=0;
my $co2=0;
my $co3=0;
my $co4=0;
my $ori;
my $not_first=0;
my $scaf=0;

while (<TAB>) {
    chomp;
    #print "$_\n";
    my $id;




    if ($_=~/FT   contig/) {
            #print "$_\n";

            $id = <TAB>;
            $id =~s/FT                   \/systematic_id="//;
            $id =~s/"//;
            chomp $id;
            my $coord = $_;
            $coord=~s/FT   contig//;
            $coord=~s/\s+//;

            # get last rounds coords
            my $co5 = $co2+1;

            # check direction
            if ($coord=~/compl/) {
                $coord=~s/complement\(//;
                $coord=~s/\)//;
                ($co3,$co4)=split(/\.\./,$coord);
                $ori="-";
                #print "CCORD $co1\t$co2\n";
            
            }
            else {
                ($co3,$co4)=split(/\.\./,$coord);
                $ori="+";

            }

            unless ($scaf=~/^$/) {
                # put scaffold-name
                if (exists $pos{$co3}) {

                    unless ($scaf=~/^$pos{$co3}$/) {
                        #print "Exists $co3\n";  
                        $i=1;
                        $scaf = $pos{$co3};
                    }
                }
                else {
                    #print "Doesnt exist $co3\n";
                    $scaf = "scaf_" . $i; 
                    $i=1;
                }
            }


            #$co3 = $co3+ $co1;
            #$co4 = $co4 + $co2;


            my $co6 = $co3-1;
            my $len = $co6-$co5+1;


            if ($not_first=~/1/) {
                print AGP "$scaf\t$co5\t$co6\t$i\tN\t$len\tscaffold\tyes\tpaired-ends\n";   
                $i++;
            }


            $co1 = 1;
            $co2 = $co4-$co3+1;
            
            print AGP "$scaf\t$co3\t$co4\t$i\tW\t$id\t$co1\t$co2\t$ori\n";   
           
            $co1=$co3;
            $co2=$co4;
            $i++;
            $not_first=1;
        }
        else {
            #print "ELSE $_\n";
        }


    


}



close (IN);
close (TAB);
close (AGP);



