#!/usr/bin/perl -w


# use strict;

use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_embl_cleanup.pl folder out-prefix
# From a folder, it gathers all embl-files in the directories, merges them, flags up mistakes, and makes a cleaned-up version


First run the writedb_entries.py script 


'
}

# Unzip the files in all folders and cat them

my $folder = shift;
my $prefix = shift;
my $cwd = cwd();
# print "CWD: $cwd\n";
my $dir = cwd();
my @dirs ;

=pod


my @paths = read_dir( "$folder", prefix => 1 ) ;


foreach my $elem (@paths) {
    unless ($elem=~m/\./) {
        push (@dirs, $elem);
    }
}

#Make sure the folder has the right path - if not a path - assume that it is in this folder

if ($folder =~m/\//) {	
	if (-d "$folder") {
		print "If: $folder\n";
		foreach my $elem (@dirs) {
			$elem = "$folder\/$elem";
			print "`gunzip -r $elem\n";
            system `gunzip -r $elem `;
			print "Unzipping of $elem finished\n";

            unless (-z  "$elem.embl" ){
                system  `cat $elem/*.embl > $elem.embl `;
            }
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
#		print "Else: $cwd\/$folder\n";
		foreach my $elem (@dirs) {
			$elem = "$cwd\/$folder\/$elem";
			print "`gunzip -r $elem\n";
            system `gunzip -r $elem `;
            print "Unzipping of $elem finished\n";

            unless (-z  "$elem.embl" ){
                system  `cat $elem/*.embl > $elem.embl `;
            }
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

print "Fishished reading files\n";



# Concatenate all files

my $nothing = " ";
push (@dirs, $nothing);
#open (EXC, ">exception.list") || die "I can't open exception.list\n";
my $filelist = join( "/*.* ", @dirs); 

# print "List:$filelist:\n";

unless (-z "$prefix.all.originals.embl") {
system `cat $filelist > $prefix.all.originals.embl`;
}

=cut 

# Read in the concatenated file
#
	open (IN, "<$prefix.all.originals.embl") || die "I can't open $prefix.all.originals.embl\n";
	my @embl = <IN>;
	close (IN);

#my @embl;
#my @no_genes;

=pod
# sort out which contigs have and do not have genes
foreach my $line (@in){
    chomp $line;
    if ($line=~m/\tchado\t/){
        push (@embl, $line);
    }
    elsif ($line=~m/\>/) {
        push (@no_genes, $line);
    }
}

# Print a list of contigs with no genes
	open (OUT, ">$prefix.contigs.list") || die "I can't open $prefix.contigs.list\n";

foreach my $line (@no_genes) {
    print OUT "$line\n";
}

=cut

# Get only the annotation

=pod
    
my @embl2;

foreach my $line (@embl) {
    chomp $line;
    if ($line=~m/^ID/ || $line=~m/FT/  ) {
       push (@embl2, $line);
    }


}
# Make a hash containing %gene{gene}{contig} = contig
#                                   {FT} = @fts
#                                   {CDS} = coords
#                                   {locus} = locus_tag
my %gene;
foreach my $line (@embl2) {
    if ($line=~m/^ID/) {
        $line =~s/ID   //;
        my @arr = split(/\./, $line);
        print "Contig:$arr[0]:\n";
    }
    elsif ($line=~m/^FT   CDS             /) {
        $line =~s/FT   CDS             //;
#        my @arr = split(/\./, $line);
        print "CDS:$line:\n";
    }
    elsif ($line=~m/^FT/) {
        $line =~s/FT                   //;
#        my @arr = split(/\./, $line);
        print "FT:$line:\n";
    }

}
=cut

# Make a hash containing %gene{gene}{contig} = contig
#                                   {FT} = @fts
#                                   {CDS} = coords
#                                   {locus} = locus_tag
my %gene;
	my $name;
	my $method = "chado";
	my $tag = "CDS";
	my $start = "0";
	my $end = "0";
	my $score = ".";
	my $strand;
	my $id;
my @ft='';
my $cds='';

foreach my $line (@embl) {
chomp $line;
if ($line=~/\w/ or $line=~/\W/ ) {
#print "LINE:$line:\n";
	my @arr=split(/\s+/, $line);
#		print "LINF:$arr[0]:\n";
    if ($arr[0]=~/^FH/ || $arr[0]=~/\/\// ) {
        # do nothing;
    }
	elsif ($arr[0]=~/^ID/) {
		$contig = $arr[1];
		$contig =~s/\.embl\;//g ;
#		print "Cont:$contig\n";
	}
	elsif ($arr[0]=~/^FT/ and $arr[1]!~/locus_tag/ ) {
		if ($arr[1] =~/CDS/) {
			if ($arr[2] =~/complement/) {
				$strand = "-";
				$arr[2] =~s/complement\(//g;
				$arr[2] =~s/join\(//g;
				$arr[2] =~s/\)\)//g;
				$arr[2] =~s/\)//g;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
#				foreach my 
#				split(//,);
                push (@cds, $line);

			}
			else {
				$strand = "+";
				$arr[2] =~s/join\(//;
				$arr[2] =~s/\)//;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
                push (@cds, $line);
			}
		}
		else {
            $line=~s/FT                   //;
#			print "Filter 2:$line\n";
            push (@ft, $line);
		}
	
	}
    elsif ($line =~m/\)/ || $line =~m/\./ ) {
#		print "Filter 3:$line\n";
        push (@cds, $line);

    }

		elsif ($arr[1] =~/locus_tag/ or $arr[1] =~/gene/) {
			$arr[1]=~s/\/locus_tag="//;
			$arr[1]=~s/\/gene="//;
			$arr[1]=~s/\"//;
#			/locus_tag="KOG0450.57"
#			print "ID:$arr[1]\n";
			$id = $arr[1];	
#			foreach my $pos (@arr2) {
#				($start,$end)=split(/\.\./, $pos);
#				print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#			}
            # Fill the hash
# Make a hash containing %gene{contig}{gene}
#                                           {FT} = @fts
#                                           {CDS} = coords
#                                           {ORI} = strand
#            print "$contig\t$id\t$strand\n";
            # Add orientation
            $gene{$contig}{$id}{"ORI"} = $strand;

            # Add features
            $fts = join ("", @ft);
#            print "Features:$fts:\n";
            my @ftarr = split(/\//, $fts);
#            print "Feature1:$ftarr[1]:\n";
            foreach my $elem ( @ftarr ) {
                if ($elem=~m/\w/){
                    push (@{$gene{$contig}{$id}{"FT"}}, $elem );
                }
            }

            # Add CDS-coords

            $cds = join ("", @cds);
            $cds=~s/FT   CDS             //;
#            print "Coords:$cds:\n";
            my @coarr = split(/\,/, $cds);
#            print "Feature1:$coarr[0]:\n";
            foreach my $elem ( @coarr ) {
                if ($elem=~m/\w/){
                    push (@{$gene{$contig}{$id}{"CDS"}}, $elem );
                }
            }

        @ft='';
        @cds='';
	    $start = "0";
	    $end = "0";
	    $score = ".";
	    $strand = "0";
	    $id = "0";


		}


	elsif ($arr[0]=~/\/\//) {
#		foreach my $pos (@arr2) {
#				($start,$end)=split(/\.\./, $pos);
#			print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#		}
	}
	else {
#		print "Filter 1:$line\n";
	}


# print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\n";
}
}


# Empty the genes hash

foreach my $cont (sort keys %gene) {
    while ( my ($name, $value) = each %{ $gene{$cont} } ) {
        my $ori = $gene{$cont}{$name}{ORI} ;
#        print "$cont\t$name\t$ori\n";

        foreach my $feat (@{$gene{$cont}{$name}{"FT"}}) {
            if ($feat=~/^product/) {
                print "$cont\t$name\t/$feat\n";
            }
            
            
#            print "FEAT:/$feat:\n";
        }
    }
}


=pod
foreach my $cont (sort keys %gene) {
    foreach my $name (sort keys %{ $gene{$cont} }) {
        my $ori = $gene{$contig}{$name}{ORI} ;
        print "$cont\t$ori\n";

        foreach my $feat (@{$gene{$contig}{$name}{"FT"}}) {
#            print "FEAT:$feat:\n";
        }
    }
}
