#!/usr/bin/perl
use strict;


unless (@ARGV < 1) {
        &USAGE;
}



# housekeeping
# my $in = shift;
# open (IN, "<$in");

my($day, $month, $year) = (localtime)[3,4,5];
$month = sprintf '%02d', $month+1;
$day   = sprintf '%02d', $day;
# print $year+1900, $month, $day, "\n";
$year = $year+1900;

print "$year$month$day.script\n";

system "script -a /nfs/helminths/users/mz3/script/$year$month$day.script";


sub USAGE {

die ' 

This starts script and makes a file with the date

';

}

