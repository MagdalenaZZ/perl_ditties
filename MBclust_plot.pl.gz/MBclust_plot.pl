


#  Take the members of all clusters


#  Retrieve their RPKMs/reads and scale them


#  plot their expression values


 xyplot(Sepal.Length ~ Sepal.Width |  data=Count, type="a", layout=c(1,3,1))
Error: unexpected '=' in "xyplot(Sepal.Length ~ Sepal.Width |  data="
> xyplot(X3 ~ X2 |  data=Count, type="a", layout=c(1,3,1))
Error: unexpected '=' in "xyplot(X3 ~ X2 |  data="
>
> xyplot(X3 ~ X2 | X5, data=Count, type="a", layout=c(1,3,1))
Error in eval(expr, envir, enclos) : object 'X5' not found
> xyplot(X3 ~ X2 | X8, data=Count, type="a", layout=c(1,3,1))
>
> parallelplot(~iris[1:4] | X5, Count, horizontal.axis = FALSE, layout = c(1, 3, 1))
Error in eval(expr, envir, enclos) : object 'X5' not found
>
> parallelplot(~iris[1:4] | X8, Count, horizontal.axis = FALSE, layout = c(1, 3, 1))
>
> xyplot(X3 ~ X2 | X8, data=Count, type="a", layout=c(1,3,1))
> parallelplot(~Count[1:9] | X8, Count, horizontal.axis = FALSE, layout = c(1, 3, 1))
Error in `[.data.frame`(Count, 1:9) : undefined columns selected
>
> parallelplot(~Count[2:9] | X8, Count, horizontal.axis = FALSE, layout = c(1, 3, 1))
Error in `[.data.frame`(Count, 2:9) : undefined columns selected
>
> parallelplot(~Count[2:8] | X8, Count, horizontal.axis = FALSE, layout = c(1, 3, 1))
>
> xyplot(X3 ~ X2 | X8, data=Count, type="a")
> xyplot(X3 ~ X2 | X8, data=Count, type="a", layout = c(1))
Error in compute.layout(x$layout, cond.max.levels, skip = x$skip) :
  layout must have at least 2 elements
> xyplot(X3 ~ X2 | X8, data=Count, type="a", layout = c(1,1))
> parallelplot(~Count[2:8] | X8, Count, horizontal.axis = FALSE, layout = c(1,1))
> head(iris)
  Sepal.Length Sepal.Width Petal.Length Petal.Width Species
1          5.1         3.5          1.4         0.2  setosa
2          4.9         3.0          1.4         0.2  setosa
3          4.7         3.2          1.3         0.2  setosa
4          4.6         3.1          1.5         0.2  setosa
5          5.0         3.6          1.4         0.2  setosa
6          5.4         3.9          1.7         0.4  setosa




