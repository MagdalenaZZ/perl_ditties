#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_intron-exon.pl infile.gff outfile




'
}


	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);
	open (OUT, ">$out") || die "I can't open $out\n";



### make a hash with gene-names

my %hash;

foreach my $line (@in) {
	chomp $line;
    $line=~s/exon/CDS/;
#    $line=~s/five_prime_UTR/CDS/;
#    $line=~s/three_prime_UTR/CDS/;
	my @arr = split(/\t/, $line);
    if ($arr[2]=~m/^CDS$/) {
#        print "$arr[8]\n";
        my @genes = split(/\./,$arr[8]);
        my $gene = "$arr[0]\t$genes[0]\t$arr[6]";
        my $coords = "$arr[3]\t$arr[4]";
        push (@{$hash{$gene}}, $coords );
#        print "$gene\t$coords\n";

    }
    elsif ($arr[2]=~m/five_prime_UTR/) {
#             print "$arr[8]\n";
        my @genes = split(/\./,$arr[8]);
        my $gene = "$arr[0]\t$genes[0]\t$arr[6]";
        my $coords = "$arr[3]\t$arr[4]";
#        push (@{$hash{$gene}}, $coords );
#        print "$gene\t$coords\n";

    }
    elsif ($arr[2]=~m/three_prime_UTR/) {
#             print "$arr[8]\n";
        my @genes = split(/\./,$arr[8]);
        my $gene = "$arr[0]\t$genes[0]\t$arr[6]";
        my $coords = "$arr[3]\t$arr[4]";
        push (@{$hash{$gene}}, $coords );
#        print "$gene\t$coords\n";
    }
}

#use Data::Dumper;
#print "dump\n";
#print Dumper(%hash);
#print "dump2\n";


foreach my $key (sort keys %hash) {
    if ($key=~m/\w+/){
#            print "$key\n";
    my $coord=join("-", @{$hash{$key}} );
#    print "$key:$coord\n";
    my @arr = split(/\s+/, $coord);

    foreach my $elem (@arr) {
#            print  "$elem\n";

        if ($elem=~/\-/) {
            my @intron = split(/\-/, $elem);
            $intron[0]++;
            $intron[1]--;
            my @key= split(/\s+/, $key);
#            print  "$elem\n";
            print  OUT "$key[0]\tintron\tintron\t$intron[0]\t$intron[1]\t\.\t$key[2]\t\.\t$key[1]\n";
        }
        else {
            #ignore
        }
    }
    }
}


exit 0;

__END__








=pod

	my $lead = "$arr[3]";
#	unshift(@arr, "$lead"); 
	my $newline = "$lead\t$line";
	my @last_arr = split(/\t/, $last_line);
#	print "Arr $arr[0]\n";
#	print "Last $last_arr[0]\n";
	my $first_gene="START\tSTART\tSTART\tSTART";

# Test if we are still on the same contig
	if ($arr[0] =~/$last_arr[0]/) {
#		print "Match\n";
		my ($key, $oa, $ob, $oc, $od)= split(/([:;])/,$arr[8]);
#		print "Key $key\n";
#		unshift(@{$hash{$key}}, $lead);	

# Test if the first value already exists	
		if ($hash{$key}[0]) {
# Replace the value if there is a new lower value
			unless ($hash{$key}[0] <= $lead){
				$hash{$key}[0] = $lead;
			}
#			print "IF: Key1 $key \n" . "value1 $newline\n";		
		}
# or put a new value
		else {	
			push(@{$hash{$key}}, $lead);
#			print "ELSE: Key1 $key \n" . "value1 $lead\n";
		}

		push(@{$hash{$key}}, $newline);
#		print "Key2 $key \n" 
#		print "NEW:$newline\n";		
	}


# Now we are on a new contig - time to print everything we caught in the hash

	else {

	#Here I have to add the first value from the new contig
		unless ($line=~/END/) {
			my ($key2, $oa, $ob, $oc, $od)= split(/([:;])/,$arr[8]);
#			$key2=~s/ID=//;
#			push(@{$hash{$key2}}, $newline);
#			print "Key2: $key2\n";
#			print "Val: $newline\n";
			$first_gene=$newline;
		}
#	print "All well\n";

# FOREACH LOOP to sort the values
		foreach my $key (sort {$hash{$a}[0] <=> $hash{$b}[0] }  keys %hash) {
#	 		 print "Value $key $hash{$key}[0]\n";
			foreach my $i (@{$hash{$key}}) {
# here I have lost the first value	
                if ($i=~/w+/) {
                my @x =split(/\s+/, $i);
                # print "$x[3]\n";	
				    $x[3]=~s/gene/Age/;
				    $x[3]=~s/mRNA/BmR/;
				    $x[3]=~s/transcript/Btran/;
                     $i = join("\t", @x);
                     #  print "NEW:$x[3]\n";
                }
			}

				my @sort = sort {(split/\t/, $a)[0] <=> (split/\t/, $b)[0]} (@{$hash{$key}});
#					print ":$sort[0]:\t:$sort[1]:\n";
					shift @sort;
					my $scalar = scalar(@sort);
					my $first1 = $sort[0];
#					print "Scalar:$scalar:\t:$first1:\t:$sort[1]:\n";
					if ($sort[0]) {
						foreach my $line2 (@sort) {
							chomp $line2;
#							print "LINE2: $line2:\n";
							if ($line2=~/pathogen/) {
#								print "Line2: $line2:\n";
								my @final= split (/\t/, $line2);
								shift @final;
								$final[2]=~s/Age/gene/;
								$final[2] =~s/BmR/mRNA/;
								$final[2] =~s/Btran/transcript/;	
								my $final = join ("\t",@final);
                                $final=~s/ $//;
                                $final=~s/\"\_\//\"\t\//g;
								print OUT3 "$final\n";
#								print "Final: $final:\n";<STDIN>;
							}
						}
					}
					else {
						print "Funny line: $sort[0]\n:";
					}
		}

	# Empty the hash
		foreach my $key  (keys %hash) {
			delete $hash{$key};
		}	

	# Add the first value to the new hash
		unless ($first_gene=~/START/) {
#			print "First: $first_gene\n";
			my @first=split(/\t/, $first_gene);
#			print "First Key: $first[9]\n";
			push(@{$hash{$first[9]}}, $first[0]);
			push(@{$hash{$first[9]}}, $first_gene);
		}
	
	}

$last_line=$line;

}


close (OUT3);


