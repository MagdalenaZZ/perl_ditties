#!/usr/local/bin/perl -w
# mz3 script 

use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: orthomcl_out_parser.pl outprefix


'
}


## parse infile

my $infile = "all_orthomcl.out";
my $outfile = shift;
 
open (IN, "<$infile");
my @in = <IN>;

open (OUT, ">$outfile");

my @stats;

foreach my $line (@in) {
    chomp $line;
    my ($head, $genes) = split(/\t/, $line);
#    print "$head\n";
    my ($cluster, $stats) = split (/\(/, $head);
    push (@stats, $head);
    my @arr = split(/\s+/, $genes);
    foreach my $elem (@arr) {
        unless ($elem=~m/EmW2/ || $elem!~m/\w/) {
            $cluster=~s/ORTHOMCL/omcl_/;
            $elem=~s/\(EMU\)//;
            print "$cluster\t$elem\n";
        }
    }

}


close (OUT);
