#!/usr/local/bin/perl -w
#
use strict;

my($file) = @ARGV;

open(F, "<$file") or die "$!";

while(<F>)
{
	chomp;

	my($ref, $hit_id, $pc_id, $aln_len, $mismatch, $gaps, $ref_st, $ref_end, $hit_st, $hit_end, $e, $score) = split /\t/;

	next unless $e < 1e-05 && $score > 50;

	print "$ref_st $ref_end $hit_st $hit_end $hit_id $pc_id $pc_id $score\n";
}
close F;
