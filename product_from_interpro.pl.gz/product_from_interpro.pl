#!/usr/local/bin/perl -w
# mz3 script for getting product-calls from interproScan
use strict;

unless (@ARGV == 4) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: product_from_interpro.pl <interpro> <namelist> <out-prefix>  interpro/pfam

prefix = prefix for the output filename

namelist - a file with gene-names, possibly followed by a product-call
(if the product-call is "hypothetical protein", it will be replaced by a better name from interpro)

Choose if your infile if Pfam or interpro


'
}


my $ip = shift;
my $in = shift;
my $out = shift;
my $pfam = shift;



         # OPEN INPUT AND OUTPUT
        open (IN, "<$in") || die "I can't open $in\n";
        my @in = <IN>;
        close (IN);

        open (IP, "<$ip") || die "I can't open $ip\n";
        my @ip = <IP>;
        close (IP);

        open (OUT, ">$out.products") || die "I can't open $out.products\n";
        open (OUT2, ">$out.domains") || die "I can't open $out.domains\n";
        open (OUT3, ">$out.errors") || die "I can't open $out.errors\n";


        # Read in interpro results to a hash %ip{gene}{program}{@names}

       my %ip;

       foreach my $line (@ip) {
           chomp $line;
           my @arr = split(/\t/, $line);
           my $gene = $arr[0];
           $gene=~s/\:pep//;
           $gene=~s/\{pep\}//;
           $gene=~s/ //g;
           chomp $gene;
           my $prog;
#           {pep}
            if ($pfam=~/^i/i) {
              $prog = $arr[3];
            }
            elsif ($pfam=~/^p/i) {
               $prog = "HMMPfam";
            }
            else {
                print "\nI don't know if the input is Pfam or interpro, try printing \"ipr\" or \"pfam\" \n\n"; die; 
            }
            # fix up product

           my $name = $arr[12];
           $name =~s/\// /g ;
           $name =~s/PDZ DHR GLGF/PDZ/ ;
           $name =~s/EF-HAND 2/EF-hand 2/ ;
           $name =~s/OST3 OST6/magnesium transporter/ ;
           $name =~s/BTB POZ/BTB:POZ/ ;
           $name =~s/ENTH VHS/ENTH (VHS)/ ;
           $name =~s/EGTP1 OBG/GTP-binding/ ;
           $name =~s/GTP1 OBG/GTP-binding/ ;
           $name =~s/t-SNARE/target-SNARE/ ;
           $name =~s/NOT2 NOT3 NOT5/NOT/ ;
           $name =~s/GRIM-19/GRIM-19/ ;
           $name =~s/DSS1 SEM1/DSS1 (SEM1)/ ;
           $name =~s/\-like// ;
           $name =~s/ domain// ;
#            $name =~s/^$/domain containing protein/ ;
          
            my @arr2 = split(/,/, $name);
            $name = $arr2[0];

#                     print "$gene\t$prog\t$name\n";
           #}

            if ($prog=~m/^HMMPfam$/ ||$prog=~m/^HMMPanther$/ ||$prog=~m/^superfamily$/ ||$prog=~m/^HMMSmart$/ ||$prog=~m/^FPrintScan$/ ||$prog=~m/^Gene3D$/ ||$prog=~m/^ProfileScan$/  ||$prog=~m/^HMMTigr$/  ||$prog=~m/^PatternScan$/ ||$prog=~m/^BlastProDom$/  ) {
                if  ($name!~/^NULL$/  ) {
                   push(@{$ip{$gene}{$prog}}, $name);
               }
            }
       }


        # Read in the existing products to a hash %in{gene} = name 

       my %in;

       foreach my $line (@in) {
           chomp $line;
           my @arr = split(/\t/, $line);
           my $gene = $arr[0];
             $gene =~s/ //g;
#            $gene= $gene . "\.1";
           my $prod = $arr[1];

#           print "IN:$gene\t$prod\n";
            $in{$gene}= $prod;

        }

my %new;

        foreach my $genx (keys %ip) {
            foreach my $prog (keys %{$ip{$genx}}) {
                if ($prog=~/HMMPfam/) {

                    my %seen = ();
                    my @uniq = grep { ! $seen{$_} ++ } @{$ip{$genx}{$prog}}  ;
                    my $prod2 = join(" and ", @uniq);
                    if ($prod2=~/\w+/ ) {
                        $new{$genx}{$prog} = $prod2;
#                        print "$genx\t$prod2\n";
                    }
                    else {
#                        print "WARN:$genx\t$prog\t$prod2\n";

                    }
                }
            }
        }

 # print out only genes which can replace hypotheticals

        foreach my $gene (sort keys %new) {

                foreach my $prog (sort keys %{$new{$gene}} ) {
                    my $prod2 = $new{$gene}{$prog};
#                    print "$gene\t$prog\t$new{$gene}{$prog}\n";
#                    print "$gene\t$prog\n";

                    if (exists $in{$gene} ) {
                        if ($in{$gene} =~m/hypothetical/) {
                            print OUT "$gene\t\/product=\"$prod2 domain containing protein\"\t/note=\"$prog\"\n";
                        }
                        elsif ($in{$gene} =~m/domain/) {
                            print OUT2 "$gene\told_$in{$gene}\t\/product=\"$prod2 domain containing protein\"\t/note=\"$prog\"\n";
                            print OUT "$gene\t\/product=\"$prod2 domain containing protein\"\t/note=\"$prog" . "2\"\n";
                        }
                        else {
                                # gene already has name
                                #print "Gene already has a name:$prod2\t$gene\n";
                                print OUT "$gene\t$in{$gene}\n";
                        }
                    }
                    else {
                        print OUT3 "WARN: interpro-gene $gene does not exist in product input \n";
#                        print "$gene\n";
                    }
                
            }



       }

close (OUT);

close (OUT2);

__END__



farm2-head2[mz3]32: cat Emultilocularis.prots.interpro | awk '{print $4}' | sort | uniq -c | sort -nr
#  28822 Seg
  11675 HMMPfam
  10408 HMMPanther   (can have NULL)
   9712 superfamily
   9092 HMMSmart
   7985 FPrintScan
   7246 Gene3D
   7120 ProfileScan
   3977 PatternScan
#   3457 Coil
    582 HMMTigr
    254 BlastProDom
    242 HMMPIR
     86 HAMAP
        


