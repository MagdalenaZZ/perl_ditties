#!/usr/bin/perl -w

use strict;




my $largest = 0;
my $contig = '';


if (@ARGV < 1) {
	print "\n\nUsage: fasta_DNAorProt.pl fasta \n\n" ;

    print " mz3 script for splitting a file to DNA and amino-acids\n\n";

	exit ;
}

my $filenameA = shift @ARGV;

my %reads = () ;


open (OUT, ">$filenameA.fas") or die "oops!\n" ;
open (OUT2, ">$filenameA.aa") or die "oops!\n" ;
open (OUT3, ">$filenameA.report") or die "oops!\n" ;

open (IN, "$filenameA") or die "oops!\n" ;

my %new;
my %newer;

while (<IN>) {

    my $index = "2";
    # print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $_;
	$seq_name=~s/>//;
    chomp $seq_name;
	my $seq = <IN> ;
	chomp($seq) ;
    my $new_name;

    $new{$seq} = $seq_name;

    }
}


    # make and fill hases of dna and amino acids

my %dna;
my %aa;

$dna{"T"}=1;
$dna{"C"}=1;
$dna{"G"}=1;
$dna{"A"}=1;
$dna{"*"}=1;
$dna{"-"}=1;
$dna{"N"}=1;

$aa{"G"}=1;
$aa{"L"}=1;
$aa{"I"}=1;
$aa{"A"}=1;
$aa{"F"}=1;
$aa{"R"}=1;
$aa{"S"}=1;
$aa{"D"}=1;
$aa{"Y"}=1;
$aa{"W"}=1;
$aa{"P"}=1;
$aa{"Q"}=1;
$aa{"C"}=1;
$aa{"M"}=1;
$aa{"H"}=1;
$aa{"T"}=1;
$aa{"V"}=1;
$aa{"E"}=1;
$aa{"N"}=1;
$aa{"K"}=1;
$aa{"#"}=1;
$aa{"*"}=1;
$aa{"+"}=1;


my $res_dna=0;
my $res_aa=0;

foreach my $seq2 ( keys %new ) {


    # determine if the seqence is DNA or amino acid
    
    my @arr = split (//, $seq2);
    my $dna_score= 0;
    my $aa_score = 0;

    foreach my $base ( @arr) {

        if (exists $dna{$base} ) {
            $dna_score++;
        }
        if (exists $aa{$base} ) {
            $aa_score++;
        }


    }

#        print "DNA:$dna_score\tAA:$aa_score\n";

    
    if ( $dna_score > ($aa_score*0.9) ) {
#        print "DNA:$seq2\n";
        print  OUT ">$new{$seq2}\n$seq2\n";
        $res_dna++;
    }
    elsif ( $aa_score > $dna_score  ) {
#        print "AA:$seq2\n";
        print  OUT2 ">$new{$seq2}\n$seq2\n";
        $res_aa++;
    }
    else {
        print "DNA:$dna_score\tAA:$aa_score\n";
        print "dunno:$seq2\n";

    }


    
}

print "There are $res_aa amino acids and $res_dna DNA sequences\n";


close (OUT);
close (OUT2);
close (OUT3);




__END__




        # make headers uniq   
        foreach my $seq_head ( keys %{$new{$seq2}} ) {
            $arrx{$seq_head }=1;
        }

        my @arrs;

        foreach my $sxx ( keys %arrx ) {
            push (@arrs, $sxx);
        }

        my $new_head = join ("_", @arrs);

        if (scalar(@arrs)> 1) {

            foreach my $ele (@arrs) {
                print OUT2 "$ele\t";
            }
                print OUT2 "merged_to\t$new_head\n";
        }
#        else {
#            print OUT2
#        }

#        print "$new_head\n";

        $newer{$new_head}{$seq2}=1;

    }


    # check if there are any duplicate names

my %res;

foreach my $id ( keys %newer ) {
        my $index =1;
        my %arrx2;

# empty the names with several sequences

            # check if name has several seqs
            if ( scalar(keys %{$newer{$id}} ) > 1 ) {
                #print "NOT UNIQ:\n";

                foreach my $kei (keys  %{$newer{$id}} )  {
                    my $new_h = "$id\.$index";
                    $res{ $new_h } = $kei;
                    $index++;
                    print OUT2 "$id\tis_now\t$new_h\n";
                }
            }
            else {
                # print "UNIQ:\n";

                foreach my $kei (keys  %{$newer{$id}} )  {
                    $res{ $id } = $kei ;
                }
            }

}

foreach my  $elem ( sort keys %res ) {
    print OUT3 "\>$elem\n$res{$elem}\n";
}



__END__
    # check if there are any duplicate names
    
    
#	print "SEQname:$seq_name:\n";	
	if ( exists $reads{$seq_name} ) {
			print OUT2 ">$seq_name\n" ;
			print OUT2 "$seq\n" ;
#            delete $reads{$seq_name};
            $new_name =  "$seq_name" . "\.$index" ;
            while ( exists $new{$new_name}) {
                $index++;
                $new_name =  "$seq_name" . "\.$index" ;
            }
            $new{$new_name} = $seq;
            print "Renamed\t$seq_name\t$new_name\n";
	}
    else {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;
            $new{$seq_name} = $seq;

    }

	$reads{$seq_name} = $seq ;

    }
	
    
    #last;


}

foreach my  $elem ( sort keys %new ) {
    print OUT3 "\>$elem\n$new{$elem}\n";
}

close (OUT);
close (OUT2);
close (OUT3);

#print "\#\#the largest length is: $contig with $largest bp \n" ;
