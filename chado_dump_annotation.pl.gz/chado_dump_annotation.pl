#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado_dump_annotation.pl genome.fas GFF/EMBL



'
}



	my $in = shift;
    my @in2=split (/\./, $in );
	my $file = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	open (OUT, ">$in2[0].sh") || die "I can't open $in2[0].sh\n";

my @cont;
my $line;
my $i;


    while (<IN>) {
        if ($_ =~/^>/) {
            chomp;
            my $head =$_;
            $head =~s/>//;

            if ($i > 100) {
                push (@cont, $line);
                $line = $head;
                $i = 0;
            }
            else {
                $line = $line . " " . $head ;
                # print "$line\n";
                $i++;
            }

        }
    }

mkdir "$in2[0]";
mkdir "$in2[0]/$file";


foreach my $con (@cont) {

print OUT  "writedb_entry -Djava.awt.headless=true -f y -c pgsrv1:5432/pathogens?mz3\@sanger.ac.uk -o $file -u script -p KL37m_X7 -fp $in2[0]/$file -s $con ;\n " 

}





print "bsub.py -q yesterday 1 $in2[0] bash $in2[0].sh\n ";
