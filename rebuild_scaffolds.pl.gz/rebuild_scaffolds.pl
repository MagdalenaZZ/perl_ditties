#!/usr/local/bin/perl -w

use strict;

open RPF, "reads.placed";
open SCF, "read.placed.original";
open SGL, "single_scaffolds.list";
open NON, "0803_Hym_genome.singletons";
open LOG, ">rebuild.scaffolds.log";

my %rpf;
my %rpf2;
my %scf;
my %supers;
my %sgl;
my %non;

while (<RPF>) {
	chomp;
	if (/(genome\d\_)contig/) {
		s/$1//g;
		#print; <STDIN>;
		my $contig = (split /\s+/, $_)[1]; 
		my $merged = (split /\s+/, $_)[5];
		my $l =  (split /\s+/, $_)[3];
		my $pos = (split /\s+/, $_)[7];
		my $orient = (split /\s+/, $_)[4];
		$rpf{$merged}{$contig} = "$l\t$pos\t$orient";
		$rpf2{$contig} = $merged;
	}
}

while (<NON>) {
	chomp;
	if (/(genome\d\_)contig/) {
		s/$1//g;
		#print; <STDIN>;
		my $contig = $_; 
		$non{$contig} = 1;
	}
}

while (<SCF>) {
	chomp;
	my $contig = (split /\s+/, $_)[0]; 
	my $super = (split /\s+/, $_)[1];
	$scf{$contig} = $super;
	$supers{$super}{$contig} = 1;
}

while (<SGL>) {
	chomp;
	my $contig = (split /\s+/, $_)[0]; 
	$sgl{$contig} = 1;
}

my %used;
my %news;
my $newscaff = 0;
foreach my $super (keys %rpf) {
	#print "$super"; <STDIN>;
	if ($used{$super}) {
		my @keys = keys %{$news{$super}};
		#print scalar @keys; <STDIN>;
		if (scalar @keys > 1) {
			#print LOG "wierd...";
			#print @keys; <STDIN>;
			my $join = join (" and ", @keys);
			print LOG "$super was already included/used $used{$super} in $join\n"; #<STDIN>;
		}
		#print "$super was already included/used $used{$super} in $keys[0]"; <STDIN>;
	} else {
		$used{$super}++;
		foreach my $contig (keys %{$rpf{$super}}) {
			my $count = scalar keys %{$rpf{$super}};
			if ($count == 1) {
				#print "just one capillary contig there..."; <STDIN>;
				if ($sgl{$contig}) {
					#print "$contig was singleton scaff contig, now extended or include illumina contigs..."; <STDIN>;	
					$news{$super}{"new_scaff_$newscaff"}++;
					print "$super\tnew_scaff_$newscaff\tsingleton\n"; #<STDIN>;
					$newscaff++;
				} else {
					#print "checking if $contig belonged to a previous scaffold..."; <STDIN>;
					if ($scf{$contig}) {
						#print "$contig was part of $scf{$contig}"; <STDIN>;
						my $check = scalar keys %{$supers{$scf{$contig}}};
						#print "***$scf{$contig} had $check contigs"; <STDIN>;
						my $scaff = $scf{$contig};
						if ($used{$scaff}) {
							#print "scaffold already used..."; <STDIN>;
							$used{$scaff}++;
						}
						foreach my $old (sort {(split /g/, $a)[1] <=> (split /g/, $b)[1]} keys %{$supers{$scaff}}) {
							if ($non{$old}) {
								#print "$old is in singletons"; <STDIN>;
								$news{"singleton_$old"}{"new_scaff_$newscaff"}++;
								print "$old\tsupercontig_$newscaff\n"; #<STDIN>;
							} elsif ($rpf2{$old}) {
								#print "$old is in $rpf2{$old}"; <STDIN>;
								#print "$rpf{$rpf2{$old}}{$old}"; <STDIN>;
								$used{$rpf2{$old}}++;
								$news{$rpf2{$old}}{"new_scaff_$newscaff"}++;
								print "$rpf2{$old}\tsupercontig_$newscaff\n"; #<STDIN>;
							}
						}
						$newscaff++;
						$used{$scaff} = 1;
						$news{$scaff}{"new_scaff_$newscaff"}++;
					} else {
						 print LOG "$contig wasn\'t in 454Scaffolds.txt file\n"; #<STDIN>;
						# print "weird 1 $contig\n"; <STDIN>;
					}
				}
			} else {
				#print "$super"; <STDIN>;
				#print "several capillary contigs merged"; <STDIN>;
				if ($used{$super}) {
					my @keys = keys %{$news{$super}};
					my $check = scalar @keys;
					if ($check > 1) {
						print LOG "WIERD!!!!..."; #<STDIN>;
						#print @keys; <STDIN>;
						print LOG "$super was already included/used $used{$super}\n"; #<STDIN>;
					}
					#print "$super was already included/used $used{$super}"; <STDIN>;
				} else {
					$used{$super}++;
					$used{$contig}++;
					#print "several capillary contigs merged"; <STDIN>;
					#print "$contig\t$rpf{$super}{$contig}"; <STDIN>;
					if ($sgl{$contig}) {
						#print "$contig was singleton scaff contig, now merged with other contigs..."; <STDIN>;
						$news{$super}{"new_scaff_$newscaff"} = 1;
						print "++ $super\tnew_scaff_$newscaff\tsingleton\n"; #<STDIN>;
						$newscaff++;
					} else {
						#print "checking if $contig belonged to a previous scaffold..."; <STDIN>;
						if ($scf{$contig}) {
							#print "$contig was part of $scf{$contig}"; <STDIN>;
							my $check = scalar keys %{$supers{$scf{$contig}}};
							#print "---$scf{$contig} had $check contigs"; <STDIN>;
							my $scaff = $scf{$contig};
							if ($used{$scaff}) {
								#print "scaffold already used..."; <STDIN>;
								$used{$scaff}++;
							}
							foreach my $old (sort {(split /\_/, $a)[1] <=> (split /\_/, $b)[1]} keys %{$supers{$scaff}}) {
								if ($rpf{$super}{$old}) {
									#print "$old is already in $super"; <STDIN>;
								}
								elsif ($non{$old}) {
									#print "$old is in singletons"; <STDIN>;
									$news{"singleton_$old"}{"new_scaff_$newscaff"} = 1;
									print "++ $old\tnew_scaff_$newscaff\trescued from singletons\n"; #<STDIN>;
								} elsif ($rpf2{$old}) {
									#print "$old is in $rpf2{$old}"; <STDIN>;
									#print "$rpf{$rpf2{$old}}{$old}"; <STDIN>;
									$used{$rpf2{$old}}++;
									$news{$rpf2{$old}}{"new_scaff_$newscaff"}++;
									print "++ $rpf2{$old}\tnew_scaff_$newscaff\n"; #<STDIN>;
								}
							}
							$newscaff++;
							$used{$scaff} = 1;
							$news{$scaff}{"new_scaff_$newscaff"}++;
						} else {
							print LOG "weird 2\n"; #<STDIN>;
						}
					}
				}
			
			}
		}
	}
}

