#! /usr/bin/perl -w
#
# File: revcompFastq.pl
# Time-stamp: <04-Jun-2010 11:20:27 tdo>
# $Id: $
#
# Copyright (C) 2009 by Pathogene Group, Sanger Center
#
# Author: Thomas Dan Otto
#
# Description:
#


use strict;

my $name = shift;
if (!defined($name)) {
  die "Usage: <mate.fastq>\n";
}

open(IN,$name) or die "couldn't open $name: $!\n";
#my @F=<F>;
#close(F);

my $res;
my $count;

open (F, "> $name.revcomp") or die "problem \n";

while (<IN>) {
#for (my $i=0;$i<(scalar(@F));$i+=4) {
  $res.=$_;
  $_=<IN>;
  $count++;
  
  chomp;
  $res.=revcomp($_)."\n";
  $_=<IN>;
  $res.=$_;
  $_=<IN>;
  chomp;
  $res.=reverse($_)."\n";

  if (($count%100000)==0) {
	print F $res;
	$res='';
  }
}
	print F $res;
close(F);

sub revcomp {
  my $dna = shift;
  my $revcomp = reverse($dna);

  $revcomp =~ tr/ACGTacgt/TGCAtgca/;

  return $revcomp;
}

