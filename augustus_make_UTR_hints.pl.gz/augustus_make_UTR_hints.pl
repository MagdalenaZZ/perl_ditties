#!/usr/bin/perl -w
# mz3 script for making utr hints-files for augustus

use strict;

unless (@ARGV == 6) {
        &USAGE;
}

sub USAGE {

die '

Usage: perl ~/bin/perl/augustus_make_UTR_hints.pl <cufflinks-output> <augustus-ouput>   prefix  other-gff cut-off cut


launch art -test fasta out.gff aug.gff temp.out.gff

If other-gff = 1    that means your gff-file is already normal and nice
if other-gff = 0    that means that you have an augustus-output file


<cut-off> is the length of the UTR - if the resulting UTR is longer than this it will be trimmed down to <cut> basepairs
<cut> is the size of the fragment left behind


'
}

# Read in-files

# my $cut = 100;

    my $cufflink_file = shift;
    my $aug_file =shift;
    my $prefix = shift;
    my $file_type = shift;
    my $cutoff = shift;
    my $cut = shift;
    my $newfile = "$prefix.aug.gff";
    my $outfile = "$prefix.temp.UTR.gff";

if (-e "temp.out") {
system `rm -f temp.out`;
}

if (-e "temp.aug.out") {
system `rm -f temp.aug.out`;
}

#=pod

if ($file_type == 0) {
system `perl ~/bin/perl/augustus2gff.pl $aug_file > $newfile && 
cat  $newfile | grep -w mRNA > $prefix.temp.aug.gff &&
cat  $cufflink_file | grep -w transcript > $prefix.temp.cuff.gff &&
cat  $prefix.temp.cuff.gff | sed s/transcript/CDS/ > $prefix.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $prefix.temp.cuff.gff -b $prefix.temp.aug.gff -u -s > $prefix.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $prefix.bed.gff -b $prefix.temp.aug.gff | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i  $outfile -s > temp.$prefix.UTR.gff `;

}

elsif ($file_type == 1) {
    
system `cat $aug_file| grep -w mRNA > $prefix.temp.aug.gff &&
cat  $cufflink_file | grep -w transcript > $prefix.temp2.cuff.gff && cat $prefix.temp2.cuff.gff | sort -nk 4,4 > $prefix.temp.cuff.gff  &&
cat  $prefix.temp.cuff.gff | sed s/transcript/CDS/ > $prefix.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $prefix.temp.cuff.gff -b $prefix.temp.aug.gff -u -s > $prefix.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $prefix.bed.gff -b $prefix.temp.aug.gff -s | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $outfile -s | sort -k1,1 -k3,3n > temp.$prefix.UTR.gff `;

}
# intersectBed picks up the cufflinks models which overlaps with the genes
# subtractBed  Removes the portion(s) of an interval that is overlapped by another feature(s).
# mergeBed Merges overlapping BED/GFF/VCF entries into a single interval.

#=cut 


# fix the output of mergeBed


my $infile ="temp.$prefix.UTR.gff";

open (OUT, ">$prefix.UTR.gff.temp");

open (IN, "<$infile");
my @list = <IN>;
my $counter = 1;

#my @lists = sort { $a <=> $b } (@list);

foreach my $line (@list) {
 	my ($scaffold, $start, $end, $strand) = split (/\s+/, $line);
	my $start2 = ($start+1);
	print OUT "$scaffold\thint\tUTR\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";
#	print "$scaffold\thint\tCDS\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";

$counter++;
}

# system `rm -fr $prefix.temp2.cuff.gff $prefix.bed.gff $prefix.temp.aug.gff $prefix.temp.cuff.gff $outfile temp.$prefix.UTR.gff `;

close (IN);
close (OUT);

#### fix the lengths of unreasonable UTRs  #### only tested with alternavtive 1 - nice gff

if ($cutoff == 0) {
exit;
}

system "cat $prefix.UTR.gff.temp $aug_file | grep -w -e mRNA -e transcript -e UTR | grep -v exon | sort -k1,1 -nk4,4 -k3,3 > $prefix.UTR.gff.temp2 ";


my $oldline= 0;

open (IN, "<$prefix.UTR.gff.temp2 ");
open (OUT2, ">$prefix.UTR.gff");



# make hash with genes and UTRs

my %gen;
my %utr;
my $lastline=0;

# $gen{geneID}{CDS} = line
#             {5UTR} = line
#             {3UTR} = line
#             {mRNA} = line
#             {gene} = line


while ( my $line = <IN>) {

    chomp $line;
	my @line = split (/\s+/, $line);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

     if ($lastline=~/$name/) {

    if ($tag=~/mRNA/ or $tag=~/transcript/ ) {
#        print "mRNA:$line\n";
        $gen{$start} = $line;
        $gen{$end} = $line;
#       print "mRNA:$start\t$end\n";

    }
    elsif ($tag=~/UTR/ ) {
        my @utr;
        # split too long into two
           my $length = ($end-$start);

    		if ($length > $cutoff )	{

                # make a new for forward
    		    my $nstart = ($end - $cut);
                push (@utr, "$name\t$method\t$tag\t$nstart\t$end\t$strand\t$score\t$dot\t$key.a" );
                # make a new for reverse
    		    my $nend = ($start - $cut);
                push (@utr, "$name\t$method\t$tag\t$start\t$nend\t$strand\t$score\t$dot\t$key.b" );

#               print "$line\n";
#               print "$name\t$method\t$tag\t$nstart\t$end\t$score\t$dot\t$key.a\n";
#               print "$name\t$method\t$tag\t$start\t$nend\t$score\t$dot\t$key.b\n";

             }

             else {
                 push (@utr, $line);
            }

        foreach my $elem (@utr) {
#            print "Elem:$elem\n";

	my @uline = split (/\s+/, $elem);
	my $uname = $uline[0];
	my $umethod = $uline[1];
	my $utag = $uline[2];
	my $ustart = $uline[3];
	my $uend = $uline[4];
	my $uscore = $uline[5];
	my $ustrand = $uline[6];
	my $udot = $uline[7];
	my $ukey = $uline[8];


        my $more = ($uend+1);
        my $less = ($uend-1);
        my $smore = ($ustart+1);
        my $sless = ($ustart-1);

        #        print "UTR:$line\n";
#        print "UTR:$more\t$less\t$smore\t$sless\t$ukey\n";

       $utr{$more}=$elem;
       $utr{$less}=$elem;
       $utr{$smore}=$elem;
       $utr{$sless}=$elem;

#        print "UTR:$more\nUTR:$less\nUTR:$smore\nUTR:$sless\n";

       }

    }
    else {
        print "Exception\n";

    }

}
    else {
        #now we are on a new scaffold
        &eval;
          }

$lastline=$line;
}


&eval;

#########################


sub eval {

foreach my $pos (sort {$a <=> $b} keys %utr) {
#            print "POS2:$pos\n";
            if (exists $gen{$pos}) {
#                print "Match\n$utr{$pos}\n$gen{$pos}\n";

            my @line = split(/\s+/, $gen{$pos});
            my @nline = split(/\s+/, $utr{$pos});

            # get gene-details
    my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

        my @arr= split(/[:;]/, $key);
        $arr[0]=~s/ID=//;
        $key = $arr[0];
#        $gen{$arr[0]}{gene}= $line;
#        print "Gene:$arr[0]\n";


        # get utr-details
        
	    my $nname = $nline[0];
	    my $nmethod = $nline[1];
	    my $ntag = $nline[2];
	    my $nstart = $nline[3];
    	my $nend = $nline[4];
    	my $nscore = $nline[5];
#    	my $nstrand = $nline[6];
    	my $ndot = $nline[7];
    	my $nkey = $nline[8];

        # plus-strand
            if ($strand=~m/^\+$/){
                if ( ($start - $nend) == 1) {

                            print OUT2 "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;color=2;$nkey\n";
                        }
                elsif ( ($nstart - $end) == 1) {

                    	    print  OUT2 "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;color=2;$nkey\n";
                }
                else {
                    print "Warning 254: weird overlap \n$gen{$pos}\n$utr{$pos}\n";
                }
            }        
        # minus-strand
            elsif ($strand=~m/^\-$/){

                if ( ($start - $nend) == 1) {



    	    	    	print  OUT2  "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;color=2;$nkey\n";                
                        }
                elsif ( ($nstart - $end) == 1) {

                        print  OUT2  "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;color=2;$nkey\n";
                }
                else {
                    print "Warning 273: weird overlap \n$gen{$pos}\n$utr{$pos}\n";
                }

            }
            else {
                print "Warning: unknown strand\n";
            }

            }
            else {
#                print "NO MATCH:\n$pos\n";
            }
}        

}




close (OUT2);

__END__
my $lastline;
my $gene =0;

while ( my $line = <IN>) {
    chomp $line;

	my @line = split (/\s+/, $line);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];


    if ($tag=~/UTR/ and $gene=~/1/ ) {
        print OUT2 "UTR: $line\n";
        $gene=0;
    }


    elsif ($tag=~/mRNA/ or $tag=~/transcript/ ) {

        my @arr= split(/[:;]/, $key);
        $arr[0]=~s/ID=//;
        $key = $arr[0];
        $gen{$arr[0]}{gene}= $line;
        print OUT2 "Gene:$arr[0]:$line\n";

        # check previous UTR too!
        my @lline = split (/\s+/, $lastline);
	    my $lname = $lline[0];
	    my $lmethod = $lline[1];
	    my $ltag = $lline[2];
	    my $lstart = $lline[3];
    	my $lend = $lline[4];
    	my $lscore = $lline[5];
#    	my $lstrand = $lline[6];
    	my $ldot = $lline[7];
    	my $lkey = $lline[8];

        # check if it is 5 or 3

        if ($ltag =~/UTR/) {

            if ($strand=~m/^\+$/){
#                print "g5'UTR:$key:$lastline\n";

    		    my $diff = ($start-$lend);
        		if  ($diff == 1 ) {

                #---------------------
                 my $length = ($lend-$lstart);
    		    	if ($length > $cutoff )	{	
    		    		$lstart = ($lend - $cut);
    	    			print OUT2 "$lname\t$lmethod\tfive_prime_UTR\t$lstart\t$lend\t$lscore\t$strand\t$ldot\tID=$key:5UTR;Parent=$key;color=2;$lkey\n";
    		    	}
    	    		else	{	
                       	print OUT2 "$lname\t$lmethod\tfive_prime_UTR\t$lstart\t$lend\t$lscore\t$strand\t$ldot\tID=$key:5UTR;Parent=$key;color=2;$lkey\n";

        			}			
                #---------------------
            }

                else {
                    print "E5:$start-$lend = $diff\n";
                    print "E5:$line\n$lastline\n";
                }



            }
            elsif ($strand=~m/\-/){
#                print "g3'UTR:$key:$lastline\n";

    		    my $diff = ($start-$lend);
        		if  ($diff == 1 ) {

                #---------------------
                     my $length = ($lend-$lstart);
    		    	if ($length > $cutoff )	{	
    		    		$lstart= ($lend - $cut);
    	    			print OUT2 "$lname\t$lmethod\tthree_prime_UTR\t$lstart\t$lend\t$lscore\t$strand\t$ldot\tID=$key:3UTR;Parent=$key;color=2;$lkey\n";
    		    	}
    	    		else	{	
                       print OUT2 "$lname\t$lmethod\tthree_prime_UTR\t$lstart\t$lend\t$lscore\t$strand\t$ldot\tID=$key:3UTR;Parent=$key;color=2;$lkey\n";

        			}			
                #---------------------

                }
                else {
                    print "E6:$start-$lend = $diff\n";
                    print "E6:$line\n$lastline\n";
                }
            }
            else {
                    print "Undetermined strand\n";
            }


            # check next line too!

            my $nextline = <IN>;
        my @nline = split (/\s+/, $nextline);
	    my $nname = $nline[0];
	    my $nmethod = $nline[1];
	    my $ntag = $nline[2];
	    my $nstart = $nline[3];
    	my $nend = $nline[4];
    	my $nscore = $nline[5];
#    	my $nstrand = $nline[6];
    	my $ndot = $nline[7];
    	my $nkey = $nline[8];
            
            if ($ntag=~/UTR/) {

            if ($strand=~m/^\+$/){
#                print "n3'UTR:$key:$nextline\n";

		    my $diff = ($nstart-$end);
		    my $diff2 = ($nend-$start);
		    my $diff3 = ($nend-$end);

    		if  ($diff == 1 or $diff2 == 1 or $diff3 == 1  ) {
                #---------------------
                     my $length = ($nend-$nstart);
    		    	if ($length > $cutoff )	{	
    		    		$lstart= ($lend - $cut);
    	    			print OUT2 "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;color=2;$nkey\n";
    		    	}
    	    		else	{
    	    			print OUT2 "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;color=2;$nkey\n";
        			}			
                #---------------------


            }

                else {
#                    print "E7:$nend-$end = $diff\n";
                    print "E7:$nend-$start = $diff\n";
                    print "E7:$line\n$nextline\n";
                }

            }
            elsif ($strand=~m/\-/){
#                print "n5'UTR:$key:$nextline\n";
		    my $diff = ($nstart - $end);
    		if  ($diff == 1 ) {

                #---------------------
                     my $length = ($lend-$lstart);
    		    	if ($length > $cutoff )	{	
    		    		$lstart = ($lend - $cut);
    	    			print OUT2 "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;color=2;$nkey\n";
    		    	}
    	    		else	{
                        print OUT2 "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;color=2;$nkey\n";
 
            			}	

                #---------------------

            }
                            else {
                    print "E8:$nstart - $end = $diff\n";
                    print "E8:$line\n$nextline\n";
                }

            }
            else {
                    print "Undetermined strand\n";
            }


            }
            elsif ($ntag=~/mRNA/) {
                my @arr= split(/;/, $key);
                $arr[0]=~s/ID=//;
                $gen{$arr[0]}{gene}= $line;
                print OUT2 "NGene:$arr[0]:$line\n";
                $gene=1;
            }
            else {
                print "WEIRD: $line\n";
            }

        }



    }

    elsif ($tag =~/UTR/) {
            
        # check if it is 5' or 3'
        if ($strand=~/\+/){
#            print "3'UTR: $line\n";
        }
        elsif ($strand=~/\-/){
#            print "5'UTR: $line\n";
        }
        else {
                print "Undetermined strand\n";
        }


    }
    elsif ($tag=~/mRNA/) {
    }
    elsif ($tag=~/CDS/ or $tag=~/exon/  ) {
    }
    else {
        print "WEIRD: $line\n";
    }


    $lastline=$line;
}


close (OUT2);



__END__

############################ fix the long lefthand-UTRs ###############
#my @inputs = sort(@input);

foreach my $line (@input) {
#    print "IN:$line";
	my @line = split (/\s+/, $line);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];
#	$key =~ s/ID=/:/g;
#grep lefthand UTR
    

	if ($tag =~/Agene/) {
    	$key =~ s/ID=/:/g;
# make sure it is a hint	
		if  ($oldline =~/hint/ ) {
#make sure it is right hint
#			print "Oldline:$oldline";			
			my @line2 = split (/\s+/, $oldline);
			my $name2 = $line2[0];
			my $method2 = $line2[1];
			my $tag2 = $line2[2];
			my $start2 = $line2[3];
			my $end2 = $line2[4];
			my $score2 = $line2[5];
			my $strand2 = $line2[6];
			my $dot2 = $line2[7];
			my $key2 = $line2[8];

 print "5' Gene start $start end $end \n";
 print "5' UTR start $start2 end $end2 \n";
 # check that it is the UTR belonging to that gene
 
        if ($start ==  ($end2 + 1)) { 
            print "5' Belongs\n";
		my $diff = ($start-$end2);
    		if  ($diff == 1 ) {
# check if it is too long	
			    my $length = ($end2-$start2);
		    	if ($length > $cutoff )	{	
		    		$start2 = ($end2 - $cut);
	    			print OUT2 "$name2\t$method2\t$tag2\t$start2\t$end2\t$score2\t$strand2\t$dot2\t$key2$key;\n";
		    	}
	    		else	{	
    				print OUT2  "$name2\t$method2\t$tag2\t$start2\t$end2\t$score2\t$strand2\t$dot2\t$key2$key;\n";
    			}			
    		}
        }
        else {
             print "5' UTR start $start2 end $end2 doesn\'t not belong to Gene start $start end $end \n";
        }

		}

# my $oldline = $line;
	}





#### get the longUTRs after the gene 

	elsif ($method =~/hint/) {
 #		print "Hint start $start end $end \n";
# make sure it is a hint	
		if  ($oldline =~/CDS/ ) {
#make sure it is right hint
# 		print "Hint start $start end $end \n";
#		print "Last CDS $oldline";			
			my @line2 = split (/\s+/, $oldline);
			my $name2 = $line2[0];
			my $method2 = $line2[1];
			my $tag2 = $line2[2];
			my $start2 = $line2[3];
			my $end2 = $line2[4];
			my $score2 = $line2[5];
			my $strand2 = $line2[6];
			my $dot2 = $line2[7];
			my $key2 = $line2[8];
			$key2 =~ s/ID=//g;
			my($key3,$key4) = (split/:/, $key2);

             print "3' Gene start $start end $end \n";
             print "3' UTR start $start2 end $end2 \n";
# check if the UTR belongs to that CDS		
		my $diff = ($start-$end2);
			if  ($diff == 1 ) {
                 print "3' Belongs\n";
#				print "$start and $end2\n";
# check if it is too long	
				my $length = ($end-$start);

				if ($length > $cutoff )	{	
					$end = ($start + $cut);
#					print "FIXED: Hint start $start end $end \n Length $length \n ";
					print OUT2  "$name\t$method\t$tag\t$start\t$end\t$score\t$strand\t$dot\t$key:$key3;\n";
				}
				else	{	
#				print "SAME: Hint start $start end $end \n Length $length \n ";
				print OUT2 "$name\t$method\t$tag\t$start\t$end\t$score\t$strand\t$dot\t$key:$key3;\n";
				}			
			}
			else {
				print "3' NOT Hint start $start2 end $end2 and Gene start $start end $end \n";
			}
		}

# my $oldline = $line;
	}

$oldline = $line;
#print "Oldline2 $oldline \n";
print "\n";

}


# get the next hint



# system `rm -fr $prefix.UTR.gff.temp`;


__END__

=pod
perl ~/bin/perl/augustus_make_UTR_hints.pl EMU_v3_17June2011.scaffold.007.transcripts.gtf pathogen_EMU_scaffold_007712.train.5.gff 007712.1000cut 1 1000 500

=cut
