#!/usr/bin/perl -w
use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta prefix

Example usage:\n $0 supercontigs.fa prefix
used to merge all gffs from chado

'
}



my $fastafile = shift @ARGV ;
my $prefix = shift @ARGV ;

my $contig_name = '' ;

my %fasta = () ;
my @names = () ;


## read the fastas
open (IN, "$fastafile") or die "oops!\n" ;
while (<IN>) {
	
	if (/>(\S+)/) {
		my $name = $1 ;		
		my $seq = <IN> ;
		chomp($seq) ;
		
		$fasta{$name} = $seq ;
		push(@names, $name) ;
	}
}

open OUT , ">", "$prefix.merged.chado.gff" or die "oops\n" ;
open OUT2 , ">", "$prefix.merged.chado.gff.error" or die "oops\n" ;

my $length = scalar (@names);

print "There are $length sequences\n";

my $index = 0;
foreach my $seq (@names) {

    print "$prefix/$seq.gff\n" ;

    open (IN, "$prefix/$seq.gff") or print "cannot open file $prefix/$seq.gff !\n" and print OUT2 "$prefix/$seq.gff\n" ;
    
    $index++;

    while (<IN>) {

	last if /\#\#FASTA/ ;
	next if /\#\#/ ; 

	print OUT "$_" ;
    }

}

print "Printed $length sequences\n";


