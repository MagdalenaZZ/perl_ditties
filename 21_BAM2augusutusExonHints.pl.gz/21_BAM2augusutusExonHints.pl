#! /usr/bin/perl -w
#
# File: solexa_parallelise_using_ssaha.pl
# Time-stamp: <19-Feb-2009 14:43:44 jit>
# $Id: $
#
# Copyright (C) 2008 by Pathogene Group, Sanger Center
#
# Author: JIT
# Description: a parallelised script to split the Illumina reads to subsets
#
#

use strict;



my $PI = `echo $$` ;


if (@ARGV != 1 ) {
    print "$0 bam\n" ;
	exit;
}



my $bam = shift ;

my %intron_bam = () ; 

print "start parsing...\n" ;

open (IN, "samtools view $bam 7180000833349 |") or die "oooops\n" ;

#open (IN, "$bam") or die "oooops\n" ;
open OUT, ">", "$bam.exonpart.gff" or die "oooops\n" ;

my $chr = '' ; 
my $start =  0 ; 
my $end = 0 ; 
my $max_cov = 0 ; 

my $first = 0 ; 

while (<IN>) {

    chomp ; 
    my @r = split /\s+/, $_ ;
    
    next unless $r[3] > 5 ; 
    
    # coords; 
    if ($first == 0 ) {
	$chr = $r[0] ; 
	$start = $r[1] ; 
	$end = $r[1] ; 
	$max_cov = $r[2] ; 
	$first = 1 ;
	next ;
    }


    if ( $chr eq $r[0] && $r[1] == ($end+1) ) {
	$end = $r[1] ; 
	$max_cov = $r[2] if $r[2] > $max_cov ; 
    }
    else {

	#print "$chr\t$start\t$end\n" ;


	print OUT "$chr\tb2h\texonpart\t$start\t$end\t0\t.\t.\tmult=$max_cov\;src=W\n" ;

	$chr = $r[0] ;
	$start = $r[1] ;
	$end = $r[1] ;
	$max_cov = $r[2] ;

    }

    
}
close(IN) ; 


print "all done! $bam.exonpart.gff produced\n" ;
