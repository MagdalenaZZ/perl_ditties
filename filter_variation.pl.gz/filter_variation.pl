#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >0) {
        &USAGE;
}


sub USAGE {

die 'Usage: filter_variation.pl readcounts other_file


'
}


my $rc = shift;
my $file = shift;


open (GL, "< $gl")  || die "I can't open $gl\n";
open (IN, "< $file")  || die "I can't open $file\n";
open (OUT2, "> $file.RPKM")  || die "I can't open $file.RPKM\n";


# Read in gene lengths

my %gls;

while(<GL>){
	chomp;
	my($gene,$len)=split(/\t/,$_);
	$gls{$gene}=$len;
}



