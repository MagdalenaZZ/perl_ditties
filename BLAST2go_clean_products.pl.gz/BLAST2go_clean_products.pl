#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: in out

Give a list of gene-names and product description
This program filters the list


'
}


	my $in = shift;

	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">filtered.out2") || die "I can't open filtered.out2\n";

foreach my $line (@in) {
chomp $line;
my @line = split (/\t/, $line);

#	print ":$line[0]:$line[1]:$line[3]:$line[4]:\n";
	$line[1] =~ s/ /_/g;
	$line[1] =~ s/_\(Fragment\)//;
	$line[1] =~ s/PREDICTED:_//;
	$line[1] =~ s/Putative_uncharacterized_protein_//;
	$line[1] =~ s/similar_to_//;
	$line[1] =~ s/Putative_uncharacterized_protein/ / ; 
	$line[1] =~ s/ADAM/adam/ ; 
	$line[1] =~ s/HSP/heat_shock_protein/ ; 
	$line[1] =~ s/TSES/Taenia_soluim_Excretory_and_Secretory_Product(TSES)/ ; 
	$line[1] =~ s/TSP/thrombospondin/ ; 
	$line[1] =~ s/TGTP/Glucose_Transport_Protein_TGTP/ ;
	$line[1] =~ s/novel_protein_vertebrate_//; 
	$line[1] =~ s/novel_protein_//;
	$line[1] =~ s/novel_//;
	$line[1] =~ s/beta-13-n-acetylglucosaminyltransferaseputati_ve/beta-13-n-acetylglucosaminyltransferase/;
	$line[1] =~ s/_-/-/;
	$line[1] =~ s/-_/-/;
	$line[1] =~ s/like-//;
	$line[1] =~ s/_like//;
	$line[1] =~ s/-like//;
	$line[1] =~ s/likely_//;
	$line[1] =~ s/-like//;
	$line[1] =~ s/_homolog//;
	$line[1] =~ s/homolog_//;
	$line[1] =~ s/conserved_//;
	$line[1] =~ s/__/_/;
	$line[1] =~ s/-_-/-/;
	$line[1] =~ s/\(_elegans\)//;
	$line[1] =~ s/\(_cerevisiae\)//;
	$line[1] =~ s/\(_coli\)//;
	$line[1] =~ s/\(_pombe\)//;
	$line[1] =~ s/\(_protein\)//;
	$line[1] =~ s/low_quality_protein:_//;
	$line[1] =~ s/\(_\)//;
	$line[1] =~ s/probable_//;


	if ($line[1] =~/[A-Z]+_[A-Z]+_[A-Z]+/) {
		$line[1] =~ tr/A-Z/a-z/;
		$line[1] =~ s/low_quality_protein:_//;
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
	}

	if ($line[1] =~/^Uncharacterized_protein/) {
#		if ($line[1] =~/involved/) {
#			print OUT "$line[0]\"$line[1]\"\t$line[2]\"\n";
#		}
#		else {
			print OUT2 "\"mz3\":Uncharacterized_protein:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
			print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
#		}
	}
	if ($line[1] =~/^EG95$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Putative_uncharacterized_protein$/) {
		print OUT2 "\"mz3\":pup2:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^ $/) {
		print OUT2 "\"mz3\":blank:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}

#save some genes
#	elsif ($line[1] =~/^VP\d+/) {
#		print "$line[0]\"$line[1]\"\t$line[2]\"\n";
#	}
	elsif ($line[1] =~/^AC\d+$/) {
		print OUT "$line[0]\"adenylyl_cyclase_($line[1])\n";
	}
	elsif ($line[1] =~/^RAG\d+$/) {
		print OUT "$line[0]\"recombination_activating_gene($line[1])\n";	
	}
#	elsif ($line[1] =~/^P\d+$/) {
#		print OUT "XXX$line[0]\"$line[1]\"\t$line[2]\"\n";
#	}
	elsif ($line[1] =~/^Gp\d+$/) {
		print OUT "$line[0]\"Glycoprotein_$line[1]\n";
	}
#remove others
	elsif ($line[1] =~/^hypothetical_protein$/) {
		print OUT2 "\"mz3\":MGF:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/SJCHG\w+_protein/) {
		print OUT2 "\"mz3\":sjap:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/sjchgc\w+_protein/) {
		print OUT2 "\"mz3\":sjap:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Protein_MGF/) {
		print OUT2 "\"mz3\":MGF:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+$/) {
		print OUT2 "\"mz3\":number:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
#	elsif ($line[1] !~/[a-z]+[a-z]+/) {
#		print OUT2 "\"mz3\":not_lower:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
#		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
#	}
	elsif ($line[1] !~/[a-z]+[a-z]+/) {
		if ($line[1] =~/^[A-Z][A-Z][A-Z][0-9]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][A-Z][0-9]$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][A-Z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z]-[0-9]$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}		
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][a-z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][A-Z][A-Z]$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}	
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z]$/ or $line[1] =~/^[A-Z][A-Z][A-Z][0-9][0-9]$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}
		elsif ($line[1] =~/^[A-Z][A-Z][A-Z][0-9][0-9][0-9]$/ or $line[1] =~/^[A-Z][A-Z][A-Z]-[0-9][0-9]$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}
		elsif ($line[1] =~/^CG[0-9]+$/ ) {
		print OUT2 "\"mz3\":not_lower:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\"mz3\"\n";
		}	
		elsif ($line[1] =~/^[A-Z][A-Z][0-9]$/ or $line[1] =~/^\w\w\w\w$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}
		elsif ($line[1] =~/^\w\w\w\w\w$/ or $line[1] =~/^\w\w\w\w\w\w$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
		}
		else {
		print OUT2 "\"mz3\":not_lower:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
		}
	}	
	elsif ($line[1] =~/^Protein_\db$/) {
		print OUT2 "\"mz3\":Protein_b:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+[LR]$/) {
		print OUT2 "\"mz3\":LR:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+kd$/) {
		print OUT2 "\"mz3\":kd1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+_kDa_protein$/) {
		print OUT2 "\"mz3\":kd2:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kDa_protein$/) {
		print OUT2 "\"mz3\":kd3:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+\.\d+_kd_protein$/) {
		print OUT2 "\"mz3\":kd34:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+\.\d+K_protein$/) {
		print OUT2 "\"mz3\":kd5:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^\d+\_protein$/) {
		print OUT2 "\"mz3\":protein:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Putative_uncharacterized_protein/) {
		print OUT2 "\"mz3\":pup:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/PREDICTED:_hypothetical_protein/) {
		print OUT2 "\"mz3\":PHP:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Predicted_protein$/) {
		print OUT2 "\"mz3\":pp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Conserved_domain_protein/) {
		print OUT2 "\"mz3\":cdp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Putative_membrane_protein$/) {
		print OUT2 "\"mz3\":Pmp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Membrane_protein$/) {
		print OUT2 "\"mz3\":Mp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Putative_Membrane_protein$/) {
		print OUT2 "\"mz3\":Mp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
#	elsif ($line[1] =~/Polyprotein/) {
#		print OUT2 "\"mz3\":pop:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
#		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
#	}
	elsif ($line[1] =~/predicted_protein/) {
		print OUT2 "\"mz3\":pp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Secreted_protein$/) {
		print OUT2 "\"mz3\":sp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Predicted_membrane_protein$/) {
		print OUT2 "\"mz3\":pmp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Novel_protein$/) {
		print OUT2 "\"mz3\":np:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Putative_transporter$/) {
		print OUT2 "\"mz3\":ptp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Uncharacterized_conserved_protein$/) {
		print OUT2 "\"mz3\":ucp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Genome_polyprotein/) {
		print OUT2 "\"mz3\":Gp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}	
	elsif ($line[1] =~/^Lipoprotein$/) {
		print OUT2 "\"mz3\":Lp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Genome$/) {
		print OUT2 "\"mz3\":gen:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/whole_genome_shotgun_sequence/) {
		print OUT2 "\"mz3\":wgs:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_sequence/) {
		print OUT2 "\"mz3\":wgs:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/Whole_genome_shotgun_assembly/) {
		print OUT2 "\"mz3\":wga:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Os0\w+00_protein$/) {
		print OUT2 "\"mz3\":os:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_FG/) {
		print OUT2 "\"mz3\":fg:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_LOC/) {
		print OUT2 "\"mz3\":hlc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^LOC[0-9]+_protein$/) {
		print OUT2 "\"mz3\":hlc:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/hypothetical_protein,_partial/) {
		print OUT2 "\"mz3\":hypp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/UPI\w+_related_cluster/) {
		print OUT2 "\"mz3\":UPI:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^unknown$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypotheticial_protein$/) {
		print OUT2 "\"mz3\":nsp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^conserved_hypothetical_protein$/) {
		print OUT2 "\"mz3\":chp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypotherical_protein$/) {
		print OUT2 "\"mz3\":hp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^expressed_hypothetical_protein$/) {
		print OUT2 "\"mz3\":ehp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^unnamed$/) {
		print OUT2 "\"mz3\":unn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_protein_isoform_1$/) {
		print OUT2 "\"mz3\":hpi1:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^Unknown_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^unknown_/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^unnamed_protein_product_/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^uncharacterized_protein_/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^unknow_protein/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^novel_protein$/) {
		print OUT2 "\"mz3\":ukn:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^protein$/) {
		print OUT2 "\"mz3\":prot:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^elegans_protein_partially_confirmed_by_transcript_evidence$/) {
		print OUT2 "\"mz3\":prot:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^isoform_\w$/) {
		print OUT2 "\"mz3\":prot:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^conserved_hypothetical_protein_/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_protein/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_prophage_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_conserved_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^hypothetical_membrane_associated_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^subfamily_c_member_17$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^domain_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^domain_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^type_ii$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^family_protein$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^subfamily_member_3$/) {
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/\=/) {
		print OUT2 "\"mz3\":=:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^_protein_2$/) {
		print OUT2 "\"mz3\":=:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/protein_binding/) {
		print OUT2 "\"mz3\":=:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}
	elsif ($line[1] =~/^poly$/) {
		$line[1] =~s/poly/polyprotein/;
		print OUT2 "\"mz3\":hyp:\t\"$line[1]\"\t$line[2]\"$line[3]\"\n";
#################		
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
###############
	}
	elsif ($line[1] =~/\w+/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
	}

}

#elegans_protein_partially_confirmed_by_transcript_evidence

# Unknown_protein
# hypothetical_protein_isoform_1
#hypotherical_protein
#expressed_hypothetical_protein
#unnamed
# conserved_hypothetical_protein
	close (OUT);
	close (OUT2);

__END__

	elsif ($line[1] =~//) {
		print OUT2 "\"mz3\"::\t\"$line[1]\"$line[2]\"$line[3]\"\n";		
		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";
	}

		print OUT "$line[0]\tmz3\t$line[2]\t$line[3]\t$line[4]\n";