#!/usr/local/bin/perl -w
# mz3 script for pulling out all scaffolds and long contigs not in scaffolds from Newbler output
# It uses the default names output by Newbler


use strict;
use GetData;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: Newbler_get_all_scaffolds_n_contigs.pl <cut-off length>

cut-off length   -  the length 


The script uses the default file-names output by Newbler, so just make sure you execute the script in your Newbler output directory

( if you want all just do a number that is ridiculously low like 1 )
 



'
}

my $range = 1000;
my $random_number = int(rand($range));


open SCAF, "<454Scaffolds.fna";
open TXT, "<454Scaffolds.txt";
open TEMP, ">$random_number.temp.continscaf.txt";


unless (-e "454AllContigs.sl.fna") {
system `fasta2singleLine.py 454AllContigs.fna 454AllContigs.sl.fna`;
}

########### check time #################
my @timeData1 = gmtime(time);
print "\n-----Doing step 1 ------", "$timeData1[2]:$timeData1[1]:$timeData1[0]\n";
########################################

my $cut_length = $ARGV[0];

# get a list of all contigs in scaffolds

my $scaf = `cat 454Scaffolds.txt | grep -v fragment | awk '{print \$6}' > $random_number.temp.continscaf.txt`;

close (TEMP);

# get a list of all large contigs larger than $cut_length

my $cont = `cat 454AllContigs.fna | grep '>' > $random_number.temp.conts.txt`;

open TEMP2, "<$random_number.temp.conts.txt";
my @array = <TEMP2>;
my @contigs ;



foreach my $line (@array) {

my @ar =split (/\s+/, $line);
my @ar2 =split (/=/, $ar[1]);
$ar[0]=~s/>//;

if ($ar2[1] > $cut_length ) {
push (@contigs, "$ar[0]");
}

}


open TEMP3, "<$random_number.temp.continscaf.txt";
my @cont_in_scaf = <TEMP3>;
chomp @cont_in_scaf;

# compare the list with large contigs and contigs in scaffolds

########### check time #################
my @timeData2 = gmtime(time);
print "-----Doing step 2 ------", "$timeData2[2]:$timeData2[1]:$timeData2[0]\n";
########################################

my @needed_conts;

foreach my $element (@contigs) {
	if (grep {$_ eq $element} @cont_in_scaf) {;
	}
	else {
		 push (@needed_conts, "$element\n");
	}
}

########### check time #################
my @timeData3 = gmtime(time);
print "-----Doing step 3 ------", "$timeData3[2]:$timeData3[1]:$timeData3[0]\n";
########################################

my $var2 = scalar @needed_conts;
if ($var2<1) {
	print "There are no missing contigs longer than $cut_length\n";
	exit 0;
}

open TEMP4, ">$random_number.temp.txt";
print TEMP4 @needed_conts;

# pull out large contigs and merge with scaffolds

close (TXT);
close (SCAF);
close (TEMP2);
close (TEMP3);
close (TEMP4);

########### check time #################
my @timeData4 = gmtime(time);
print "-----Doing step 4 ------", "$timeData4[2]:$timeData4[1]:$timeData4[0]\n";
########################################

if (-e "454Contigs_longer$cut_length.noscaff.fas") {
system `rm -fr 454Contigs_longer$cut_length.noscaff.fas`;
print "-----Deleted file 454Contigs_longer$cut_length.noscaff.fas and replaced it with new calculation\n";
}

open TEMP5, ">>454Contigs_longer$cut_length.noscaff.fas";

my $largest = 0;
my $contig = '';

my $filenameA = "454AllContigs.sl.fna";
my $contig_name = "$random_number.temp.txt";
my %reads = () ;

open (IN, "$contig_name") or die "oops!\n" ;

while (<IN>) {
	chomp ;
	my @line = split /\s+/ , $_ ;
	$reads{$line[0]}++ ;
}
close(IN) ;

open (IN, "$filenameA") or die "oops!\n" ;

while (<IN>) {

    if (/^>(\S+)/) {

	my $seq_name = $1 ;
	my $seq = <IN> ;
	chomp($seq) ;
	
	if ($reads{$seq_name} ) {
			print TEMP5 ">$seq_name\n" ;
			print TEMP5 "$seq\n" ;

	}


    }

}

system `cat 454Scaffolds.fna  454Contigs_longer$cut_length.noscaff.fas > 454Scaffolds_contigs_longer$cut_length.fna && rm -fr  $random_number.temp.continscaf.txt $random_number.temp.conts.txt`;

 system `rm -fr  $random_number.temp.txt`;

########### check time #################
my @timeData5 = gmtime(time);
print "-----Finished ------", "$timeData5[2]:$timeData5[1]:$timeData5[0]\n";
########################################

close (TEMP5);


exit 0;





__END__

perl ~/bin/perl/Newbler_get_all_scaffolds_n_contigs.pl 200 
