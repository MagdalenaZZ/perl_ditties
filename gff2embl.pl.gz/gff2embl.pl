#!/usr/bin/perl -w

# mz3 script for changing gff to embl

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff2embl.pl input.gff input.fasta


input.gff	Input gff-file, which can have additional features
input.fasta	Fasta with all sequences to which the gff belongs (sequence on single line, more than 2 sequences)



'
}


my $in = shift;
my $in2 = shift;
my  $logfile = "$in\.error";

        open (STDERR, ">$logfile") || die "I can't open $logfile\n";

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (IN2, "<$in2") || die "I can't open $in2\n";
	my @in2 = <IN2>;
	close (IN2);

my $last_line = 0;

############################################

# read in the sequences and lengths

my %lengths ;
my @contam;
my $key = 0;

unless ($in2[2]=~/>/)  {
	print STDERR "The fasta-file is not single line, please check again that it is correct and doesn't contain blanklines or empty headers: $!\n";
	 die "Die: $!\n";
}


foreach my $line (@in2) {
chomp $line;
# filter headers

	if ($line =~m/>/) {
		$line =~s/>//;
		$key = "$line";
        #print "Header: $line\n";
	}
	elsif ($line=~m/^$/) {
	}
	else {
		my $count = $line =~ tr/GgCcNnAaTt//;
		$line =~ tr/GgCcAaTtNn/\t/;
		my $others = $line;
		push (@contam, $others);
		push(@{$lengths{$key}}, $count);
	}
}

foreach my $line (@contam) {
$line =~ s/\t//g;
$line =~ s/ /space=" "  /g;
	if ($line =~m/./ ){
# redirect this to standard error
		print STDERR "WARNING: Unknown characters in fasta: $line\n";
	}
}

print STDERR "Finished parsing fasta-file\n";
#################
#systematic_id=
# read in the contigs in a hash

foreach my $line (@in) {
	chomp $line;
	#$line=~s/ID=/systematic_id=/;
	my @arr= split(/\t/, $line);
	if ( exists $lengths{$arr[0]} ) {
# push the line onto an array
			my $key = $arr[0];
			push(@{$lengths{$key}}, "$line");
#            print "$key\t$line\n";
	}

	else {
		print STDERR "WARNING: This line has a contig not present in the fasta: \n$line\n";
	}

}

############################################
# Remove keys which don't have values

foreach my $key ( keys  %lengths ) {

	unless ($lengths{$key}[1]) {
        #print STDERR "Contig $key has no genes: length $lengths{$key}[0]\n";
        #delete $lengths{$key};	
	}

}

####################


print STDERR "Starting to read and write contigs\n";

foreach my $key ( keys  %lengths ) {

# Test if the contig has any information 

# If it has information - write the array
	my @array = @{$lengths{$key}};

## For each new contig open a new file
	my $contig_name = $key;
	my $out = $contig_name . ".embl";
	open (OUT, ">$out") || die "I can't open $out\n";
	print STDERR "Started writing to file $out\n";
# print header
	print  OUT  "ID   $contig_name; SV 1; linear; genomic DNA; HTG; INV; $array[0] BP.\n";
# ID   CD789012; SV 4; linear; genomic DNA; HTG; MAM; 1000 BP. 
# write FH lines
	print OUT  "FH   Key             Location/Qualifiers\n";
	print OUT  "FH\n";
	shift @array;
	#push(@array, " ");

################################################################################
# Print the contents 
################################################################################
$last_line="0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0\t0";

my @genelist;
my @gene ='';



if (scalar(@array)<1) {
  print STDERR "Missing genes on contig $contig_name \n";
  close (OUT);
  mkdir "$in\_Empty_embls";
  system "mv $out $in\_Empty_embls";
}

else {

my $very_last = $array[-1];
my @very_last = split(/\t/, $very_last);


######### Process the lines #####################################################
    
    #pop @array;
    foreach my $line (@array) {
	chomp $line;
	my @arr= split(/\t/, $line);
	my @last_arr= split(/\t/, $last_line);

################### Very last line ##############################################

	if ($arr[8]=~/$very_last[8]/) {
	# print "Very last line\n";
	# print "$arr[8]\n";

#### write info for the very last gene
	# add the last CDS info
			my $value = "$arr[3]\.\.$arr[4]";
			push (@gene, $value);

				my $coords = join("," , @gene);
				$coords =~s/,//;
			if ($last_arr[6] =~/\+/) {
				@gene ='';
#FT   CDS             join(20929..26310,27215..28456)
				print OUT "FT   CDS              join($coords)\n";
#				print  "FT   CDS              join($coords)\n";
			}
			elsif ($last_arr[6] =~/\-/) {
				my @rev_gene= reverse(@gene);
				my $coords = join("," , @rev_gene);
				my @coords2 = split(/,/, $coords);
				my @coords3 = reverse(@coords2);
				my $coords3 = join("," , @coords3);
				@gene ='';
#	FT   CDS              complement(join(20929..26310,27215..28456))
				 print OUT "FT   CDS              complement(join($coords3))\n";
#				 print  "FT   CDS              complement(join($coords3))\n";
			}

# get info for the last gene
			my (@locus) =split (/\t/, $genelist[0]);
			$locus[8] =~s/ID=//;
#			print OUT  "FT                   /source=\"$locus[1]\"\n";
			print OUT  "FT                   /systematic_id=\"$locus[8]\"\n";

# write info
#        print "$genelist[0]\n";
		my @info = split (/\t/, $genelist[0]);
		my $last_elem = (scalar(@info) );
#        print "LAST:$last_elem\n";
		if ($last_elem > 8) {
        		my @slice = @info[8..$last_elem];

#        if ($last_elem > 9) {
#        		my @slice = @info[9..$last_elem];
        		pop @slice;
#                print "SLICE: $slice[1]\n";

        ################# fix tailing product tabs and spaces #################################################

#                my $length1 =(scalar(@arr) -1 );
#                print "L:$length1\n";
				my $tail = join("\t", @slice);
#				print  "TAIL:$tail\n";
                #my @slice1= @arr[0..8];
#                my @slice2= @arr[9..$last_elem];
#                $tail = join("\t", @slice2);
                $tail=~s/  / /g;
                $tail=~s/  / /g;
                $tail=~s/\t\t/\t/g;
                $tail=~s/\t\t/\t/g;
                $tail=~s/\t\t/\t/g;
                #$tail=~s/\t/ /g;
                $tail=~s/\"\ \//\"\t\//g;
                #  print "TAIL:$tail\n";
                my @slice3 = split(/\t/, $tail);
                @slice=@slice3;
                shift @slice;
       #####################################################
 			foreach my $elem2 (@slice) {
				if ($elem2=~/\w+/) {
                    if ($elem2=~/\w+/) {
                            print  OUT "FT                   $elem2\n";  
                            #print  "FT                   $elem2\n";                            
                    }
                    else {
                        print "Incomplete feature:$elem2\n";
                    }
				}
			}



		}     # belongs to if ($last_elem > 9)

		else {
			print "Undefined genelist[0] $line\n";
		}
	}


############ all other lines ##########################################################################

	elsif ($arr[2] =~/gene/) {
		
### save the info for next round
# get info for the new gene
		unshift (@genelist, $line);

##### Deal with the previous gene here

	unless ($gene[1]) {
		next;
	}

#### write info for the previous gene

#			print "269 Arr: $arr[6]\n";
				my $coords = join("," , @gene);
				$coords =~s/,//;
#				@gene ='';
#			print "273 Coords: $coords\n";		
			if ($last_arr[6] =~/\+/) {
#				my $coords = join("," , @gene);
#				$coords =~s/,//;
				@gene ='';
#FT   CDS             join(20929..26310,27215..28456)
				print OUT "FT   CDS              join($coords)\n";
#				print "280: FT   CDS              join($coords)\n";
			}
			elsif ($last_arr[6] =~/\-/) {
				my @rev_gene= reverse(@gene);
#				my @rev_gene= @gene;
				my $coords = join("," , @rev_gene);
				my @coords2 = split(/,/, $coords);
				my @coords3 = reverse(@coords2);
				my $coords3 = join("," , @coords3);
#				chomp $coords;
				@gene ='';
#	FT   CDS              complement(join(20929..26310,27215..28456))
				 print OUT "FT   CDS              complement(join($coords3))\n";
#				 print  "293: FT   CDS              complement(join($coords3))\n";
			}
            elsif ($last_arr[6] =~/\./) {
				 print "WARNING: Orientation is dot, printed as \'-\' $last_arr[9]\n";
				my @rev_gene= reverse(@gene);
#				my @rev_gene= @gene;
				my $coords = join("," , @rev_gene);
				my @coords2 = split(/,/, $coords);
				my @coords3 = reverse(@coords2);
				my $coords3 = join("," , @coords3);
#				chomp $coords;
				@gene ='';
#	FT   CDS              complement(join(20929..26310,27215..28456))
				 print OUT "FT   CDS              complement(join($coords3))\n";
#				 print  "293: FT   CDS              complement(join($coords3))\n";
            }
            else {
				 print "WARNING: Orientation is unreadable: $last_arr[9]\n";
            }

# get info for the previous gene
#			push(@result,  "List1: $genelist[1]\n");			
			my @locus =split (/\t/, $genelist[1]);
			$locus[8] =~s/ID=//;
#			$locus[0] =~s/ID=//;
			$locus[1] =~s/chado/Manual annotation/;
#			print OUT  "FT                   /source=\"$locus[1]\"\n";		
			print OUT  "FT                   /systematic_id=\"$locus[8]\"\n";
#            print "304: FT                   /systematic_id=\"$locus[8]\"\n";


# write info
#
#
#        print "$genelist[0]\n";
		my @info = split (/\t/, $genelist[1]);
		my $last_elem = (scalar(@info) );
#        print "313: LAST:$last_elem\n";
		if ($last_elem > 9) {
        		my @slice = @info[9..$last_elem];
        		pop @slice;
#                print "317: SLICE: $slice[1]\n";
################# fix tailing product tabs and spaces ###############################

                my $tail = join("\t", @slice);
                $tail=~s/  / /g;
                $tail=~s/  / /g;
                $tail=~s/\t\t/\t/g;
                $tail=~s/\t\t/\t/g;
                $tail=~s/\t\t/\t/g;
                #$tail=~s/\t/ /g;
                #$tail=~s/\"\ \//\"\t\//g;
                #  print "TAIL:$tail\n";
                my @slice3 = split(/\t/, $tail);
                @slice=@slice3;

#####################################################

 			foreach my $elem2 (@slice) {
				if ($elem2=~/\w+/) {
                    #if ($elem2=~/\"\w+/) {
#                            print  "FT                   $elem2\n";
                            print  OUT "FT                   $elem2\n";   
                            #}
                            #else {
                            #print "338: Incomplete feature:$elem2\n";
                            #}
				}
			}


            
		}     # belongs to 	if ($last_elem > 9) 

	}       # belongs to elsif ($arr[2] =~/gene/)


	elsif ($arr[2] =~/mRNA/) {
		# do nothing
	}
	elsif ($arr[2] =~/CDS/) {
#			split(/\t/, $);
			my $value = "$arr[3]\.\.$arr[4]";
#			print "356: Value: $value\n";
			push (@gene, $value);
	}

	else {
			print STDERR "WARNING: $line is neither gene, mRNA or CDS";
	}
$last_line=$line;
}




################################################################################
# Do the ending
################################################################################


print OUT "\/\/\n";

close (OUT);

}

}

print STDERR "Finished\n";
close (STDERR);

__END__

