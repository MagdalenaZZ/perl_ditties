#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: GO_correlate.pl replace-file files


    ' . "\n";
}




my $rep = shift;
my @files = @ARGV;


# read in rep into a hash 

open (REP, "<$rep")|| die;

my %hits;


while (<REP>) {
    chomp;

    my @arr = split(/\t/, $_);

    $hits{$arr[1]}="$arr[0]";
    #print ":$arr[1]:\t:$arr[0]:\n";
}


# read in all files and store GO-values in a hash of hashes
my %h;

foreach my $file (@files) {

    open (IN, "<$file")|| die;

    $file=~s/\.max.0.05.prod.outR.txt//;

    while (<IN>) {
        chomp;

        my @arr = split(/\t/,$_);
        my $go = "$arr[1]\t$arr[2]";
        my $annot = "$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[0]";
        $go =~s/\"//g;
        my @arr2 = split(/\,/,$arr[7]);
        my @arr3 = split(/\,/,$arr[8]);
        $h{$go}{"ANNOT"}{$annot}="$file";

        #print "$go\n";

       my $i = 0;

       foreach my $ele (@arr2) {
           #print "$go\t$ele\t$file\t$arr3[$i]\n";
            $h{$go}{"GO"}{"$ele\t$file"}="$arr3[$i]";
            $i++;

       }

    }


}



foreach my $go (sort keys %h) {
    print "$go\n";
    print "Gene\tSample\tProduct\tTrue geneID(for orthologs)\n";

    foreach my $an (sort keys %{$h{$go}{"ANNOT"}}) {
        #print "$an\t$h{$go}{ANNOT}{$an}\n";
    }

    my @arr;

    foreach my $gene (sort keys %{$h{$go}{"GO"}}) {

        my @a = split(/\t/,$gene);
        my $gen = $a[0];

        if (exists $hits{$gen}) {
            #print "$hits{$gene}\t$h{$go}{GO}{$gene}\t$gene\n";
            push (@arr, "$hits{$gen}\t$a[1]\t$h{$go}{GO}{$gene}\t$gen\n");
        }
        else {
            #print "$gene\t$h{$go}{GO}{$gene}\tNA\n";
            push (@arr, "$gene\t$h{$go}{GO}{$gene}\tNA\n");
        }


    }

    my @sorted = sort(@arr);

    foreach my $el (@sorted) {
        print "$el";
    }
 
print "\n\n";

}


exit;











