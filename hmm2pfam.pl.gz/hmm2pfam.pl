#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}

sub USAGE {

die 'Usage: gff2pfam.pl in.domblout  e-val

Give a hmm.domblout input-file  and e-val cutoff

The program will make a pfam-style output

'

}


my $in = shift;
my $eval = shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

    open (OUT, ">$in.pfam") || die "I can't open $in.pfam\n";
    open (OUT2, ">$in.filtered") || die "I can't open $in.filtered\n";

    
foreach my $line (@input) {
chomp $line;

    unless ($line =~/^#/) {
        my @var	= split(/\s+/, $line);

        if ( $var[12] < $eval ) {
            print OUT "$var[0]\t$var[17]\t$var[18]\t$var[19]\t$var[20]\t$var[3]\t$var[3]\t$var[3]\t$var[15]\t$var[16]\t$var[13]\t$var[12]\t$var[21]\t$var[3]\n";
        }
        else {
            print OUT2 "$var[0]\t$var[17]\t$var[18]\t$var[19]\t$var[20]\t$var[3]\t$var[3]\t$var[3]\t$var[15]\t$var[16]\t$var[13]\t$var[12]\t$var[21]\t$var[3]\n";
        }

    }
}





	close (OUT);
    close (OUT2);
