#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}

sub USAGE {

die 'Usage: nogs.pl nog-list folder



'
}

# input
	my $list = shift;
    my $folder = shift;

my @folders;

### making fake data ######
my $spe1 = "spec_1";
my $spe2 = "spec_2";

push (@folders, $spe1);
push (@folders, $spe2);

##################


    open (LIST, "<$list") || die "I can't open $list\n";
	my @list = <LIST>;


### making fake data ######
my $spe1 = "nog_1";
my $spe2 = "nog_2";

push (@list, $spe1);
push (@list, $spe2);

##################

# make a hash of a hash with all species, and all nogs

my %hash;

foreach my $species (@folders) {

    foreach my $nog (@list) {

        # here I give all the nogs for all species, and say that they don't have them

        $hash{$species}{$nog} = "no";
    }
}

####### now you just cycle through the input and change the no to yes if it has ##################


foreach my $file (@folders) {

    # open the file
    open (IN, "<$file") || die "I can't open $file\n";

    # parse the file to get out the nog and species
    

    # then declare it as existing
    $hash{$species}{$nog} = "yes";

    close (IN);

}

###### now you have a hash with all species, and yes or no for all nogs for all species ################

# write output






__END__


	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT3, ">$out.warnings") || die "I can't open $out.warnings\n";


