#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: tRNAscan-SE_parser.pl tRNAscan.output  genome.fasta


Processes the output-file (-o) of tRNAscan-SE

Same genome-file as you ran  tRNAscan-SE on
 



'
}

	my $in = shift;
	my $genome = shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$in.gff") || die "I can't open $in.gff\n";


foreach my $line (@in) {
    chomp $line;
    #print "$line\n";
    my @ar = split(/\s+/, $line);

    if (scalar(@ar)==9 and $ar[0]!~/-----/) {
        my $ori = '.';

        if ($ar[2]> $ar[3]) {
            $ori="-";
        }
        else {
            $ori="+";
        }


        #if (  ($ar[2]-$ar[3]) > 200 or ($ar[3]-$ar[2]) > 200 ) {
            #print "$line\n";
            #}
            #
            #
            

        if ( $ori =~/\+/) {
            print OUT "$ar[0]\ttRNAScan\tCDS\t$ar[2]\t$ar[3]\t$ar[8]\t$ori\t\.\tID=$ar[0]\_$ar[1];note=\"$ar[4] $ar[5]\"\n";
        }

        else {
            print OUT "$ar[0]\ttRNAScan\tCDS\t$ar[3]\t$ar[2]\t$ar[8]\t$ori\t\.\tID=$ar[0]\_$ar[1];note=\"$ar[4] $ar[5]\"\n";
        }


    }
}


system "perl ~/bin/perl/fasta_from_CDS.pl $genome $in.gff";


exit;


