#!/usr/bin/perl
use strict;

unless (@ARGV >1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/scatterplot_in_R.pl in.tab in.design "Design" colours colour.legend


infile has this structure:
        Cond1.1   Cond1.2   Cond1.2   Cond2.2
Gene1   val1  val2  val3    val4
Gene2   val1  val2  val3    val4



';

}

my $in = shift;
my $des = shift;
my $de = shift;
my $col = shift;
my $leg = shift;

#print "$in\n$des\n$de\n$col\n$leg\n\n";

my @inr=split(/\//,$in);
my @colr=split(/\//,$col);


open (R, ">$inr[-1].$colr[-1].R") || die "Cannot print to file $inr[-1].$colr[-1].R\n";


# Read in data

print R "library(DESeq2)\n";
print R "CountTable = read.table( \"$in\", header=TRUE, row.names=1 )\n";
print R "design =  read.table( \"$des\", header=TRUE, row.names=1 )\n";
print R "dds<-DESeqDataSetFromMatrix(countData= CountTable,colData= design,design=$de)\n";

print R "## releveling\n";
print R "try(dds\$Trans <- relevel(dds\$Trans, \"normal\"))\n";
print R "try(dds\$Cell <- relevel(dds\$Cell, \"LSK\"))\n";
print R "try(dds\$Hox <- relevel(dds\$Hox, \"hasHox\"))\n";
print R "try(dds\$BCat <- relevel(dds\$BCat, \"WT\"))\n";
print R "try(dds\$Biol <- relevel(dds\$Biol, \"A\"))\n";
print R "try(dds\$Virus <- relevel(dds\$Virus, \"Puro\"))\n";
print R "\n";

print R "# Starting to test interactions\n";
print R "dds <-DESeq(dds)\n";
#print R "res <-results(dds, addMLE=TRUE )\n";
print R "res <-results(dds)\n";


 
# Read in colours
print R "Cols = read.table( \"$col\", row.names=1 )\n";
print R 'colnames(Cols) <-c("Colour","Gene")';
print R "\n";

# Read in legend
print R "legend = read.table( \"$leg\" )\n";
print R 'colnames(legend) <-c("Colour","Gene")';
print R "\n";



print R "res2 <-as.data.frame(res)\n";

# Merge Colours and data by row.names
#print R "r <-merge(Cols,CountTable,bx=0,by=0, sort=F)\n";
print R "r <-merge(Cols,res2,bx=0,by=0, sort=F)\n";



# Rename columns
#print R 'colnames(r) <- c("Row.names", "C1","Colour" )\n';
print R 'colnames(r)';
print R "\n";


print R "pdf(\"$inr[-1].$colr[-1].plotMA.pdf\", useDingbats=FALSE)\n";

print R '
plotMA(res,main="DESeq2",ylim=c(-2,2))
#plot(res$baseMean,res$log2FoldChange, ylim=c(-2,2), log = "x")
#abline(0,0)
';

print R "dev.off()\n";



# plot dots and legend
print R "pdf(\"$inr[-1].$colr[-1].myMA.pdf\", useDingbats=FALSE)\n";
print R "par(mar=c(5.1, 4.1, 4.1, 8.1), xpd=TRUE)\n";

print R "plot(r\$baseMean,r\$log2FoldChange, col=as.character(r\$Colour), bty='L', log=\"x\")\n";
#print R "plot(r\$baseMean,r\$log2FoldChange, col=as.character(r\$Colour), bty='L')\n";
print R "legend(1000000,2,as.vector(legend\$Gene),col=as.vector(legend\$Colour), pch=1)\n";
print R " par(xpd=FALSE) \nabline(0,0)\n";
print R "dev.off()\n";


system "R CMD BATCH $inr[-1].$colr[-1].R";


exit;









