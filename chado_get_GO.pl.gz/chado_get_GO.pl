#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado_get_GO.pl input.gff 

Takes a gff-file from Chado and gets the GO-terms. Prints to outfile.


'
}

	my $in = shift;
	my $out = "$in.GO";
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

# print "Hi!\n";

## Basic stats 

my @contigs;
my @methods;
my @tags;
my @coords;
my @keys;
my @split_genes;
my @geness;

my $index = 1;
my %go;

foreach my $line (@in) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

    #print "$key\n";

    if ($key=~/GO/ and $tag=~/polypeptide/) {
        $key=~s/%3D/;/g;
        $key=~s/%3B/;/g;

        my @arr = split(/;/, $key);
        pop @arr;
        foreach my $elem (@arr) {
            push (@{$go{$arr[0]}} = $elem;
            print "$arr[0]\t$elem\n";
        }
    }
}



close(OUT);
