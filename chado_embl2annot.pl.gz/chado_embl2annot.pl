#!/usr/bin/perl -w


# use strict;

use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: chado_embl2annot.pl infile out-prefix
# From an embl-file , it flags up mistakes, and makes a cleaned-up version


First run the writedb_entries.py script 


'
}



my $in = shift;
my $out = shift;

# Read in the concatenated file
#
	open (IN, "<$in") || die "I can't open $in\n";
	my @embl = <IN>;
	close (IN);


# Print a list of contigs with no genes
	open (PR, ">$out.previous_ID") || die "I can't open $out.previous_ID\n";
	open (CL, ">$out.colour") || die "I can't open $out.colour\n";
	open (GO, ">$out.GO") || die "I can't open $out.GO\n";
	open (PD, ">$out.prod") || die "I can't open $out.prod\n";
    open (EC, ">$out.EC") || die "I can't open $out.EC\n";
    open (DB, ">$out.db") || die "I can't open $out.db\n";
    open (NT, ">$out.note") || die "I can't open $out.note\n";
    open (PS, ">$out.pseudo") || die "I can't open $out.pseudo\n";
    open (GN, ">$out.gene") || die "I can't open $out.gene\n";
    open (CC, ">$out.cc") || die "I can't open $out.cc\n";


# print features
open (OUT, ">$out") || die "I can't open $out\n";

# Get only the annotation

# Make a hash containing %gene{gene}{contig} = contig
#                                   {FT} = @fts
#                                   {CDS} = coords
#                                   {locus} = locus_tag
                                  
my %gene;
	my $name;
	my $method = "chado";
	my $tag = "CDS";
	my $start = "0";
	my $end = "0";
	my $score = ".";
	my $strand;
	my $id;
my @ft='';
my $cds='';

foreach my $line (@embl) {
chomp $line;
if ($line=~/\w/ or $line=~/\W/ ) {
#print "LINE:$line:\n";
	my @arr=split(/\s+/, $line);
#		print "LINF:$arr[0]:\n";
    if ($arr[0]=~/^FH/ || $arr[0]=~/\/\// ) {
        # do nothing;
    }
	elsif ($arr[0]=~/^ID/) {
		$contig = $arr[1];
		$contig =~s/\.embl\;//g ;
#		print "Cont:$contig\n";
	}
	elsif ($line=~/^FT\s+gap/ or $line=~/^FT\s+source/  or  $line=~/^FT\s+rRNA/ or  $line=~/^FT\s+ncRNA/ or $line=~/^FT\s+tRNA/   ) {
        #$contig = $arr[1];
        #$contig =~s/\.embl\;//g ;
        #print "$line\n";
	}

	elsif ($arr[0]=~/^FT/ and $arr[1]!~/locus_tag/ ) {
		if ($arr[1] =~/^CDS/) {
			if ($arr[2] =~/complement/) {
				$strand = "-";
				$arr[2] =~s/complement\(//g;
				$arr[2] =~s/join\(//g;
				$arr[2] =~s/\)\)//g;
				$arr[2] =~s/\)//g;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
#				foreach my 
#				split(//,);
                push (@cds, $line);

			}
			else {
				$strand = "+";
				$arr[2] =~s/join\(//;
				$arr[2] =~s/\)//;
#				print "CDS:$arr[2]\n";	
				@arr2=split(/,/, $arr[2]);
                push (@cds, $line);
			}
		}
		else {
            $line=~s/FT                   //;
            #print "Filter 2:$line\n";
            push (@ft, $line);
		}
	
	}
    elsif ($line =~m/\)/ || $line =~m/\./ ) {
        #print "Filter 3:$line\n";
        push (@cds, $line);

    }

		elsif ($arr[1] =~/locus_tag/ or $arr[1] =~/gene/) {
			$arr[1]=~s/\/locus_tag="//;
			$arr[1]=~s/\/gene="//;
			$arr[1]=~s/\"//;
#			print "ID:$arr[1]\n";
			$id = $arr[1];	

            # Fill the hash
# Make a hash containing %gene{contig}{gene}
#                                           {FT} = @fts
#                                           {CDS} = coords
#                                           {ORI} = strand
#            print "$contig\t$id\t$strand\n";
            # Add orientation
            $gene{$contig}{$id}{"ORI"} = $strand;

            # Add features
            $fts = join (" ", @ft);
#            print "Features:$fts:\n";
            my @ftarr = split(/\//, $fts);

            if (scalar(@ftarr) < 1) {
                print "Ignored:$fts:\n";
            }

            elsif ($ftarr[1]=~/^previous_systematic_id=/) {
                print   PR "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^colour=/) {
                print   CL "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^GO=/) {
                print   GO "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^product=/) {
                print   PD "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^EC_number=/) {
                print   EC "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^db_xref=/) {
                print   DB "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^note=/) {
                print   NT "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^pseudogene=/) {
                print   PS "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^gene=/) {
                print   GN "$id\t$ftarr[1]\n";
            }
            elsif ($ftarr[1]=~/^controlled_curation=/) {
                print   CC "$id\t$ftarr[1]\n";
            }

            else {
                print "$id\t$ftarr[1]\n";
            }

            foreach my $elem ( @ftarr ) {
                if ($elem=~m/\w/){
                    push (@{$gene{$contig}{$id}{"FT"}}, $elem );
                }
            }

            # Add CDS-coords

            $cds = join ("", @cds);
            $cds=~s/FT   CDS             //;
#            print "Coords:$cds:\n";
            my @coarr = split(/\,/, $cds);
#            print "Feature1:$coarr[0]:\n";
            foreach my $elem ( @coarr ) {
                if ($elem=~m/\w/){
                    $elem=~s/complement\(//;
                    $elem=~s/join\(//;
                    $elem=~s/\)//g;
                    $elem=~s/\>//g;
                    $elem=~s/\<//g;
                    push (@{$gene{$contig}{$id}{"CDS"}}, $elem );
                }
            }

        @ft='';
        @cds='';
	    $start = "0";
	    $end = "0";
	    $score = ".";
	    $strand = "0";
	    $id = "0";


		}


	elsif ($arr[0]=~/\/\//) {
#		foreach my $pos (@arr2) {
#				($start,$end)=split(/\.\./, $pos);
#			print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.\tID=$id\n";
#		}
	}
	else {
        #print "Filter 1:$line\n";
	}


# print "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\n";
}
}



# Empty the genes hash
#
	open (OUTP, ">$out.products") || die "I can't open $out.products\n";
	open (OUTGFF, ">$out.gff") || die "I can't open $out.gff\n";
	open (OUTCUR, ">$out.curation") || die "I can't open $out.curation\n";


foreach my $cont (sort keys %gene) {
    while ( my ($name, $value) = each %{ $gene{$cont} } ) {
        my $ori = $gene{$cont}{$name}{ORI} ;
#        print "$cont\t$name\t$ori\n";

        foreach my $feat (@{$gene{$cont}{$name}{"FT"}}) {
            if ($feat=~/^product/) {
                print OUTP "$cont\t$name\t/$feat\n";
            }
            elsif  ($feat=~/curatorName/) {
                print OUTCUR "$cont\t$name\t/$feat\n";
            }


            
            
#            print "FEAT:/$feat:\n";
        }


         my @coords;

        foreach my $cds (@{$gene{$cont}{$name}{"CDS"}}) {
#            if ($feat=~/^product/) {
#                print OUTP "$cont\t$name\t/$feat\n";
#            }
#            elsif  ($feat=~/curatorName/) {
#                print OUTCUR "$cont\t$name\t/$feat\n";
#            }
            push (@coords, $cds);
#            print "FEAT:/$cds:\n";

        }

        my $co = join("-", @coords);
#        print "$name:$co:\n";
        my @arr = split(/\.\./,$co); 

        foreach my $elem (@arr) {
            if ($elem=~m/\-/) {
                my ($start, $end)=split(/\-/, $elem);
                my $res = $end - $start;
#                print "$cont\t$name\t$res\n";
            }
        }


    }
}


close (OUT);
close (OUTP);
close (OUTGFF);
