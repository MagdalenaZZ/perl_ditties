#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

    die '


Usage: fastq_splitter.pl <read-number> file_1.fastq ( file_1.fastq )  


This program splits a pair of fastq-files to several of a size determined by you.

Then it makes a library-file for iterative alignment.

    ' . "\n";
}



my $rno = shift;
my $fas = shift;
my $fas2= '';
if (scalar(@ARGV) > 0) {
    $fas2 = shift;
    print "made 2 \n";
}


my @arr = split(/\./,$fas);

my $base = $arr[0];

#mkdir "$base\_$rno";



my @files;
my $len = 0;

my $paired = 0;
if ($fas2 =~/\w+/) {
        $paired = 1;
        print "We are paired $fas $fas2\n\n";
}

if ($fas =~/q$/ ) {
    print "I'm fastq\n";
}
elsif ($fas =~/a$/ ) {
    print "I'm fasta\n";
}



if ( $paired == 1 and $fas =~/a$/  ) {
     print "I'm paired fasta\n";

    $rno = ($rno * 2);
    print "$rno\n";
    my $index = 0;
    my $i = 1;

    open (FA, "<$fas") || die 'Cant find file $fas';
    open (FA2, "<$fas2") || die 'Cant find file $fas';

    my @fas = '';

    while ( <FA> ) {
        #print "$_";
        
        if ( $index < $rno   ) {
            push(@fas, $_);
            #print "I'm adding to $fas.$i\t$_\n";
            $index++;
        }
        else {
            open (FAS, ">$fas.$i");
            print FAS @fas;
            close (FAS);
            #print "I'm printing to $fas.$i\n";
            push ( @files, "$fas.$i");
            $index = 0;
            $i++;
            @fas = '';

            # start the next
            push(@fas, $_);
            $index++;

        }

    }
    $len = scalar(@files);


    close (FA);

    $index = 0;
    $i = 1;

    @fas = '';



    while ( <FA2> ) {
        #print "$_";
        
        if ( $index < $rno   ) {
            push(@fas, $_);
            #print "I'm adding to $fas.$i\t$_\n";
            $index++;
        }
        else {
            open (FAS2, ">$fas2.$i");
            print FAS2 @fas;
            close (FAS2);
            #print "I'm printing to $fas.$i\n";
            push ( @files, "$fas2.$i");
            $index = 0;
            $i++;
            @fas = '';

            # start the next
            push(@fas, $_);
            $index++;

        }

    }
        
        
        
    close (FA2);



}

elsif ( $paired == 1 and $fas =~/q$/ ) {
    print "I'm paired fastq\n";
    print "We are paired $fas $fas2\n\n";
    $rno = ($rno * 4);
    print "$rno\n";
    my $index = 0;
    my $i = 1;
    my $hk = 0;


    open (FA, "<$fas") || die 'Cant find file $fas';
    open (FA2, "<$fas2") || die 'Cant find file $fas';

    my @fas = '';

    open (FAS, ">$fas.$i");

    while ( <FA> ) {
        #print "$_";

        if ( $index < $rno   ) {
            print FAS "$_";
            #print "I'm adding to $fas.$i\t$_\n";
            $index++;
            $hk++;
            if ($hk == 100000 ) {
                # print to file and close            
                print FAS @fas;    
                @fas = '';
                $hk = 0;
            }
        }
        else {
            
            # print last and close old file          
            print FAS @fas;
            close (FAS);
            #print "I'm printing to $fas.$i\n";
            push ( @files, "$fas.$i");

            # reset indexes and open new file
            $index = 0;
            $i++;
            @fas = '';
            open (FAS, ">$fas.$i");

            # start the next
            push(@fas, $_);
            $index++;
            $hk++;

        }

    }
    $len = scalar(@files);


    close (FA);

    $index = 0;
    $i = 1;

    @fas = '';

    open (FAS2, ">$fas2.$i");


    while ( <FA2> ) {
        #print "$_";
       


        if ( $index < $rno   ) {
            push(@fas, $_);
            #print "I'm adding to $fas.$i\t$_\n";
            $index++;
            $hk++;
            if ($hk == 100000 ) {
                # print to file and close            
                print FAS2 @fas;    
                @fas = '';
                $hk = 0;
            }
        }
        else {
            
            # print last and close old file          
            print FAS2 @fas;
            close (FAS2);
            #print "I'm printing to $fas.$i\n";
            push ( @files, "$fas2.$i");

            # reset indexes and open new file
            $index = 0;
            $i++;
            open (FAS2, ">$fas2.$i");

            @fas = '';

            # start the next
            push(@fas, $_);
            $index++;
            $hk++;

        }

       
    }
        
        
        
    close (FA2);



















}

elsif ( $paired == 0 and $fas =~/q$/ ) {
     print "I'm unpaired fastq\n";

}


else {
     print "I'm unpaired fasta\n";
 }



open (LIB, ">$fas.lib");


for (my $in = 0; $in < $len; ) {

    print LIB "-fasta -shortPaired -separate $files[$in] $files[ ($len+$in) ]\n";
    $in ++;

}

close (LIB);





exit;

__END__


# -fasta	-fastq -separate -short	-shortPaired

# perl ~/bin/perl/fastq_splitter.pl 100000 DjF2_294733_whole.9234_8#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta DjF2_294733_whole.9234_8#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta &


# Before I can run this from khmer, I have to 
#
# ~mh12/git/python3.2/fastn_deinterleave.py 
# fasta2singleLine.py
#

  perl ~/bin/perl/fastq_splitter.pl 1000000  DjF3_294733_whole.9234_6#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta DjF3_294733_whole.9234_6#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta &
  perl ~/bin/perl/fastq_splitter.pl 100000  DjF1_294733_whole.9221_8#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta  DjF1_294733_whole.9221_8#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta &
perl ~/bin/perl/fastq_splitter.pl 100000000   DjF2_294733_whole.9234_8#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta DjF2_294733_whole.9234_8#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta &
perl ~/bin/perl/fastq_splitter.pl 10000000  DjF1_294733_whole.9248_7#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta  DjF1_294733_whole.9248_7#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta &


perl ~/bin/perl/fastq_splitter.pl 100  DjF3_294733_whole.9233_8#11.10.80.no_polyAfastq.fasta.keep.pe_1.fasta DjF3_294733_whole.9233_8#11.10.80.no_polyAfastq.fasta.keep.pe_2.fasta
perl ~/bin/perl/fastq_splitter.pl 10  DjF2_294733_whole.9234_7#11.10.80.no_polyAfastq.fasta_1.fasta DjF2_294733_whole.9234_7#11.10.80.no_polyAfastq.fasta_2.fasta






