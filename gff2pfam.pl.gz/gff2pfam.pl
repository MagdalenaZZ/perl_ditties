#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}

sub USAGE {

die 'Usage: gff2pfam.pl in.gff 

Give a gff input-file and the program will make a pfam-style output  - of genes only!

'
}

my $in= shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);
	open (OUT, ">$in.pfam") || die "I can't open $in.pfam\n";

   
my @out;

foreach my $line (@input) {
chomp $line;

    unless ($line =~/^#/) {
        my @var	= split(/\s+/, $line);

        if ($var[2]=~/gene/) {
            push (@out, "$var[0]\t$var[3]\t$var[4]\t$var[3]\t$var[4]\tPF\tgene\tgene\t0\t0\t0\t0\t0\t1\tCL0\n");
        }
    }
}

my @sorted = sort(@out);

foreach my $line (@sorted) {
    print OUT "$line";
}


print "Results written to file $in.pfam \n";
exit;

__END__

EmuJ_001195800.1..pep    161    295    160    296 PF02732.10  ERCC4             Domain     2   142   143     74.4   6.9e-21   1 CL0236
EmuJ_001195900.1..pep     36    249     35    250 PF01400.19  Astacin           Domain     2   190   191    124.6     3e-36   1 CL0126
EmuJ_001195900.1..pep    282    318    281    318 PF01549.19  ShK               Domain     2    38    38     27.2   3.5e-06   1 CL0213
EmuJ_001195900.1..pep    333    367    332    367 PF01549.19  ShK               Domain     2    38    38     27.6   2.6e-06   1 CL0213
EmuJ_001195900.1..pep    379    417    379    417 PF01549.19  ShK               Domain     1    38    38     30.6   3.1e-07   1 CL0213
EmuJ_001195900.1..pep    451    487    450    487 PF01549.19  ShK               Domain     2    38    38     17.5    0.0038   1 CL0213
EmuJ_001195950.1..pep     30    165     29    165 PF14955.1   MRP-S24           Family     2   136   136    165.5   5.2e-49   1 No_clan
EmuJ_001196000.1..pep    280    380    280    385 PF03126.13  Plus-3            Domain     1   103   108     91.6   2.9e-26   1 No_clan
EmuJ_001196100.1..pep     29     93     28     93 PF00226.26  DnaJ              Domain     2    64    64     64.7   4.3e-18   1 CL0392
EmuJ_001196200.1..pep    241    297    241    297 PF00046.24  Homeobox          Domain     1    57    57     72.2   1.9e-20   1 CL0123


