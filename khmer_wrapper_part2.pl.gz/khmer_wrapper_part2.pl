#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  khmer_wrapper_part2.pl  kmer reads_1 reads_2 

This script produces 



';

}



my $kmer = shift;
my $file1 = shift;
my $file2 = shift;
my $base = 0;


if ($file1=~/\w+/) { 
    # nothing
    my @arr = split(/\//,$file1);    
    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;
}


system "rm -f $base\_1.fastq_N $base\_1.fastq_N ";


print "Lets do this....\n";

#print "$file1\t$file2\n";

    open (IN, "<$file1");
    unless (-e "$base\_1.fasta" ) {
        open (OUT, ">$base\_1.fasta");
    }
print "Converting file $file1\n";

while (<IN>) {
    #print "IN\n";
    my @arr1 = split(/\s+/, $_);
    print OUT "$arr1[0]\n";

}

print "Converting file $file2\n";

open (IN2, "<$file2");
unless (-e "$base\_2.fasta" ) {
    open (OUT2, ">$base\_2.fasta");
}

while (<IN2>) {
    my @arr2 = split(/\s+/, $_);
    print OUT2 "$arr2[0]\n";

}

system "rm -f $base\_1.fastq_corrected.fa $base\_2.fastq_corrected.fa ";



system "~mh12/git/python/fastn_shuffle.py   $base\_1.fasta  $base\_2.fasta  $base.fasta";


open (OUT3, ">$base\_$kmer.sh");

# do kmehr

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py  -C 20 -k $kmer -N 4 -x 2e9 --paired   $base.fasta  \n";

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/sandbox/strip-and-split-for-assembly.py $base\_corrected.fa.keep  \n";

print "bsub.py --dep=\"$base\_$kmer\_2\" -q small 10 $base\_$kmer\_3 sh $base\_$kmer.sh\n";


print "\n";



