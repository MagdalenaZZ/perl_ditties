#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~mz3/bin/perl/interpro2product.pl gff  databases

databases - list databases you want to get the product names from

Possible alternatives:



Pfam
PRINTS
ProSiteProfiles
ProSitePatterns
SMART




Example:


perl ~mz3/bin/perl/interpro2product.pl interpro.gff  Pfam  PRINTS ProSiteProfiles ProSitePatterns SMART


Works on the interpro gff-file outputted by annotate_eukaryotes

Warning 1: same gene can get several alternative names
Warning 2: the gene-names are not as pretty as those outputted my Pfam original format




';

}




my $gff = shift;
my %db;

foreach my $ele (@ARGV) {
    chomp $ele;
    #print "$ele\n";
    $db{$ele}=1;
}


open (GFF, "<$gff") || die "Cant find file $gff\n";
#open (OUT, ">$gff.pfam") || die "Cant open file $gff.pfam\n";
#open (OUT2, ">$gff.go") || die "Cant open file $gff.po\n";
open (OUT3, ">$gff.prod") || die "Cant open file $gff.prod\n";


my %go;

# process gff

while (<GFF>) {
    my @arr = split(/\t/,$_);
    if ( exists $db{$arr[1]}  ) {
        #print "$arr[0]\t$arr[1]\t$arr[3]\t$arr[4]\t$arr[8]\n";

        my @ann = split(/;/,$arr[8]);


        my $id = $arr[0];


        foreach my $line (@ann) {


                #    }
            if ($line=~/^signature_desc=/) {
                my $go=$line; 
                $go=~s/signature_desc=//;
                #$go=~s/"//g;
                if ($go!~/NA/) {
                    #my @terms = split(/\,/,$go);

                    $go=~s/ attachment site profile//;
                    $go=~s/ family signature//;
                    $go=~s/ signature//;
                    $go=~s/ domain profile//;
                    $go=~s/ domain//;
                    $go=~s/ proteins profile/ protein/;
                    $go=~s/ proteins/ protein/;
                    $go=~s/ profile//;
                    $go=~s/\.$//;
                    $go=~s/ repeat$/ repeat domain containing protein/;

                    #print "$arr[0]\t$arr[1]\t$go\n"; 

                    $go{$arr[0]}{$arr[1]}{$go}=1;

                    #foreach my $term (@terms) {
                        #print "$id\t$term\n";
                        #   $go{$id}{$term}=1;
                        #}

                }
            }



        }


        #       print OUT "$id\t$start\t$end\t$start\t$end\t$pfam\t$desc\t$source\t$no1\t$no2\t$no1\t$no2\t$no3\t$no4\t$no5\t$no6\t$na\n";
    
    }
    else {
        # ignore
    }


}




foreach my $gene ( sort keys %go) {
     #print  "$gene\t";

        if (exists $go{$gene}{"Pfam"}){

            foreach my $key (sort keys %{ $go{$gene}{"Pfam"} } ) {
                print OUT3 "$gene\t/product=\"$key\"\n";
            }
        }
        else {
            #foreach my $ori (sort keys %{$res{$st}}) {
            foreach my $key ( sort keys %{$go{$gene}} ) {
                foreach my $key2 ( sort keys %{$go{$gene}{$key}} ) {

                    print OUT3 "$gene\t/product=\"$key2\"\n";
                }   

            }
        }

}




exit;








