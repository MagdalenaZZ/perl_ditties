#!/usr/bin/perl -w
use strict;
use Data::Dumper;

unless (@ARGV ==4) {
        &USAGE;
}


sub USAGE {

die 'Usage: BLAST_best.pl gff gff2 blast out

Example: perl ~/bin/perl/BLAST_best.pl test00800.result.step4.sorted.gff.gene test00800.alt.gff.gene test00800.blast out

Give a gff-file (with only genes), which is the original
and then a gff-file with alternative transcrips
and then a list of BLAST-hits containing these genes and others
The output reports which genes are not covered by BLAST-hits, and if a gene should be replaced by one with a better BLAST-hit bitscore

After this run 
gff_retrieve_subsets.pl
and 
gff_sorter.pl

'
}

	my $gff = shift;
	my $gff2 = shift;
	my $blast = shift;
	my $out = shift;

	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (GFF2, "<$gff2") || die "I can't open $gff2\n";
	my @gff2 = <GFF2>;
	close (GFF2);

	open (BLAST, "<$blast") || die "I can't open $blast\n";
	my @blast= <BLAST>;
	close (BLAST);

my %gene;

my $root;
my $alt;

# Read in all BLAST-hits and gff-lines, and store them in a hash of hashes of hashes

# genes{generoot}{genealt}{"gff"} = gff-line
# genes{generoot}{genealt}{"ori"} = true/false
# genes{generoot}{genealt}{"blast"} = BLASTline
# genes{generoot}{genealt}{"bitscore"} = score
# genes{generoot}{genealt}{"procent"} = procent identity

# For $gff fill the hash with gene-name, gene-alt and gff-line
# Set ori to true
	open (OUTF, ">$out.curated.gff.gene") || die "I can't open $out.curated.gff.gene\n";

foreach my $line (@gff) {
	chomp $line;
	if ($line=~m/EmW/) {
		print OUTF "$line\n";
	}
	else {

#	print "Line:$line:\n";

	my @arr = split(/\s+/, $line);
#	print "Arr8:$arr[8]:\n";
	$arr[8]=~s/ID=//;
	my @name = split(/\./, $arr[8]);
	$root = "$name[0]\.$name[1]"; 
	$alt = "$name[-1]";
#	print "Root:$root:\n";
#	print "Alt:$alt:\n";	
	$gene{$root}{$alt}{"gff"} = $line;
	$gene{$root}{$alt}{"ori"} = "true";
	}
}

# print Dumper(%gene);

# For $gff2 fill the hash with gene-name, gene-alt and gff-line
# Set ori to false

foreach my $line (@gff2) {
	chomp $line;
	if ($line=~m/EmW/) {
		print OUTF "$line\n";
	} 
	else {

#	print "Line:$line:\n";

	my @arr3 = split(/\s+/, $line);
#	print "Arr8:$arr[8]:\n";
	$arr3[8]=~s/ID=//;
	my @name = split(/\./, $arr3[8]);
	$root = "$name[0]\.$name[1]"; 
	$alt = "$name[-1]";
#	print "Root:$root:\n";
#	print "Alt:$alt:\n";	
	$gene{$root}{$alt}{"gff"} = $line;
	$gene{$root}{$alt}{"ori"} = "false";
	}
}

close (OUTF);
# print Dumper(%gene);

#######################################################################################

# For each $blast -file fill the hashes
# genes{generoot}{genealt}{"blast"} = BLASTline
# genes{generoot}{genealt}{"bitscore"} = score
# genes{generoot}{genealt}{"procent"} = procent identity

foreach my $line2 (@blast) {
	chomp $line2;
#	print "Line:$line:\n";
	my @arr = split(/\s+/, $line2);
	my @name = split(/\./, $arr[0]);	
	$root = "$name[0]\.$name[1]"; 
	$alt = "$name[-1]";
#	print "Root:$root:\n";
#	print "Alt:$alt:\n";
#	print "Bit:$arr[11]:\n";


# if the key is already defined, test if the bitscore is higher before replacing it
# each BLAST-search may have several hits for the same transcript - so only the best is kept

	if ( defined $gene{$root}{$alt}{bitscore} ) {
		if ( $gene{$root}{$alt}{bitscore} >= $arr[11] ) {
#			print "In $root $alt $gene{$root}{$alt}{bitscore}" ." larger than $arr[11]\n";
		}
		else {
			$gene{$root}{$alt}{"blast"} = $line2;
			$gene{$root}{$alt}{"bitscore"} = $arr[11];
			$gene{$root}{$alt}{"hit"} = $arr[1];
			$gene{$root}{$alt}{"procent"} = $arr[2];
#			print "Changed $root $alt $gene{$root}{$alt}{bitscore}" ." smaller than $arr[11]\n";
		}
	}
	else {
		$gene{$root}{$alt}{"blast"} = $line2;
		$gene{$root}{$alt}{"bitscore"} = $arr[11];
		$gene{$root}{$alt}{"hit"} = $arr[1];
		$gene{$root}{$alt}{"procent"} = $arr[2];
	}
}


# print Dumper(%gene);

# Report all ori=true which dont have a BLAST-hit 
	open (OUTB, ">$out.blast.out") || die "I can't open $out.blast.out\n";
	open (OUTC, ">$out.ori.noblast.gff") || die "I can't open $out.ori.noblast.gff\n";
	open (OUTG, ">$out.ori.noblast.gff.list") || die "I can't open $out.ori.noblast.gff.list\n";
#	my @blast= <BLAST>;

# Remove genes which don't have any blast-hits

foreach my $root (keys %gene) {
	for my $alt (keys %{$gene{$root}}) {
		if (defined $gene{$root}{$alt}{blast}) {
#			print "BLAST:$gene{$gene}{$alt}{blast}:\n";
			unless ($gene{$root}{$alt}{ori}) {
				print OUTB "No gff-input for gene \t$root\.$alt\n";	
				delete $gene{$root}{$alt};
			}
		}
		else {
			if ( $gene{$root}{$alt}{ori} =~/true/ ) {
				print OUTB "No BLAST-hit in input for original gene\t$root\.$alt\n";
				print OUTC "$gene{$root}{$alt}{gff}\n";	
				my $name = (split (/\s+/, $gene{$root}{$alt}{gff}))[8];
				$name =~s/ID=//;
				print OUTG "$name\n";				
				delete $gene{$root}{$alt};
				# make false ori as placeholder
				$gene{$root}{$alt}{"blast"} = "0\t0\t0\t0\t0\t0\t0\t0\t0\t0";
				$gene{$root}{$alt}{"bitscore"} = "0";
				$gene{$root}{$alt}{"hit"} = "none";
				$gene{$root}{$alt}{"procent"} = "0";	
				$gene{$root}{$alt}{"gff"} = "0\t0\t0\t0\t0\t0\t0\t0\t0";
				$gene{$root}{$alt}{"ori"} = "noblast";
 
#				delete $gene{$gene};
			}
			else  {
				print OUTB "No BLAST-hit in input for gene \t$root\.$alt\n";	
				delete $gene{$root}{$alt};
#				delete $gene{$gene};
			}
#			elseif ($gene{$gene}{$alt}{ori} =~/false/) {	
#				print OUTB "No gff-input for gene \t$gene\.$alt\n";	
#				delete $gene{$gene}{$alt};	
#			}
#			delete $gene{$gene}{$alt};
		}
	}
}

# Remove genes which exist in blast, but doesnt have any gff




close (OUTG);
close (OUTC);
# For each gene-root - get all the genealt that match 
# if the current one has the highest bit-score - keep it
# if another one has a higher bit-score 

# Remove genes which don't have any alternative transcripts

foreach my $root (keys %gene) {
# print "Gene:$root\n";
my $var=scalar keys %{$gene{$root}};
# print "$var\n";
	if ($var==0) {
		print OUTB "Deleting $root because no transcripts have a blast-hit\n";
		delete $gene{$root};
	}

}

close (OUTB);


############################################################################
# my @AoA;
my %best_gff;

# For each transcript belonging to a gene
foreach my $gene (keys %gene) {
#	print "Gene:$gene:\n";
	my @AoA;
	my  @scores = '';

# Get the bitscores, name and procent ID

	my @scores2;
	
	foreach my $alt (keys %{$gene{$gene}}) {
#		print "Line:$gene\.$alt\t$gene{$gene}{$alt}{bitscore}:\n";
#		push (@scores, "$gene{$gene}{$alt}{bitscore}\t$gene\.$alt");
		if (defined $gene{$gene}{$alt}{bitscore}) {
			my @proc = split(/\s+/, $gene{$gene}{$alt}{blast} );
#			print "%ID:$gene{$gene}{$alt}{blast}\n";
#			print "%ID:$proc[2]\n";
			push (@scores2, "$gene{$gene}{$alt}{bitscore}");
			push (@scores, "$gene{$gene}{$alt}{bitscore}");
			push (@scores, "$gene\.$alt");
			push (@scores, "$proc[2]");
#			print "$gene{$gene}{$alt}{bitscore}\t$gene\.$alt\t$proc[2]\n";
		# move into an array
			push @AoA, [ @scores ];
			@scores = '';
		}

# Remove the genes which don't have bitscores
		else {
			delete $gene{$gene}{$alt};
		}
	}
	
# sort the array
 my @sorted = sort tableSorter @AoA;

	my $best_bit = $sorted[0][1];
#	my $best_alt = $sorted[0][-1];
#####################################
 sub tableSorter ($$) {
     my($row1, $row2) = @_;
     my $column1comparison = $row2->[1] <=>  $row1->[1] ;
     if($column1comparison != 0){
         return $column1comparison;
     }
 #   my $column2comparison = $row1->[2] cmp $row2->[2];
#     if($column2comparison != 0){
 #        return $column2comparison;
#     }

   return $row1->[0] cmp $row2->[0];
 }
#####################################

 my @sorted2 = sort tableSorter2 @AoA;

	my $best_proc = $sorted2[0][-1];
#	print "Best ID:" . "$sorted2[0][-1]" . ":\n";
#####################################
 sub tableSorter2 ($$) {
     my($row1, $row2) = @_;
     my $column1comparison = $row2->[3] <=>  $row1->[3] ;
     if($column1comparison != 0){
         return $column1comparison;
     }
 #   my $column2comparison = $row1->[2] cmp $row2->[2];
#     if($column2comparison != 0){
 #        return $column2comparison;
#     }

   return $row1->[0] cmp $row2->[0];
 }
#####################################

#print ((sort {$b <=> $a} @array)[0]);
#	print "Best bit:" . "$sorted[0][1]" . ":\n\n";

@AoA ='';

# Evalutate the bitscores

#For each gene
foreach my $alt (sort keys %{$gene{$gene}}) {
# If it is the original
	if (defined $gene{$gene}{$alt}{ori}) {
		if ($gene{$gene}{$alt}{ori} =~/true/ )	{
#			if ($gene{$gene}{$alt}{bitscore} == $best_bit) {
#					print "Ori is best:$gene\.$alt\t$gene{$gene}{$alt}{gff}\n";
					$best_gff{$gene}{"gff"} = "$gene{$gene}{$alt}{gff}";
					$best_gff{$gene}{"blast"} = "$gene{$gene}{$alt}{bitscore}\t$gene{$gene}{$alt}{procent}";
#					print "$gene{$gene}{$alt}{bitscore}\t$gene{$gene}{$alt}{procent}\n";
						}
#			elsif ($gene{$gene}{$alt}{procent} == $best_proc) {
#					print "Ori is best:$gene\.$alt\n";
#					$best_gff{$gene} = "$gene{$gene}{$alt}{gff}";
#				}
#			else {
#					print "Ori is worse:$gene\.$alt\n";
#			}
		}
		elsif ( $gene{$gene}{$alt}{ori} =~/noblast/ ) {
					$best_gff{$gene}{"gff"} = "$gene{$gene}{$alt}{gff}";
					$best_gff{$gene}{"blast"} = "$gene{$gene}{$alt}{bitscore}\t$gene{$gene}{$alt}{procent}";
#					print "Ori is undefined:$gene\.$alt\t$gene{$gene}{$alt}{gff}\n";
		}
}


###########################

foreach my $alt (sort keys %{$gene{$gene}}) {
# If it is an alternative transcript

	if (defined $gene{$gene}{$alt}{ori}) {
		if ($gene{$gene}{$alt}{ori} =~/false/ ) {

# If there is not an alternative transcript put any transcript
#			unless (exists $best_gff{$gene}) {
#				$best_gff{$gene} = "$gene{$gene}{$alt}{gff};/note=\"replaced\"";
#			}

# Now test if one alternative is better
			if ($best_gff{$gene}) {
# Test if the alternative has bot h% and bit-score higher than the original
				my @best=split(/\t/, $best_gff{$gene}{blast});
#				print "$best_gff{$gene}{gff}\n";
#				print "$best_gff{$gene}{blast}\n";
#				print "current bit:$best[0]:\n";
#				print "current procent:$best[1]:\n";		
#				print "Best bit:$best_bit\n";
#				print "Best procent:$best_proc\n";
# If the alternative has equal or better bit and higher % choose that one
				if ( $gene{$gene}{$alt}{bitscore}>= $best[0] and $gene{$gene}{$alt}{procent} > $best[1] ) {
#				print "This gene has equal bit and equal or better % than the existing one $gene\.$alt\n";
					$best_gff{$gene}{"gff"} = "$gene{$gene}{$alt}{gff};/note=\"replaced\"";
					$best_gff{$gene}{"blast"} = "$gene{$gene}{$alt}{bitscore}\t$gene{$gene}{$alt}{procent}";
				}
# If the alternative has equal or better bit and equal or higher % and is a replacement itself
				elsif ($gene{$gene}{$alt}{bitscore}>= $best[0] and $gene{$gene}{$alt}{procent} >= $best[1] and $best_gff{$gene}{gff} =~/replace/ ) {
					$best_gff{$gene}{"gff"} = "$gene{$gene}{$alt}{gff};/note=\"replaced\"";
					$best_gff{$gene}{"blast"} = "$gene{$gene}{$alt}{bitscore}\t$gene{$gene}{$alt}{procent}";
#				print "This gene is replacing a replacement $gene\.$alt\n";
				}

			}
		

		}
	}
	else {
		print "This has no ori $gene\.$alt\n";
	}


=pod
			if ( $gene{$gene}{$alt}{bitscore} == $best_bit) {
# and $gene{$gene}{$alt}{procent} == $best_proc) {
#					print "Alternative:$gene\.$alt\n";
					unless (exists $best_gff{$gene} and $best_gff{$gene}!~/replaced/) {
					$best_gff{$gene} = "$gene{$gene}{$alt}{gff};/note=\"replaced\"";
#					print "REPLACED bit:$gene{$gene}{$alt}{gff} \n";	
					}				
						}
			elsif ( $gene{$gene}{$alt}{procent} == $best_proc) {
					unless (exists $best_gff{$gene}) {
					$best_gff{$gene} = "$gene{$gene}{$alt}{gff};/note=\"replaced\"";
#					print "REPLACED procent:$gene{$gene}{$alt}{gff} \n";	
					}
			}
			else {
#					print "Worse alternative:$gene\.$alt\n";				
			}			
	}
}
=cut
#	else {
#		print "No bitscore\n";
#	}
#



}
}
	
#}

# print "###########\n";


	open (OUTD, ">$out.gff.gene") || die "I can't open $out.gff.gene\n";
	open (OUTE, ">$out.gff.list") || die "I can't open $out.gff.list\n";
	open (OUTG, ">$out.replaced.gff.list") || die "I can't open $out.replaced.gff.list\n";

foreach my $gene ( keys  %best_gff) {
	if ($best_gff{$gene}{gff} =~m/gene/) {
		print OUTD "$best_gff{$gene}{gff}\n";
	 	my @arr=split(/([;=])/, $best_gff{$gene}{gff});
		if ($best_gff{$gene}{gff} =~/replace/) {
		print OUTG "$arr[2]\n";
		}
		else {
		print OUTE "$arr[2]\n";
		}
	}
#foreach my $alt (sort keys %{$gene{$gene}}) {
#	if ($keys =~m/gene/) {
#		print OUTD "$keys\n";
#		my @arr=split(/([;=])/, $keys);
#		print OUTE "$arr[2]\n";		
#	}
}

close (OUTC);
close (OUTD);
close (OUTG);

print "Finished\nBest genes are printed to the file $out.gff.gene\nGenes with no BLAST-hits are printed to file $out.ori.noblast.gff\nA list of genes is printed in file $out.gff.list for use in  perl ~/bin/perl/gff_retrieve_subsets.pl \n";


__END__


# cat $gff $gff2 > $gff.total\n
# $gff.total $out.gff.list

Why did I loose g11257 ?
