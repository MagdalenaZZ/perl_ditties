#!/usr/bin/perl -w
#mz3 script for changing gff from Artemis to zff for augustus

use strict;

my %hash;
my @line;
my @order;
my @kos;

#parse the file

while (<>) {

@line = split (/\s+/, $_);
my $sequence = $line[0];
my $method = $line[1];
my $tag = $line[2];
my $start = $line[3];
my $end = $line[4];
my $sdot = $line[5];
my $strand = $line[6];
my $zero = $line[7];
my $note = $line[8];


if ($tag eq "gene") {
	my @pars = split (/=/, $note); 
	my @kos = split (/;/, $pars[1]);
#	print $kos[0]; #<STDIN>
	push (@order, "$kos[0] $strand");
}


#take only lines with CDS

elsif ($tag eq "exon") {
	my @notes = split (/;/, $note); 
	my @exons = split (/=/, $notes[0]);
	my @kog = split (/ipt./, $notes[1]);
	my ($kog2, $kog3) = split (/=/, $kog[0]);
	push (my @kogg, "$kog3");

# print $notes[1];
# print $kog3;


# define hash

	my $newline = "";

	if ($strand eq "+"){
		$newline =  "$start\t$end\t$notes[1]";
	} elsif ($strand eq "-") {
		$newline = "$end\t$start\t$notes[1]";
	}

 	

	print $newline, "\n";

	push (@{$hash{$kog[1]}}, $newline);
} 
 
}
 
 
 
# parse hash
 
 foreach my $ids (@order)  {
 
 my $id = (split /\s+/, $ids)[0];
 my $strand = (split /\s+/, $ids)[1];
 #	print ">$id\n";
 
 if ($id eq "") {next;}
 if (!defined $hash{$ids}) {next;}
 
 	my $count = scalar (@{$hash{$id}} );
	print "$count\n";
 
 	foreach my $index (0..$count-1) {

 		if ($count==1) {
 
 		print "Esngl\t${$hash{$ids}}[$index]\n";
 		}
 
 		else {
 
 			if ($index==0) {
				if ($strand eq "+") {
					print "Einit\t${$hash{$id}}[$index]\n";
				}
				else  {
					print "Eterm\t${$hash{$id}}[$index]\n";		
				}
 			}
			elsif ($index==($count-1)) {
 				if ($strand eq "+") {
					print "Eterm\t${$hash{$id}}[$index]\n";
				}
				else  {
					print "Einit\t${$hash{$id}}[$index]\n";		
				}
 			}
 
			else {
 				print "Exon\t${$hash{$id}}[$index]\n"; 
 			}
		 }
	 }
}
 
  
 
# print > ID 
 
 
# foreach keys of hash {ID}
 
 
# print value
 
__END__

=POD 
     >sequence-1
    Einit    201    325   Y73E7A.6
    Eterm   2175   2319   Y73E7A.6
    >sequence-2
    Einit    201    462   Y73E7A.7
    Exon    1803   2031   Y73E7A.7
    Exon    2929   3031   Y73E7A.7
    Exon    3467   3624   Y73E7A.7
    Exon    4185   4406   Y73E7A.7
    Eterm   5103   5280   Y73E7A.7

Einit
Exon 
Eterm

Esngl

 

=cut
 
 
 EMU425_training_set.gtf.gff
 
