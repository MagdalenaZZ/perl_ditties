#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado_get_GO.pl input.gff 

Takes a gff-file from Chado and gets the GO-terms. Prints to outfile.


'
}

	my $in = shift;
	my $out = "$in.GO";
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

# print "Hi!\n";

## Basic stats 

my @contigs;
my @methods;
my @tags;
my @coords;
my @keys;
my @split_genes;
my @geness;

my $index = 1;
my %go;

foreach my $line (@in) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

    #print "$key\n";

    if ($key=~/GO/ and $tag=~/polypeptide/) {
        $key=~s/\%3D/ /g;
        $key=~s/\%3B/ /g;
        $key=~s/\%2C/ /g;
        $key=~s/\%2B/ /g;
        $key=~s/\%09/ /g;
        $key=~s/\%28/ /g;
        $key=~s/\%29/ /g;
        $key=~s/\%5H/ /g;
        $key=~s/\%5C/ /g;


        my @arr = split(/;/, $key);
        my $key = shift @arr;

        foreach my $elem (@arr) {
            if ($elem=~/GO/){
                push ( @{$go{$key}} , $elem);
                #print "$arr[0]\t$elem\n";
            }
        }

    }
}


foreach my $gene (keys %go) {
    my $gene2 = $gene;
    $gene2 =~s/ID=//;
    $gene2 =~s/\.1:pep//;

    print OUT "\n$gene2\t";
    foreach my $ele ( @{$go{$gene}} ) {
        #print "$gene\t$ele\n";
        $ele =~s/GO:/ GO:/g;
        my @arr = split(/\s+/, $ele);
        foreach my $el (@arr) {
            if ($el =~/GO:/) {
                print OUT "$el, ";
            }
        }

    }


}

print OUT "\n";



close(OUT);
