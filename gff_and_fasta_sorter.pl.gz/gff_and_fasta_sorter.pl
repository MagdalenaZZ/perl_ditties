#!/usr/local/bin/perl -w

use strict;

unless (@ARGV > 0 ) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl gff_and_fasta_sorter.pl file.fas file.gff fasta-name

Takes a fasta and a gff-file, and merges them, and gives them new coordinates
So that the fasta is just one sequence, and all the gff-features are sorted on it



'


}

my $fas = shift;
my $gff = shift;
my $prefix = shift;


# Read in fasta and make a new merged fasta


system "cat $fas | grep -v '>' > $fas.temp ";

open (IN, "<$fas.temp") or die "Cant find $fas.temp\n" ;
my @in = <IN>;
open (OUT, ">$fas.temp2") or die "Cant find $fas.temp2\n" ;


print OUT ">$prefix\n";
print OUT @in;

#system "/nfs/pathogen005/mz3/mh12/python/fasta2multiline.py $fas.temp2 $fas.m.fas 300";
system "fasta2singleLine.py $fas.temp2 $fas.merged.fas";

system "rm -f $fas.temp $fas.temp2 ";





# Make a faidx
system "samtools faidx $fas";

open (FAI, "<$fas.fai") or die "Cant find $fas.fai\n" ;


# Read in the faidx


my @farr;

while (<FAI>) {
    my @arr = split(/\s+/, $_);
#    my @arh = split(/\:/, $arr[0]);   
     push (@farr, "$arr[0]\t$arr[1]"  );
#    print "$arr[0]\t$arr[1]\n";
}


# Read in gff

my %gash;



open (GFF, "<$gff") or die "Cant find $gff\n" ;

while (<GFF>) {
    chomp $_;

    my @arf = split(/\s+/, $_);
    push ( @{$gash{$arf[0]}}, $_ );
    #print "GFF:$arf[0]:$_\n";

}


# Adjust gff-coords

my $newcord = "0";
my @new_scaf;

my $newO = 1;

open (OG, ">$gff.$prefix.gff") or die "Cant find $gff.$prefix.gff\n" ;

foreach my $line (@farr){

    # print "New scaffold:$line:\n";
    my @ar3 = split(/\s+/, $line);
    # print "FAIDX:$ar3[0]\t$ar3[1]\n";

# If this gene exists on a known scaffold

    if (exists $gash{$ar3[0]}) {

        #print "This scaffold has genes\n"; 
        my $genst;
        my $sst;
        my $new_start;
        my $new_end;
        my $sstart;
        my $send;

        foreach my $elem (  @{$gash{$ar3[0]}} ) {

            #print "$elem\n";
            my @gf = split(/\t/, $elem );



#   if this is a gene on a new scaffold         
            if ( $gf[2]=~/gene/) {
#                print "Line $elem is a gene\n";

                    $gf[0] = $prefix;
                    $gf[3] = $gf[3]+$newO;
                    $gf[4] = $gf[4]+$newO;
                    #my $newgff = join("\t", @gf);
                    #print "$newgff\n";
                    print OG join("\t", @gf) . "\n";

            }

        }
    }

    $newO = $newO + $ar3[1];
    #print "NEW $newO\n";
}


=cut
}
}
else {
#        print "Not exists\n";

}


    $newcord = $newcord + $ar3[1];

#    print "New:$newcord:\n";
}

__END__





# make contigs-file
open (O2, ">$gff.cho") or die "Cant find $gff.cho\n" ;

foreach my $key ( @new_scaf ) {

 my @arl =  split (/-/, $key);

 print O2 "$arl[0]\t$arl[1]\t$arl[2]\n";
# print "$arl[0]\t$arl[1]\t$arl[2]\n";
}


system "perl ~/bin/perl/fasta_subset_from_coords.pl $fas $gff.cho $flank";




exit;









