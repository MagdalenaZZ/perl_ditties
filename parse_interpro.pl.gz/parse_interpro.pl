#!/usr/local/bin/perl -w
# mz3 script for parsing a folder of interpro-results

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/parse_interpro foldername



'
}

my $foldername = shift;


# get a list of all files in the folder

system "ls $foldername > temp";

open (TMP, "<temp") || die "I can't open temp\n";

 my @list = <TMP>;

# print "$list[3]\n";

# open the file
foreach my $elem (@list)  {
chomp $elem;
	if ($elem=~"temp") {
# do nothing
	}
	else {
# read in the file
		open (TMP2, "<$elem") || die "I can't open $elem\n";
		my @lines = <TMP2>;
		foreach my $line (@lines) {
# if you find protein id - get protein name
#   <protein id="g82.t1" length="105" crc64="986350D0D6D8A9ED" >

			if ($line =~"protein id") {
				print "\n";

				my @id = split (/\s+/, $line);
				print "$id[2]\t";
				print "$id[3]\t";
			}
			elsif ($line =~"classification id") {

#	  <classification id="GO:0009987" class_type="GO">
#	    <category>Biological Process</category>
#	    <description>cellular process</description>
#	  </classification>
#	  <match id="G3DSA:3.90.230.10" name="no description" dbname="GENE3D">
#	    <location start="31" end="174" score="5.1e-09" status="T" evidence="Gene3D" />
				my @class = split (/"/, $line);	
				print "$class[1]\t";
			}


# For all interpro id -get info
#	<interpro id="IPR008010" name="Membrane protein,Tapt1/CMV receptor" type="Family">
			elsif ($line =~"interpro id") {
				my @iprid = split (/"/, $line);				
				print "$iprid[1]\t";
				print "\""."$iprid[3]" . "\"". "\t";
				print "$iprid[5]\t";				
			}


			elsif ($line =~"match id") {
	# for all others - get info
	#	  <match id="PF05346" name="DUF747" dbname="PFAM">

				my @matchid = split (/"/, $line);
					if ($matchid[1] =~/^seg$/)	{
					# do nothing
					}
					else {		
					print "$matchid[1]\t";
					print "$matchid[3]\t";				
					print "$matchid[5]\t";
					}

			}
			elsif ($line =~"loction start") {
#  <location start="1" end="105" score="0.0015" status="T" evidence="HMMPfam" />
				my @loc = split (/\s+/, $line);
				print "$loc[3]\t";
			}

		}
		close (TMP2);
	}


}

close (TMP);

	print "\n";





# For all interpro id -get info
#	<interpro id="IPR008010" name="Membrane protein,Tapt1/CMV receptor" type="Family">

	#	for all match id get info

	# if match id = "seg" ignore it
	#	  <match id="seg" name="seg" dbname="SEG">
	#	    <location start="132" end="144" score="NA" status="?" evidence="Seg" />

	# for all others - get info
	#	  <match id="PF05346" name="DUF747" dbname="PFAM">
	#	    <location start="1" end="105" score="0.0015" status="T" evidence="HMMPfam" />

__END__

gene:

/EC_number=""
/polypeptide_domain=""



GO:0003779; aspect=F; actin binding; genedb_misc=From GO association file; genedb_misc=Inferred from Electronic Annotation; feature_property=20090907; genedb_misc=GeneDB_Smansoni; PMID:19435743;
GO:0005509; aspect=F; calcium ion binding; genedb_misc=From GO association file; genedb_misc=Inferred from Electronic Annotation; feature_property=20090907; genedb_misc=GeneDB_Smansoni; PMID:19435743;
GO:0005856; aspect=C; cytoskeleton; genedb_misc=From GO association file; genedb_misc=Inferred from Electronic Annotation; feature_property=20090907; genedb_misc=GeneDB_Smansoni; PMID:19435743;
GO:0005737; aspect=C; cytoplasm; genedb_misc=From GO association file; genedb_misc=Inferred from Electronic Annotation; feature_property=20090907; genedb_misc=GeneDB_Smansoni; PMID:19435743; 


