#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die '
Usage: perl ~/bin/perl/augustus_fix_gff-coords.pl input.gff augustus.aa augustus.codingseq

Sequences as single lines

Example:
perl ~/bin/perl/augustus_fix_gff-coords.pl head.res head.AUGUSTUSnoH.aa head.AUGUSTUSnoH.codingseq


'
}

my $gff = shift;
my $aa = shift;
my $cs = shift;

	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (AA, "<$aa") || die "I can't open $aa\n";
	my @aa = <AA>;
	close (AA);

	open (CS, "<$cs") || die "I can't open $cs\n";
	my @cs = <CS>;
	close (CS);


# Make a hash with gene-name {aa} {cs} {coord} 

my $gene; 
my %hash;

foreach my $line (@aa) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
#		print "Gene:$gene\n";
	}
	else  {
		$line=~s/\*//;
		$hash{$gene}{aa}=$line;
	}

}

foreach my $line (@cs) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
#		print "Gene:$gene\n";
	}
	else  {
		$hash{$gene}{cs}=$line;
	}

}


foreach my $key (keys %hash) {

# print "HASHkey:$key:\n";
# print "Protein $hash{$gene}{aa}\n";
# print "Seq $hash{$gene}{cs}\n";

	open (TEMP, ">temp.fas") || die "I can't open temp.fas\n";
	print TEMP ">$gene\n$hash{$key}{cs}\n";
	close (TEMP);

	print "$key\t";
	system `transeq -sequence temp.fas -outseq temp.pep`;
#	print "$key\t";
	system `fasta2singleLine.py temp.pep temp.sl.pep`;

#print "Trans:" . `transeq $hash{$gene}{cs}` . "\n";
	open (TEMP2, "<temp.sl.pep") || die "I can't open temp.sl.pep\n";
	my @temp2 = <TEMP2>;
	close (TEMP2);
#	print "$temp2[0]$temp2[1]";

#count the bases

	my $b_count = $hash{$key}{cs} =~ tr/[acgtnACGTN]//;
	my $third = ($b_count/3)-1;
	my $a_count = $hash{$key}{aa} =~ tr/[A-Z]//;
#	my $GC_count = $line =~ tr/GgCc//;

#	print "$b_count\t$a_count\t$third\n";
# $hash{$key}{aa}\n$hash{$key}{cs}\n";

	 if ($third==$a_count) {
#		print "$key length correct $third\n";
		if ($hash{$key}{aa}=~/X/) {
			$hash{$key}{coord}="1";   #warn not X
		}
		else {
			$hash{$key}{coord}="0";
		}
	}
	 else {
		if ( $third=~/333333/) {
#		print "$key -1\n";
		$hash{$key}{coord}="-1";
		}
		elsif ($third=~/666666/) {
#		print "$key -2\n";
		$hash{$key}{coord}="-2";
		}
		else {
			print "WARN: $key length not correct $third\n";
		}
	}

# compare the bases 

	chomp $temp2[1];
	$temp2[1]=~s/\*//g;
	$hash{$key}{aa}=~s/\*//g;
	# If the sequences are identical - good
	if ($hash{$key}{aa}=~/$temp2[1]/ and $temp2[1]=~/$hash{$key}{aa}/) {
#		print "ID:$key\n$hash{$key}{aa}\n$temp2[1]\n";	
		$hash{$key}{off}="identical";
	}
	# if the sequence is contained, but probably just stop different
	elsif ($temp2[1]=~/$hash{$key}{aa}/) {
		$hash{$key}{off}="end problem";	
#		print "NOT SAME STOP:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
	}
	# if the sequences are different - bad
	else {
#		print "NOT SAME START:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
		$hash{$key}{off}="start problem";	
		

	}
#	close (TEMP2);

#close (TEMP);


}

########### Fix the gene #################
my $firstCDS=0;
my $lastline="0\t0\t0\t0\t0\t0\t0\t0\t0";
push(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
push(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
my $end=0;
	open (GFF2, ">$gff.corrected") || die "I can't open $gff.corrected\n";



foreach my $line (@gff) {
chomp $line;


my @arr1=split(/\s+/, $line);
my @arr=split(/\s+/, $lastline);


my $lasttag;
my $cds;
# print "LINE:$line\n";

	if ($arr1[2]=~/gene/) {
		#lastline is final CDS
		$lasttag="finalCDS";
	}
	elsif ($arr1[2]=~/mRNA/) {
		#lastline is gene
		$lasttag="gene";
	}
	elsif ($arr1[2]=~/CDS/) {
		#lastline is mRNA and current CDS = firstCDS
		if ($arr[2]=~/mRNA/) {
			$lasttag="mRNA";
			# current line is firstCDS!
			$firstCDS=1;
		}
		#lastline is CDS and current line CDS = middleCDS
		elsif ($arr[2]=~/CDS/ and $firstCDS==1) {
			$lasttag="firstCDS";
			$firstCDS=0;
		}
		elsif ($arr[2]=~/CDS/ and $firstCDS==0) {
			$lasttag="middle";
		}
				
	}
	elsif ($arr1[2]=~/^0$/) {
	}
	else {
		print "ERROR: $line\n";
	}


# Get keys for lastline
my $key=0;

	if ($arr[2]=~/gene/) {
		$arr[8]=~s/ID=//;
		$key=$arr[8];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/mRNA/) {

		my @new =split(/;/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;

	}
	elsif ($arr[2]=~/CDS/) {
		my @new =split(/:/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/0/) {
		# do nothing
	}
	else {
		print "ERROR: $line\n";
	}

	$lastline=$line;

# print "KEY:$key:\n";


	if ($key!~/^0$/ and $key=~/\w+/) {

		if (exists $hash{$key}{coord} and exists $hash{$key}{off}) {
#		print "$key\t$hash{$key}{coord}\t$hash{$key}{off}\n";
		my $coord="$hash{$key}{coord}";	
		my $off="$hash{$key}{off}";
		print "REW:$key\t$coord\t$off:\n";
		
			my $new;
# All well
##			if ( ($coord eq "0") and ($off=~/identical/) ) {
#			if ($key=~m/identical/) {			
#		print "$key all right\n";
				$new = join("\t", @arr);
				print GFF2 "$new\n";	
##			}
# One off in start
			elsif ($hash{$key}{coord}==-1 and $hash{$key}{off}=~/start/ and $lasttag=~/firstCDS||gene||mRNA/ ) {
				if ($arr[2]=~/gene/) {
					print "$key adjust start with -1\n";
				}
			$arr[3]= ($arr[3] + 1);
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# One off in start, but unaffected line
			elsif ($hash{$key}{coord}==-1 and $hash{$key}{off}=~/start/) {
#			print "$key adjust start with -1\n";
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# One off in end
			elsif ($hash{$key}{coord}==-1 and $hash{$key}{off}=~/end/ and $lasttag=~/finalCDS||gene||mRNA/ ) {
				if ($arr[2]=~/gene/) {
					print "$key adjust end with -1\n";
				}
			$arr[4]= ($arr[4] -1 );
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# One off in end, but unaffected line
			elsif ($hash{$key}{coord}==-1 and $hash{$key}{off}=~/end/) {
#			print "$key adjust end with -1\n";
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# Two off in start
			elsif ($hash{$key}{coord}==-2 and $hash{$key}{off}=~/start/ and $lasttag=~/firstCDS||gene||mRNA/) {
				if ($arr[2]=~/gene/) {
					print "$key adjust start with -2\n";
				}
			$arr[3]= ($arr[3] + 2 );
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# Two off in start, but unaffected line
			elsif ($hash{$key}{coord}==-2 and $hash{$key}{off}=~/start/) {
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}

# Two off in end
			elsif ($hash{$key}{coord}==-2 and $hash{$key}{off}=~/end/ and $lasttag=~/finalCDS||gene||mRNA/ ) {
				if ($arr[2]=~/gene/) {
					print "$key adjust end with -2\n";
				}
			$arr[4]= ($arr[4] - 2);
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}
# Two off in end, but unaffected line
			elsif ($hash{$key}{coord}==-2 and $hash{$key}{off}=~/end/ ) {
			$new = join("\t", @arr);
			print GFF2 "$new\n";
			}

############ negativ values ################################



# catch exceptions #######################

			else {
				if ($key==0) {
				}
				elsif (exists $hash{$key}{coord}) {
				print "WEIRD:$key\t$hash{$key}{coord}\t$hash{$key}{off}\n";
				}
				else {
				print "WEIRD:$key\n";
				}

			}

########################################

		}
		else {
		print "WARN:This gene does not have sequence:$key\n";
		}
	}
	else {
		if ($end=~/1/) {
			last;
		}
		$end=1;
	}




}


	close (GFF2);






__END__

=pod



KEY:pathogen_EMU_contig_2012.g1.t1:
WEIRD:pathogen_EMU_contig_2012.g1.t1		
KEY:pathogen_EMU_contig_2012.g1.t1:
WEIRD:pathogen_EMU_contig_2012.g1.t1		
KEY:pathogen_EMU_contig_2012.g1.t1:

HASHkey:pathogen_EMU_contig_33435.g51noH.t1:
Translate nucleic acid sequences
HASHkey:pathogen_EMU_contig_2574.g11noH.t1:
Translate nucleic acid sequences
HASHkey:pathogen_EMU_contig_21923.g40noH.t1:
Translate nucleic acid sequences
HASHkey:pathogen_EMU_contig_2472.g4noH.t1:
Translate nucleic acid sequences
HASHkey:pathogen_EMU_contig_2644.g24noH.t1:
Translate nucleic acid sequences





	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";

# Get coordinates 

foreach my $line (@in) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

if (($tag=~/CDS/) || ($tag=~/exon/) ) {
push (@coords,  "$start\t$end\t$strand\t$contig\t$key" ); 
}
}

############### check that all genes are in triplets ####################
my %codon;

# Make a hash with the gene name as key value, and all CDS positions as an array
# coords only contains CDSs

foreach my $line (@coords) {
chomp $line;
#print "Line:$line:\n";
my @arr=split(/([:=\t])/, $line);
#$arr[10] =~s/://;
#print "Arr1\t$arr[10]\n";
#print "Arr0\t$arr[0]\n";
#print "Arr2\t$arr[2]\n";
my $sum= ($arr[2]-$arr[0]+1);
#print "Sum\t$sum\n";

$codon{$arr[10]}+=$sum;
#print "SUM:key $arr[10] value $codon{$arr[10]}\n";
}

# Work out the replacement

foreach my $key (keys %codon) {
	my $third = ($codon{$key}/3);
#	print "$key\t$codon{$key}\t$third\n";
	if ($third=~/333333/) {
		$codon{$key}="-1";
#	print "Warning: Gene $key has $codon{$key} bases, resulting in incomplete codon $third which needs to be adjusted by -1\n";
	}
	elsif ($third=~/666666/) {
		$codon{$key}="-2";
#	print "Warning: Gene $key has $codon{$key} bases, resulting in incomplete codon $third which needs to be adjusted by -2\n";
	}
	else {
		$codon{$key}="0";
	}	
}

# get the DNA sequence from coordinates


# Parse the original gff, and replace the co-ordinates with new coordinates as appropriate for genes mRNAs and CDSs
	open (IN3,"<$in");
	print "Opening $in\n";




close (IN3);