#!/usr/bin/perl -w

use strict;

unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

    die '


Usage: file_splitter.pl <line-number> file


This program splits a file into smaller files of any number of lines you prefer
    ' . "\n";
}



my $rno = shift;
my $fas = shift;
my @files;



     print "Im splitting file $fas into $rno line files\n";
    my $index = 0;
    my $i = 1;
    my $hk = 0;


    open (FA, "<$fas") || die 'Cant find file $fas';

    my @fas = '';

    open (FAS, ">$fas.$i");

    while ( <FA> ) {
        #print "$_";

        if ( $index < $rno   ) {
            print FAS "$_";
            #print "I'm adding to $fas.$i\t$_\n";
            $index++;
        }
        else {

            # print last and close old file

            close (FAS);
            push ( @files, "$fas.$i");

            # reset indexes and open new file
            $index = 0;
            $i++;
            open (FAS, ">$fas.$i");
            print FAS "$_";
            $index++;
        }

    }

    close (FAS);
    push ( @files, "$fas.$i");
    my $len = scalar(@files);

    close (FA);

    $index = 0;
    $i = 1;

    @fas = '';


    exit;






exit;


