#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: go_sql_queries.pl list

Give a list of GO-terms, like "nucleus" an retrieve a mySQL query for that.
Log into mysql -hmysql.ebi.ac.uk -ugo_select -pamigo -P4085 go_latest 
paste the query, and then

exit;


'
}

	my $in = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);


foreach my $line (@in) {
chomp $line;

print "
\n
SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='$line' AND distance <> 0 ;\n";

}



__END__



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='metabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='oxidation reduction' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='lipid catabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='aromatic amino acid family catabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='peptide cross-linking' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='methionine biosynthetic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='steroid biosynthetic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='nucleobase biosynthetic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='sphingolipid metabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='sterol metabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='cellular lipid catabolic process' AND distance <> 0 ;



SELECT DISTINCT descendant.acc, descendant.name, descendant.term_type FROM term
 INNER JOIN graph_path ON (term.id=graph_path.term1_id)
 INNER JOIN term AS descendant ON (descendant.id=graph_path.term2_id)
WHERE term.name='glycerol metabolic process' AND distance <> 0 ;




