#!/usr/local/bin/perl -w
# mz3 script for splitting a fasta-file to several chunks

use strict;

unless (@ARGV > 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: fasta_chunker.pl <input.fa> <prefix> <int> \'blastargs\'
prefix = prefix for the output filename
<int>  is the approximate number of bytes you want the file to be 

Example: 
perl ~/bin/perl/blast_fasta_chunker.pl test.fa test 100000 \'blastx -db /lustre/scratch103/sanger/mz3/EMU_BLAST/EMU_predictions.rightname.fas -outfmt "6 std frames" \'

'
}

### this is the splitter-part of the script ####

my $in = $ARGV[0];
my $out =$ARGV[1] ;
my $size = $ARGV[2];
my $blastargs = $ARGV[3];

#print "$blastargs\n";

#__END__

open (IN, "<$in");
#my @in = <IN>;
my @files;
#my $length = scalar(@in);

#my $targetsize = 50*1024*1024;
my $targetsize = $size;
my $fileprefix = $out;
my $outfile = 0;
my $outsize = 0;
my $outfh;
my $temp='';

local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
#  print "LINE:$line:\n"; 
  next unless $line;
  # discard initial empty chunk  
#  if($line =~ /^\$\$$/ || $outfile == 0){
  if($line =~m/\_/ || $outfile == 0){
        $outsize += length($temp);
#        print "SIZE:$outsize:\n";
        if ( $outfile == 0 || ($outsize - $targetsize) > 0)  { 
              ++$outfile; 
              if($outfh) {close($outfh);}
              open ($outfh, '>', "$fileprefix\_$outfile\.fa"); 
              push (@files,  "$fileprefix\_$outfile\.fa" );
#              print "$outfh\t$fileprefix\_$outfile\n";
              $outsize = 0;
        }
        $temp='';
    }
  $temp = $temp.$line;
  print $outfh "\>$line";  
}


#	open (OUT, ">$file.sh") || die "I can't open $file.sh\n";


open FILE, ">$out.awesome.sh" or die $!;
print FILE "$blastargs -query \$1 -out \$1.blast\n";
close FILE;

foreach my $file (@files) {
my $format = "summary";
#my $cmd = qq{~mh12/git/python3/bsub.py 6 $file '$blastargs -query $file -out $file.blast'};
#print OUT "$cmd\n";
#system_call($cmd);
#system "team133-bsub.pl normal 5 $file.o $file.e $file  $blastargs -query $file -out $file.blast";
system "bsub.py 20 $file sh $out.awesome.sh $file";
}



# close (OUT);

__END__

sub system_call {
    my $cmd  = shift;
    if (system($cmd)) {
        print STDERR "Error in system call:\n$cmd\n";
        exit(1);
    }
}


