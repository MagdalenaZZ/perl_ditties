#!/usr/bin/perl -w
use strict;
use Data::Dumper;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: 

mz script for choosing the first transcript

'
}

	my $gff = shift;

	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (OUT2, ">$gff.others.out") || die "I can't open $gff.others.out\n";

my %genes;
foreach my $line (@gff) {
chomp $line;

my @arr =split(/\s+/, $line);

$arr[8] =~s/ID=//;
my @arr2 = split (/\./,$arr[8] );
my $gene = "$arr2[0]\.$arr2[1]";

# print "$gene\n";
# print "Line:$line\n";
if ($genes{$gene}) {
print OUT2 "$line\n";
}
#$hash{ $key } = $value; 
else {
$genes{ $gene } = "$line"; 
}

#$genes{"$gene"};

# {"gff"} = "$line";

#	$gene{$root}{$alt}{"gff"} = $line;
}


	open (OUT, ">$gff.out") || die "I can't open $gff.out\n";
#	my @gff = <GFF>;


foreach my $gene (%genes) {

if ($gene !~m/AUGUSTUS/) {
print "Key:$gene\n";
print "GFF:$genes{$gene}\n";
print OUT "$genes{$gene}\n";
}

}

	close (OUT);	
	close (OUT2);