#!/usr/bin/perl -w

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

    die '


Usage: choose_columns.pl list file.tab

Takes a list of column names

Returns one separate file for each column name together with first column 

' . "\n";
}


my $list = shift;
my $in = shift;

open (LIST, "<$list")|| die;

my %list;

# 
while (<LIST>) {
chomp;

    if ($_=~/\w+/) {
        $list{$_}=1;
        #print ":$_:\n";
    }
}


open (IN, "<$in")|| die;
my @in = <IN>;

my $first = shift @in;

my @headers = split("\t", $first);


my $i = 1;
foreach my $col (@headers) {

    #print "$col\n";
    # This column exists
    if (exists $list{$col}) {
    
        open (OUT, ">$col.chosen")|| die;


        foreach my $elem (@in) {
            my @a = split("\t", $elem);
            print OUT "$a[0]\t$a[($i-1)]\n";
        }

        close (OUT);


    }

$i++;

}








