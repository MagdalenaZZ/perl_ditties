#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  khmer_wrapper.pl  kmer reads_1 reads_2 

This script produces 



';

}



my $kmer = shift;
my $file1 = shift;
my $file2 = shift;


unless ($kmer=~/^\d+$/) {
    die 'kmer have to be a digit';
}


# if file is .gz, unzip here

my $zip = 0;
my $base;
my $f1;
my $f2;

# unzip GZIPPED files


if ($file1=~/\.gz$/) {
    # unzip
    $zip = 1;
    my @arr = split(/\//,$file1);
    $arr[-1]=~s/\.gz//;
    print "gunzip -c $file1 > $arr[-1] \n";
    $f1 = $arr[-1] ;

    my @arr2 = split(/\//,$file2);
    $arr2[-1]=~s/\.gz//;
    print "gunzip -c $file2 > $arr2[-1] \n";
    $f2 = $arr2[-1]; 


    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;

    #print "\n$base\n";

}

elsif ($file1=~/\.fastq$/) {
    # nothing
    my @arr = split(/\//,$file1);
    my @arr2 = split(/\//,$file2);
    
    $base = $arr[-1];
    $base =~s/\_1\.//;
    $base =~s/fastq//;
    $base =~s/fasta//;
    $base =~s/\.\././g;

}




# make seecer input and bsub
#
open (SH, ">$base\_$kmer.seecer.sh");


if (-d "$base\_$kmer") {
    die  "\nFolder $base\_$kmer already exists, pelase try different files or different kmer, or delete this folder\n\n";
}
else {
    mkdir "$base\_$kmer";
}

print "\n\n";


if ($zip == 1) {
    print SH "bsub.py -q yesterday 30 $base\_$kmer\_1  bash ~/bin/SEECER-0.1.2/SEECER/bin/my_run_seecer.sh -t $base\_$kmer -k $kmer $f1 $f2\n";
}

elsif ($zip == 0) {
    print SH "bsub.py -q yesterday 30 $base\_$kmer\_1 bash ~/bin/SEECER-0.1.2/SEECER/bin/my_run_seecer.sh -t $base\_$kmer -k $kmer $file1 $file2 \n";
}



# system "perl ~mz3/bin/perl/khmer_wrapper_part2.pl $kmer $file1\_corrected.fa $file2\_corrected.fa  ";

open (OUT3, ">$base\_$kmer.khmer.sh");

print OUT3 "# preprocessing for khmer\n";

print OUT3 "rm -f $base\_1.fastq_N $base\_1.fastq_N \n";


print "Lets do this....\n";

=pod

#print "$file1\t$file2\n";

    open (IN, "<$file1");
    unless (-e "$base\_1.fasta" ) {
        open (OUT, ">$base\_1.fasta");
    }
print "Converting file $file1\n";

while (<IN>) {
    #print "IN\n";
    my @arr1 = split(/\s+/, $_);
    print OUT "$arr1[0]\n";

}

print "Converting file $file2\n";

open (IN2, "<$file2");
unless (-e "$base\_2.fasta" ) {
    open (OUT2, ">$base\_2.fasta");
}

while (<IN2>) {
    my @arr2 = split(/\s+/, $_);
    print OUT2 "$arr2[0]\n";

}
=cut





print OUT3  "~mh12/git/python/fastn_shuffle.py   $base\_1.fastq_corrected.fa   $base\_2.fastq_corrected.fa   $base.fasta\n";

print OUT3 "rm -f $base\_1.fastq_corrected.fa $base\_1.fastq_corrected.fa \n";



# do kmehr

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py  -C 20 -k $kmer -N 4 -x 2e9 --paired   $base.fasta  \n";

print OUT3 "/nfs/users/nfs_m/mz3/bin/screed/khmer/sandbox/strip-and-split-for-assembly.py $base\_corrected.fa.keep \n";


print SH "bsub.py --dep=\"$base\_$kmer\_1\" -q normal 10 $base\_$kmer\_2 perl ~mz3/bin/perl/khmer_wrapper_part2.pl $kmer $file1 $file2 \n";


print SH "bsub.py --dep=\"$base\_$kmer\_2\" -q normal 10 $base\_$kmer\_3 sh $base\_$kmer.khmer.sh\n";


print "\n";


close(OUT);

close(OUT2);

close(OUT3);

close(SH);














__END__




# once finished, delete unzipped files

=pod

sleep(120);


for (my $i=0; $i < 200;) {
        

    if (-e " $base\_$kmer.o" ) {
   	    open (IN, "<$base\_$kmer.o") || die "I can't open $base\_$kmer.o\n"; 
        while (<IN>) {
            if ($_=~/LSBATCH/){
                $i = 300;
            }
        }
        $i ++;
        print "running ...\n";
        sleep (120);


    }
    else {
        print "waiting ...\n";
        sleep (120);
    }

}



# remove redundant files

if ($zip == 1) {
    print "rm -fr $f1 $f2 $f1\_N $f2\_N $base\_$kmer  \n";
}

elsif ($zip == 0) {
    print "rm -fr $file1\_N $file2\_N $base\_$kmer  \n";
}

=cut
# /lustre/scratch108/parasites/mz3/Transcriptome_assembly/Dugesia/SGA/Whole_pcs4_polyA
#
__END__


print "Lets do this....\n";

    open (IN, "<$fas\_corrected.fa");
    open (IN2, "<$fas2\_corrected.fa");
    open (OUT, ">$fas\_corrected.fas");
    open (OUT2, ">$fas2\_corrected.fas");

while (<IN>) {
    my @arr = split(/\s+/, $_);
    print OUT "$arr[0]\n";

}

while (<IN2>) {
    my @arr = split(/\s+/, $_);
    print OUT2 "$arr[0]\n";

}


print "";




# do kmehr

print "bsub.py --dep=\"$base\_$kmer\_1\" -q small 5 $base\_$kmer\_2 /nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py  -C 20 -k $kmer -N 4 -x 2e9 --paired $base\_corrected.fa  \n";

print "bsub.py --dep=\"$base\_$kmer\_2\" -q small 5 $base\_$kmer\_3 /nfs/users/nfs_m/mz3/bin/screed/khmer/sandbox/strip-and-split-for-assembly.py $base\_corrected.fa.keep  \n";

print "\n";







__END__

-N 4 always

-x 4e9 for up to a billion mRNAseq reads from any organism. Past that, increase it.

Higher x is higher memory usage, and higher accuracy


1 SGA corrected lane /nfs/users/nfs_m/mz3/bin/screed/khmer/scripts/normalize-by-median.py --ksize 31 -N 4 -x 2e9 -C 20 --paired DjA2_PZQ_294733_1hr.9234_8#1.CORR.interleave.fastq


    CPU time   :    631.20 sec.
    Max Memory :      7650 MB
    Max Swap   :      7737 MB

    Max Processes  :         3
    Max Threads    :         4



/root/khmer/scripts/normalize-by-median.py  -C 20 -k 20 -N 4 -x 2e9 --savehash ecoli_ref.kh /data/ecoli_ref.fq.gz

###########
# Next, trim low-abundance k-mers:

 /root/khmer/scripts/filter-abund.py ecoli_ref.kh ecoli_ref.fq.gz.keep
#############


For Oases, you will want to split these into paired and orphan reads files:

% python /root/khmer/sandbox/strip-and-split-for-assembly.py schizo-50m.fq.gz.keep

 


