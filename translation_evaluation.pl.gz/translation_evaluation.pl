#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl translation_evaluation.pl  query.fasta  db.fasta  blast-output

Do a BLASTsearch, and then this program will count up the amount of similarity between those files.

It will output some key statistics, and a table of all the best hits


';

}


# catch the 3 input arguments in variables


my $query = shift;
my $db =  shift;
my $blast = shift;


# Make faidx files from the $query and the $db by system call to "samtools faidx"

        ### ADD CODE ####


# Read in the output from faidx, and store it in two hashes

my %q_lens;  #  $q_lens{ ID } = length

my %db_lens;  #  $db_lens{ ID } = length

        ### ADD CODE ####
        
#open file

foreach my $line (@input) {
        # go through all lines, and pick your values
        $q_lens{ $id } = lenght; # store in the hash

}



# Make a blast hash
 my %blast;

# Parse the blast-output

    # make sure you only get the best hit and store in the hash


# Make a results hash
 my %res;


# Go through the results hash, and evaluate if your hit is 1 hit or several
# this is the bit where you do all actual calculations

foreach my $key (keys %blast) {
    # calculate the values you want in the result

        ### ADD CODE ####


    if ( one hit ) {

        # this is how you retrieve the lengths from the hases you declared earlier
        my $b =  $q_lens{$key};
        my $c =  $db_lens{$key};

        ### ADD CODE ####
    }
     
    elsif ( several hits ) {
        ### ADD CODE ####

    }

    else {
        # catch exceptions
        print "Warning: this line is not right\n";
    }


}


# report output 1: how many query sequences have no hit?

# how many keys are in %q_lens?
# how many keys are in  %res?

# report output 2: write a table containing "qname \t hitlength \t length of query and db seq \t match-score \n"
#
foreach my $key (keys %res) {

    # print result
        ### ADD CODE ####

}






