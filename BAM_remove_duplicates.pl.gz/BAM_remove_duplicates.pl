#!/usr/bin/perl -w

use strict;



if (@ARGV < 3) {
	print "\n\nUsage:  BAM_remove_duplicates.pl SAM-file.sam genome.fasta overlap<INT> depth<INT>length<INT>  \n\n " ;
    	print " mz3 script for removing non-tiling duplicates from a SAM file \n\n";
	print '

	overlap - the maximum distance between non-tiling duplicates, ie 10
	depth - the minimum average read depth of a tile to discard, ie 10
	length - the maximum length of a tile to discard, ie 100 bp (set close to read length, or just above)
	

	';
	exit ;
}

my $in = shift;
my $fasta = shift;
my $ovl=shift;
my $dep=shift;
my $len=shift;



# run picard
print "Running picard with the following parameters:\n picard  MarkDuplicates I=$in O=$in.markdup.bam M=$in.met VALIDATION_STRINGENCY=SILENT MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=1000 REMOVE_DUPLICATES=false\n\n";
#system "picard  MarkDuplicates I=$in O=$in.markdup.bam M=$in.met VALIDATION_STRINGENCY=SILENT MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=1000 REMOVE_DUPLICATES=false";


# get a file with only duplicates
print "Running samtools to retrieve duplicates:\nsamtools view -h -b -f 0x400 $in.markdup.bam > $in.markdup.duplicates.bam\n ";
#system "samtools view -b -f 0x400 $in.markdup.bam > $in.markdup.duplicates.bam";

print "samtools sort $in.markdup.duplicates.bam $in.markdup.duplicates.sorted\n\n";
#system "samtools sort $in.markdup.duplicates.bam $in.markdup.duplicates.sorted";


# get a file with only uniques
print "Running samtools to retrieve unique reads:\nsamtools view -h -b -F 0x400 $in.markdup.bam > $in.markdup.unique.bam\n\n";
#system "samtools view -b -F 0x400 $in.markdup.bam > $in.markdup.unique.bam";



# make genome position file
print "samtools faidx $fasta\n";
print "cat $fasta.fai | cut -f1,2 > $fasta.genome\n";


__END__



# identify postition of duplicates

# get overlaps, filter small duplicate heaps (under $dep)
print "genomeCoverageBed -bg -ibam $in.markdup.duplicates.sorted.bam -g $fasta.genome | awk '$4>$dep {print $0}' > $in.bg \n";

# get tiles of overlaps, also taking into account length of the length of the heap, and depth
print "mergeBed -d $ovl  -c 4 -o median -i BZ2small.markdup.duplicates.sorted.bam.bg  | awk '{print $0"\t"$3-$2}' | awk '$4>$dep  {print $0}' | awk '$5<$len {print $0}' \n";

# save duplicates which are not in valid high expression regions

print "";



=pod
open ( IN, "<$in.markdup.duplicates.sam" ) || die "File  $in.markdup.duplicates.sam was not created \n";

while (<IN>) {
}
=cut

#| cut -f3,4,6 | uniq -c > $in.markdup.duplicates.tmp " ;



## look for  high-frequency duplicates



## look for clusters of duplicates 

# make a BED-format output

# use BEDtools merge

# save duplicates that are in groups using BEDtools







