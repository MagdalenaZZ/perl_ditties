#!/usr/bin/perl -w

use strict;


unless (@ARGV==2) {
        &USAGE;
}

sub USAGE {

die '


Usage: blast2go_EC2tab.pl infile.annot  outfile

Do Blast2GO and then export as annot_file




'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";



foreach my $line (@in) {
	chomp $line;
	my @arr=split(/\t/,$line);
	if ($arr[1]=~/^EC:[0-9]+\.[0-9]+/) {
#		my @arr=split(/\t/,$line);
		my $arr12 = "\/EC_number=\"$arr[1]\"";
		$arr[1]=$arr12;
		my $line=join("\t",@arr);
#                  /EC_number="3.5.3.11" 
		print OUT "$line\n";
	}
	else {
		print "Unparsed line: $line\n";
	}
}








	close (OUT);