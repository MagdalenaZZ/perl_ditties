#!/usr/local/bin/perl -w

use strict;
use Text::ParseWords;

unless (@ARGV==3) {
        &USAGE;
}

sub USAGE {

die 'Usage: hmmer_chooser.pl in eval out

Give a hmmer-searh output-file 
The program will report the best hit from several different models, if their evalue is less than eval


'
}

	my $in = shift;
	my $eval = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";


my %genes;
my %res;
my $index = 1;
my %gff;

foreach my $line (@input) {

    unless ($line =~/#/) {
my @var	= split(/\s+/, $line);

my $gene= $var[0];
my $acc = $var[1];
my $model = $var[2];
my $acc2 = $var[3];
my $full_eval = $var[6];
my $full_score = $var[5];
my $full_bias = $var[6];
my $best_eval = $var[7];
my $best_score = $var[8];
my $best_bias = $var[9];
my $dom_exp = $var[10];
my $dom_reg = $var[11];
my $dom_clu = $var[12];
my $dom_ov = $var[13];
my $dom_env = $var[14];
my $dom_dom = $var[15];
my $dom_rep = $var[16];
my $dom_inc = $var[17];
my $dom_desc = $var[18];

#print "Eval $var[6]\n";

$genes{$gene}{$full_eval}= $line;

push (@{$gff{$gene}} , "$gene\thmm\tCDS\t$dom_inc\t$dom_desc\t$dom_reg\t\+\t\.\t$acc2");

$index++;
    }

}



foreach my $gen (keys %genes) {
        my $max = $eval;

    foreach my $keys (sort keys %{$genes{$gen}}) {
#=pod
#    print "$gen\t$keys\t$max\n";        
        if ($keys < $max) {
#            print "$gen\tThis result is better $keys < $max\n";
            $max = $keys;
        }
        else {
#            print "$gen\tThis result is worse $keys > $max\n";
        }
#=cut
    }

    my $best_hit =  $genes{$gen}{$max};
    $res{$gen} = $best_hit;

}



print OUT "Gene\tModel\tEval\n";


foreach my $gene2 (sort keys %genes) {

    my @var	= split(/\s+/, $res{$gene2});

my $gene= $var[0];
my $acc = $var[1];
my $model = $var[3];
my $acc2 = $var[3];
my $full_eval = $var[6];
my $full_score = $var[5];
my $full_bias = $var[6];
my $best_eval = $var[7];
my $best_score = $var[8];
my $best_bias = $var[9];
my $dom_exp = $var[10];
my $dom_reg = $var[11];
my $dom_clu = $var[12];
my $dom_ov = $var[13];
my $dom_env = $var[14];
my $dom_dom = $var[15];
my $dom_rep = $var[16];
my $dom_inc = $var[17];
my $dom_desc = $var[18];

print OUT "$gene\t$model\t$full_eval\n";

open (OUT2, ">>$in.$model.hits") || die "I can't open $in.$model.hits\n";
print OUT2 "$gene\n";
close (OUT2);

}


close (OUT);


# fix the gff-file
#
#
open (OUT3, ">>$in.best.gff") || die "I can't open $in.best.gff\n";

#my @gffs = sort(@gff);
my %novl;
my %ovl;
my %uniq;

foreach my $gen (keys %gff) {

    my @arr = @{$gff{$gen}};


my @rows = map { chomp; [split /[,\s]+/, $_] } @arr; #read each row into an array
my @sorted = sort { $a->[5] <=> $b->[5] } @rows; # sort the rows (numerically) by second column

my @sort;

for (@sorted) {
#  print join("\t", @$_) . "\n"; # print them out as CSV
  push (@sort,  join("\t", @$_)  );
}


#print "First\t$sort[0]\n";

        my $lin = shift (@sort);
        push (@{$novl{$gen}}, $lin);

#print "First\t$sort[0]\n";

# split the lines and choose the best one not overlapping    
    foreach my $elem (@sort) {
        my @arr2 = split(/\t/, $elem);
        my $gene = $arr2[0];
        my $hmm =  $arr2[1];
        my $cds =  $arr2[2];
        my $startx =  $arr2[3];
        my $endx =  $arr2[4];
        my $score =  $arr2[5];
        my $strand =  $arr2[6];
        my $dot =  $arr2[7];
        my $info =  $arr2[8];

#        my $start = 0;
#        my $end = 0;
#        print "$elem\t$start1\t$end1\n";
            
#=pod

        my $new_elem= $elem;

        my @best0 =  split(/\t/,  @{$novl{$gene}}[0]);
        my $start = $best0[3];
        my $end = $best0[4];

        if (exists @{$novl{$gene}}[1] ) {
        my @best1 =  split(/\t/,  @{$novl{$gene}}[1]);
            my $start1 = $best1[3];
            my $end1  = $best1[4];
        }

        my $start1;
        my $end1;
        my $start2;
        my $end2;
        my $start3;
        my $end3;
        my $start4;
        my $end4;

=pod        
        foreach my $best (@{$novl{$gene}}) {
            my @best = split(/\t/, $best);
            $start = $best[3];
            $end = $best[4];
        }
=cut

            if ($start >= $startx and $start >= $endx ) {         
                # it is before;
#                push (@{$novl{$gene}}, $elem);
              $uniq{$elem} = 1;                
            }
            elsif ($endx >= $end and $startx >= $end ) {
                # it is after;
#                push (@{$novl{$gene}}, $elem);
              $uniq{$elem} = 1;
            }
            else {
                # it is overlapping;
                $new_elem = "$elem\to";
                $ovl{$elem} = 1;

            }
        

#        print "OLD:$elem\nNEW:$new_elem\n\n";

#=cut
    }

}


# print output

=pod
foreach my $genx (keys %novl) {
    my $i = 1;
    foreach my $ele ( @{$novl{$genx}} ) {
        print "$ele\_$i\n";
        $i++;
    }
}
=cut

my @this_not_that;
foreach (keys %uniq) {
    push(@this_not_that, $_) unless exists $ovl{$_};
}

my @uniqs = sort (@this_not_that);
foreach my $ele (@uniqs){
    print "UNIQ: $ele\n";
}

close (OUT3);

print "Finished\n";


