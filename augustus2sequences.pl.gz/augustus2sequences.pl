#!/usr/bin/perl -w
# mz3 script for taking protein and nucleotide sequences from augustus output

use strict;


my($file) = @ARGV;

open(FILE, "<$file") or die "$!";

unless (@ARGV == 1) {
        &USAGE;
}

# cat 2903aug.EMUaug11.aug.gff | tr -d # | grep -v Delete | grep -v intron | grep -v exon | grep -v : | grep -v hint | grep -v - | grep -v the | grep -v none | grep -v CDS | grep -v number | grep -v AUGUSTUS > cleaned_2903aug.EMUaug11.aug.gff

close (FILE);

system `cat $file | grep -v Delete | grep -v intron | grep -v exon | grep -v : | grep -v hint | grep -v - | grep -v the | grep -v none | grep -v CDS | grep -v number | grep -v AUGUSTUS | grep -v alignments | grep -v format | sed s/#//g > cleaned_$file`;


open(FILE2, "<cleaned_$file") or die "$!";

my @results = '';

my @file= <FILE2>;
close (FILE2);

foreach my $line (@file) {
	if ($line =~ /^\n/) {
#		print "blank line: $line";<STDIN>;
	}
	else {
#		print "not blank line: $line";<STDIN>;
		push (@results, $line) ;
	}

}
open(FILE3, ">supercleaned_$file") or die "$!";

print FILE3 @results;


close (FILE2);
close (FILE3);



sub USAGE {

die 'Usage: perl  augustus2sequences.pl <augustus-gtf-file> > outputname





'
}

__END__
