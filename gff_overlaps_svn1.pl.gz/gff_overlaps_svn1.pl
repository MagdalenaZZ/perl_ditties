#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_overlaps.pl input.gff detailed_output

Takes a gff-file and finds overlapping features

'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUTO, ">$out.overlapping") || die "I can't open $out.overlapping\n";

 print "Hi!\n";

 ######### sort the array  #########
 
    
# my @arr = @{$gff{$gen}};
my @rows = map { chomp; [split /[,\s]+/, $_] } @in; #read each row into an array
my @sorted = sort { $a->[0] cmp $b->[0] || $a->[3] <=> $b->[3] || $a->[4] <=> $b->[4]  } @rows; # sort the rows (numerically) by second column
# my @sorted = sort { $a->[0] cmp $b->[0] || $a->[8] cmp $b->[8]  || $a->[3] <=> $b->[3] } @rows; # sort the rows (numerically) by second column


my @sort;

for (@sorted) {
#  print join("\t", @$_) . "\n"; # print them out as CSV
  push (@sort,  join("\t", @$_)  );
}


 
 #############################

my $lastline = "0\t0\t0\t0\t0\t0\t0\t0\t0";

 foreach my $line (@sort) {
chomp $line;
my @line = split(/\s+/, $line);


	my $contig = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

my @last = split(/\s+/, $lastline);

	my $lcontig = $last[0];
	my $lmethod = $last[1];
	my $ltag = $last[2];
	my $lstart = $last[3];
	my $lend = $last[4];
	my $lscore = $last[5];
	my $lstrand = $last[6];
	my $ldot = $last[7];
	my $lkey = $last[8];



    if ( $contig =~/$lcontig/ ) {
        if ($lstart < $start and $lend < $start) {
            # right !
#            print "RIGHT:\n$lastline\n$line\n\n";
            print OUT "$line;comment=right\n";
        }
        elsif ($lstart == $start and $lend == $end ) {
            # identical
#            print "IDENTICAL:\n$lastline\n$line\n\n";
            print OUTO "$line;comment=identical\n";
        }
        elsif ( $key =~/$lkey/){
            if ($start == $lstart || $end == $lend ) {
                my $len = $end - $start;
                my $llen = $lend - $lstart;
                if ($len > $llen) {
#                    print "BEST: $line\n";
                    print OUTO "$line;comment=longest\n";
                }
                else {
#                    print "BEST: $line\n";
                    print OUTO "$line;comment=shortest\n";
                    # lastline is longer
                }

            }
            else {
                # test if they are overlapping, or not
                if ( $lend >= $start) {
                    print OUTO "$line;comment=overlapping_of_same_key\n";
                }
                else {
 #                print "Same key, several exons:\n$lastline\n$line\n\n";
                    print OUT "$line;comment=several_exons\n";
                }
            }

        }
        elsif ($strand =~/\Q$lstrand\E/) {
#           print "SAME strand:\n$lastline\n$line\n\n";
           print OUTO "$line;comment=same_strand\n";
        }
=pod
        elsif ($start >= $lstart and $end >= $lend ) {


            # overlapping to the right
            if ($key eq $lkey) {
#                print "Same key:\n$lastline\n$line\n\n";
    #            print OUTO "$line;identical\n";
                my $len = $end - $start;
                my $llen = $lend - $lstart;
                if ($len > $llen) {
                    print OUT "$line\n";
                }
                else {
                    # lastline is longer
                }

            }
            elsif ($start > $lstart and $end > $lend ) {
                # regular overlap
                if ($strand =~/\Q$lstrand\E/) {
                    # genes are close, and on same strand
#                    print "SAME strand:\n$lastline\n$line\n\n";
                    print OUTO "$line;overlapping_on_same_strand,_but_different_genes\n";

                }
                else {
                    # genes are close, but on different strands
#                    print "DIFF strand:\n$lastline\n$line\n\n";
                    print OUT "$line;overlapping _but_on_different_strands\n";

                }
            }
            else {
                # diffrent
#                print "Overlapping :\n$lastline\n$line\n\n";
                    # genes are close, and on same strand
                if ($strand =~/\Q$lstrand\E/) {
#                    print "SAME strand:\n$lastline\n$line\n\n";
                    print OUTO "$line;overlapping_on_same_strand,_but_different_genes2\n";

                }
                else {
                    # genes are close, but on different strands
#                    print "DIFF strand:\n$lastline\n$line\n\n";
                    print OUT "$line;overlapping _but_on_different_strands\n";
                }

            }
        }
        elsif ($lstart >= $start and $lend >= $end ) {
            # overlapping first is longer
#            print "OVL is longer:\n$lastline\n$line\n\n";
            if ($key eq $lkey) {
#                print "Same key:\n$lastline\n$line\n\n";
    #            print OUTO "$line;identical\n";
                my $len = $end - $start;
                my $llen = $lend - $lstart;
                if ($len > $llen) {
                    print OUT "$line\n";
                }
                else {
                    # lastline is longer
                }

            }
            else {
#                print "Diffrent key:\n$lastline\n$line\n\n";
            }
        }
        elsif ($start >= $lstart and $lend >= $end ) {
#            print "OVL is longer2:\n$lastline\n$line\n\n";

            # overlapping second is longer
            if ($key eq $lkey) {
#                print "Same key2:\n$lastline\n$line\n\n";
    #            print OUTO "$line;identical\n";
                my $len = $end - $start;
                my $llen = $lend - $lstart;
                if ($len > $llen) {
                    print OUT "$line\n";
                }
                else {
                    # lastline is longer
                }
            }
            else {
#                print "Diffrent key2:\n$lastline\n$line\n\n";                
            }

        }
=cut
        else {
            # else
#            print "OVL diff strand, diff key:\n$lastline\n$line\n\n";
            print OUT "$line;comment=ovl\n";
        }


    }

   
    else {
         print OUT "$line;comment=first_UTR\n";
    }


    $lastline = $line;
}



close (OUT);
close (OUTO);

exit;

