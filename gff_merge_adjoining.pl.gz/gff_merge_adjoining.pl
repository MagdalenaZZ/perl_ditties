
#!/usr/bin/perl
use strict;
use Clone qw(clone);

unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/gff_merge_adjoining.pl  in.gff  <space length>








';

}


my $in = shift;
my $space = shift;
my @res;



#### read in exons, and filter the bad ones, and merge adjoining ones



my $laste;


open(EX, "<$in") || die "Cant read file $in, check that it exists\n";
open(OUT, ">$in.merged$space.gff") || die "Cant write to file $in.merged$space.gff\n";


my @ex = <EX>;
my @res1;
my $lkey=shift(@ex);

# merge features less than 10 bp apart
foreach my $k (@ex) {
    chomp $k;
    chomp $lkey;

    my @ar1 = split(/\t/, $k);
    my @ar2 = split(/\t/, $lkey);

    #print "Comparing $lkey to $k\n";

    # if the feature is > 20 bp apart
    if ( $ar1[0]=~/$ar2[0]/ and   ($ar1[3]-$space ) < $ar2[4]) {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "   overlapping \t $ar2[3] $ar2[4] $ar1[3]  $ar1[4] $ovl\n";
                
        # if extension happended, update the feature length
 
        my $min = $ar2[3];
        my $max = $ar2[4];
        my $min2 = ($ar1[3], $min  )[$ar1[3] > $min ];
        my $ie2 = ($max, $ar1[4])[$max < $ar1[4]];
        $ar2[3] = $min2;
        $ar2[4] = $ie2;

        # if extension happended, update the note
        
        my @old_note = split(/"/,$ar2[8]);
        my @new_note = split(/"/,$ar1[8]);
        my $bridge = "0,$ovl:";

        $ar2[8]= "$old_note[0];note=contains$old_note[1]\_$new_note[0]\n";

        my $newl = join("\t", @ar2);
        #print "New feature $newl\n";
        $lkey=$newl;
    }
    else {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "not overlapping \t$ar2[3] : $ar2[4] : $ar1[3]  :  $ar1[4]  :  $ovl\n";
        push(@res1, $lkey);
        
        $lkey = $k;
    }



}

# add the last one
push(@res1, $lkey);



# clean and sort 


#foreach my $ke1 (@res1) {
#    chomp $ke1;
#$_=~s/CDS/intron/;
#    push(@res, $ke1);
    #print "$ke1\n";
#}


#my @sorted = sort { (split '\t', $a)[3].(split '\t', $a)[4] <=> (split '\t', $b)[3].(split '\t', $b)[4] } @res;
#@res = @sorted;



# make output

foreach my $ke2 (@res1) {
    chomp $ke2;
    print OUT "$ke2\n";
    
}


close(OUT);

exit;




