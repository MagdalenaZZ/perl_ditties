#!/usr/bin/perl
use strict;


unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  consensus_caller.pl  alignment.mfa < % mismatches accepted >

Ex:  consensus_caller.pl  alignment.mfa 10

Takes the output from a multi-fasta alignment and calls a consensus on it

If one seuqence has more than  < % mismatches accepted > it will be rejected, and realignment and new consensus-calling will occur
Give % as a number between 0 and 100. The precentage is adjusted so it is absolute on short sequences, i.e. for 10% it is 5 mismatches on 50 bp, and then progressively adjusted for longer sequences, so that it is 67 mismatches on 1000 bp, and 143 mismatches on 5000 bp.

If several sequences are bad, only the worst will be removed before the next re-alignment.


';

}

my $fas = shift;
my $mm = 10;
$mm = shift;

system "fasta2singleLine.py $fas $fas.sl ";


open (FAS, "<$fas.sl") || die 'cant find file $fas.sl';


my %fas;

# read in the sequences


my $len = 0;

while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $len = length($seq);
        $fas{"$head\t$len"} = $seq;
        
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}

close (FAS);


#my $i = 0;

my %con = '';

my $consensus;

my %penalty;
my %misfits;

# now make a consensus

for (my $i = 0; $i < $len; $i++) {

    # make a hash with all the characters on a posisiton
    foreach my $key (sort keys %fas) {
        my $sub = substr($fas{$key}, $i, 1 );
        my @arr = split(/\t/, $key);
        unless ($sub=~/-/){
            $con{"$sub"} += 1;
            push ( @{$penalty{"$sub"}}, @arr[0]);  
        }
    }

    # evaluate which base to call as the consensus
     
    my $sca = scalar(keys %con);
    #print "# $i # $sca #\n";

    my $best = 0;
    my $current = "N";
    my $solved = 0;

    foreach my $elem (keys %con) {

        # all characters are the same
        if ($sca == 2 and $sca =~/\w/ ){
            $consensus = $consensus . $elem;
            $solved = 1;
        }

        # There is a conflict, and the majority is called
        elsif ( $elem =~/\w/ ) {
            # Call the best majority base
            if ( $con{$elem} > $best and $elem!~/N/ ) {
                $best = $con{$elem};
                $current = $elem;
            }
            # If the element is an N - ignore it
            elsif ( $elem=~/N/ ) {
                # ignore
            }
            # If the element was not chosen, make a not about which sequence(s) had the mismatching bases
            else {
                #print "Rejected $elem\t$con{$elem}\n";
                foreach my $misfit ( @{$penalty{$elem}} ) {
                    $misfits{$misfit}+= 1;
                }
            }
                      
        }
        else {
            # empty key
        }


    }
    unless ($solved ==1) {
         $consensus = $consensus . $current;
    }


    %con='';
    %penalty='';    
    
}


# check if one aligned sequence fits very unwell

my $max_key;
my $max_element = 0;
$mm = $mm*$len / (100 + ( 0.5 * $len));
print "MM $mm\n";

foreach my $miss (keys  %misfits) {
    #print "$miss\t$misfits{$miss}\n";
    if ($misfits{$miss} <= $mm ) {
        delete $misfits{$miss};
    }
    else {
        # get the highest element - the sequence with the most errors
        if ( $misfits{$miss} > $max_element ) {
            $max_element =  $misfits{$miss};
            $max_key =  $miss;
        }
    }
}

print "Worst key: $max_key\t$max_element\n\n";


# pick out the sequences which are accepted and rejected
 
my $seq_no = 0; 

open (FAS, "<$fas.sl") || die;

open (FSR, ">>$fas.sl.rejected") || die;
open (FSA, ">$fas.sl.accepted") || die;


while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;

        #print ">$head\n$seq\n";

        if ($head eq $max_key ) {
            $seq =~s/-//g;
            print FSR ">$head\n$seq\n";
            print "$head rejected \n";
        }
        else {
            print FSA ">$head\n$seq\n";
            $seq_no++;
            print "$head accepted \n";
        }
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}

close (FSA);
close (FSR);


print "seq_no $seq_no\n";



## now realign accepted ####

# some has been rejected, and there are some sequences left to be accepted

if (-s "$fas.sl.rejected" and $seq_no > 1 ) {
    print "Rejected exists, and $seq_no is more than 1\nI realign $fas.sl.accepted\n";
    print  "/nfs/users/nfs_m/mz3/bin/mafft-7.040-with-extensions/bin/mafft --quiet --anysymbol --maxiterate 1000 --genafpair $fas.sl.accepted > $fas.sl.accepted.mfa\n";
#    system ("/software/pubseq/bin/mafft --quiet --anysymbol --maxiterate 1000 --genafpair $fas.sl.accepted > $fas.sl.accepted.mfa");wait;
#    system "rm -f $fas.sl.accepted";wait;
#    system "perl  ~/bin/perl/consensus_caller.pl  $fas.sl.accepted.mfa $mm";wait;
    
}

# only one sequence accepted
elsif ( $seq_no == 1  ) {  
    print "$seq_no is 1 so I do nothing\n";

}

# finished, no more aligning or consensus-calling to do
else {
    open (FAS2, ">$fas.consensus.fa") || die;
    print FAS2 ">$fas\n$consensus\n";
#    close (FAS);
#    close (FAS2);
#    system "cat $fas.sl.accepted $fas.consensus.fa > $fas.sl.acc_con ";wait;
#    system ("/software/pubseq/bin/mafft --quiet --anysymbol --maxiterate 1000 --genafpair --clustalout $fas.sl.acc_con > $fas.sl.accepted.clu");wait;
    #system "rm -f $fas.sl.acc_con";wait;
    print "Else, $seq_no is X, and I print to  $fas.consensus.fa\n then merge $fas.sl.accepted $fas.consensus.fa and get $fas.sl.accepted.clu \n";


}


exit;





