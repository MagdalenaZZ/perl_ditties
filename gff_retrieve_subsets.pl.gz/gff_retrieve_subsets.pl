#!/usr/bin/perl -w

use strict;




#my $largest = 0;
#my $contig = '';


if (@ARGV < 2) {


    print "Usage: gff_retrieve_subsets.pl infile.gff list \n\n" ;
    print " mz3 script for retriveing gff if their gene-name is in a list \n\n";
    print " Warning - you can\'t have the same name for two different genes in the inputfile \n\n";
	exit ;
}

my $filenameA = shift;
my $list = shift;

my %genes = () ;
my %genes2 = () ;

open (IN, "<$list") or die "Can\'t open file $list\n" ;
open (OUT, ">$list.chosen.gff") or die "Can\'t open file $list.chosen.gff\n" ;
open (OUT2, ">$list.unchosen.gff") or die "Can\'t open file $list.unchosen.gff\n" ;

while (<IN>) {
	chomp ;
	my @line = split(/\s+/ , $_ );
 #   print "Key:$line[0]:\n";	
	$genes{$line[0]} = $line[0];
	$genes2{$line[0]} = $line[0];
}

close(IN) ;

open (IN2, "<$filenameA") or die "Can\'t open file $filenameA\n" ;

my @gff = <IN2>;

foreach my $line (@gff) {
	chomp $line;
#     print "$line" ;
 #   if (/^>(\S+)/) {
	my @line2 = split(/[(;:\t)]/ , $line );
	$line2[8] =~s/ID=//;
	$line2[8] =~s/\.t1\.cds//;
	$line2[8] =~s/\.t1//;

#	chomp $line2[8];
#	print ":$line2[8]:\n";
	my $gene_name = $line2[8];
#	my $seq = <IN2> ;
#	chomp($seq) ;
	
	if ( exists $genes{$gene_name} ) {
#			print "$gene_name\n" ;
			print OUT "$line\n" ;
			delete $genes2{$gene_name};
	}
	else {
#		print "$gene_name doesnt match\n";
			print OUT2 "$line\n" ;
	}

#    }
    #last;


}

foreach my $gene_name (%genes2) {
	print "$gene_name\t$genes2{$gene_name} was not in file $filenameA\n";
}

close (OUT);
close (OUT2);

# if exists $hash{$key};

#print "\#\#the largest length is: $contig with $largest bp \n" ;
