#!/usr/local/bin/perl -w
# mz3 script 


#use strict;

unless (@ARGV == 1) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: faCount.pl file.fq.gz ||  file.fastq

This script recognises if a file is fq.gz or just fq,
and counts the number of reads therein



'
}

my $file = shift;
#my $FH="FH";

if ($file =~ /\.gz$/) {
    open(FH, "gunzip -dc $file |") || die "can't open pipe to $file\n";
}
else {
    open(FH, $file) || die "can't open $file";
}

open(OUT, ">$file.wcl") || die "can't open file $file.wcl\n";


#open $FH, "gunzip -dc $filename |" or die $!;

my $count =0;

while (<FH>) {
	if ($_=~/^@\w+/ and $_=~/[\:]\d+[\:]\d+[\:]\d+/ ) {
		$count++;
		#print "$_";	
	}
}


print OUT "$file\t$count\n";





exit;




