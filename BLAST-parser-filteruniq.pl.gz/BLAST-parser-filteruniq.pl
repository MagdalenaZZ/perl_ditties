#!/usr/local/bin/perl -w

use strict;

unless (@ARGV) {
        &USAGE;
}


sub USAGE {

die 'Usage: 


'
}


	my $blat = shift;
	open (IN, "$blat") || die "I can't open $blat\n";
	my @input = <IN>;
	close (IN);


my @sort;



#  # sort using explicit subroutine name
# sub byage {
# $age{$a} <=> $age{$b}; # presuming numeric
# }
# @sortedclass = sort byage @class;


foreach my $line (@input) {

my @in = split(/\s+/, $line);

my @sorted = sort {$in[0] cmp $in[1]} @in;

#print @sorted;

push (@sort, "$sorted[0]\t$sorted[1]");

}

# print @sort;

my %seen = (); 
my @uniq = (); 

foreach my  $item (@sort) { unless ($seen{$item}) { 
# if we get here, we have not seen it before 
$seen{$item} = 1; push(@uniq, $item); } }

foreach my $elem (@uniq) {
print "$elem\n";
}
