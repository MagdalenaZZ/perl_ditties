#!/usr/local/bin/perl -w

my $est = shift;
my $estAA = shift;

open (OUTtranslate, ">$estAA") || die ;

print OUTtranslate "My sequences are: \n";

	# read all EST sequences and translate each in its frame, finding longest ORF:
	open (IN, $est) || die ;

	my $seqName = my $seq = '' ;
	while (<IN>) {
		if (/^>/) {
			# process previous sequence:
			my $frame = $frame{$seqName} ;
			if ($seqName && $frame && ($frame ne '-')) {
				my $protein = longestORF ($seq, $frame) ;
				print OUTtranslate ">$seqName frame$frame{$seqName}\n$protein\n" ;
			}
			# get new sequence name:
			($seqName) = /^>(?:gi\|)?([^\s\|]+)/ ; ##### THIS LINE CAUSED PROBLEMS WITH RAW DATA BEFORE
			$seq = '' ;
		} 
		else {
			$seq .= $_ ;
		}	
	}


	my $frame = $frame{$seqName};
	if ($seqName && $frame && ($frame ne '-')) {
		my $protein = longestORF ($seq, $frame) ;
		##### if you want to modify the sequence name, do it here (although it won't match the blast .tab file anymore):
		print OUTtranslate ">$seqName  frame$frame\n$protein\n" ;
	}

	close IN ;
	close OUTtranslate ;




sub longestORF {
	my ($seq, $frame) = @_ ;

	my ($prot) = translate ($seq, $frame) ;
	my @aa = split ('', $prot) ;
	my $lengthLongest = 0 ;
	my $longestPept = '' ;
	while (@aa) {
		my $pept = '' ;
		while (@aa && (($a = shift(@aa)) ne '*')) {
			$pept .= $a ;
		}
		$pept =~ s/^X+|X+$//g ; # remove leading / trailing unknown aa
		if (length($pept) > $lengthLongest) {
			$lengthLongest = length($pept) ;
			$longestPept = $pept ;
		}
	}

	return ($longestPept) ;
}
