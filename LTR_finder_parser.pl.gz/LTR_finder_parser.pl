#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: LTR_finder_parser.pl LTRoutput



Go to the webpage http://tlife.fudan.edu.cn/ltr_finder/index.php
    and upload your genome in <50 Mb chunks
Take the result and put in a text-file
Run this parser


NOT FINISHED!!!!!



'
}

my $in = shift;
my $out = "$in.gff";
open (IN, "<$in") || die "I can't open $in\n";
open (OUT, ">$out") || die "I can't open $out\n";
#	my @in = <IN>;
#


while (<IN>) {


    if ($_=~/Len:\d+$/ and $_=~/\[\d+\]/) {
        my $head=$_;
        my $loc=<IN>;
        my $score=<IN>;
        my $status=<IN>;
        my $ltr5=<IN>;
        my $ltr3=<IN>;
        my $tg5=<IN>;
        my $ca3=<IN>;
        my $TSR=<IN>;
        my $sharpness=<IN>;
        my $strand=<IN>;
        my $ppt=<IN>;

        # fix components
        my @head = split(/\s+/,$head);
        my @loc = split(/\s+/,$loc);
        my @score = split(/\s+/,$score);
        my @ltr5 = split(/\s+/,$ltr5);
        my @ltr3 = split(/\s+/,$ltr3);
        my @TSR = split(/\s+/,$TSR);
        my @ppt = split(/\s+/,$ppt);


        $loc[7]=~s/Strand://;
        $score[5]=~s/\]//;
        chomp $sharpness;
        chomp $status;
       

        if (scalar(@loc)<7) {
            #print "LOC " . scalar(@loc) . " \n";
            next;
        }

        unless ($loc[7]=~/\+/ or $loc[7]=~/\-/  ) {
            #print "Strand $loc[7]\n";
            $loc[7]=".";
        }




        #print "$head$loc";
        # print results
        print OUT "$head[1]\tLTR_finder\tgene\t$loc[2]\t$loc[4]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2];note=$score[5];note=$sharpness\n";
        # 5LTR
        print OUT "$head[1]\tLTR_finder\tCDS\t$ltr5[2]\t$ltr5[4]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].5LTR;Parent=$head[1]_$loc[2];colour=4;note=5LTR\n";
        #middle
        print OUT "$head[1]\tLTR_finder\tCDS\t".  ($ltr5[4]+1) . "\t" . ($ltr3[2]-1) . "\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].insert;Parent=$head[1]_$loc[2];colour=7;note=insertion\n";
        
        # 3LTR
        print OUT "$head[1]\tLTR_finder\tCDS\t$ltr3[2]\t$ltr3[4]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].3LTR;Parent=$head[1]_$loc[2];colour=4;note=3LTR\n";

        unless ($TSR=~/NOT FOUND/) {
        # TSR 1 and 2
            print OUT "$head[1]\tLTR_finder\tCDS\t$TSR[2]\t$TSR[4]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].TSR1;Parent=$head[1]_$loc[2];colour=9;note=TSR1\n";
            print OUT "$head[1]\tLTR_finder\tCDS\t$TSR[6]\t$TSR[8]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].TSR2;Parent=$head[1]_$loc[2];colour=9;note=TSR2\n";
        }
        # PPT
        if (scalar(@ppt)>5) {
            print OUT "$head[1]\tLTR_finder\tCDS\t$ppt[3]\t$ppt[5]\t\.\t$loc[7]\t\.\tID=$head[1]_$loc[2].PPT;Parent=$head[1]_$loc[2];colour=3;note=PPT\n";
        }
    }
    else {
    }


}



	close (IN);
	close (OUT);

    system "perl ~mz3/bin/perl/gff2art.pl $out";

exit;


