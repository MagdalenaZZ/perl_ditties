#!/usr/bin/perl
use strict;

unless (@ARGV >0) {
        &USAGE;
}

sub USAGE {

die '

perl ~/bin/perl/SNP_ANOVA.pl file


';

}

my $in = shift;


open my $ins, "<$in"  || die "Error \n";
open (OUT, "> $in.an") || die "\nCannot write to file $in.an\n";


my %u;


while (<$ins>) {
    chomp;

    $_=~s/0\/0/0/g;
    $_=~s/0\/1/1/g;
    $_=~s/1\/1/2/g;
    $_=~s/0\/2/3/g;
    $_=~s/2\/2/4/g;
    $_=~s/1\/2/5/g;

    my @a = split(/\t/, $_);

    # calculate within cells

    # GMP
    my %gmp;
    $gmp{$a[3]}=1;
    $gmp{$a[4]}=1;
    $gmp{$a[7]}=1;
    $gmp{$a[8]}=1;
    $gmp{$a[9]}=1;
    $gmp{$a[10]}=1;
    $gmp{$a[13]}=1;
    $gmp{$a[14]}=1;
    $gmp{$a[15]}=1;
    $gmp{$a[16]}=1;


    
    # LSK
    my %lsk;
    $lsk{$a[1]}=1;
    $lsk{$a[2]}=1;
    $lsk{$a[5]}=1;
    $lsk{$a[6]}=1;
    $lsk{$a[11]}=1;
    $lsk{$a[12]}=1;

    my $gmp = scalar keys %gmp;
    my $lsk = scalar keys %lsk;


    my $bet;
    # between cells
    if ($gmp==1 & $lsk ==1) {
        if ($a[1]==$a[3]){
            $bet = "Same";
        }
        else {
            $bet = "Diff";
        }
    }
    else {
        $bet = "NA";
    }


    print "Within LSK " . "$lsk" . "\t";
    print "Within GMP " . "$gmp"  . "\t";
    print "Between cells " . "$bet"  . "\t";

    print "\n";



}



__END__


foreach my $row (sort keys %u) {

    my $comp;

    if ($row=~/\.\/\./ ) {
        $comp="inc";
    }
    else {
        $comp="comp";
    }

  
    if ($row!~/1/ || $row!~/2/   ) {
        print OUT "$u{$row}\t$row\t$comp\tRef\n";
    }
 
    elsif ($row!~/0/ || $row!~/2/  ) {
        print OUT "$u{$row}\t$row\t$comp\tAllAlt\n";
    }

    else {
        print OUT "$u{$row}\t$row\t$comp\tOther\n";
    }

}


close(OUT);

exit;

