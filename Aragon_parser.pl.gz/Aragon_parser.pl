#!/usr/bin/perl -w


use strict;

unless (@ARGV ==1 ) {
        &USAGE;
}


sub USAGE {

die 'Usage: Aragon_parser.pl aragon.tab.out


Takes an outfile from Aragon (tab-format) and gives a gff-file and fasta back





'
}

my $in = shift;

unless (-s $in) {
 die "Check that your input-file $in is correct and restart \n";
}


open (IN, "<$in") || die "I can't open $in\n";
open (OUT, ">$in.gff") || die "I can't open $in.gff\n";
open (FAS, ">$in.fas") || die "I can't open $in.fas\n";

my $head;
my $seq;
my @seq='';
my $pos;
my $codon;



while (<IN>) {
    chomp;
    #print "$_\n";

    
    if ($_=~/^>/) {



        # make head of new entry

        #print  "HEAD: $_\n";
        $_=~s/\>//;
        $head = $_;
    }
    elsif ($_=~/^\d+\s+tRNA/) {

        # print last entry

        if (scalar(@seq)> 1 and $seq[1]=~/\w+/ ) {
            #print "print $seq[1]\n";
            print FAS ">$head\n";
            print FAS join("",@seq) . "\n";
            @seq='';
            print OUT "$pos\n";
        }


        #print "POS: $_\n";
        my @pos = split(/\s+/,$_);
        my ($start,$end)=split(/,/,$pos[2]);
        my $strand = '+';
        if ($start=~/c/) {
            $strand='-';
        }
        $start=~s/c\[//;
        $start=~s/\[//;
        $end=~s/\]//;
        $pos = "$head\tAragon\tCDS\t$start\t$end\t\.\t$strand\t.\tID=$head\_$pos[0];note=$pos[1];note=$pos[4]";
    
    }
    elsif ($_!~/\d+/  and $_=~/\w+/) {
        #print "SEQ: $_\n";
        push (@seq,$_);
    }
    else {
        #print "DUNNO: $_\n";
    
    }

}




# print the last entry


        if (scalar(@seq)> 1 and $seq[1]=~/\w+/ ) {
            #print "print $seq[1]\n";
            print FAS ">$head\n";
            print FAS join("",@seq) . "\n";
            @seq='';
            print OUT "$pos\n";
        }


close (IN);
close (OUT);
close (FAS);


exit;

