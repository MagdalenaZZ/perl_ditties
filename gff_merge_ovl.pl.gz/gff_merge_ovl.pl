#!/usr/bin/perl -w

# mz3 script for merging overlapping exons from the same transcript/gene,
# but not from different ones

use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff_merge_ovl.pl input.gff 


input.gff.exon	Input gff-file, where exons belonging to same gene/transcrip have the same name


Output:
overlapped  .gff


WARNING: bedtools merge does one-off error on positions!!!!!



'

}


my $in = shift;


system "bedtools merge -s -c 9,4,5 -o collapse -i $in > $in.raw";

open (IN, "<$in.raw") || die "I can't open $in.raw\n";
	my @in3 = <IN>;
	close (IN);


open (OUT, ">$in.raw2") || die "I can't open $in.raw2\n";

foreach my $line (@in3) {
	chomp $line;

	my @a=split(/\t/, $line);

# many genes
	if ($a[4]=~/\,/) {
		#print "MANY\t$line\n";
		my @genes=split(/\,/, $a[4]);
		my @starts=split(/\,/, $a[5]);
		my @ends=split(/\,/, $a[6]);
		#my $i=0;

		my @unique = do { my %seen; grep { !$seen{$_}++ } @genes };

		if ( scalar(@unique) > 1 ) {
			#print "Length " . scalar(@unique) . " @unique\n";
			#print "MANY\t$line\n";

			my %co;
			for (my $i=0; $i<scalar(@genes); $i++) {

				$co{$genes[$i]}{"$starts[$i]\t$ends[$i]"}=1;
				#print "$a[0]\tmerged\texon\t$starts[$i]\t$ends[$i]\t.\t$a[3]\t.\t$genes[$i]\n";
			}

			my $min=100000000000;
			my $max =0;

			foreach my $gene (keys %co) {
				foreach my $pos (keys %{$co{$gene}} ) {
					my @b = split(/\t/, $pos);
					if ($b[0]<$min) {
						$min = $b[0];
					}
					if ($b[1]>$max) {
						$max = $b[1];
					}
				}

				print OUT "$a[0]\tmerged\texon\t$min\t$max\t.\t$a[3]\t.\t$gene\n";
				$min=100000000000;
				$max =0;
			}

		}
		# just one gene
		else {
			print OUT "$a[0]\tmerged\texon\t$a[1]\t$a[2]\t.\t$a[3]\t.\t$unique[0]\n";
		}
	}
# no mergning done
	else  {
		print OUT "$a[0]\tmerged\texon\t$a[1]\t$a[2]\t.\t$a[3]\t.\t$a[4]\n";
	}
}

system "cat $in.raw2 | sort -k1,1 -k4,4n | uniq > $in.merged.gff";

#system "rm -f $in.raw $in.raw2";




exit;




