#!/usr/bin/perl
use strict;
#use Clone qw(clone);

unless (@ARGV > 3) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~mz3/bin/perl/wiggleJunkie.pl sorted.bam file.fas <coverage int>  <anchor length>


BAM-file have to be sorted!!!


It will only output features present in <converage int> reads or more
and features with an anchor length of <anchor length> or more for all mapped fragments

The anchor length is how much of a read is present on either side of a splice-junction.
If the anchor length is 10, a read which is 100bp long and split with 95 bp on one side of the junction and 5 bp on the other side will be filtered away.
The same read with 25 bp on one side and 75 bp on the other side will be kept




';

}


my $in = shift;
my $fas = shift;
my $cov = shift;
my $anc = shift;
my $maxim = 20000;
my $depth = 5;
my $merge = 20;

print "\nSuccessful 1\n";


# run bump-caller and junction-finder on bam-file
  
#print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc\n"; 
#unless (-s "SAM_extract_junctions/$in.$cov") {
#    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc"; wait;
#}

#print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in $fas $cov $maxim $depth\n"; 
#unless (-s "$in.PE.$cov.$maxim.gff") {
#    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in $fas $cov $maxim $depth";  wait;
#}

print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas\n";
system "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas"; wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split\n";  
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split";  wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;

print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge\n"; 
system "perl /nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge";  wait;

print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED $cov $merge\n";
system "perl /nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED $cov $merge";  wait;


print "\nSuccessful 2\n";

__END__

# Test if all files are made like they should
print "\n\n";


unless (-s "$in.$cov.$anc.gff") {
    print "You file $in.$cov.$anc.gff is not getting produced as expected, check the script SAM_extract_junctions.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff") {
    print "You file $in.$cov.$anc.gff.genomeCoverageBed.bga.gff is not getting produced as expected, check the script coverage2feature.pl to make sure it is working\n";
    print "perl /nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge";
    print "\n";
    print "perl /nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED $cov $merge";
    print "\n";
    die;
}

unless (-s "$fas.genome") {
    print "You genome-file is not getting produced as expected, check the script wj_make_genome.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.split" or -s "$in.genomeCoverageBed.bga") {
    print "You file $in.$cov.$anc.gff.genomeCoverageBed.bga.split is not getting produced as expected, check the BEDtools genomeCoverageBed  to make sure it is working\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split  ";
    print "\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga  ";
    print "\n";
    die;
}


print "\nSuccessful 3\n";




# now merge and overlap features: exons PEs introns


system "cat $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff $in.PE.$cov.$maxim.gff  $in.$cov.$anc.gff | sort -k1,1 -k4,4n > $in.$cov.$anc.all.gff  ";

system "~jit/bin/BEDTools-Version-2.12.0/bin/mergeBed -i $in.$cov.$anc.all.gff -n | awk '{print \$1\"\tTranscript\tgene\t\"\$2\"\t\" \$3\"\t\.\t\.\t\.\tTranscript\"NR\"_\"\$4}' > $in.$cov.$anc.trans.gff";

system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.trans.gff";


# Now annotate the parts of a transcript which are transcribed and output file good for diff exp


system "/nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 1 $merge";


system "~jit/bin/BEDTools-Version-2.12.0/bin/intersectBed -a $in.$cov.$anc.trans.gff -b $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff -wb  | awk '{print \$1\"\t\"\$2\"\tCDS\t\"\$4\"\t\"\$5\"\t\"\$6\"\t\"\$7\"\t\"\$8\"\t\"\$9\";note=\"\$9}' > $in.$cov.$anc.gff";

system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.gff";

print "\nSuccessful 4\n";


mkdir "wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga wiggleJunkie";
#system "mv genomeCoverageBed.bga.split wiggleJunkie";
system "mv $in.PE.$cov.$maxim.gff wiggleJunkie";
system "mv $in.$cov.$anc.all.gff  wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split wiggleJunkie";


exit;









__END__


fg




