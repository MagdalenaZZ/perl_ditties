#!/usr/local/bin/perl -w
# script for taking gene-predictor inputs and setting up directories for training jigsaw

use strict;

use Getopt::Std;
use Getopt::Long;


my %opts;

#unless (@ARGV) {
#        &USAGE;
#}

getopts('hi:o:d:s:g:c:b:a', \%opts);

&USAGE if $opts{h};

######################
my $path = "";

if ($opts{d}) {
	$path = $opts{d}; 
	# print "$path\n";
	# my $path = "/nfs/users/nfs_m/mz3/bin/perl";
}
else {
my $path = " /lustre/scratch101/sanger/mz3/gene_pred/";
print "$path\n";
}
######### get format and subscripts #############

my $snapf = "$path/original_out/output_snap-1.gff";
my $augf = "$path/original_out/aug.o";
my $blastf = "$path/original_out/none";
my $glimf = "original_out/Hym2000.glim.gff";

my %snap = LOAD($snapf);
my %aug = LOAD($augf);
my %blast = LOAD($blastf);

my $psnap = "~mz3/bin/perl/snap2jigsaw_gff.pl";
my $psnap2 = "~mz3/bin/perl/snap2jigsaw.pl";
my $paug = "~mz3/bin/perl/augustus2jigsaw.pl";
my $pblast = "~mz3/bin/perl/blast2jigsaw.pl";
my $pcuff = "cufflinks2jigsaw.pl";
my $pembl = "gff2embl_jigsaw.pl";
my $pgff = "gff2jigsaw_dev.pl";
my $pglim = "glimmer2jigsaw.pl";

###########################################################


open IN,  "$path/jigsaw/lists/dirs2create.txt";
my $dir = "$path/jigsaw/dirs";
while (<IN>) {
	chomp;
	my $contig = $_;
	mkdir ("$dir/$contig");
	if ($snap{$contig}) {
		open SNAP, ">$dir/$contig/$contig.snap.gff";
		foreach my $line (@{$snap{$contig}}) {
			print SNAP "$line";
		}
		close SNAP;
		system("$psnap $dir/$contig/$contig.snap.gff > $dir/$contig/$contig.snap.gp");
	} 
	if ($aug{$contig}) {
		open AUG, ">$dir/$contig/$contig.aug.gff";
		foreach my $line (@{$aug{$contig}}) {
			print AUG "$line";
		}
		close AUG;
		system("$paug $dir/$contig/$contig.aug.gff > $dir/$contig/$contig.aug.gp");
	}
	if ($blast{$contig}) {
		open BLAST, ">$dir/$contig/$contig.blastx";
		foreach my $line (@{$blast{$contig}}) {
			print BLAST "$line";
		}
		close BLAST;
		system("$pblast $dir/$contig/$contig.blastx > $dir/$contig/$contig.blastx.ph");
	}

}



sub LOAD {
open FILE, "$_[0]";
my %hash;
while (<FILE>) {
	next if (/\#/);
	my $contig = (split /\s+/, $_)[0];
	push (@{$hash{$contig}}, $_);
}
return %hash;
}


close (IN);
close (FILE);

sub USAGE {

die 'Usage: 2jigsaw.pl - 
	-o: 	output file name
	-d: 	path
	-s:	snap
	-g:	glimmerHMM
	-c:	cufflinks
	-a:	augustus
	-b:	blast (tabular format)
'
}


