#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: fastq_to_freq.pl file.fastq fastq


i.e.

 fastq_to_freq.pl file.fastq fastq
 fastq_to_freq.pl file.bam BAM
 fastq_to_freq.pl file.sam SAM



This program takes a fastq file or a BAM/SAM-file and counts all read lengths

This program takes a file with a column with numbers and draws a frequency histogram from it.
Using perl module, not R





    ' . "\n";
}

my $file = shift;
my $mode = shift;
 

open (FAS, "<$file") || die "I can't open $file\n";
open (OUT, ">$file.lengths") || die "I can't open $file.lengths\n";



# Determine maximum length and save data to fas

my %fas;

if ($mode=~/fastq/i) {

    while (<FAS>) {
        chomp;

        if ($_=~/^@\w+/) {
            my $head = $_;
            my $seq = <FAS>;
            my $mid = <FAS>; 
            my $qual = <FAS>; 
            my $len =length($seq);
            print OUT "$len\n";
        }
        
        else {
            #print "not digit $arr[1]\n"
        }


    }

}


elsif ( $mode=~/bam/i ) {

     open (IN, "samtools view $file |") || die "I can't open $file\n";

    while (<IN>) {
        my @arr=split(/\t/,$_);
        my $len = length($arr[9]);
            print OUT "$len\n";
    }

}

else  {
    print "not implemented. sorry!\n"
}

print "\n~/bin/perl/freq_histogram_in_R.pl *.lengths \n ";



exit;




