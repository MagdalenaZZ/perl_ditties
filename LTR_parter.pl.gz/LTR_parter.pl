#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: LTR_parter.pl blast-hit



Takes a file where BLASTs have been done on a fasta-file which is a sub-file of a genome fasta, and positions are reported as:

pathogen_EmW_Chr_01_4341542_4342511
means that the fasta BLASTed fits on the position 4341542 - 4342511 on pathogen_EmW_Chr_01


Very specific script and unlikely to be of much use to anyone except me


'
}

my $in = shift;



open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\s+/, $line);
    #print "$line\n";
    my @head = split(/\_/, $arr[0]);
   
    # check if it is forward or reverse
    # forward
    if ($arr[9]-$arr[8] > 0) {
        my $adjusted_start = $head[4]+$arr[6];
        my $adjusted_end = $head[4]+$arr[7];
        print "$head[0]\_$head[1]\_$head[2]\_$head[3]\tBLAST\tCDS\t$adjusted_start\t$adjusted_end\t\.\t\+\t\.\t$arr[1]\n";
    }
    else {
        #print "negative $arr[8]\t$arr[9]\n";
        my $adjusted_start = $head[4]+$arr[7];
        my $adjusted_end = $head[4]+$arr[6];
        print "$head[0]\_$head[1]\_$head[2]\_$head[3]\tBLAST\tCDS\t$adjusted_start\t$adjusted_end\t\.\t\-\t\.\t$arr[1]\n";
    }

}




__END__


pathogen_EmW_Chr_01_4001449_4002542	ID=3LTR	83.87	93	14	1	898	990	1	92	7e-21	87.9
pathogen_EmW_Chr_01_4001449_4002542	ID=5LTR	80.90	199	29	8	898	1092	1	194	3e-39	 148
pathogen_EmW_Chr_01_4001449_4002542	ID=PPT	93.33	15	1	0	880	894	1	15	0.19	23.3
pathogen_EmW_Chr_01_4001449_4002542	ID=TRIM	82.39	318	40	9	688	990	565	881	1e-73	 263
pathogen_EmW_Chr_01_4001449_4002542	ID=internal	86.29	175	24	0	688	862	370	544	5e-52	 191


pathogen_EmW_Chr_03_6858114_6859364	ID=3LTR	80.43	184	16	8	1051	1233	1	165	2e-31	 122
pathogen_EmW_Chr_03_6858114_6859364	ID=5LTR	87.77	188	16	6	1051	1237	1	182	1e-58	 213
pathogen_EmW_Chr_03_6858114_6859364	ID=PPT	100.00	15	0	0	1033	1047	1	15	0.005	28.8
pathogen_EmW_Chr_03_6858114_6859364	ID=TRIM	82.83	396	48	10	839	1233	578	954	7e-96	 337
pathogen_EmW_Chr_03_6858114_6859364	ID=internal	84.91	212	32	0	839	1050	383	594	3e-59	 215
