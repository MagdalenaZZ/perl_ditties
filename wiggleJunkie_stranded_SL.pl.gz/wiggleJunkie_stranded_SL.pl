#!/usr/bin/perl
use strict;
#use Clone qw(clone);

unless (@ARGV > 3) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/wiggleJunkie_stranded.pl bam-file file.fas <coverage int>  <anchor length>




It will only output features present in <converage int> reads or more
and features with an anchor length of <anchor length> or more for all mapped fragments

The anchor length is how much of a read is present on either side of a splice-junction.
If the anchor length is 10, a read which is 100bp long and split with 95 bp on one side of the junction and 5 bp on the other side will be filtered away.
The same read with 25 bp on one side and 75 bp on the other side will be kept




';

}


my $in = shift;
my $fas = shift;
my $cov = shift;
my $anc = shift;
my $maxim = 20000;
my $depth = 5;
my $merge = 50;

my $ori_in = $in;


# split BAM by strand

unless (-s "$in.plus.strand.bam") {
    system "samtools view -H $in > $in.plus.strand.sam";
    system "samtools view -F 4 $in | perl -nle 'print if /XS\\:A\\:\\+/' >> $in.plus.strand.sam";
    system "samtools view -Sb $in.plus.strand.sam > $in.plus.strand.bam";
    print "samtools view -H $in > $in.plus.strand.sam\n";
    print "samtools view -F 4 $in | perl -nle 'print if /XS\\:A\\:\\+/' >> $in.plus.strand.sam\n";
    print "samtools view -Sb $in.plus.strand.sam > $in.plus.strand.bam\n";
}

unless (-s "$in.minus.strand.bam") {
    system "samtools view -H $in > $in.minus.strand.sam";
    system "samtools view -F 4 $in | perl -nle 'print if /XS\\:A\\:\\-/' >> $in.minus.strand.sam";
    system "samtools view -Sb $in.minus.strand.sam > $in.minus.strand.bam";
    print "samtools view -H $in > $in.minus.strand.sam\n";
    print "samtools view -F 4 $in | perl -nle 'print if /XS\\:A\\:\\-/' >> $in.minus.strand.sam\n";
    print "samtools view -Sb $in.minus.strand.sam > $in.minus.strand.bam\n";
}


# run extract junctions on both strands

print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in.minus.strand.bam $cov $anc\n"; 
unless (-s "SAM_extract_junctions/$in.$cov") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in.minus.strand.bam $cov $anc"; wait;
}

print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in.minus.strand.bam $fas $cov $maxim $depth\n"; 
unless (-s "$in.PE.$cov.$maxim.gff") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in.minus.strand.bam $fas $cov $maxim $depth";  wait;
}


print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in.plus.strand.bam $cov $anc\n"; 
unless (-s "SAM_extract_junctions/$in.$cov") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in.plus.strand.bam $cov $anc"; wait;
}

print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in.plus.strand.bam $fas $cov $maxim $depth\n"; 
unless (-s "$in.PE.$cov.$maxim.gff") {
    system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_PE_coverage.pl $in.plus.strand.bam $fas $cov $maxim $depth";  wait;
}





#__END__



system "samtools faidx $fas";
system "cat $fas.fai | cut -f1,2 > $fas.genome";
#print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas\n";
#system "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas"; wait;


# Do plus strand

my $ori_in= $in;
my $in = "$in.plus.strand.bam";
my $in_plu = $in;

#print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand +  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
#system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand +  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;
#print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand -  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
#system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand -  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;

print "perl ~mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge\n"; 
system "perl ~mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge";  wait;
#print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge\n"; 
#system "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga  BED $cov $merge";  wait;


system "cat $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff | sed 's/\t.\t.\t.\t/\t.\t+\t.\t/' > $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff2 ";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff2  $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff3";


# Do minus strand

my $in = "$ori_in.minus.strand.bam";
my $in_min = $in;

#print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand +  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
#system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand +  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;
#print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand -  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
#system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -strand -  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;

print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga\n";
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga";  wait;


#print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge\n"; 
#system "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge";  wait;
print "perl ~mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED $cov $merge\n"; 
system "perl ~mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga  BED $cov $merge";  wait;

system "cat $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff | sed 's/\t.\t.\t.\t/\t.\t-\t.\t/' > $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff2 ";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff2  $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff3";





print "\nSuccessful 2\n";



#system "rm -f $ori_in.plus.strand.sam $ori_in.minus.strand.sam $ori_in.plus.strand.bam.$cov.$anc.gff.genomeCoverageBed.bga $ori_in.minus.strand.bam.$cov.$anc.gff.genomeCoverageBed.bga ";


# Test if all files are made like they should
print "\n\n";


unless (-s "$in.$cov.$anc.gff") {
    print "\nYour file $in.$cov.$anc.gff is not getting produced as expected, check the script SAM_extract_junctions.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in $cov $anc";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff") {
    print "\nYour file $in.$cov.$anc.gff.genomeCoverageBed.bga.gff is not getting produced as expected, check the script coverage2feature.pl to make sure it is working\n\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 5 $merge";
    print "\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga.split BED 10 $merge";
    print "\n";
    die;
}

unless (-s "$fas.genome") {
    print "\nYour genome-file is not getting produced as expected, check the script wj_make_genome.pl to make sure it is working\n\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas";
    print "\n";
    die;
}

unless (-s "$in.$cov.$anc.gff.genomeCoverageBed.bga.split" or -s "$in.genomeCoverageBed.bga") {
    print "\nYour file $in.$cov.$anc.gff.genomeCoverageBed.bga.split is not getting produced as expected, check the BEDtools genomeCoverageBed  to make sure it is working\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga.split  ";
    print "\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.$cov.$anc.gff.genomeCoverageBed.bga  ";
    print "\n";
    #die;
}


print "\nSuccessful 3\n";


my @files;


####### MINUS ######

$in = $in_min;


# now merge and overlap features: exons PEs introns

system "cat $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff $in.PE.$cov.$maxim.gff  $in.$cov.$anc.gff | sort -k1,1 -k4,4n > $in.$cov.$anc.all.gff  ";
system "~jit/bin/BEDTools-Version-2.12.0/bin/mergeBed -i $in.$cov.$anc.all.gff -n | awk '{print \$1\"\tTranscript\tgene\t\"\$2\"\t\" \$3\"\t\.\t\.\t\.\tTranscript\"NR\"_\"\$4}' > $in.$cov.$anc.trans.gff";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.trans.gff";

# Now annotate the parts of a transcript which are transcribed and output file good for diff exp

system "/nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 1 $merge";
system "~jit/bin/BEDTools-Version-2.12.0/bin/intersectBed -a $in.$cov.$anc.trans.gff -b $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff -wb  | awk '{print \$1\"\t\"\$2\"\tCDS\t\"\$4\"\t\"\$5\"\t\"\$6\"\t\"\$7\"\t\"\$8\"\t\"\$9\";note=\"\$9}' > $in.$cov.$anc.gff";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.gff";


print "\nSuccessful 4a\n";



mkdir "wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga wiggleJunkie";
#system "mv genomeCoverageBed.bga.split wiggleJunkie";
system "mv $in.PE.$cov.$maxim.gff wiggleJunkie";
system "mv $in.$cov.$anc.all.gff  wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split wiggleJunkie";

system "cat  $in.$cov.$anc.gff | sed 's/\t\.\t\.\t/\t\.\t\+\t/' | awk -F';' '{print \$1\"fw\"}' > $in.$cov.$anc.ST ";

push (@files,  "$in.$cov.$anc.ST");

####### PLUS ######


$in = $in_plu;




# now merge and overlap features: exons PEs introns

system "cat $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff $in.PE.$cov.$maxim.gff  $in.$cov.$anc.gff | sort -k1,1 -k4,4n > $in.$cov.$anc.all.gff  ";
system "~jit/bin/BEDTools-Version-2.12.0/bin/mergeBed -i $in.$cov.$anc.all.gff -n | awk '{print \$1\"\tTranscript\tgene\t\"\$2\"\t\" \$3\"\t\.\t\.\t\.\tTranscript\"NR\"_\"\$4}' > $in.$cov.$anc.trans.gff";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.trans.gff";

# Now annotate the parts of a transcript which are transcribed and output file good for diff exp

system "/nfs/users/nfs_m/mz3/bin/perl/coverage2feature.pl $in.$cov.$anc.gff.genomeCoverageBed.bga BED 1 $merge";
system "~jit/bin/BEDTools-Version-2.12.0/bin/intersectBed -a $in.$cov.$anc.trans.gff -b $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff -wb  | awk '{print \$1\"\t\"\$2\"\tCDS\t\"\$4\"\t\"\$5\"\t\"\$6\"\t\"\$7\"\t\"\$8\"\t\"\$9\";note=\"\$9}' > $in.$cov.$anc.gff";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $in.$cov.$anc.gff";



print "\nSuccessful 4b\n";


mkdir "wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split.gff.c2f.gff wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga wiggleJunkie";
#system "mv genomeCoverageBed.bga.split wiggleJunkie";
system "mv $in.PE.$cov.$maxim.gff wiggleJunkie";
system "mv $in.$cov.$anc.all.gff  wiggleJunkie";
system "mv $in.$cov.$anc.gff.genomeCoverageBed.bga.split wiggleJunkie";

system "cat  $in.$cov.$anc.gff | sed 's/\t\.\t\.\t/\t\.\t\-\t/' | awk -F';' '{print \$1\"rv\"}' > $in.$cov.$anc.ST ";

push (@files,  "$in.$cov.$anc.ST");



####### MERGE ######



#  Finally, merge the features, and add genes , and add strainding info

print "cat @files | awk '\$5-\$4>1' | sort -k1,1 -k9,9 -k4,4n > $ori_in.CDS \n " ;
print "~/bin/perl/fix_children_gff4Artemis.pl $ori_in.CDS $ori_in.CDS.gff \n " ;
print "~/bin/perl/gff2art.pl  $ori_in.CDS.gff \n " ;

system "cat @files | awk '\$5-\$4>1' | sort -k1,1 -k9,9 -k4,4n > $ori_in.CDS " ;
system "~/bin/perl/fix_children_gff4Artemis.pl $ori_in.CDS $ori_in.CDS.gff " ;
system "~/bin/perl/gff2art.pl  $ori_in.CDS.gff " ;



if (-s  "$ori_in.CDS.gff"  ) {
    print "Finished successfully\nYour result is $ori_in.CDS.gff \n";

}




exit;


__END__









#__END__



# read the junctions file, and make groups of junctions

system "perl ~/bin/perl/junctions2feature.pl $fas $in_plu.$cov.$anc.gff";
print "perl ~/bin/perl/junctions2feature.pl $fas $in_plu.$cov.$anc.gff\n";

system "perl ~/bin/perl/junctions2feature.pl $fas $in_min.$cov.$anc.gff";
print "perl ~/bin/perl/junctions2feature.pl $fas $in_min.$cov.$anc.gff\n";



print "\nSuccessful 4\n";




