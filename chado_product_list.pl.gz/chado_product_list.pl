#!/usr/local/bin/perl -w


use strict;


unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: chado_product_list.pl product-list infile outfile


Give the program the list of names, and it will split it to known and unknown product names

gff-markup-format
genename    <TAB>   /feature=""   <TAB>  /feature="" ....

'
}

	my $prod = shift;	
	my $in = shift;	
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (PR, "<$prod") || die "I can't open $prod\n";
	my @prod= <PR>;
	close (PR);

	open (OUTK, ">$out.known") || die "I can't open $out.known\n";
	open (OUTN, ">$out.new") || die "I can't open $out.new\n";


    # Read in product-names in a hash
    
    my %prods;

    foreach my $line (@prod) {
        chomp ($line);

        if ($line=~/\w/) {
        $prods{$line} = 1;
#        print "PROD1:$line\n";
        }
    }


        # Read in gene-names in a hash
    
    my %in;

    foreach my $line (@in) {
        chomp ($line);

        if ($line=~/\w/) {
        $in{$line} = 1;
#        print "GENE1:$line\n";
        }
    }


    # Read in new product-names and match
    
#        print "$arr[0]:$arr[1]\n";
#        print ":$arr[0]:$arr[1]:$arr[2]:\n";        
       
my %new;
my %seen;

         foreach my $line (sort keys %in) {
             chomp ($line);
             my @arr = split(/["\t]/, $line);
#                print ":$arr[0]:$arr[1]:$arr[2]:\n";


            foreach my $pro (keys %prods) {
#                print "PROD:$pro\n";


                if (exists $arr[2]) {


                    if ($arr[2]=~m/^\Q$pro\E$/ & $pro=~m/^\Q$arr[2]\E$/ ) {
                        #print "MATCH:$pro:$arr[2]\n";
                        print OUTK "$line\n";
                        $seen{$line} = 1;
                    }
                    else {
                        $new{$line} = 1;
#                       print OUTN "$line\n";
                    }

                }
                else {
                    print "not proper product:$line\n";
                }

            }
        }


        foreach my $line (sort keys %new) {
            unless (exists $seen{$line}) {
                   print OUTN "$line\n";
               }
        }

    close (OUTK);
    close (OUTN);
