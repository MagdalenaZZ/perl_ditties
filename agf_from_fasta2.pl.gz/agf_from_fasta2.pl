#!/usr/local/bin/perl -w
# mz3 script for making agp-file from scaffold-file

use strict;
use GetData;

my $N = 1;
my $std = 0; # the gap length of default gaps


unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: agp_from_fasta.pl <fasta-file>

'
}

my $scaffs = $ARGV[0];

open SCAFF, ">$scaffs.contigs_in_scaffs.fasta" || die "Can't open $scaffs.contigs_in_scaffs.fasta\n: $!\n";;
open SINGLE, ">$scaffs.contigs_singletons.fasta" || die "Can't open $scaffs.contigs_singletons.fasta\n: $!\n";;
open AGP, ">$scaffs.agp";

my %seqs = GetData::loadfasta($scaffs);

foreach my $key (sort keys %seqs) {
	my $agpcont = 1;
	my $pos = 1;
    my $seq =  $seqs{$key};
    $seq =~tr/[a-z]/[A-Z]/;
    $seqs{$key} = $seq;

    #print "$key\t$seqs{$key} \n";
#    $seqs{$key} = tr/[a-z]/[A-Z]/;

	if ($seqs{$key} =~ /N{$N,}/) {
        #print "has N\n";

        my @gaps = $seqs{$key} =~ m/N{$N,}/g;
		my @contigs = split (/N{$N,}/, $seqs{$key});
        my $index = 1;
        foreach my $contig (@contigs) {
        	my $conta = $key . "$index";
            $conta=~s/scaffold/contig/;

			my $l = length $contig;
            #print "contig $conta\t$l\n"; 
	        if ($l >= $N) {
                #print "$seqs{$key}\n";
                my $end = $pos+$l-1;
                $key = (split /\s+/, $key)[0]; ### WILL TAKE ONLY THE FIRST FIELD
				print SCAFF ">$conta\n$contig\n"; #<STDIN>;
				print AGP "$key\t$pos\t$end\t$agpcont\tW\t$conta\t1\t$l\t+\n";



				$pos += $l;
				my $gapend = 0;

				if ($index-1 < $#contigs) {
                    $agpcont++;
					my $lgap = length $gaps[$index-1];
                    if ($lgap == $std) {
                        $lgap =100;
					    $gapend = $pos+$lgap-1;
					    print AGP "$key\t$pos\t$gapend\t$agpcont\tU\t$lgap\tscaffold\tyes\tpaired-ends\n"; #<STDIN>;
					    $pos = $gapend+1;
                    }
                    elsif ( $lgap > 5000 ) { # in case the gap is very long
					    $gapend = $pos+$lgap-1;
					    print AGP "$key\t$pos\t$gapend\t$agpcont\tN\t$lgap\tscaffold\tyes\tmap\n"; #<STDIN>;
					    $pos = $gapend+1;
                    } 
                    else {
					    $gapend = $pos+$lgap-1;
					    print AGP "$key\t$pos\t$gapend\t$agpcont\tN\t$lgap\tscaffold\tyes\tpaired-ends\n"; #<STDIN>;
					    $pos = $gapend+1;
                    }
				}
				
				$index++;
                $agpcont++;
            }


        }

=pod

		foreach my $contig (@contigs) {
			my $l = length $contig;
			#print "contig$conta\t$l"; <STDIN>;
#			if ($l >= $minl) {
				#print $seqs{$key}; <STDIN>;
				my $end = $pos+$l-1;
				$key = (split /\s+/, $key)[0]; ### WILL TAKE ONLY THE FIRST FIELD
				print SCAFF ">$key\_$conta\n$contig\n"; #<STDIN>;
				print AGP "scaffold_$key\t$pos\t$end\t$agpcont\tW\t$key\_$conta\t1\t$l\t+\n";
				$agpcont++;
				$pos += $l;
				my $gapend = 0;
				if ($conta-1 < $#contigs) {
					my $lgap = length $gaps[$conta-1];
					$gapend = $pos+$lgap-1;
					print AGP "scaffold_$key\t$pos\t$gapend\t$agpcont\tN\t$lgap\tfragment\tyes\n"; #<STDIN>;
					$pos = $gapend+1;
#				}
				$conta++;
				$agpcont++;
			}
=cut	
    }
    else {
		#my $l = length $seqs{$key};
        #print "no N\n";

		my $seq = $seqs{$key};
		$key = (split /\s+/, $key)[0]; ### WILL TAKE ONLY THE FIRST FIELD
		print SINGLE ">$key\n$seq\n"; #<STDIN>;
	}
}

close AGP;
close SCAFF;
close SINGLE;



