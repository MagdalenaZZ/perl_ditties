#!/usr/bin/perl -w


if (@ARGV < 1 ) {
    print "\nUsage: R_signal_parser.pl Eset.signal.Rout \n\n\n" ;

    print "\nExample: R_signal_trainer.pl myv_COMBAT tmpsig Celltype~. 1412:1442 1:30 18\n\n\n" ;

        exit;
}




# Input
#
$rout= shift; # Expression set
#$signal=shift; # List of signal genes



open (IN, "<$rout") || die "I can't open $rout\n";


$/ = '>';

while (<IN>) {

    if ($_=~/^ confuMat/) {

        my @arr = split(/\n/,$_);
        print "#$arr[2]#\n";
    }

}




exit;



