#!/usr/bin/perl -w

use strict;
use File::Slurp;
use Cwd;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/embl_retrieve_sequence.pl input-folder


Input needs top be a folder of embl-files with annotation and sequences 
The output is a file not containing the sequence -only the annotation


'
}

my $folder = shift;

# Get the right info for the folder

my $cwd = cwd();

my @paths = read_dir( "$folder", prefix => 1 ) ;

if ($folder =~m/\//) {	
	if (-d "$folder") {
		print "If: $folder\n";
		foreach my $elem (@paths) {
			$elem = "$folder\/$elem";
            #print "$elem\n";
		}	
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}
else  {
	if (-d "$cwd\/$folder") {
		print "Else: $cwd\/$folder\n";
		foreach my $elem (@paths) {
			$elem = "$cwd\/$elem";
            #print "$elem\n";
		}		
	}
	else {
		print "Can\'t find folder $folder. Try giving full path.\n";
	}
}

open (OUT, ">temp") || die "I can't open temp\n";

#__END__

foreach my $elem (@paths) {
chomp $elem;
# print "$elem\n";
#}

#__END__
	if ($elem =~/\.embl/)  {
# Take each file in the folder
# chomp $elem;
	print "Elem:$elem:\n";
		my @arr = split(/\// ,$elem);
#	print "Arr1:$arr[-1]:\n";
		my $outfile = $arr[-1];
		$outfile =~s/short\.//;
		$outfile =~s/more\.//;
        #print "Out:$outfile:\n";

#Make input and output files
		open (IN, "<$elem") || die "I can't open $elem\n";
		open (OUT, ">$outfile.fas") || die "I can't open $outfile.fas\n";
		my @arr2 = <IN>;

# Parse the file
		foreach my $line (@arr2) {
			chomp $line;
		    if ($line=~/^\s+\d+\s+(\w+)\s+(\w+)\s+(\w+)\s+(\w+)\s+(\w+)\s+(\w+)/) {
                print OUT "$1$2$3$4$5$6\n";
            }
			

		}
        print "Results printed to file $outfile.fas\n";

    }

	close (IN);
	close (OUT);


}


exit;



