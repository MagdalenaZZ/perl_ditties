#!/usr/local/bin/perl -w


#
use strict;

unless (@ARGV ==3) {
        &USAGE;
}


sub USAGE {

die '
Usage: perl ~/bin/perl/augustus_fix_gff-coords.pl input.gff augustus.aa augustus.codingseq

Sequences as single lines

Example:
perl ~/bin/perl/augustus_fix_gff-coords.pl head.res head.AUGUSTUSnoH.aa head.AUGUSTUSnoH.codingseq


'
}

my $gff = shift;
my $aa = shift;
my $cs = shift;

	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (AA, "<$aa") || die "I can't open $aa\n";
	my @aa = <AA>;
	close (AA);

	open (CS, "<$cs") || die "I can't open $cs\n";
	my @cs = <CS>;
	close (CS);


# Make a hash with gene-name {aa} {cs} {coord} #####

my $gene; 
my %hash;

foreach my $line (@aa) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
#		print "Gene:$gene\n";
	}
	else  {
		$line=~s/\*//;
		$hash{$gene}{aa}=$line;
	}

}

foreach my $line (@cs) {
chomp $line;
	if ($line =~/^>/) {
		$line =~s/>//;
		$gene=$line;
#		print "Gene:$gene\n";
	}
	else  {
		$hash{$gene}{cs}=$line;
	}

}


foreach my $key (keys %hash) {

# print "HASHkey:$key:\n";
# print "Protein $hash{$gene}{aa}\n";
# print "Seq $hash{$gene}{cs}\n";

	open (TEMP, ">temp.fas") || die "I can't open temp.fas\n";
	print TEMP ">$gene\n$hash{$key}{cs}\n";
	close (TEMP);

	print "$key\t";
	system `transeq -sequence temp.fas -outseq temp.pep`;
#	print "$key\t";
	system `fasta2singleLine.py temp.pep temp.sl.pep`;

#print "Trans:" . `transeq $hash{$gene}{cs}` . "\n";
	open (TEMP2, "<temp.sl.pep") || die "I can't open temp.sl.pep\n";
	my @temp2 = <TEMP2>;
	close (TEMP2);
#	print "$temp2[0]$temp2[1]";

#count the bases

	my $b_count = $hash{$key}{cs} =~ tr/[acgtnACGTN]//;
	my $third = ($b_count/3)-1;
	my $a_count = $hash{$key}{aa} =~ tr/[A-Z]//;
#	my $GC_count = $line =~ tr/GgCc//;

#	print "$b_count\t$a_count\t$third\n";
# $hash{$key}{aa}\n$hash{$key}{cs}\n";

	 if ($third==$a_count) {
#		print "$key length correct $third\n";
		if ($hash{$key}{aa}=~/X/) {
			$hash{$key}{coord}="1";   #warn not X
			print "WARN: $key length only correct with X in seq $third\n";
		}
		else {
			$hash{$key}{coord}="0";
		}
	}
	 else {
		if ( $third=~/333333/) {
#		print "$key -1\n";
		$hash{$key}{coord}="-1";
		}
		elsif ($third=~/666666/) {
#		print "$key -2\n";
		$hash{$key}{coord}="-2";
		}
		else {
			print "WARN: $key length not correct $third\n";
		}
	}

# compare the bases 

	chomp $temp2[1];
	$temp2[1]=~s/\*//g;
	$hash{$key}{aa}=~s/\*//g;
	# If the sequences are identical - good
	if ($hash{$key}{aa}=~/$temp2[1]/ and $temp2[1]=~/$hash{$key}{aa}/) {
#		print "ID:$key\n$hash{$key}{aa}\n$temp2[1]\n";	
		$hash{$key}{off}="identical";
	}
	# if the sequence is contained, but probably just stop different
	elsif ($temp2[1]=~/$hash{$key}{aa}/) {
		$hash{$key}{off}="end";	
#		print "NOT SAME STOP:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
	}
	# if the sequences are different - bad
	else {
#		print "NOT SAME START:$gene\n$hash{$key}{aa}\n$temp2[1]\n";
		$hash{$key}{off}="start";	
		

	}
#	close (TEMP2);

#close (TEMP);


}

########### Fix the gene #################
my $firstCDS=0;
my $lastline="0\t0\t0\t0\t0\t0\t0\t0\t0";
push(@gff, "0\t0\tgene\t0\t0\t0\t0\t0\t0");
push(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
# unshift(@gff, "0\t0\t0\t0\t0\t0\t0\t0\t0");
my $end=0;
	open (GFF2, ">$gff.corrected") || die "I can't open $gff.corrected\n";


my $lasttag=0;

foreach my $line (@gff) {
chomp $line;


my @arr1=split(/\s+/, $line);
my @arr=split(/\s+/, $lastline);


# my $lasttag=0;
my $cds;
# print "LINE:$line\n";

	if ($arr1[2]=~/gene/) {
		#lastline is final CDS
		if ($lasttag=~/mRNA/) {
			$lasttag="singleCDS";
#			print "LINE:$line:\n";
#			print "LAST:$lastline:\n";
#			print "$lasttag\n";
		}
		else {
			$lasttag="finalCDS";
#			print "LINE:$line:\n";
#			print "LAST:$lastline:\n";
#			print "$lasttag\n";
		}
	}
	elsif ($arr1[2]=~/mRNA/) {
		#lastline is gene
		$lasttag="gene";
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

	}
	elsif ($arr1[2]=~/CDS/) {
		#lastline is mRNA and current CDS = firstCDS
		if ($arr[2]=~/mRNA/) {
			$lasttag="mRNA";
			# current line is firstCDS!
			$firstCDS=1;
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
		#lastline is CDS and current line CDS = middleCDS
		elsif ($arr[2]=~/CDS/ and $firstCDS=~/1/) {
			$lasttag="firstCDS";
			$firstCDS=0;
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
		elsif ($arr[2]=~/CDS/ and $firstCDS=~/0/) {
			$lasttag="middle";
#		print "LINE:$line:\n";
#		print "LAST:$lastline:\n";
#		print "$lasttag\n";

		}
				
	}
	elsif ($arr1[2]=~/^0$/) {
	}
	else {
		print "ERROR: $line\n";
	}

#	$lastline=$line;
#} # temp end



############## Get keys for lastline ##############################
my $key=0;

	if ($arr[2]=~/gene/) {
		$arr[8]=~s/ID=//;
		$key=$arr[8];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/mRNA/) {

		my @new =split(/;/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;

	}
	elsif ($arr[2]=~/CDS/) {
		my @new =split(/:/, $arr[8]);
		$key=$new[0];
		$key=~s/ID=//;
	}
	elsif ($arr[2]=~/0/) {
		# do nothing
	}
	else {
		print "ERROR: $line\n";
	}

	$lastline=$line;

# print "KEY:$key:\n";

##################################################################

	if ($key!~/^0$/ and $key=~/\w+/) {

		if (exists $hash{$key}{coord} and exists $hash{$key}{off}) {
#		print "$key\t$hash{$key}{coord}\t$hash{$key}{off}\n";
		my $coord="$hash{$key}{coord}";	
		my $off="$hash{$key}{off}";
#		if ($lasttag=~/mRNA/) {
#		print "REW:$lasttag\t$key\t$coord\t$off:\n";
#	}
		my $new;
# All well
			if ($coord=~/0/ and $off=~/identical/) {
				$new = join("\t", @arr);
#				print GFF2 "$new\n";
			}
# One off in start
			elsif ($coord=~/-1/ and $off=~/start/ and $arr[6]=~/\+/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] + 1);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}


# One off in end
# One off in end, but unaffected line
			elsif ($coord=~/-1/ and $off=~/end/ and $arr[6]=~/\+/) {
				if ( ($lasttag=~/lastCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] - 1);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}


# Two off in start
# Two off in start, but unaffected line
			elsif ($coord=~/-2/ and $off=~/start/ and $arr[6]=~/\+/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -2\n";
#					}
					$arr[3]= ($arr[3] + 2);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}

# Two off in end
# Two off in end, but unaffected line
			elsif ($coord=~/-2/ and $off=~/end/ and $arr[6]=~/\+/) {
				if ( ($lasttag=~/lastCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] - 2);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}




############ negative values ################################


# One off in start
			elsif ($coord=~/-1/ and $off=~/start/ and $arr[6]=~/\-/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/lastCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] - 1);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}


# One off in end
# One off in end, but unaffected line
			elsif ($coord=~/-1/ and $off=~/end/ and $arr[6]=~/\-/) {
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] + 1);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# One off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}

# Two off in start
# Two off in start, but unaffected line
			elsif ($coord=~/-2/ and $off=~/start/ and $arr[6]=~/\-/) {
				if ($lasttag=~/mRNA/) {
#				print "REW:$lasttag\t$key\t$coord\t$off:\n";
				}
				if ( ($lasttag=~/lastCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -2\n";
#					}
					$arr[3]= ($arr[3] - 2);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in start, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}

# Two off in end
# Two off in end, but unaffected line
			elsif ($coord=~/-2/ and $off=~/end/ and $arr[6]=~/\-/) {
				if ( ($lasttag=~/firstCDS/) or ($lasttag=~/singleCDS/) or ($lasttag=~/gene/) or ($lasttag=~/mRNA/) ) {
					#change line
#					if ($arr[2]=~/gene/) {
						print "$lasttag\t$key adjust start with -1\n";
#					}
					$arr[3]= ($arr[3] + 2);
					$new = join("\t", @arr);
					print GFF2 "$new\n";
				}
# Two off in end, but unaffected line
				else {
					$new = join("\t", @arr);
					print GFF2 "$new\n";
					print "$lasttag\t$key not adjusted\n";
				}
			}


# catch exceptions #######################
			else {
				print "WARN:$key has inconsistent values\n";
			}

########################################




		}
		else {
			print "WARN:$key does not have sequence\n";
		}
	}
	else {
		print "WARN:$key is not 0 or word\n";
	}

}




close (GFF2);






__END__
