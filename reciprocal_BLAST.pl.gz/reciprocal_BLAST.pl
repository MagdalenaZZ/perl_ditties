#
# This text file contains concatenated Perl scripts, as used for data compilation and analysis of
# the paper 'Phylogenomic analysis reveals bees and wasps (Hymenoptera) at the base of the radiation
# of Holometabolous insects' by Joel Savard et al.. 
#
# To run them, you first need to cut them were indicated, save them as independent files, and then 
# run them under Perl with the appropriate command line arguments. 
#
# The relevant extract from the 'MJL_dataUtils' package is at the end of this file; please save this 
# in the same directory as any script that needs it (mostly for convenient input of FASTA format 
# files).
#
# For questions, please contact the last author at M.J.Lercher@bath.ac.uk.




###################################################################################################
#                                                                                                 #
# This program tests for full orthology by reciprocal blast                                       #
#                                                                                                 #
###################################################################################################

#!/usr/bin/perl
use strict ;

my $eCutoff		= 1e-25	; # only accept hits below this e-value cutoff - should be 1 for the first run!!!!

my $base 		= 'Lm2006' ;
my $execPath	= '/usr/bin/blastall' ;
my $outFile2	= $base . "Reciprocals$eCutoff.tab" ;

my @species  = ('Dm', 'Ag', 'Bm', 'Tc', 'Am', 'Am2', 'Nv', 'Ng', 'Ap', 'Hc', 'Da') ;	# excluding Lm
my %fullName = (	# these are the names of the BLAST databases
		'Dm' => 'D_melanogasterNR' ,
		'Ag' => 'A_gambiaeNR' ,
		'Bm' => 'B_moriNR' ,
		'Tc' => 'T_castaneumNR' ,
		'Am' => 'A_melliferaNR' ,
		'Am2' => 'A_mellifera2NR' ,
		'Nv' => 'N_vitripennisNR' ,
		'Ng' => 'N_giraultiNR' ,
		'Lm' => 'L_migratoriaNR' ,
		'Ap' => 'A_pisumNR' ,
		'Hc' => 'H_coagulataNR' ,
		'Da' => 'D_magnaNR' ) ;

my $blastExec 	=  "$execPath -p blastp -a 4 -v 1 -b 1 -I T -e $eCutoff " ;

my @species1 = @species ; # or: my @species1 = @species[0..2]

###################################################################################################
# take Locusta hits in each species from files, and then blast everybody's sequences against everybody else:
my %hits = () ;
foreach my $s1 (@species1) {
	# make lookup table query->hit for Locusta:
	%{$hits{Lm}{$s1}} = readBlast("${base}Lm$s1.tab") ;
	# blast against all:
	my $query 	  = "$base${s1}Acc.fa" ;
	foreach my $s2 ('Lm', @species) {
		next if ($s1 eq $s2) ;
		my $outFile  = "$base$s1$s2.bls" ;
		my $outFileS = "$base$s1$s2.tab" ;
		print "blasting $fullName{$s1} -> $fullName{$s2} ...\n" ;
		`$blastExec -i $query -o $outFile -d $fullName{$s2}` unless ((-f $outFile) || (-f $outFileS)) ; #skip if done before...
		processBLAST ($outFile, $outFileS) unless (-f $outFileS) ;
		# make lookup table query->hit (check for reciprocal  best hits with this later):
		%{$hits{$s1}{$s2}} = readBlast($outFileS) ;
	}
}

###################################################################################################
# check for reciprocal  best hits (all pairwise comparisons):
open (OUT, ">$outFile2") || die ;
print OUT "L_migratoria" ;
push @species, 'Lm' ;
foreach my $s (@species) {
	print OUT "\t$fullName{$s}" ;
}
foreach my $s1 (0..$#species) {
	foreach my $s2 ($s1+1 .. $#species) {
		print OUT "\t$species[$s1]$species[$s2]" ;
	}
}
print OUT "\n" ;

foreach my $t (keys %{$hits{Lm}{Dm}}) {
	next unless $hits{Lm}{Dm}{$t} ;
	$hits{Lm}{Lm}{$t} = $t ;	# to find back the Locusta gene itself
	print OUT $t ;
	foreach my $i1 (0..$#species) {
		my $h1 = $hits{Lm}{$species[$i1]}{$t} || 0 ;
		print OUT "\t$h1" ;
	}

	# check for pairwise reciprocity:
	foreach my $i1 (0..$#species) {
		my $s1 = $species[$i1] ;
		my $h1 = $hits{Lm}{$s1}{$t} ;
		foreach my $i2 ($i1+1 .. $#species) {
			my $s2 = $species[$i2] ;
			my $h2 = $hits{Lm}{$s2}{$t} ;
			my $s1_s2 = $h1 && $hits{$s1}{$s2}{$h1} ;
			my $s2_s1 = $h2 && $hits{$s2}{$s1}{$h2} ;
			my $rec = ($h1 && $h2 && ($s1_s2 eq $h2) && ($s2_s1 eq $h1)) || 0 ;
			print OUT "\t$rec" ;
		}
	}
	print OUT "\n" ;
}
close OUT ;

###################################################################################################

sub readBlast {
	my $file = $_[0] ;
	my %hash ;
	$hash{'-'} = 0 ;
	open (IN, $file) || die "couldn't open $file" ;
	<IN> ;
	while (<IN>) {
		chomp ;
		my @l = split ("\t", $_) ;
		next if ($eCutoff && ($l[4] > $eCutoff)) ;	## new line to exclude distant hits
		$hash{$l[0]} = ($l[2] ne '-') ? $l[2] : 0 ;
	}
	close IN ;
	return %hash ;
}
