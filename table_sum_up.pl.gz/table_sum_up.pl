#!/usr/local/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: table_sum_up.pl merged.tab


Sums up values with identical headers


DOESNT WORK!!!!



'
}



my $data = shift;

open(DATA, "<$data") or die "Cant find file $data\n  $!";

chomp(my $head = <DATA>);

#print "$head\n";

my @arr1 = split(/\t/,$head);

my $col = scalar(@arr1);

#print "$col\n";


### determine which should be merged


my %seen;

my $index = 1;

foreach my $elem (@arr1) {
    if (exists $seen{$elem}) {
        #push (@{$seen{$elem}} , $index);
        $seen{$elem}{$index} =  1;
        
    }
    else {
        $seen{$elem}{$index} =  1;
    }
    $index ++;
}


use Data::Dumper;
#print Dumper(%seen);


my %res;

foreach my $key (sort keys %seen ) {
#    print "$key\n";

#    foreach my $ele ( @{$seen{$key}} ) {
        #print "$ele\n";

            #if (exists $h{$ele} ) {
            #print "exists $ele\n";
            #}
#    }
}





my %h;

$index = 1;

while (<DATA>) {

    my @arr = split(/\t/,$_);

    foreach my $elem (@arr) {
        foreach my $ke ( %seen ) {
            if (exists $seen{$ke}{$index} ) {
                push( @{$h{$ke}{$index}}, $elem );
                #print "$ke\t$index\t$elem\n";
            }
        }

    }

    $index++;

}




close DATA;



for ( my $i = 0 ;$i < $index ; $i--  ) {

    foreach my $el (sort keys %h) {

        foreach my $ele (sort keys %{$h{$el}}  ) {
            my @arr = @{$h{$el}{$ele}}; 
            #print ":$el:\t:$ele:@arr\n";
            print "@arr\n";

        }
    }
}





exit;
