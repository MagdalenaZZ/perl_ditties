#!/usr/bin/perl -w

use strict;

unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/embl_split.pl input


Input needs to be an embl-file with sequences delimited by //


'
}

my $in = shift;

#system "cat $in | grep -w -i -e ID -e FH -e FT -e SQ > $in.all";
open (IN, "<$in") || die "I can't open $in\n";

my @list = <IN>;

open (OUT, ">tmp") || die "I can't open tmp\n";

# $\ = "ID";

foreach my $elem (@list) {

	unless ($elem=~/^ID/) {
	print OUT "$elem";
	}
	if ($elem=~/^ID/) {
		close (OUT);
		my @arr = split(/\s+/, $elem);
#		print "Arr1: $arr[1]\n";
#		my $length =length($arr[1]);
#		print "Length:  $length\n";
#		my $arr2 = $arr[1];
#		chomp $arr2;
		$arr[1]	=~ s/;//;
#		print "Arr2: $arr[1]\n";
		open (OUT, ">$arr[1].embl") || die "I can't open $arr[1].all.embl\n";
		print OUT "$elem";
	
	}

}

close (IN);

system "rm -f tmp";