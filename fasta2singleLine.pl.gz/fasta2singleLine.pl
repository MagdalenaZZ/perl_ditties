#!/usr/local/bin/perl -w

# mz3 script for making sl fasta


use strict;

#unless (@ARGV > 1) {
#        &USAGE;
#}

my $fasta = shift;
my $i=shift;

open (IN, $fasta);
open (OUT, ">$fasta.sl");

my @fasta = <IN>;

my $head="";
my $fas="";

my %fas;
my @order;


foreach my $line (@fasta) {
   chomp $line;

	if ($line=~/\>/) {

        push(@order, $line);
        
        if ($fas=~/\w+/) {
            $fas{$head}=$fas;
            $fas="";
        }
        $head=$line;

	}
	else {
    		$fas="$fas"."$line";
	}

}

$fas{$head}=$fas;


if ($i=~/m/) {
$i=~s/m//;
my $m= $i;

#print "$i\t$m\n";

foreach my $hd (@order) {

     
    if (exists $fas{$hd}) {

        print OUT "$hd\n";
    my @array;
    for ($i = 0; $i < length($fas{$hd}); $i += $m){
        push(@array, substr($fas{$hd}, $i, $m));
    }
    print OUT join("\n", @array) ."\n";
#        my @pairs = $fas{$hd} =~ /$m/sg;  # Accepts odd-length strings.

#        print "Last $fas{$hd}\n";
#        foreach my $elem(@pairs) {
#            print OUT "$elem\n";
#        }

    }
    else {
        print "Empty header: $hd\n";
    }
}

}

else {
foreach my $hd (@order) {

     
    if (exists $fas{$hd}) {
        print OUT "$hd\n$fas{$hd}\n";
    }
    else {
        print "Empty header: $hd\n";
    }
}

}


exit;


__END__

