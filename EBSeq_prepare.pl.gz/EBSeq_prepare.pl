


=pod
3.1 Gene Level DE Analysis (Two Conditions)
3.1.1 Required input
Data: The object Data should be a G 􀀀 by 􀀀 S matrix containing the
expression values for each gene and each lane (sample), where G is the number
of genes and S is the number of lanes. These values should exhibit raw counts,
without normalization across samples. Counts of this nature may be obtained
from RSEM [4], Cuinks [6] or other such pre-processing approaches.
Conditions: The object Conditions should be a Factor vector of length S
that indicates to which condition each sample belongs. For example, if there
are two conditions and three samples in each, S = 6 and Conditions may be
given by
as.factor(c("C1","C1","C1","C2","C2","C2"))
=cut

=pod
3.2.1 Required inputs
Data: The object Data should be a I 􀀀 by 􀀀 S matrix containing the
expression values for each isoform and each lane, where I is the number of
isoforms and S is the number of lanes. Again, these values should exhibit raw
data, without normalization across samples.
Conditions: The object Conditions should be a vector with length S to
indicate the condition of each sample.
IsoformNames: The object IsoformNames should be a vector with length I
to indicate the isoform names.
IsosGeneNames: The object IsosGeneNames should be a vector with length
I to indicate the gene
=cut

