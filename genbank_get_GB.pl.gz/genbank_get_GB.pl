#!/usr/bin/perl -w


# use strict;


use LWP::Simple;


unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die '


Usage: genbank_get_GB.pl   all.blast   number   outprefix

# Takes a tab-file fasta output and return the full record for those

all.blast - your GenBank output
number - number of hits/file - integer less than 1000 - preferably 100
outprefix - whatever you want your outprefix to be


Preferably go to a new folder, because this script will output lots of files

After you have done this - go to next step:
run 

genbank2similarity.pl



'
}

	my $in = shift;
	my $number = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	open (EXC, ">exception.list") || die "I can't open exception.list\n";
	my @in = <IN>;
	close (IN);


my %hash;

if ($in=~m/exception.list/) {
    print "Reading the exceptions-file\n";
    foreach my $line (@in) {
        chomp $line;
        $hash{$line} = 1;
    }
}
else {

    foreach my $line (@in) {

        @arr=split(/([|\t])/, $line);
#	print "$arr[0]\t$arr[8]\n";
        if ($arr[8] =~/\./) {
            push (@{$hash{$arr[8]}}, $arr[0]);
#	push(@{$hash{$key}}, $newline);
        }
        elsif ($arr[8] =~/\w+/) {
            my $newarr8 = "$arr[8]" . "_" . "$arr[10]";
#		print "$newarr8\n";
            push (@{$hash{$newarr8}}, $arr[0]);
        }
        else {
#	print "Else:$arr[8]:\n";
        }

    }

}


my @gblist;

foreach my $key (sort keys %hash) {
# print "Key: $key\t\n";
# print OUT "Key: $key\t\n";
push (@gblist, $key);
}


# Get an array-slice with $number IDs and send the job then sleep
$length = (scalar (@gblist) -1);

# print "Length: $length\n";
my $length2 = $length;

for (my $i=0; $i<$length2; $i=$i+$number) {
	my $number1 = ($number - 1);
	my $hundred = ($i+$number1);
#	print "Hunderd: $hundred\n";
#	print "Length: $length\n";
	if  ($length <= $hundred) {
		$hundred = $length;
#		print "Else\n";
	}
#	print "First: $i\n";
#	print "Hunderd2: $hundred\n";
	my $gi_list = join(" ", @gblist[$i..$hundred]);

	system "python ~/bin/python/get_BG.py $gi_list >  $out\.$i\-$hundred.gb \n";
	sleep(3);

}



close (EXC);
close (OUT);


