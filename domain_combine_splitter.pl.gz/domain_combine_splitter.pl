#!/usr/local/bin/perl -w
# mz3 script for splitting a pfam-file into species
#
use strict;
use File::Slurp;
use Cwd;

unless (@ARGV == 1) {
        &USAGE;
 }

 sub USAGE {

die 'Usage: domain_combination_splitter.pl <input.pfam> 


Assumes that species differ by their prefix ex:  EmW_ , DRE_

'
}

### this is the splitter-part of the script ####

my $in = shift;

mkdir "$in.res";

my %fi;

open (IN, "<$in");
my @in = <IN>;
close (IN);

chdir "$in.res";

foreach my $line (@in) {
    chomp $line;
    my @arr = split(/\s+/, $line);
    my @id = split(/_/, $arr[0]);
#    print "$id[0]\t$arr[6]\n";
    $id[0]=~s/^\>//; 
    open (OUT, ">>$id[0].pfam");

    print OUT "$line\n";

    close (OUT);

}



my $cwd = cwd();

my @files = read_dir( "$cwd", prefix => 1 ) ;

  

foreach my $file (@files) {

    if ($file =~/\w+.pfam/) {
        print "bsub.py 20 $file.dc perl ~/bin/perl/domain_compare_cluster.pl $file\n";

        system "bsub.py 20 $file.dc perl ~/bin/perl/domain_compare_cluster.pl $file";
    }

}


chdir "..";

exit;


__END__


#my $length = scalar(@in);

#my $targetsize = 50*1024*1024;
my $targetsize = $size;
my $fileprefix = $out;
my $outfile = 0;
my $outsize = 0;
my $outfh;
my $temp='';

local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
#  print "LINE:$line:\n"; 
  next unless $line;
  # discard initial empty chunk  
#  if($line =~ /^\$\$$/ || $outfile == 0){
  if($line =~m/\_/ || $outfile == 0){
        $outsize += length($temp);
#        print "SIZE:$outsize:\n";
        if ( $outfile == 0 || ($outsize - $targetsize) > 0)  { 
              ++$outfile; 
              if($outfh) {close($outfh);}
              open ($outfh, '>', "$fileprefix\_$outfile"); 
              push (@files,  "$fileprefix\_$outfile" );
#              print "$outfh\t$fileprefix\_$outfile\n";
              $outsize = 0;
        }
        $temp='';
    }
  $temp = $temp.$line;
  print $outfh "\>$line";  
} 

######################
#
#
#
# make a shell-file
foreach my $file (@files) {
# my $format = "summary";
print "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -pfamB -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam\n";
system "bsub.py -q basement 5 $file  /software/pathogen/external/applications/pfam_scan/bin/pfam_scan.pl -pfamB -dir /data/blastdb/Supported -fasta $file -outfile $file.pfam";
}




