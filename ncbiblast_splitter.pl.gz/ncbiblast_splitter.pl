#!/usr/local/bin/perl -w
# mz3 script for splitting a protein-file to several blast jobs

use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;


unless (@ARGV > 3) {
        &USAGE;
 }

 sub USAGE {

die '


Usage: ncbiblast_splitter.pl <input.fa> <program> <database> <seqtype>
prefix = prefix for the output filename


program - blastp, blastx, blastn tblastn, tblastx 

databases - PROTEIN -  intact, uniref90, uniprotkb_eukaryota, uniprotkb
databases - NUCLEOTIDE -  em_rel
more database options available on: perl ~/bin/perl/ncbiblast_lwp.pl --paramDetail database


seqtype - dna or protein




'
}

my $in = shift;
my $p = shift;
my $db = shift;
my $stype  = shift;


# read in the fasta-file and break it into separate files

system "mkdir blasts_$in";
chdir "blasts_$in";
system "ln -s ../$in";
system "perl ~mz3/bin/perl/fastn_splitter.pl 1 $in "; 
system "rm -f $in";


# send out 25 blastjobs

my $cwd = cwd();
my @paths = read_dir( "$cwd", prefix => 1 ) ;

my $i = 0;

foreach my $file (@paths) {

    for ($i < 25; $i++) {
        print "perl ~mz3/bin/perl/ncbiblast_lwp.pl --quiet -p blastp -D uniprotkb --stype protein --outformat 8 --outfile $file.blast --email mz3\@sanger.ac.uk  $file\n";
    }
}






# check if they have finished

# send out 25 more jobs e.t.c.



# ncbiblast_lwp.pl --quiet -e 0.0001
