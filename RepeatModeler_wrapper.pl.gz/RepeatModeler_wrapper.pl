#!/usr/bin/perl -w


use strict;

unless (@ARGV ==1 ) {
        &USAGE;
}


sub USAGE {

die 'Usage: RepeatModeler_wrapper.pl file.fasta


Takes a fasta-file, remakes it for RepeatModeler, makes index and suggests a commanline





'
}

my $in = shift;

unless (-s $in) {
 die "Check that your fasta-file $in is correct and restart \n";
}


system "perl ~mz3/bin/perl/fasta_rename.pl $in LIST $in.rm";


system " ~mz3/bin/AB-BLAST/xdformat -n -I -o $in.rm $in.rm";


print "~mz3/bin/RepeatModeler/RepeatModeler  -database $in.rm  \n";
exit;



__END__
open (IN, "<$in") || die "I can't open $in\n";
my @in= <IN>;
close (IN);





