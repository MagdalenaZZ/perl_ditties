#!/usr/bin/perl -w

use strict;




unless (@ARGV == 1) {
	print "Usage: nucmer_parser_IRs.pl nucmer.coords \n\n" ;

    print " mz3 script for retriveing invert repeats from nucmer output \n\n";

	exit ;
}

my $nuc = shift;
my %reads = () ;

open (IN, "$nuc") or die "oops!\n" ;
open (OUT, ">$nuc.IRs.gff") or die "oops!\n" ;

while (<IN>) {
	chomp;
    $_=~s/\|/ /g;
    $_=~s/^\s+//g;

	my @arr = split(/\s+/, $_);
    #$reads{$line[0]}++ ;
    #print ":$arr[1]:\t:$arr[2]:\t:$arr[3]:\t:$arr[4]:\n";

     # get hit lines
    if (scalar(@arr)> 5) {  

        #my ($qs,$qe) = split(/\s+/, $arr[1]);
        #print "QEQS:$arr[1]:\t:$qs:\t:$qe:\n";
        #
        if ($arr[1]=~/^\d+$/) {

            #print scalar(@arr) . "\n";

            #if (scalar(@arr) > 9) {
                #print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$arr[9]\n";
                #}
            #else {
                #print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
                #}
            #\t:$arr[1]:\t:$arr[2]:\t:$arr[3]:\t:$arr[4]:\n";


            # find self-hits
            if ($arr[0]=~/$arr[2]/ and $arr[1]=~/$arr[3]/ and $arr[7]=~/$arr[8]/) {
                #print "$arr[0]\t$arr[1]\t$arr[3]\t$arr[2]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
            }
            # find non-same contig matches
            elsif ($arr[7]!~$arr[8]) {
                #print "$arr[7]\t$arr[8]\n";
            }
            # find the ones that are parallell
            if ( ($arr[1] < $arr[4] ) and  ($arr[2] < $arr[5])  ) {
                #print "PARA $arr[1]\t$arr[4]\t$arr[2]\t$arr[5]\n";
            }
            # find the ones that are reverse parallell
            elsif ( ($arr[1] > $arr[4] ) and  ($arr[2] > $arr[5])  ) {
                #print "REVPAR $arr[1]\t$arr[4]\t$arr[2]\t$arr[5]\n";
            }
            # find the ones that are reverse parallell
            elsif ( ($arr[1] > $arr[4] ) and  ($arr[2] < $arr[5])    ) {
                #print "IR1 $arr[1]\t$arr[4]\t$arr[2]\t$arr[5]\n";
            }
            elsif ( ($arr[1] < $arr[4] ) and  ($arr[2] > $arr[5])   ) {
                #print "IR2 $arr[1]\t$arr[4]\t$arr[2]\t$arr[5]\n";
            }
            #elsif ($arr[10] < 80) {
                #print "Bad similarity ID\n";
                #}
            else {
                #print "$arr[1]:$arr[4]\t:$arr[2]:$arr[5]:\t:$arr[7]:$arr[8]:\t:$arr[10]:\t:$arr[12]\t$arr[13]:\n";
            }
        }
        else {
            #print "ELSE1\t:$_\n";
        
        }
     }
     else {
         #print "$_\n";
     }


}
close(IN) ;
close(OUT) ;


__END__

while (<IN>) {

    # print "$_" ;

    if (/^>(\S+)/) {

	my $seq_name = $1;
	 $seq_name=~s/>//;
	my $seq = <IN> ;
	chomp($seq) ;
#	print "SEQname:$seq_name:\n";	
	if ($reads{$seq_name} ) {
			print OUT ">$seq_name\n" ;
			print OUT "$seq\n" ;

	}
    else {
			print OUT2 ">$seq_name\n" ;
			print OUT2 "$seq\n" ;

    }


    }
	
    
    #last;


}

close (OUT);
close (OUT2);

#print "\#\#the largest length is: $contig with $largest bp \n" ;
