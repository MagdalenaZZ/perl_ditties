#!/usr/bin/perl -w

use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {




    die '

    Usage: heatmap_from_counts.pl merged.RPKM

    file-format:

    ID-line Treatment.rep Treatment.rep 
    Gene    RPKM    RPKM



' . "\n";
}


# Read in file and clean it up
my $in = shift;
open (IN, "<$in")|| die;
open (R, ">$in.R")|| die;

my @in = <IN>;

my $header = shift @in;

my @arr = split(/\s+/, $header);
my $id = shift @arr;

my @pe;

foreach my $elem (@arr) {
#    my @arr2 = split(/\./, $elem);
#    $elem = $arr2[0];
    push (@pe, "paired-end");
}

#print "@arr\n";

print "\n";




# Print R header

print R "library(DESeq)\n";
print R "pasillaCountTable<-read.table(\"$in\", header=TRUE, row.names=1)\n";



# Print 

my $pas = join("\", \"", @arr );
my $pe = join("\", \"", @pe );

print R "pasillaDesign = data.frame(row.names = colnames( pasillaCountTable ), condition = c(\"$pas\") ";
 
print R ", libType = c( \"$pe\" ) )\n";



# Print R calculations
#
print R "cdsFull = newCountDataSet( pasillaCountTable, pasillaDesign )\n";
print R "cdsFull = estimateSizeFactors( cdsFull )\n";
print R " cdsFull = estimateDispersions( cdsFull )\n";


# make heatmap from count-table

print R " pdf(\"$in.genes_clustered.pdf\")\n";


print R '

cdsFullBlind = estimateDispersions( cdsFull, method = "blind" )
vsdFull = varianceStabilizingTransformation( cdsFullBlind )
library("RColorBrewer")
library("gplots")
#select = order(rowMeans(counts(cdsFull)), decreasing=TRUE)[1:30]
select = order(rowMeans(counts(cdsFull)), decreasing=TRUE)
hmcol = colorRampPalette(brewer.pal(9, "GnBu"))(100)
heatmap.2(exprs(vsdFull)[select,], col = hmcol, trace="none", margin=c(10, 6))

';

print R "dev.off()\n";


# make heatmap from cluster distances
#print R " pdf(\"$in.heatmap.pdf\")\n";

print R "
dists = dist( t( exprs(vsdFull) ) )
mat = as.matrix( dists )
rownames(mat) = colnames(mat) = with(pData(cdsFullBlind), paste(condition, libType, sep=\" :\"))
#heatmap.2(mat, trace=\"none\", col = rev(hmcol), margin=c(13, 13))
";
#print R "dev.off()\n";



print R "pdf(\"$in.heatmap.pdf\")\n";
print R '

heatmap( as.matrix( dists ),symm=TRUE, scale="none", margins=c(20,20),col = colorRampPalette(c("seagreen","blanchedalmond","darkred" ))(100),labRow = paste( pData(cdsFullBlind)$condition, pData(cdsFullBlind)$libType ) )

';
print R "dev.off()\n";


# Principal component plot of the samples

print R " pdf(\"$in.PCA.pdf\")\n";
print R ' print(plotPCA(vsdFull, intgroup=c("condition", "libType")))

';
print R "dev.off()\n";




close (R);


system "R CMD BATCH  $in.R";


__END__

library(DESeq)


# read in datafile in R

countTable<-read.table("EMU.merged.reads.txt", header=TRUE, row.names=1)

condition = c("7745_8-3", "7745_8-4", "7745_8-5", "7745_8-6", "7745_8-7", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu")


#cds = newCountDataSet( countTable, condition )
 cds = estimateSizeFactors( cds )
sizeFactors( cds )
cdsFull = newCountDataSet( countTable, pasillaDesign )


# make heatmap from count-table

print R '
cdsFullBlind = estimateDispersions( cdsFull, method = "blind" )
vsdFull = varianceStabilizingTransformation( cdsFullBlind )
library("RColorBrewer")
library("gplots")
select = order(rowMeans(counts(cdsFull)), decreasing=TRUE)[1:30]
hmcol = colorRampPalette(brewer.pal(9, "GnBu"))(100)
heatmap.2(exprs(vsdFull)[select,], col = hmcol, trace="none", margin=c(10, 6))

';


# make heatmap from cluster distances

print R '

dists = dist( t( exprs(vsdFull) ) )
mat = as.matrix( dists )
rownames(mat) = colnames(mat) = with(pData(cdsFullBlind), paste(condition, libType, sep=" : "))
heatmap.2(mat, trace="none", col = rev(hmcol), margin=c(13, 13))

';


# Principal component plot of the samples

print R ' print(plotPCA(vsdFull, intgroup=c("condition", "libType")))

';


pasillaDesign = data.frame(
 row.names = colnames( countTable ), 
 condition = c("aPS", "aPS", "aPS", "MCana", "MCana", "MCana", "MCnoBC", "MCnoBC", "MCnoBC", "MCu", "MCu", "MCu", "MCvitro", "MCvitro", "MCvitro", "MCvivo", "MCvivo", "MCvivo", "naPS", "naPS", "naPS", "PC1-2", "PC1-2", "PC1-2", "PC2", "PC2", "PC2", "PC3", "PC3", "PC3")
, libType = c( "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end", "paired-end", "paired-end",  "paired-end" ) )



condition = c("aPS", "aPS", "aPS", "MCana", "MCana", "MCana", "MCnoBC", "MCnoBC", "MCnoBC", "MCu", "MCu", "MCu", "MCvitro", "MCvitro", "MCvitro", "MCvivo", "MCvivo", "MCvivo", "naPS", "naPS", "naPS", "PC1-2", "PC1-2", "PC1-2", "PC2", "PC2", "PC2", "PC3", "PC3", "PC3")



pasillaDesign = data.frame(  row.names = colnames( countTable ), condition = c("7745_8-3", "7745_8-4", "7745_8-5", "7745_8-6", "7745_8-7", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu", "naPS", "aPS", "PC1", "PC2", "PC3", "MCnoBC", "MCvitro", "MCvivo", "MCanaerob", "MCu") , libType = c( "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end", "paired-end" ) )


cdsFull = newCountDataSet( pasillaCountTable, pasillaDesign )
cdsFull = estimateSizeFactors( cdsFull )
cdsFull = estimateDispersions( cdsFull )
