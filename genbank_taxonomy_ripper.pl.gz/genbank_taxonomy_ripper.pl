#!/usr/bin/perl -w


use strict;
unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: genbank_taxonomy_ripper.pl  names.dmp nodes.dmp 

Give a list of gene-names and product description
This program filters the list and rationalises gene-names to give the most popular name


WARNING: not finished

'
}


	my $name = shift;
	my $node = shift;

	my $out = shift;


	open (IN2, "<$node") || die "I can't open $node\n";

my %nodes;


# read in fitting nodes

while (<IN2>) {
    chomp;
        my @arr = split("\t", $_);
    unless (exists $nodes{$arr[0]}) {
        $nodes{$arr[0]}=$arr[1];
        print "$arr[0]\t$arr[2]\t$arr[4]\n";
    }
}

close (IN2);




	open (IN, "<$name") || die "I can't open $name\n";
	
my %names;

# read in fitting names
while (<IN>) {
    chomp;
        my @arr = split("\t", $_);
    unless (exists $names{$arr[0]}) {
        $names{$arr[0]}=$arr[1];
        #print "$arr[0]\t$arr[2]\n";
    }
}

close (IN);
