#!/usr/bin/perl -w

use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: hmmer2BLAT.pl hmm3_result.tblout

Takes a hmmer-output, and turns it into BLAT output


' . "\n";
}



my $in = shift;


# read in BLAT into a hash of hashes, with hit-name as key, and full line after
# merge overlapping hits to the longest

open (IN, "<$in")|| die;
open (OUT, ">$in.psl")|| die;



while (<IN>) {
    chomp;


    #print "$_\n";
    my @arr = split(/\s+/, $_);

    if (scalar(@arr)>21 ) {

        if ($arr[19]=~/\D+/ or $arr[18]=~/\D+/) {
            #print "WORD $_\n";
        }
        else {
        my $match = $arr[18]-$arr[17];
        my $mismatch = "0";
        my $repmatch = "0";
        my $Ns = "0";
        my $QgapCount = "0";
        my $QgapBases = "0";
        my $TgapCount = "0";
        my $TgapBases = "0";
        my $strand = "\.";
        my $Qname = $arr[0];
        my $Qsize = $arr[2]; # Qsize
        my $Qstart = $arr[17];
        my $Qend = $arr[18];
        my $Tname = $arr[3];
        my $Tsize = $arr[5]; # Tsize
        my $Tstart = $arr[15];
        my $Tend = $arr[16];
        my $block = "0";
        my $blockSizes= "0";
        my $Qstarts= "0";
        my $Tstarts= "0"; 

        print OUT "$match\t$mismatch\t$repmatch\t$Ns\t$QgapCount\t$QgapBases\t$TgapCount\t$TgapBases\t$strand\t$Qname\t$Qsize\t$Qstart\t$Qend\t$Tname\t$Tsize\t$Tstart\t$Tend\t$block\t$blockSizes\t$Qstarts\t$Tstarts\n";
        }
    }
    else {
        #print "$_\n";
    }

}



close(OUT);

exit;



__END__


*          *                        *               *       *       *                   *       *      

0          1    2       3   4       5          6    7       8       9           10      11      12  13          14      15      16      17      18      19          20

match	mis- 	rep. 	N's	Q gap	Q gap	T gap	T gap	strand	Q        	Q   	Q    	Q  	T        	T   	T    	T  	block	blockSizes 	qStarts	 tStarts
     	match	match	   	count	bases	count	bases	      	name     	size	start	end	name     	size	start	end	count


72	6	0	0	0	0	0	0	+	HS21_13036:1:1101:1000:3863#20/1	100	18	96	F9_1016967	78	0	78	1	78,	18,	0,
71	0	0	0	1	7	1	5	+	HS21_13036:1:1101:1000:3863#20/1	100	18	96	F99_22714	78	0	76	2	35,36,	18,60,	0,40,
77	1	0	0	0	0	0	0	+	HS21_13036:1:1101:1000:3863#20/1	100	18	96	F999_595	78	0	78	1	78,	18,	0,
70	2	0	0	1	8	1	6	+	HS21_13036:1:1101:1000:3863#20/1	100	18	98	F9999_33	78	0	78	2	34,38,	18,60,	0,40,




9*                                              10*     13*                            14                                                                         15  16     11*  12* 

0                                   1           2       3                   4           5       6       7       8    9  10    11         12   13      14      15    16  17      18    19   20  21  22 
#                                                                                           --- full sequence --- -------------- this domain -------------   hmm coord   ali coord   env coord
# target name                       accession   tlen query name           accession   qlen   E-value  score  bias   #  of  c-Evalue  i-Evalue  score  bias  from    to  from    to  from    to  acc description of target
#               ------------------- ---------- ----- -------------------- ---------- ----- --------- ------ ----- --- --- --------- --------- ------ ----- ----- ----- ----- ----- ----- ----- ---- ---------------------
HS35_12870:1:2103:20325:4610#10/1   -            100 PRIMERS_rev.mfa.sl   -             78    0.0023   26.1   0.3   1   1     0.072       1.4   17.1   0.1    33    72    60    99    26   100 0.79 -
HS35_12870:1:1113:19994:14397#10/1  -            100 PRIMERS_rev.mfa.sl   -             78    0.0038   25.4   0.1   1   1   0.00043    0.0086   24.3   0.1     5    72    10    99     7   100 0.72 -
HS35_12870:1:2112:17004:90387#10/1  -            100 PRIMERS_rev.mfa.sl   -             78     0.004   25.3   1.1   1   1   0.00043    0.0087   24.2   0.7    32    77    53    98     1   100 0.78 -
HS35_12870:1:1210:17670:15829#10/1  -            100 PRIMERS_rev.mfa.sl   -             78     0.006   24.8   0.2   1   1     0.051         1   17.6   0.1    32    73    58    99     2   100 0.55 -
HS35_12870:1:1201:7751:99637#10/1   -            100 PRIMERS_rev.mfa.sl   -             78    0.0071   24.5   0.2   1   1   0.00041    0.0083   24.3   0.1    33    76    50    93    12    95 0.79 -
HS35_12870:1:2108:7500:9272#10/1    -            100 PRIMERS_rev.mfa.sl   -             78    0.0078   24.4   0.6   1   1     0.056       1.1   17.5   0.4    20    73    39    99     2   100 0.45 -
HS35_12870:1:2203:5410:13280#10/1   -            100 PRIMERS_rev.mfa.sl   -             78    0.0082   24.3   0.4   1   1    0.0005      0.01   24.1   0.3    16    76    36    96    16   100 0.74 -








