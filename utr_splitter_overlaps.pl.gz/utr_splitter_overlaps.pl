#!/usr/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV == 3) {
        &USAGE;
}

sub USAGE {

die '

Usage: perl ~/bin/perl/utr_splitter.pl <utr.gff> <cufflinks-output>  <prefix> 

This program takes a correctly formatted gff-file of UTRs and checks if it has 
introns in the UTRs 

'
}


	my $in = shift;
	my $cuff = shift;
	my $prefix = shift;





# Get CDSs of transcripts overlapping with the UTRs # Merge the overlapping ones


system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $cuff -b $in -u -s | grep -w exon | sed 's/exon/CDS/' > $prefix.bed.gff && ~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $prefix.bed.gff -s | sort -k1,1 -k3,3n > $prefix.bed.ovl.gff ";
# print "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $cuff -b $in -u -s | grep -w exon sed 's/exon/CDS/'  > $prefix.bed.gff && ~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $prefix.bed.gff -s | sort -k1,1 -k3,3n > $prefix.bed.ovl.gff \n"; wait;

sleep (5);

# Cut the overlaps in the length of the UTRs



	open (IN, "<$in") || die "I can't open $in\n";
	my @utrs = <IN>;
	close (IN);

    open (CUFF, "<$prefix.bed.ovl.gff") || die "I can't open $prefix.bed.ovl.gff\n";
#    open (CUFF, "<$prefix.cuff.art.gff ") || die "I can't open $prefix.cuff.art.gff\n";
    
	my @cuff = <CUFF>;
	close (CUFF);

        open (OUT, ">$in.introns.gff") || die "I can't open $in.introns.gff\n";

my %unused;

print "Checking UTRs\n";

foreach my $utr (@utrs)  {
        chomp $utr;
        my @arr = split(/\s+/, $utr);
        my $i=0;
        my $a = $arr[3];
        my $b = $arr[4];

#        print OUT "$utr\n";

        $unused{$arr[8]} = $utr;

    foreach my $cds (@cuff) {
        chomp $cds;

        my @cds = split(/\s+/, $cds);
        my $x = $cds[1];
        my $y = $cds[2];

                my $max = ($x, $a)[$x < $a];
                my $min = ($b, $y)[$b > $y];

         # if we are on the same scaffold
        if ($arr[0] =~/$cds[0]/ and $cds[0] =~/$arr[0]/  ) {

        # before

        if ($a >=  $x and $b >=  $x and $a >=  $y and $b >=  $y ) {
#            print "BEFORE: $utr\n$cds\n$a\t$x\t$max\n$b\t$y\t$min\n\n";
        }

        # after
                
        elsif ($x >=  $a and $x >=  $b and $y >=  $a and $y >=  $b ) {
#            print "AFTER: $utr\n$cds\n$a\t$x\t$max\n$b\t$y\t$min\n\n";
        }
        
        # ovl middle + sides
        
        elsif ($x >=  $a and $b >=  $x and $y >=  $a and $b >=  $y ) {
#            print "MIDDLE: $utr\n$cds\nNEW:$cds\n\n";
            print OUT "$arr[0]\tnew\t$arr[2]\t$x\t$y\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
            delete $unused{$arr[8]};
        }

        # ovl crossing
        
        elsif ($a >=  $x and $b >=  $x and $y >=  $a and $y >=  $b ) {
#            print "LARGER: $utr\n$cds\nNEW:$a\t$b\n\n";
            print OUT "$arr[0]\tnew\t$arr[2]\t$a\t$b\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
                        delete $unused{$arr[8]};

        }

        # ovl left
        elsif ($a >=  $x and $b >=  $x and $y >=  $a and $b >=  $y ) {
#            print "OVL left: $utr\n$cds\nNEW:$a\t$y\n\n";
            print OUT "$arr[0]\tnew\t$arr[2]\t$a\t$y\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
                        delete $unused{$arr[8]};

        }
        
        # ovl right

        elsif ($x >=  $a and $b >=  $x and $y >=  $a and $y >=  $b ) {
#            print "OVL right: $utr\n$cds\nNEW:$x\t$b\n\n";
            print OUT "$arr[0]\tnew\t$arr[2]\t$x\t$b\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\n";
                        delete $unused{$arr[8]};


        }

        else {
             print "WARNING: $utr\tWARNING: $cds\n";
        }
        
    }


    }


}




# print the unused UTRs
    print "Printing un-used UTRs to $in.introns.gff with the comment \"no_transcribed_CDS\"\n";

foreach my $key (sort keys %unused) {
    print OUT "$unused{$key};comment=no_transcribed_CDS\n";
}


my $out = "$in.introns.sorted.gff";

$out=~s/gff\.//;

print "Sorting files\n";

system "cat $in.introns.gff |  awk '{print \$1\"::\"\$4\"::\"\$0}' | sort -nk1,2 | uniq | awk -F'::' '{print \$3}'  > $out ";

system "rm -f $in.bed.ovl.gff $in.bed.gff $in.UTR.gff.err.gff $in.introns.gff ";

# system "rm -f test3.bed.ovl.gff test3.bed.gff $in.introns.gff ";

    print "Finished\n";

	close (OUT);
#	close (OUT);

    exit 0;

__END__



#        print "CDS:$x\t$y\n";
=pod

#        while ($y < $a) {
        while ($a >= $y ) {

            $i++;
#            while ($x =< $b) {
            while ( $x  >= $b ) {



                print "$utr\n$cds\n$a\t$x\t$max\n$b\t$y\t$min\n\n";

            }

        }
=cut

# Cut the overlaps in the length of the UTRs

# for each contig

    # make a hash with the starts and ends of UTRs and ranges

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);



my %utr;   #  $utr{$contig}{start/end}{s/e}= $line

    foreach my $line (@in) {
        chomp $line;
        my @arr = split(/\s+/, $line);
        $utr{$arr[0]}{$arr[3]}{s}=$line;
        $utr{$arr[0]}{$arr[4]}{e}=$line;
    }

    # read in the overlaps

    open (CUFF, "<$prefix.bed.gff") || die "I can't open $prefix.bed.gff\n";
	my @cuff = <CUFF>;
	close (CUFF);

    open (OUT, ">$prefix.CDS") || die "I can't open $prefix.CDS\n";

    my $new;

my %n;

    foreach my $line (@cuff) {
        chomp $line;
#        print "CUFF:$line\n";
        my @arr = split(/\s+/, $line);
        if (exists $utr{$arr[0]}{$arr[3]}{s} ) {
            my @utr = split(/\s+/, $utr{$arr[0]}{$arr[3]}{s} );
#            print "3: $line\n";
            if ($arr[4]> $utr[4]) {
                $arr[4] = $utr[4];
                $new = join("\t", @arr);
#                print "Match s changed:\nOLD:$line\n$new\n$utr{$arr[0]}{$arr[3]}{s}\n\n";
                $n{$new}=1;
#                print OUT "$new\n";

            }
            else {
#                print "Match start:\n$line\n$utr{$arr[0]}{$arr[3]}{s}\n\n";
                $n{$line}=1;
#                 print OUT "$line\n";

            }

        }
        elsif  (exists $utr{$arr[0]}{$arr[4]}{e} ) {
            my @utr = split(/\s+/, $utr{$arr[0]}{$arr[4]}{e} );
#            print "4: $line\n";
            if ($arr[3] < $utr[3]) {
                $arr[3] = $utr[3];
                $new = join("\t", @arr);
#                print "Match e changed:\nOLD:$line\n$new\n$utr{$arr[0]}{$arr[4]}{e}\n\n";
                $n{$new}=1;
#                 print OUT "$new\n";
#                  print "4 IF: $new\n";
            }
            else {
#                  print "4 ELSE: $line\n";
#                print "Match end:\n$line\n$utr{$arr[0]}{$arr[4]}{e}\n\n";
                $n{$line}=1;
#                 print OUT "$line\n";

            }
        }

        else {
#           print "No match: $line\n";
            if (exists $n{$new} ) {
#               print "5: $line\n";
            }
               $n{$line}=2;
#            print "5 ELSE: $line\n";



#              print OUT "$new;comment=no_match\n";
        }

    }


    foreach my $key (sort keys %n) {
#        print "OUT:$key\n"; 
        if  ($n{$key} ==2 ) {
              print OUT "$key;comment=no_match\n";
        }
        else {
              print OUT "$key\n";
        }

    }

close (OUT);


# Get introns of the overlappig transcripts
#


 system "perl ~/bin/perl/gff_intron-exon-counter.pl $prefix.CDS $prefix.introns.gff";

# Subtract the introns from the UTRs

print  " ~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a $prefix.introns.gff -b $in -s > $prefix.sub.gff  \n";


# Make an embl of the UTRs




exit 0;


__END__




