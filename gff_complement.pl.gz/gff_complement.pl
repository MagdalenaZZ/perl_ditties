#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_complement.pl genome.fai gff-file

Takes a gff-file, and gives the "reverse-complement" of it - all regions which are not covered by the gff.



'
}


my $fai = shift;
my $gff = shift;


# calculate coverage and pick 0 coverage

system "cat $fai | cut -f1,2 > $fai.genome";
#print "\n\n";

system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed -i $gff -g $fai.genome -bga | grep -w 0\$ > $gff.tmp";

#print "\n\n";
system "cat $gff.tmp | awk \'\{print \$1  \"\\t0cov\\tCDS\\t\" \$2 +1   \"\\t\" \$3  \"\\t\.\\t\+\\t\.\\t\"   \"0cov-\"\$1 \"\-\" \$2\"\-\"\$3         \}\' >   $gff.0cov.gff ";
#print "\n\n";



exit;













