#!/usr/local/bin/perl -w

use strict;

unless (@ARGV==2) {
        &USAGE;
}

sub USAGE {

die 'Usage: translate.pl in frame


Give a single-line DNA fasta-file 
The program will give the translation
Future versions may include 6-frame translation and other cool things

The program:
1. Checks for non-DNA characters and reports them (if any). Only ATGCN are accepted
2. Checks if the DNA has perfect codons, and if not, chops off the end ,and warns about it
3. After translation it checks if the gene has an M-start, a *-stop, and no stop-codons in the gene. 
Proteins that looks right are printed to file $in.aa.corrected
Warnings are reported to the file $in.aa.warnings

Options for frame:

3/F/forward/ - all three forward translations
6/6-frame - six-frame translation
ORF/orf - makes all ORFs 
default (type anything else) - 1-frame translation



'
}

	my $in = shift;
    my $frame = 1;
    $frame = shift;
	my $out = "$in.aa";
	open (IN, "<$in") || die "I can't open $in\n";
#	my @input = <IN>;


	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT3, ">$out.warnings") || die "I can't open $out.warnings\n";

# check that there are no weird letters
my $res = `perl ~mz3/bin/perl/gc_content.pl $in`; wait;

if ($res=~/other/) {
    print "The file contains some non-DNA characters (see below), so the translation has been aborted\n$res\n";
    die;
}



## read the fastas
#open (IN, "$fastafile") or die "Cant open file $fastafile\n" ;
my %fasta;
my %lens;
#my @names;

while (<IN>) {
#    print "Hi\n";
    	if ( $_ =~m/^>/) {
		my $name = $_ ;
        $name =~s/\>//;
        chomp ($name);
		my $seq = <IN> ;
		chomp($seq) ;
        $seq =~tr/ACGTN/acgtn/;
        if ( length($seq) > 2 ) {
    		$fasta{$name} = $seq ;
            $lens{$name} = length($seq) ;
#    		push(@names, $name) ;
#        print "$name\t$seq\n"; <STDIN>;
        }
	}
    else {
    }
}


# add additional frames for 3-fram and orf

if ($frame =~/^3$/ || $frame =~/^f/ || $frame =~/orf/i ||  $frame =~/^6$/  ) {

foreach my $gene (keys %fasta) {
        #        $gene = "$gene" . "_1";
        my $end = length($fasta{$gene}); 
        my $gene2 = "$gene" . "#2";
        my $gene3 = "$gene" . "#3";
        my $frame2 =  substr ($fasta{$gene}, 1, $end);
        my $frame3 =  substr ($fasta{$gene}, 2, $end);
            if ( length($frame2) > 2 ) {
                $fasta{$gene2}= $frame2;
            }
            if ( length($frame3) > 2 ) {
                $fasta{$gene3}= $frame3;
            }
#        print "$gene\t$fasta{$gene}\n$gene2\t$frame2\n$gene3\t$frame3\n\n"; <STDIN>;
#
    if ($frame =~/orf/i ||  $frame =~/^6$/  ) {


     my $revcomp = reverse($fasta{$gene});
     $revcomp =~ tr/ACGTacgt/TGCAtgca/;
        
        my $end = length($fasta{$gene}); 
        my $gene4 =  "$gene" . "#4";
        my $gene5 = "$gene" . "#5";
        my $gene6 = "$gene" . "#6";
        my $frame4 =  substr ($revcomp , 0, $end);
        my $frame5 =  substr ($revcomp , 1, $end);
        my $frame6 =  substr ($revcomp , 2, $end);


        if ( length($frame4) > 2 ) {
                $fasta{$gene4}= $frame4;
            }

            if ( length($frame5) > 2 ) {
                $fasta{$gene5}= $frame5;
            }
            if ( length($frame6) > 2 ) {
                $fasta{$gene6}= $frame6;
            }

#            print "4:$gene4\t$frame4\n";
    }



}

}






foreach my $gene (sort keys %fasta) {

    print OUT ">$gene\n";
    my $seqlen = length($fasta{$gene});
    my $codlen = ($seqlen/3);
#    print "1:$codlen\n";
#    print "Gene:$gene\nSeq:$fasta{$gene}\n$seqlen\n";
#
    if ($codlen =~/\D/) {
        #   is not an integer
        print OUT3 "$gene does not have perfect codons, ignoring the last base(es) $codlen\n";
#        my $dec = 0;
        my @dec = split (/\./, $codlen );
        $codlen = $dec[0];
        #print "DEC:$dec[0]\n";
    }

#    print "2:$codlen\n";
    for (; $codlen >=1; $codlen-- ) {
        my $xxx =  substr ($fasta{$gene}, 0, 3);
#        print "COD:$xxx\n";
        my $end = length($fasta{$gene});        
        my $new =  substr ($fasta{$gene}, 3, $end);
        $fasta{$gene} =  $new;
#        print "$fasta{$gene}\n$new\n\n";
        &trans($xxx);

    }

    print OUT "\n"; 

}


close (OUT);

close (IN);


######### choose the best frame #######################################

if ($frame =~/^3$/ || $frame =~/^f/ || $frame =~/^6/  ) {

	open (IN4, "<$in.aa") || die "I can't open $in.aa\n";
	open (OUT4, ">$in.aa.best") || die "I can't open $in.aa.best\n";
    
    my %all;
    # put all seqs in hash
    while (<IN4>) {
    #    print "Hi\n";
    	if (/>(\S+)/) {
    		my $name = $1 . "#1" ;	
            my @nam = split ( /#/ , $name);
#            push (@nam, "1" );
    		my $seq = <IN4> ;
    		chomp($seq) ;
            my @seqs = split(/\*/,$seq);
            my @sorted = sort { length($b) <=> length($a) } @seqs;
#            print "$name\t" . join(', ', @sorted) . "\n"; <STDIN>;

            # check if that key already has a gene
            if (exists $all{$nam[0]} ) {
                # if current lenght is longer than saved length
                if ( length($all{$nam[0]}) < length($sorted[0]) ) {
            		$all{$nam[0]} = $sorted[0] ;
                }
                else {
                     # do nothing
                }
            }
            else {
        		$all{$nam[0]} = $sorted[0] ;
            }
        }
    }

    # print output

    foreach my $genex (sort keys %all) {
#        my $geney = ">$genex";
        print OUT4  "\>$genex\n$all{$genex}\*\n";
    }


    close (IN4);
    close (OUT4);
    system "mv $in.aa $in.allframes.aa";
    system "mv $in.aa.best $in.aa";
}

###### do ORFs and get the co-ords right #######

elsif ($frame =~/orf/i) {

	open (IN5, "<$in.aa") || die "I can't open $in.aa\n";
	open (OUT5, ">$in.aa.best") || die "I can't open $in.aa.best\n";

my %all;

    while (<IN5>) {

    	if ( $_ =~m/^>/) {
        chomp($_);
		my $name = $_ .  "#1" ;
        $name =~s/\>//;	
            my @nam = split ( /#/ , $name);
            $name = "$nam[0]" . "#" . "$nam[1]" ;
            my $len_name = "$nam[0]";
#            push (@nam, "1" );
    		my $seq = <IN5> ;
    		chomp($seq) ;
            my @seqs = split(/\*/,$seq);
        
# make a hash which contains all seqs and all co-ords
#
        my $totlen = length($seq) * 3;
        my $fin_len = 1;
        my $offset = 1;

        my $ori = ".";
        if ($name=~/#1/ || $name=~/#2/ || $name=~/#3/  ) {
            $ori = "\+";
        }
        elsif ($name=~/#4/ || $name=~/#5/ || $name=~/#6/  ) {
            $ori = "\-";
             $fin_len =  $lens{$len_name};
#            my @rev = reverse (@seqs);
#            @seqs = @rev;
        }


         if ($name=~/#2/ ) {
            $fin_len++;
            $offset++;
        }   
        elsif ($name=~/#5/ ) {
            $fin_len--;
            $offset++;
        }
        elsif ($name=~/#3/) {
            $fin_len++;
            $fin_len++;
            $offset++;
            $offset++;            
        }
        elsif ($name=~/#6/ ) {
            $fin_len--;
            $fin_len--;
            $offset++;
            $offset++;
        }


#        print "\n$name\t$totlen\t$lens{$len_name}\n";

        my $num = 1;

   
               foreach my $line (@seqs) {
        my $len = length($line);
        $len = $len + 1 ;

        if ($name=~/#1/ || $name=~/#2/ || $name=~/#3/  ) {
    
            my $start = $fin_len;
            $fin_len = $fin_len + ($len*3) - 1;
            my $end = $fin_len;
            my $stop = "\*";
            if ($end > $lens{$len_name} ) {
                $end = $end - 3;
                $stop = "";
            }
#        print "$len_name\ttranslate\tCDS\t$start\t$end\tsco=$len\t$ori\t.\tID=$name\:ORF_$num;comment=$line$stop\n";
        }

        elsif ($name=~/#4/ || $name=~/#5/ || $name=~/#6/  ) {
           
            my $rstart =  $lens{$len_name};

#        print "$len_name\ttranslate\tCDS\t$start\t$end\tsco=$len\t$ori\t.\tID=$name\:ORF_$num;comment=$line$stop\n";
        }

        else {
            print "Serious error, don't know which frame I'm in\n";
        }

#        print "$len\t$offset\t$start-$end\t$line$stop\n";

        $fin_len++;
        $num++;
#        print "$line\n";

    }
#
#
#

            my @sorted = sort { length($b) <=> length($a) } @seqs;
#            print "$name\t" . join(', ', @sorted) . "\n"; <STDIN>;

            # check if that key already has a gene
            if (exists $all{$nam[0]} ) {
                # if current lenght is longer than saved length
                if ( length($all{$nam[0]}) < length($sorted[0]) ) {
            		$all{$nam[0]} = $sorted[0] ;
                }
                else {
                     # do nothing
                }
            }
            else {
        		$all{$nam[0]} = $sorted[0] ;
            }
        }
    }

    # print output

    foreach my $genex (sort keys %all) {
#        my $geney = ">$genex";
        print OUT5  "\>$genex\n$all{$genex}\*\n";
    }


    close (IN5);
    close (OUT5);

}

####################################################################

# check that the proteins are correct
#
	open (IN2, "<$in.aa") || die "I can't open $in.aa\n";
	open (OUT2, ">$in.aa.corrected") || die "I can't open $in.aa.corrected\n";

my %prot;

while (<IN2>) {
#    print "Hi\n";
	if (/>(\S+)/) {
		my $name = $1 ;		
		my $seq = <IN2> ;
		chomp($seq) ;
#        $seq =~tr/ACGTN/acgtn/;
		$prot{$name} = $seq ;
#		push(@names, $name) ;
#        print "$name\t$seq\n";

	}
    else {
    }
}

foreach my $pro (sort keys %prot) {
   my $pseq= $prot{$pro};
   my $first = substr ($pseq, 0, 1);
   my $last = substr ($pseq, , -1);
   my $middle = substr ($pseq, 1 , -1);
   $middle =~tr/\*/\#/;
   unless ($first =~/M/) {
       print OUT3 "$pro missing M-start\t$pseq\n";
       next;
   }
   unless ($last =~/\*/) {
       print OUT3 "$pro missing *-stop\t$pseq\n";
       next;

   }
   if ($middle =~/\#/) {
       print OUT3 "$pro have multiple stop-codons\t$pseq\n";
       next;

   }

   print OUT2 ">$pro\n$pseq\n";

#    print "F:$first\tL:$last\tM: $middle\n"; <STDIN>;
}

close (IN2);
close (OUT2);
close (OUT3);

#########################################

   sub trans {

      my $codon = $_[0];
#        print "\nCODON:$codon\t";
      my  $clen = length ($codon);
       unless ($clen == 3) {
           print "The codon is not 3 bases long, so something is horribly wrong with this script\n";
           die;
       }


     if ($codon=~/^ttt$/ || $codon=~/^ttc$/ ) {
         print OUT "F";
     }
     elsif ($codon=~/^tt\w$/) {
         print OUT "L";
     }
     elsif ($codon=~/^ct\w$/) {
         print OUT "L";
     }
     elsif ($codon=~/^atg$/) {
         print OUT "M";
     }
     elsif ($codon=~/^at\w$/) {
         print OUT "I";
     }
     elsif ($codon=~/^gt\w$/) {
         print OUT "V";
     }
     elsif ($codon=~/^tc\w$/) {
         print OUT "S";
     }
     elsif ($codon=~/^cc\w$/) {
         print OUT "P";
     }
     elsif ($codon=~/^ac\w$/) {
         print OUT "T";
     }
     elsif ($codon=~/^gc\w$/) {
         print OUT "A";
     }
     elsif ($codon=~/^tat$/ || $codon=~/^tac$/ ) {
         print OUT "Y";
     }
     elsif ($codon=~/^tan$/ ) {
         print OUT "X";
         print "Unknown codon $codon replaced by X\n";
     }
     elsif ($codon=~/^tag$/ || $codon=~/^taa$/ ) {
         print OUT "*";
     }
     elsif ($codon=~/^cat$/ || $codon=~/^cac/ ) {
         print OUT "H";
     }
     elsif ($codon=~/^caa$/ || $codon=~/^cag/ ) {
         print OUT "Q";
     }
     elsif ($codon=~/^aat$/ || $codon=~/^aac/ ) {
         print OUT "N";
     }
     elsif ($codon=~/^aaa$/ || $codon=~/^aag/ ) {
         print OUT "K";
     }
     elsif ($codon=~/^gat$/ || $codon=~/^gac/ ) {
         print OUT "D";
     }
     elsif ($codon=~/^gaa$/ || $codon=~/^gag/ ) {
         print OUT "E";
     }
     elsif ($codon=~/^cg\w$/) {
         print OUT "R";
     }
     elsif ($codon=~/^gg\w$/) {
         print OUT "G";
     }

     elsif ($codon=~/^agt/ || $codon=~/^agc/ ) {
         print OUT "S";
     }
     elsif ($codon=~/^aga/ || $codon=~/^agg/ ) {
         print OUT "R";
     }
     elsif ($codon=~/^tgt/ || $codon=~/^tgc/ ) {
         print OUT "C";
     }
     elsif ($codon=~/^tga/ ) {
         print OUT "*";
     }
     elsif ($codon=~/^tgg/ ) {
         print OUT "W";
     }
     else {
         print OUT "X";
         print "Unknown codon $codon replaced by X\n";
     }
     
}
