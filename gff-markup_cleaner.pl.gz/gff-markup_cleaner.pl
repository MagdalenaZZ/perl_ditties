#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '



Usage: perl ~/bin/perl/gff-markup_cleaner.pl gff-file outfile


Give the program the gff-file you want to modify, and it will go and remove duplicate product names, and replace mz3 with hypothetical protein



'
}

	my $in = shift;
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my @new;

# make format right 

foreach my $line (@in) {
chomp $line;
	$line=~s/mz3/hypothetical protein/g;

	my @arr = split(/\t/,  $line );

	if (exists $arr[9]) {
		my $len = scalar(@arr);
		$len--;
		my @small = @arr[9..$len];
		my $last = join("\t", @small);
		$last=~s/_/ /g;
		$last=~s/\,\"/\"/g;
		$last=~s/ \"/\"/g;
		$last=~s/  / /g;
		$last=~s/  / /g;
		$last=~s/\t\t/\t/g;
		$last=~s/\t\t/\t/g;
		$last=~s/\t/ /g;	
		$last=~s/\" \//\"\t\//g;
		$last=~s/db xref/db_xref/g;
		$last=~s/GO REF/GO_REF/g;
		$last=~s/EC number/EC_number/g;
        $last=~s/From\tBlast2GO/From Blast2GO/g;

#        print "LAST:$last\n";
#		print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$last\n";
		push (@new, "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$last");
	}
	else {
		push (@new,$line);
	}
}

#__END__


	open (OUT, ">$out") || die "I can't open $out\n";

# remove duplicate products

foreach my $line (@new) {

	if ($line =~/gene/) {
#		print "Line:$line:\n";
		my @arr = split(/\t/,  $line );
		my $len = scalar(@arr);
#		my $leng = $#length(@arr);
		$len--;
#		print "Length:$len\n";
#		$len--;
		my $final;
		my $first;
		if ( $len > 8 ) {
			my @small = @arr[9..$len];
			my @first = @arr[0..8];
			$first = join("\t", @first);
# Sort out only unique product calls
 			my %seen = ();
			my @ret = ();
			foreach my $all (@small) {
     		   		unless ($seen{$all}) {
  			          push (@ret, $all);
			            $seen{$all} = 1;
      				 }
    			}
			foreach my $elem (@ret) {
#				print "Elem:$elem:\n";
			}
# If there are other calls, get rid of "hypothetical protein"
			my $ret_len = scalar(@ret);
#					print "##########\n";
			my $index=0;
				my @arr2;
			foreach my $elem2 (@ret) {
#				my @arr2;
				if ($elem2=~/\/product=\"hypothetical protein\"/) {	
#					print "HYP:$elem2:\n";
					@arr2=split(/\"/, $elem2 );
#					print "GENE:$arr2[1]\n";
				}
				elsif ($elem2=~/\/product=/) {
#					print "PROD:$elem2:\n";	
					@arr2=split(/\"/, $elem2 );	
#					print "GENE:$arr2[1]\n";					
					$index=1;							
				}
# Clean up the note
				elsif ($elem2=~/\/note=\"Product/) {
#					print "ARR2:$arr2[1]:\n";
#					shift @arr2;
#					print "ARR2:$arr2[0]:\n";
#					print "NOTE:$elem2:\n";
					my @arr3=split(/'/, $elem2 );	
#					print "REP:$arr3[1]\n";		
					$arr3[1]=$arr2[1];
#					print "REP2:$arr3[1]\n";	
					$elem2 = join("'", @arr3);
#					print "FNOTE:$elem2:\n";
#					@arr2='';
				}
			}

# remove hypothetical protein
			if ($index==1) {
				foreach my $elem2 (@ret) {	
					if ($elem2=~/\/product=\"hypothetical protein\"/) {	
#						shift @ret;   ### <=== this takes away the wrong element!
						$elem2='';
					}
# remove notes of hypothetical proteins
					elsif ($elem2=~/\/note="Product 'hypothetical protein' is based on blast-similarity with GenBank:/) {
						$elem2='';
					}
# fix genbank accession in notes
					elsif ($elem2=~/\/note="Product/) {
#						print "Elem:$elem2\n";
						my @arr4= split (/:/,$elem2);
						$arr4[1]=~s/ /_/;
#						print "Arr4:$arr4[1]\n";
						$elem2=join(":", @arr4);
#						print "Elem:$elem2:\n"
					}


				}			
			}

# check the integrity of the entries
			foreach my $elem (@ret) {
				if ($elem!~/\w/) {
    				print "Elem not word:$elem:\n";
                }
                elsif ($elem!~/\/*\"*\"/) {
                   print "Elem not intact:$elem:\n"; 
                }
                elsif ($elem=~/\t/) {
                    print "Elem has tab:$elem:\n";
                }
                else {
                }
            }
            
                $final = join("\t", @ret);
#                print "FIRST:$first\n";
                my $new_line = "$first\t$final";
                $new_line=~s/\t\t/\t/g;
                $new_line=~s/\t\t/\t/g;
                $new_line=~s/\t\t/\t/g;
                if ($new_line=~/\w+/) {
        			print OUT "$new_line\n";
#					print "#### END ######\n";	
                }
		    }
# if the gene doesnt have a product, give it a hypothetical one
		else {
			print OUT "$line\t/product=\"hypothetical protein\"\n";
		}
		

	}

	elsif ($line=~/CDS/ or $line=~/mRNA/) {
    	print OUT "$line\n";
	}
    else {
        print "WARN:weird line:$line:\n";
    }



}






close (OUT);
