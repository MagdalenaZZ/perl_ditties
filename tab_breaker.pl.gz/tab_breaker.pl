#!/usr/local/bin/perl -w

# 

use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: networker.pl file


Takes one file with labels and tab-delimited categories and prints one instance of each tab

cloumn1 <TAB> column2
cloumn1 <TAB> column3
cloumn1 <TAB> column4


'
}

my $dom1 = shift;


my %h;

# read all domain architectures into a hash
#
	open (IN, "<$dom1") || die "I can't open $dom1\n";
	my @doms = <IN>;
	close (IN);

    open (OUT, ">$dom1.out") || die "I can't open $dom1.out\n";
   

    foreach my $line  (@doms) {
    
        my @arr = split(/\t/, $line);
        my $label = shift(@arr);
        my $elem = $arr[0];

        if ($elem=~/\w+/) {
            $h{$label}{$elem}=1;
        }
        #foreach my $elem (@arr) {
            #if ($elem =~/\w+/ and $elem !~/^\d+$/  ) {
                #print "$label\t$elem\n";
                #$h{$label}{$elem}=1;
                #}
            #}

    }



foreach my $ele (sort keys %h) {
    print OUT "$ele\t";

    foreach my $ele2 (sort keys %{$h{$ele}}) {
        print OUT "$ele2,";
    }

    print OUT "\n";

}




close (OUT);





