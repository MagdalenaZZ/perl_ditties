for x in *.bam ; do 
bsub -o out.$x.o -e out.$x.e -R "select[type==X86_64 && mem > 1000] rusage[mem=1000]" -M1000 -J $x " samtools index $x ; samtools view $x | perl ~tdo/Bin/sam2fastq.2files.pl $x "; 
done 


samtools view <BAMFILE> | perl ~tdo/Bin/sam2fastq.2files.pl NAME


