#!/usr/bin/perl -w


# use strict;

use Cwd;
use LWP::Simple;
use Data::Dumper;
use File::Slurp;

unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die '


Usage: genbank_get_products.pl   all.blast   number   outprefix

# Takes a tab-file fasta output and return the full record for those

all.blast - your GenBank output
number - number of hits/file - integer less than 1000 - preferably 100
outprefix - whatever you want your outprefix to be


Preferably go to a new folder, because this script will output lots of files

After you have done this - go to next step:
run 

'
}

	my $in = shift;
	my $number = shift;
#    chomp $number;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	open (ERR, ">$in.e") || die "I can't open $in.e\n";

	my @in = <IN>;
	close (IN);
    my $start ="0";

my %hash;
my %retcall;
my $out2;

if ($in=~m/exception.list/) {
        print "IN:$in\n";
#        my @arr3 = split(/\./, $in);
#        print "Index: $arr3[1]\n";
#        $index = $arr3[1];
        
        print "\nReading the exceptions-file\n";
        foreach my $line (@in) {
        chomp $line;
        $hash{$line} = 1;
    }

}
else {
foreach my $line (@in) {

	@arr=split(/([|\t])/, $line);
#	print "$arr[0]\t$arr[8]\n";
	if ($arr[8] =~/\./) {
		push (@{$hash{$arr[8]}}, $arr[0]);
#	push(@{$hash{$key}}, $newline);
	}
	elsif ($arr[8] =~/\d+/) {
		my $newarr8 = "$arr[8]" . "_" . "$arr[10]";
#		print "$newarr8\n";
		push (@{$hash{$newarr8}}, $arr[0]);
	}
	else {
#	print "Else:$arr[8]:\n";
	}

}

}


my @gblist;

foreach my $key (sort keys %hash) {
print "Key: $key\t\n";
# print OUT "Key: $key\t\n";
push (@gblist, $key);
}


# Get an array-slice with $number IDs and send the job then sleep
$length = (scalar (@gblist) -1);

# print "Length: $length\n";
my $length2 = $length;

for (my $i=0; $i<$length2; $i=$i+$number) {
	my $number1 = ($number - 1);
	my $hundred = ($i+$number1);
#	print "Hunderd: $hundred\n";
#	print "Length: $length\n";
	if  ($length <= $hundred) {
		$hundred = $length;
#		print "Else\n";
	}
#	print "First: $i\n";
#	print "Hunderd2: $hundred\n";
	my $gi_list = join(",", @gblist[$i..$hundred]);

#	print "$gi_list\n";

	@acc_array = split(/,/, $gi_list);

	#append [accn] field to each accession
	for (my $j=0; $j < @acc_array; $j++) {
		   $acc_array[$j] .= "[accn]";
	}

	#join the accessions with OR
#	$query = join('+OR+',@acc_array);
	#assemble the esearch URL
	$base = 'http://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
	$url = $base .  "esearch.fcgi?db=protein&term=$gi_list&usehistory=y&retmax=50000&email=mz3\@sanger.ac.uk";
#	print "$url\n";
	#post the esearch URL
	$output = get($url);

	#parse WebEnv and QueryKey
    my $count = "0";
	my $web = $1 if ($output =~ /<WebEnv>(\S+)<\/WebEnv>/);
	my $key2 = $1 if ($output =~ /<QueryKey>(\d+)<\/QueryKey>/);
	$count = $1 if ($output =~ /<Count>(\d+)<\/Count>/);

#    print "RETCALL:$i\-$hundred\t$gi_list\n";
    $retcall{"$i\-$hundred"}=$gi_list;
#	print "Key: $key2\n";
#	print "Web: $web\n";
#	print "Count: $count\n";

#        print "out:$out\n";
#        print "i:$i\n";
#        print "hun:$hundred\n";
#        print "in:$in\n";


        if ($in=~m/exception.list/) {
            $out2 = "$in" . "\.exception" .  "\.list";
#            print "IF\n";
        }
        else {
            $out2 = "$out" . "\.$i\-$hundred";
#            print "ELSE\n";
        }
#        print "OUT2:$out2\n";

	if ( $count == 0 ) {
		#catch exceptions
		my @arr=split(/,/,$gi_list);

#        if ($in=~m/exception.list/) {
#        my $el = "$in" . "\.exception" .  "\.list";
#        }
#        else {
#        my $el = "$out" . "\.$i\-$hundred" . "\.exception" .  "\.list";
#        }

        open (EXC, ">$out2") || die "I can't open $out2\n";
		foreach my $elem (@arr) {
    		print EXC "$elem\n";
		}
        close (EXC);
	}
    else {
	#assemble the efetch URL
		$url = $base . "efetch.fcgi?db=protein&query_key=$key2&WebEnv=$web&email=mz3\@sanger.ac.uk";
	# 233683-split[1-5]" "/s
		$url .= "&rettype=gp&retmode=text";


############
#        if ($in=~m/exception.list/) {
#            my $out2 = "$in" . "\.exception" .  "\.list";
#        }
#        else {
#        	my $out2 = "$out" . "\.$i\-$hundred" . ".gb";
#        }
#########


	#post the efetch URL
    	$fasta = get($url);
        if ($fasta =~/<ERROR>Unable to obtain query #1<\/ERROR>/) {
        	open (OUT, ">$out2.exception.list") || die "I can't open $out2.exception.list\n";
            my @arr=split(/,/,$gi_list);
    		foreach my $elem (@arr) {
        		print OUT "$elem\n";
		}

#        	print OUT "$gi_list\n";
        }
        elsif (defined $fasta) {
    	open (OUT, ">$out2.gb") || die "I can't open $out2.gb\n";
    	print OUT "$fasta";
        }
        else {
        	open (OUT, ">$out2.exception.list") || die "I can't open $out2.exception.list\n";
            my @arr=split(/,/,$gi_list);
    		foreach my $elem (@arr) {
        		print OUT "$elem\n";
		    }
#            open (OUT, ">$out2.error") || die "I can't open $out2.error\n";
#        	print OUT "$gi_list\n";
        }
    close (OUT);
    }
}




# Check that the resulting file has right number of hits 

my $cwd = cwd();
my @paths = read_dir( "$cwd", prefix => 1 ) ;

#Try again for the incomplete ones

		foreach my $elem (@paths) {
            chomp $elem;
#			print "File: $elem\n";
            my @arr = split(/\./ ,$elem);
            $index = $arr[1];
             
            if ($elem !~/error.list$/ and  $elem=~/gb$/ ) {    
                my $count = `cat $elem | grep -w LOCUS | wc -l`;
                chomp $count;
#        			print "File: $elem\t$count\n";
                    if ($count < $number ) {
            			print  ERR "Warning: $elem:$count:$number:\n";
#                        &Gbret;
                        print "New for: $index\n";
                        print "New for: $retcall{$index}\n";  

                    	open (OUT3, ">$out.$index.exception.list") || die "I can't open $out.$index.exception.list\n";

                        my @arr4 = split(/,/, $retcall{$index});
                        foreach my $linec (@arr4) {
                            print OUT3 "$linec\n";
                        }
                        print ERR "perl ~/bin/perl/genbank_get_products_svn2.pl $out.$index.exception.list $number $out.redone\n\n";                        
                    }
                    else {
            			print ERR "Right: $elem:$count:$number:\n";
                    }
            }
            elsif ($elem =~/error$/) {

                open (IN2, "<$elem") || die "I can't open $elem\n";
	            my @in2 = <IN2>;

                my $gi_list = $in2[0];	
#                print "Retrying $elem\n";
#                print "Number: $number\n";
#                print "INDEX: $index\n";
#                print "GI:$gi_list\n";

#                &Gbret;
                print "Redone $elem\n\n";

        	sleep(10);
            }
            elsif ($elem =~/exception.list$/)  {
                    print ERR "perl ~/bin/perl/genbank_get_products_svn2.pl $elem $number $out.redone\n\n";   
            }
        
}

print "Fishished rerunning\n";


close (OUT);

close (ERR);




####

sub Gbret {              

	$base = 'http://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
	$url = $base .  "esearch.fcgi?db=protein&term=$gi_list&usehistory=y&retmax=50000&email=mz3\@sanger.ac.uk";
#	print "$url\n";
	#post the esearch URL
	my $output = get($url);

	#parse WebEnv and QueryKey
    my $count = "0";
	my $web = $1 if ($output =~ /<WebEnv>(\S+)<\/WebEnv>/);
	my $key2 = $1 if ($output =~ /<QueryKey>(\d+)<\/QueryKey>/);
	$count = $1 if ($output =~ /<Count>(\d+)<\/Count>/);


	print "Key: $key2\n";
	print "Web: $web\n";
	print "Count: $count\n";

	if ( $count == 0 ) {
        #catch exceptions
		my @arr2=split(/,/,$gi_list);
        my $el = "$out" . "\.$index" . "exception" .  "\.list";
        open (EXC, ">$el") || die "I can't open $el\n";
		foreach my $elem (@arr2) {
    		print EXC "$elem\n";
		}
        close (EXC);
	}
    else {
	#assemble the efetch URL
		$url = $base . "efetch.fcgi?db=protein&query_key=$key2&WebEnv=$web&email=mz3\@sanger.ac.uk";
	# 233683-split[1-5]" "/s
		$url .= "&rettype=gp&retmode=text";


	my $out2 = "$out" . "\.$index" . ".gb";
	#post the efetch URL
	$fasta = get($url);
    if ($fasta=~/\w+/) {
	open (OUT, ">$out2") || die "I can't open $out2\n";
	print OUT "$fasta";
    }
    else {
	open (OUT, ">$out2.error") || die "I can't open $out2.error\n";
	print OUT "$gi_list\n";
    }
    
    }

}
####




__END__


#Goal: Starting with a list of nucleotide GI numbers, prepare a set of corresponding accession numbers.

#Solution: Use EFetch with &retttype=acc

#Input: $gi_list – comma-delimited list of GI numbers

#Output: List of accession numbers.


$gi_list = '24475906,224465210,50978625,9507198';

#assemble the URL


$base = 'http://eutils.ncbi.nlm.nih.gov/entrez/eutils/';
$url = $base . "efetch.fcgi?db=nucleotide&id=$gi_list&rettype=acc";

print "URL:$url\n";
#post the URL
$output = get($url);
print "$output";




__END__
# http://www.ncbi.nlm.nih.gov/protein/gi|256081707


# Works: mfetch -d embl -i acc:X76770 -v full

mfetch -d embl -i acc:226479796 -v full
mfetch -d refseq -i acc:NM_009417.2 -v full
mfetch -d refseq -i acc:NM_000547.4 -v full
mfetch -d refseq -i acc:NM_001003009.1 -v full
mfetch -d refseq -i acc:NM_019353.1 -v full
