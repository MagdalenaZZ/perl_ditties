#!/usr/local/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die 'Usage: table_apply.pl table1

Takes one tab-delimited table and performs a calculation on them 

Very weird script!!!



'
}



my $data = shift;
my $out = "$data.out";


open(DATA, "<$data") or die "Cant find file $data\n  $!";
open(OUT, ">$out") or die "Cant find file $out\n  $!";


my $first = 1;

my $i=0;

# get the matching rows 

while ( <DATA> ) {
    chomp;
    my @arr = split("\t", $_);

    # remove header
    if ($first =~/1/) {
        print OUT "$_\n";
        $first =0;
        next;
    }

    else {

      
        my $row1 = shift (@arr);

        print OUT "$row1\t";

        foreach my $el (@arr) {
       
            my $x = $el;
            my $res;

            # remove instances where they are not numbers
            unless (  $x =~ /^\d+$/ or $x =~ /^[+-]?\d+$/ or $x  =~ /^[+-]?\d+\.?\d*$/ or $x  =~ /^[+-]?\d+\.?\d*e\-\d+$/  ) {
                print "Not number $row1\t:$x:\n";
                $i++;
                next;
            }
            # if (  ($x!~/^\d+$/ || $x!~/^\d+\.\d+$/ )  and  ($y!~/^\d+$/ || $y!~/^\d+\.\d+$/ )   ) {
            #}
            if ($x!~/^0$/) {
            #if ($x!~/^0$/ and $y!~/^0$/) {
            # CALCULATION STATEMENT
                $res = log10($x + 1) ;
            }
            else {
                $res = log10(1)+0.00001;
            }

            #print OUT2 "$head[$i]\t$row1\t$x\t$y\t$res\n";
            print OUT "$res\t";
            $i++;

        }


    }
    print OUT "\n";


}


sub log10 {
    my $n = shift;
    return log($n)/log(10);
}

close(OUT);


exit;


__END__




