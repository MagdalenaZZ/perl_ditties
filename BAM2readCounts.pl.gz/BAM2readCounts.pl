#!/usr/bin/perl -w



use strict;

unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

die 'Usage:   BAM2readCounts.pl  gff *.bam



The GFF-file needs to look like this:

Schisto_mansoni.Chr_1.unplaced.SC_0010        chado   exon    9513    9784    .       +       .       Smp_137360.1
Schisto_mansoni.Chr_1.unplaced.SC_0010        chado   exon    14110   14416   .       +       .       Smp_137360.1
Schisto_mansoni.Chr_1.unplaced.SC_0010     chado   exon    121509  121525  .       +       .       Smp_027990.1






'
}


my $in =shift;
my @bams =@ARGV;


open (OUT, ">$in.sh") || die "I can't open $in.sh\n";


=pod
# parse the gff and make it right

open (IN, "<$in") || die "I can't open $in\n";
open (OUT, ">$in.gff") || die "I can't open $in.gff\n";

system "cat $in | grep -w gene | sed 's/gene/CDS/'  ";

my @in = <IN>;
close (IN);


=cut




foreach my $file (@bams) {
    #print "$file\n";
    my $prefix = $file;
    $prefix=~s/\.gz//g;
    $prefix=~s/\.bam//g;
    $prefix=~s/\.sam//g;
    $prefix=~s/\.accepted_hits//g;
    $prefix=~s/\//\./g;

    print OUT "bash ~bf3/bin/tophat1.bam2BEDtools.auto.sh $file \n";
    print OUT "bash ~bf3/bin/tophat2.bam2RPKM_BEDtools.sh $file.forBEDToolsOnly.UNsorted.raw_mapQ30.bam   $in  $prefix\n";
    print OUT "rm -f *.tmp\n";

#    system "bash ~bf3/bin/tophat1.bam2BEDtools.auto.sh $file ";
#    system "bash ~bf3/bin/tophat2.bam2RPKM_BEDtools.sh $file.forBEDToolsOnly.UNsorted.raw_mapQ30.bam   $in  $prefix";



}


close (OUT);


exit;







