#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta_from_gff.pl ref.fas input.gff out-prefix <offset>

Takes a gff-file and a fasta-file and makes fasta-file from it.


Example:
perl ~/bin/perl/fasta_from_gff.pl genome.fa  file.gff 
perl ~/bin/perl/fasta_from_gff.pl genome.fa  file.gff 10


NOT WORKING  --> if you set offset to "adaptive", it will extend to next gene

# make sure the fasta is single-line

offset will add a set of bases to the start or the end of your sequence (it is optional, and should only be used when there are not CDS which should be cobbled together)



'
}


	my $ref = shift;
	my $in = shift;
	my $out = $in;
    my $off = 1;

    if (@ARGV) {
        $off = shift;
    }


# get the genes from the gff

my %gff;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

    my $gene;

    foreach my $ele (@in) {
        chomp $ele;
        my @arr = split(/\t/, $ele);
        if ($arr[2]=~/gene/) {
            $gff{$arr[0]}{"$arr[3]\t$arr[4]\t$arr[6]"}{"GENE"}="$ele";
            $gene ="$arr[3]\t$arr[4]\t$arr[6]";

        }
        else {
            push( @{$gff{$arr[0]}{$gene}{"CDS"}}, "$ele") ;

        }
    }


# read in the fasta

open (FAS, "<$ref") || die "I can't open $ref\n";

my %fas;
$/ = ">";   



while (<FAS>) {
    chomp;
    if ($_=~/\w+/) {
        my @ar2 = split(/\n/,$_);
        my $head = shift(@ar2);
        my $seq = join("", @ar2);
        #print "$head\t$seq\n";
        if ($head =~/\w+/ and $seq=~/\w+/){
            $fas{$head}=$seq;
        }
    }
}

$/ = "\n";  

# extranct the genes from the fasta

open (OUT, ">$out.fas") || die "I can't open $out.fas\n";
open (OUG, ">$out.gff") || die "I can't open $out.gff\n";	


foreach my $scaf (sort keys %gff ) {
   
    my $seq;
    #print "$scaf";
    if (exists $fas{$scaf}) {
        #print "$scaf exists\n";
        $seq= $fas{$scaf};
    }
    else {
        print "$scaf does not exists in fasta, will be ignored - check you chose the right fasta and gff-file\n\n";
    }


    # get the gene coordinates from the fasta

    foreach my $gen (sort keys %{$gff{$scaf}} ) {
        

        # now get the fasta-sequence covering that gene
        my ($start,$end,$ori)=split(/\s+/, $gen );
        #print "$scaf\t$gen\t:$start:$end:$ori:\t$gen\t$gff{$scaf}{$gen}{GENE}\n";


            $start = $start - $off;
            my $adjust = $start - $off+1;

            my $len = ($end - $start  + $off );
            $end = $end + $off;
            my $sub = substr($seq, $start, $len);
            print OUT ">$scaf\_$start\-$end\-$len\n$sub\n";


=pod
        if ($ori=~/\+/) {
            $start = $start - $off;
            $end = $end + $off;
            my $len = $end - $start;
            my $sub = substr($seq, $start, $len);
            print OUT ">$scaf:$start:$end\n$sub\n";
        }
            #elsif ($ori=~/\-/) {
            $start = $start - $off;
            $end = $end + $off;
            my $len = $end - $start;
            my $sub = substr($seq, $start, $len);
            print OUT ">$scaf:$start:$end\n$sub\n";

            }
        else {
            #print "Warning, no orientation given for gene $gen\n";
            $start = $start - $off;
            $end = $end + $off;
            my $len = $end - $start;
            my $sub = substr($seq, $start, $len);
            print OUT  ">$scaf:$start:$end\n$sub\n";
        }

=cut


        # now re-position the gff-file
        
        # recalculate gene-positions
        my @new_gene = split(/\t/, $gff{$scaf}{$gen}{GENE});
        $new_gene[0]="$scaf\_$start\-$end\-$len";
        $new_gene[3]=($new_gene[3]-$adjust);
        $new_gene[4]= ($new_gene[4]-$adjust);
        my $new_gene = join("\t", @new_gene);

        #print "$gff{$scaf}{$gen}{GENE}\n";
        print OUG "$new_gene\n";
        
         if (exists $gff{$scaf}{$gen}{CDS}  ) {
            foreach my $cds ( @{ $gff{$scaf}{$gen}{CDS} } ) {
           
           
                # recalculate other posistions 
                
                               
                my @new_cds= split(/\s+/, $cds);
                
                #print "CDS " . scalar(@new_cds) . " $adjust $cds\n";

                if (scalar(@new_cds)>7) {
                    $new_cds[0]="$scaf\_$start\-$end\-$len"; 
                    $new_cds[3]=($new_cds[3]-$adjust);
                    $new_cds[4]=($new_cds[4]-$adjust);
                    my $new_cd = join("\t", @new_cds);

                    #print "$gff{$scaf}{$gen}{GENE}\n";
                    print OUG "$new_cd\n";
                }
            }
        }
        else {
            print "empty CDS $gen\n";
        }


        

    }
}




	close (OUT);
	close (OUG);


# make files for artemis

system "samtools faidx $out.fas";
system "/nfs/users/nfs_m/mz3/bin/perl/gff2art.pl $out.gff";

print "You can use the files test.bam.trans.gff.fas and test.bam.trans.gff.gff.gz for Artemis \n\n";

__END__

# fix the input format

system("cat $in | sed 's/exon/CDS/'| sed 's/five_prime_UTR/CDS/'| sed 's/three_prime_UTR/CDS/' | sed 's/similarity/CDS/'| grep -w CDS  | awk -F':' '{print \$1}' |sed 's\/=\/\\t/' | awk '{print  \$1\"\\t\"\$2\"\\t\"\$10\"x\"\$7\"\\t\"\$4\"\\t\"\$5\"\\t\"\$6\"\\t\"\$7\"\\t\"\$8\"\\t\"\$9}'  > $out.temp.gff ");
# run bedtools

my $call2 = "~jit/bin/BEDTools-Version-2.10.1/bin/fastaFromBed -s -name -fi $ref -bed $out.temp.gff -fo $out.out ";

print "Done bedtools\n";

# merge CDSs belonging to the same gene to one contig

my $call3 = " cat $out.out | grep '>' | sort | uniq > $out.list ";

	open (SH, ">$out.sh") || die "I can't open $out.sh\n";
		print SH  " $call2 ; $call3; ";
	close (SH);

system "sh $out.sh";

	open (IN2, "<$out.out") || die "I can't open $out.out\n";
	my @in2 = <IN2>;
	close (IN2);

	open (IN3, "<$out.list") || die "I can't open $out.list\n";
	my @in3 = <IN3>;
	close (IN3);

 sleep(5);

print "Done sleep\n";

# make hash for orientation


#=pod=pod
my %orient;

foreach my $line (@in3) {
#	print "Line $line\n"; <STDIN>;
	$line =~ tr/\>//d ;
	my ($key, $value)=split(/x/, $line);
	chomp $value;
#	print "Key $key--\n"; <STDIN>;
#	print "Value $value\n"; <STDIN>;
 	$orient{$key} = $value;
}
#=cut

# make hash with sequences
my %seqs;
	my $name;
foreach my $elem  (@in2) { 
	chomp $elem; 
#	my $name;
#	print "Line $elem\n"; <STDIN>;
	if ($elem=~/^>/) { 
		$elem =~tr/\>//d;
		my $x =0 ;
		($name, $x)= split(/x/, $elem);
#	print "Name $name\n"; <STDIN>;		
	} 
	else { 
		push(@{$seqs{$name}}, $elem);
#	print "Name $name\n"; <STDIN>;	
#	print "Seq $elem\n"; <STDIN>;	
 	} 
} 

print "Done sequences\n";


	open (OUT, ">$out.final.fa") || die "I can't open $out.final.fa\n";


# output hash
my $seq = "";
foreach my $head (sort keys %seqs) {
	print OUT ">$head\n";
	#print ">$head\n"; <STDIN>;
	if ($orient{$head}) {
		my $check = scalar @{$seqs{$head}};
		#print "orient $orient{$head} yes $head exist $check"; <STDIN>;
		$seq = join("",@{$seqs{$head}}) if $orient{$head} eq "+"; 
		$seq = join("",reverse @{$seqs{$head}}) if $orient{$head} eq "-" ; 
		print OUT "$seq\n";
        print "$head\n";

		my $length = length($seq);
#		print "$length\n"; <STDIN>;
        #my $length2 = ($length/3) ;
            #unless ($length2=~/^\d+$/   ) {
                #print "Wrong length $head $length\n";
                  #}
		#print "+++$seq\n"; <STDIN>;
	} 
	else {
		print "$head do not exist in orient hash"; <STDIN>;
	}
}

close (OUT);

#print "Done output\n";


#open (OUT, "<$out.final.fa") || die "I can't open $out.final.fa\n";


#system "perl ~mz3/bin/perl/translate.pl $out.final.fa 1";

#print "Done translate\n";

#close (OUT);
