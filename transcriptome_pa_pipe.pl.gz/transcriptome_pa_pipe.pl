#!/usr/local/bin/perl -w


use strict;

unless (@ARGV == 3) {
        &USAGE;
}

sub USAGE {

die 'Usage: transcriptome_pa_pipe.pl velvet-folder species reference

Takes a transcriptome assembly, and then clusters and translates it,
    and then looks for full-length reads

species = species name to do augustus against
reference = species to blast against in order to determine completeness




'
}

my $fol = shift;
my $spec = shift;
my $ref = shift;

open (OUT, ">$fol.$spec.translate.sh") || die;

# clean the asseembly from AAAAAAs

print OUT "~mz3/bin/perl/fasta_change_A2N.pl 20 $fol/transcripts.fa \n";
print OUT "mv $fol/transcripts.fa.N.fas  $fol/transcripts.fa \n";

print OUT "~mz3/bin/perl/fasta_change_A2N.pl 20 $fol/UnusedReads.fa \n";
print OUT "mv $fol/UnusedReads.fa.N.fas  $fol/UnusedReads.fa \n";

# cluster the assembly

print OUT "perl ~mz3/bin/perl/usearch_clustering.pl $fol\n";
# print " perl ~/bin/perl/usearchParser.pl uc  $fol.fa.sl.consensus \n";


# translate the assembly
print OUT "perl ~mz3/bin/perl/transcriptome_translator.pl $spec $fol.fa.sl.merged.fas \n";

# result $fol.fa.sl.consensus.aa


# blast it

# print OUT "blast_splitter.py --protein_ref $fol.fa.sl.consensus $ref blast\_$fol\_vs\_$ref 100000 -p blastp -m 8\n";
#
print OUT "makeblastdb -dbtype prot -parse_seqids -in $ref\n";

print OUT "blastp -query $fol.fa.sl.merged.fas.aa -db $ref -out blast\_$fol\_vs\_$ref.blast   -max_target_seqs 2 -evalue 0.0001 -outfmt 6\n";

#  look for full-length reads

#print OUT "perl ~mz3/bin/perl/blast_completeness.pl blast\_$fol\_vs\_$ref/all.blast $fol.fa.sl.consensus.aa $ref   \n";
#print OUT "perl ~mz3/bin/perl/translation_evaluation_filter.pl  $fol.fa.sl.consensus.aa $ref blast\_$fol\_vs\_$ref/all.blast 60\n";

print OUT "perl ~mz3/bin/perl/blast_completeness.pl blast\_$fol\_vs\_$ref.blast $fol.fa.sl.merged.fas.aa $ref   \n";
print OUT "perl ~mz3/bin/perl/translation_evaluation_filter.pl  $fol.fa.sl.merged.fas.aa $ref blast\_$fol\_vs\_$ref.blast 60\n";


print "\nResults written to sh $fol.$spec.translate.sh \n\n";


__END__


perl ~/bin/perl/transcriptome_pa_pipe.pl 59244.MergedAssembly27 test Emultilocularis.aa.sl
perl ~/bin/perl/transcriptome_pa_pipe.pl 54505.MergedAssembly27 test Emultilocularis.aa.sl



stats for test	stats for 84894.MergedAssembly27.fa.sl.merged.fas
sum = 232481, n = 399, ave = 582.66, largest = 4881	sum = 172696, n = 264, ave = 654.15, largest = 4881
N50 = 688, n = 69	N50 = 766, n = 44
N60 = 543, n = 107	N60 = 630, n = 69
N70 = 428, n = 156	N70 = 468, n = 101
N80 = 342, n = 218	N80 = 365, n = 142
N90 = 259, n = 296	N90 = 289, n = 194
N100 = 139, n = 399	N100 = 139, n = 264
N_count = 0	N_count = 7249
