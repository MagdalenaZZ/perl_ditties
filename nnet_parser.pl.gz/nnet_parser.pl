#!/usr/bin/perl -w

use strict;
#use Cwd;
#use Statistics::Lite qw(:all);

unless (@ARGV > 0 ) {
        &USAGE;
}


sub USAGE {

    die '


Usage: nnet_parser.pl genelist nnet_result.Rout


This script parses the Rout output file of the nnet_script.
and delivers a ranked gene list




' . "\n";

}

# Get the files right

#my $cwd = cwd();
my $genelist=shift;
my $in=shift;


#$/ = ">>";


open (OUT, ">$in.topgenes") || die "I can't open $in.topgenes\n";

if ($in=~/.gz$/) {
	open (IN, "gunzip -c $in |") || die "I can't open pipe to $in\n";
}
else {
	open (IN, "<$in") || die "I can't open $in\n";
}


open (IN2, "<$genelist") || die "I can't open $genelist\n";

#my @in = <IN>;
my @in2 = <IN2>;
close (IN2);

# read through the file, catch the varsel rankings

print OUT "Freq\tNumber\tSymbol\n";

while (<IN>) {

	#print "ELEM $elem\n";

	if ($_=~/varsel_LOOCV\@rankings/) {
		#print "$_\n\n";
		#$/= "\n";
		my $nothing = <IN>;
		my $genes = <IN>;
		my $ranks = <IN>;

		if ($nothing=~/Error/) {
			exit;
		}

		$ranks =~ s/^\s+//;
		$genes =~ s/^\s+//;
		chomp($ranks);
		chomp($genes);
		
		#print "$in\t$genes\t$ranks\n";

		my @gen =split(/\s+/,$genes);
		my @ran =split(/\s+/,$ranks);

		my $i=0;
		foreach my $rank (@ran) {
			if ($rank>1) {
				print OUT "$rank\t$gen[$i]\t$in2[($gen[$i]-1)]";
			}
			else {
			}
			$i++;
		}
		#print "$genes\t$ranks\n";

		close (IN);
		close (OUT);
		exit;
	}
	else {
	}


}





