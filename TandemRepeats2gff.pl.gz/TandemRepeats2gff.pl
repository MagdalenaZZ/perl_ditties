#!/usr/local/bin/perl -w

use strict;
use Cwd;
#use Data::Dumper;
use File::Slurp;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: TandemRepeats2gff.pl  <folder>

Takes the output from the software TandemRepeats
and returns a gff-file



NOT FINISHED!!!!



'
}


my $cwd = cwd();
my @paths = read_dir( "$cwd", prefix => 1 ) ;
open (OUT, ">TandemRepeat.gff") || die "I can't open TandemRepeat.gff\n";



foreach my $file (@paths) {

    if ($file=~/\.txt\.html$/ and $file=~/\w+/) {
        #print "Opening $file\n";
	    open (IN, "<$file") || die "I can't open $file\n";
        #my @in = <IN>;

        my $head;
        my $ind;
        my $con;
        my $per;
        my @ind;

        while (<IN>) {
            chomp;
            #print "$_\n";
            if ($_=~/^Sequence: \w+/) {
                $head = $_;
                $head=~s/Sequence: //;

                #print "HEAD:$head\n";
            }
            elsif ($_=~/^\s+Indices:/) {
                $ind = $_;
                #print "IND:$ind\n";
                @ind = split(/\s+/, $ind);
                $ind[2]=~s/--/\t/;
                $per = <IN>;
                chomp $per;
            }
            elsif ($_=~/^Consensus pattern/) {
                $con = <IN>;
                chomp $con;
                #print "CON: $con";
                print OUT "$head\tTandemRepeat\tCDS\t$ind[2]\t\.\t\+\t\.\tID=$head;note=$con $per\n";
            }
            else {
            }
            

        }

	    close (IN);
    }

}

close (OUT);
system "perl ~mz3/bin/perl/gff2art.pl TandemRepeat.gff ";


__END__
	my $in = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

#	open (OUT, ">$in.fas") || die "I can't open $in.fas\n";







