#!/usr/bin/perl -w
use strict;

unless (@ARGV == 1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff2glimmer3.pl <gff-file> 

mz3 script for converting a gff-file with training genes to Glimmer training input

'
}

my $in = shift;

open IN, "<$in";

my %hash;
my @cds_array;
my $old_name;
my $st_tmp;
my $end_tmp;
my $foo;
my $old_strand =0;

while (<IN>) {
	chomp;
tr/=/ /;

	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $zero = $line[7];	
	my $note = $line[8];
	my $phase = 0;
	
###############################

	if ($tag eq "gene"){

# PRINT THE ARRAY
		if ($old_strand eq "+")
		{
			print map {"$old_name\t$_\n"} @cds_array;
		}
		elsif ($old_strand eq "-")
		{
#			print "$cds_array[0]\n";
#			print "$cds_array[1]\n";
			my ($first, $red)= split (/\t/  , $cds_array[0]);
#			print "$first\n";
			my ($last, $red2) = split (/\t/  , $cds_array[$#cds_array]);
#			print "$last\n";
			if ($first > $last) {
#			@cds_array = reverse (@cds_array);
			print map {"$old_name\t$_\n"} @cds_array;
			}
			elsif ($first < $last) {
			@cds_array = reverse (@cds_array);
			print map {"$old_name\t$_\n"} @cds_array;
			}

		}
		else {
		}		
		@cds_array =(); 
		print "\n";	
	}

	if ($tag eq "CDS") {

# GET START AND END ORDERED	
		if ($start < $end) {
		$st_tmp=$start;
		$end_tmp=$end;
		}
		if ($start > $end) {		
		$st_tmp=$end;
		$end_tmp=$start;
		}

#		$old_name = $name;
		$foo = "$st_tmp\t$end_tmp";


# SORT THE ARRAYS
		
		if ($strand eq "+") {
#			$foo = "$st_tmp\t$end_tmp";
			push @cds_array, $foo;
		}	

		elsif ($strand eq "-") {
			$foo = "$end_tmp\t$st_tmp";
			push @cds_array, $foo;
		}

		$old_name = $name;
		$old_strand = $strand;
#		print "$old_strand\n";
		
	}

# print "$old_strand\n";
}

close (IN)