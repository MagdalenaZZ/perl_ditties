#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}



sub USAGE {

die ' 

Usage:

perl ~/bin/perl/pfam_love_my_domain.pl  <domain>  file.fasta





';

}




my $dom = shift;
my $fasta = shift;

print "mkdir domain_$dom\n";

print "cat ../*/*.pfam | grep $dom > $dom.pfam\n";

print "cat ../*/*.pfam | grep $dom | cut -f1 | sort | uniq > $dom.pfam.list\n";

print "cat ../*/*.pfam | grep -f $dom.pfam.list  > $dom.pfam.associations\n";
print "perl ~/bin/perl/domain_compare_cluster.pl $dom.pfam.associations\n";

print "cat $dom.pfam.associations | cut -f7 | sort | uniq -c | sort -nr > $dom.pfam.associations.sum \n";


print " cat  ../*/*.phobius.sp | grep -f $dom.pfam.list > $dom.sp \n";

print "cat  ../*/*.phobius.tm | grep -f $dom.pfam.list > $dom.tm\n";



print "perl ~/bin/perl/pfam2gff_n_fasta.pl $dom.pfam $fasta\n";

print "perl ~/bin/perl/phylogenize_me.pl domain_fasta_$dom.pfam/$dom.fas prot aln \n";

print "~/bin/FastTree -gamma -out $dom.dom_only.nwk domain_fasta_$dom.pfam/$dom.fas.mfa\n";

print "perl ~/bin/perl/tree_painter.pl  $dom.dom_only.nwk\n";

print "mv *$dom* domain_$dom\n";

print "\n";
print "\n";


print "\n";
print "\n";
