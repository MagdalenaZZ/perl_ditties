#!/usr/bin/perl -w


use strict;


unless (@ARGV==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_overlap_collapser.pl gff  
Finds adjoining overlapping features





'
}

my $in = shift;


# store info from gff in a hash
my %conts;

open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\s+/, $line);
        $conts{$arr[0]}{$arr[3]}{"$line"}=1; 
}




system "~jit/bin/BEDTools-Version-2.12.0/bin/mergeBed  -nms -i $in > $in.merged ";


open (IN, "<$in.merged") || die "I can't open $in.merged\n";
my @in2 = <IN>;
close (IN);

open (OUT, ">$in.merged.gff") || die "I can't open $in.merged.gff\n";

foreach my $line (@in2) {
    chomp $line;
    #print "$line\n";
    my @arr = split(/\t/, $line);


    my $ori = "+";
    my $note = "note=";
    my $feat = "merged";
    my $thing = "CDS";

    # check if there is a feature matching that
    if (exists $conts{$arr[0]}{$arr[1]} ) {

        my $len = scalar(keys %{$conts{$arr[0]}{$arr[1]}});
        #print "LEN $len\n";

        # if there is only 1 key
        #if ($len=~/^1$/) {
            # print "$conts{$arr[0]}{$arr[1]}\n";
            #}

        # if there are more keys
        foreach my $key (keys %{$conts{$arr[0]}{$arr[1]}} ){
            #print "Exists $key \n";
            my @ar = split(/\t/, $key);
            $ori = $ar[6];
            $note=$ar[8];
            $feat=$ar[1];
            $thing=$ar[2];
        }
    }

    else {
        #print "NOT $arr[0]\t$arr[1]\n";
    }
    
    

    print OUT "$arr[0]\t$feat\t$thing\t$arr[1]\t$arr[2]\t\.\t$ori\t\.\t$note\n";
}


close(OUT);






__END__




open (IN, "<$in") || die "I can't open $in\n";
my @in = <IN>;
close (IN);

my $start = 0;
my $end = 0;
my $last_line = 0;

my @out;


my %conts;

# read in each contig separately

foreach my $line (@in) {
    chomp $line;
    my @arr =split (/\s+/, $line);
    if ($arr[4]-$arr[3] > 50000 ) {
        print "WARNING: long gene discarded: $line\n";
    }
    else {
        $conts{$arr[0]}{"$arr[3]\t$arr[4]"}{"$line"}=1; 
    }

    

}


# put in a fake line
#foreach my $key (sort keys %conts) {
#    push ( @{$conts{ $key }},  "$key\t0\t0\t999999999999998\t999999999999999\t0\t0\t0\t0\t0\t"); 
#}

my %res;


foreach my $scaf (sort keys %conts) {


    
    foreach my $gene (sort keys %{$conts{$scaf}}) {

        my @ovl;

        foreach my $gene2 (sort keys %{$conts{$scaf}}) {
            print "$scaf\t$gene\t$gene2\n";
            #print "$scaf\t$gene\n";
            
            # test overlap with all and save to @ovl





        }

            # if there is an overlap, remove the old keys and make a new one


            # if there is no overlap put in result

    }    
    
    
    
#
#    my @unsort = @{$conts{$key}};

#    my @sort = sort { (split '\t', $a)[3] <=> (split '\t', $b)[3] || (split '\t', $a)[4] <=> (split '\t', $b)[4]    } @unsort ;

#            print "START\n";
    # check overlap with previous

}


