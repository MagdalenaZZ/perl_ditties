#!/usr/local/bin/perl -w


use strict;

unless (@ARGV >5) {
        &USAGE;
}

sub USAGE {

die 'Usage: iCORN.pl readRoot read_1.fastq read_2.fastq fragment-size reference start end

i.e. perl ~/bin/perl/iCORN.pl test 300 ../new.500.fas 1 1

#read-root = expects input-files to be called "$readRoot"_1.fastq and "$readRoot"_2.fastq
fragment-size = <expected insert size>
reference - reference genome




'
}


my $readRoot= shift;
my $read1 = shift;
my $read2 = shift;
my $fragmentSize = shift;
my $ref = shift;
my $start = 1;
my $end = 1;

# Renaming the reads

system "ln -s $read1 $readRoot\_1.fastq";
system "ln -s $read2 $readRoot\_2.fastq";


# clean the input-file
#

print "\n\nCleaning up the input file\n\n";
system "perl ~/bin/perl/choose_length.pl $ref $ref.500 500";
system "perl ~/bin/perl/fasta_rename.pl $ref.500 LIST  $ref.500.renamed";
system "perl ~/bin/perl/fasta_caps.pl $ref.500.renamed";
system "perl ~/bin/perl/gc_content.pl $ref.500.renamed.caps";

print "Contigs shorter than 500 bp have been removed\n\n";

print "If the sequences in your reference has some funny characters you should strongly consider removing them before progressing any further\n\n";

my $reference = "$ref.500.renamed.caps";

my $i = $start;
my $rand = substr( rand, 2, 5);

open (SH, ">ICORN$rand.sh");


while ($i<=$end) { 
    print SH "# Round $i\n";
	
	my $directory = "ICORN$rand" . "_$i";

	### call the mapper
	 if ("$i" == "$start" ) {
            print SH "# 1 Mapping command\n";	    
            print SH "/nfs/users/nfs_m/mh12/git/python3/map_splitter.py  -M 8 -m 0.6 --setup_mem 6.5 -c ICORN2.MAP.$rand.$i bwa  $reference $directory $read1 $read2";
            print SH "\n";
    }
	else {
	    print SH "# 1 Mapping command\n";
        my $prev = $i-1;
	    print SH " /nfs/users/nfs_m/mh12/git/python3/map_splitter.py  -M 8 -m 0.6 --setup_mem 6.5 --depend ICORN.CORRECT.$rand.$prev -c ICORN2.MAP.$rand.$i -k 13 -s 3 bwa $reference.$i $directory $read1 $read2 ";
	    print SH "\n";
    }

	### call the SNP caller
	print SH "# 2 SNP calling command\n";
	print SH " bsub.py --dep=\"ICORN2.MAP.$rand.$i\" --threads=8 -q long 6 ICORN2.SNP.$rand.$i  ~mz3/bin/myICORN/my_icorn2.startSNP.sh $directory ";
    print SH "\n";	

	### call icorn starter
    my $next = $i+1;
	print SH "# 3 iCORN starter command\n";
	print SH "bsub.py --dep=\"ICORN2.SNP.$rand.$i\" -q hugemem 60 ICORN.CORRECT.$rand.$i  ~mz3/bin/myICORN/my_icorn2.correct.sh $directory $readRoot $fragmentSize $reference.$next\n";	
	
    $i ++;	

}


close (SH);

print "\n\nCommands written to file ICORN$rand.sh \n\n";
exit;





