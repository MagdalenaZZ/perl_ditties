#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: split_checker.pl output \'infile-pattern\'

Takes an output which has been run on a fasta-file
and a match to the fasta-files which were the input

Example: perl ../split_checker.pl  HYM.results.raw \'HYM_\d+.fa\'

It gives output to say whether the output is free from repeats, and contains results from all the infiles 


'
}

my $res = shift;
my $pattern = shift;
my $files;
my $cwd = cwd();
# print "CWD: $cwd\n";
my $folder = cwd();
my @files;

# Read infiles into %in

my @paths = read_dir( "$folder", prefix => 1 ) ;

print "PAT:$pattern:\n";
open (OUT, ">$res.$pattern.res") || die "I can't open $res.$pattern.res\n";

my %in;

foreach my $file (@paths) {

    if ($file=~m/$pattern/) {
        print "Reading $file\n";
        
        push (@files, $file);
        open (IN, "<$file") || die "I can't open $file\n";
    	my @in= <IN>;
    	close (IN);

        foreach my $line (@in) {
            chomp $line;
            if ($line=~m/\>/) {
                $line=~s/\>//;
                my @arr = split(/\s+/, $line);

                $in{$arr[0]} = $file;
                #print "$file\t$line\n"; <STDIN>;
            }
        }
    }
    else {
        # rejected file
    }


}


# Read output into %out
#
my %out;
        open (RES, "<$res") || die "I can't open $res\n";
    	my @res= <RES>;
    	close (RES);

my %res;
my $indicator = 0;

foreach my $line (@res) {
    chomp $line;
    if ( $line=~m/##FASTA/ or $indicator=~/1/ ) {
        $indicator=1;
    }
    elsif ($line=~m/^#/){
    }
    elsif ($line=~m/\w+/){
        my @arr = split(/\s+/, $line);
        $res{$arr[0]}=+1;
        #print "$arr[0]\n";
    }
}

=pod
foreach my $elem (keys %res) {
    if ($res{$elem} > 1) {
        print "$elem is repated $res{$elem} times \n";
    }
}
=cut

print "Finished reading results\n";

# parse through the output and check that everything is there

my %used;
my %used_res;


    foreach my $key (keys %in) {
           my @hits = grep(/$key/, keys %res);
           foreach my $li (@hits) {
            # store how many times an infile is used
                $used{$in{$key}}=+1;
            # store the nice results
                $used_res{$li}=+1;
           }
    }

=pod

foreach my $elem (keys %res) {
#    print "ELEM:$elem\n";
    foreach my $key (keys %in) {
#           my $el=$in{$key};
#    print "KEY:$el\n";        
        if ($elem=~m/$key/) {
#            print "$key is in $elem\n";
            # store how many times an infile is used
            $used{$in{$key}}=+1;
            # store the nice results
            $used_res{$elem}=1;
        }
    }
}
=cut


print "Finished checking output\n";


# parse through the output and flag up all lines which do not have input

foreach my $elem (keys %res) {
    if (exists $used_res{$elem}) {
     # do nothing
    }
    else {
        print "WARNING - unused result: $elem \n";
    }
}

print "Finished checking results\n";

# parse through the input and flag up any file which do not have output

#my @files2 = (keys %used);

my $quit = 0;

foreach my $line (@files) {
        if (exists $used{$line}) {
            print  OUT "This file has output: $line $used{$line}\n";
        }
        else {
            print OUT "This file doesn't have output: $line\n";
            $quit=1;
        }
    
}


unless ($quit==0) {
    exit;
}
# print parsed results
#
#print "Writing corrected results\n";

#        open (OUT, ">$res.corrected") || die "I can't open $res.corrected\n";
 
#foreach my $elem (keys %used_res) {
#        print OUT "$elem\n";
#}



    	close (OUT);


__END__



