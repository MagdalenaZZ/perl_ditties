#!/usr/bin/perl -w

use strict;


unless (@ARGV > 1) {
        &USAGE;
}


sub USAGE {

    die '


Usage: perl ~mz3/bin/perl/gff_make_all_splice_forms.pl gff-file junctions.gff.stats

Run this program through the complete pipeline:  alternative_splice-forms.pl 


'}



my $genes = shift;
my $file = shift;


system "cat $genes $file | sed 's/mRNA/BmRNA/' | sed 's/gene/Agene/' | sort -k1,1 -k4,4n -k3,3  > $file.temp.gff ";
# print "cat $genes $file | sed 's/mRNA/BmRNA/' | sed 's/gene/Agene/' | sort -k1,1 -k4,4n -k3,3  > $file.temp.gff \n";

# read in the genes, and save them as {contig}{gene}{info}{CDS}=info
open (GFF, "<$file.temp.gff") ||  die "I cant find file $file.temp.gff " ;


my %h;
my $curr_gene = "0";
my $curr_gene_info = "0";
my $gene_end;




while (<GFF>) {
    chomp $_;
    my @arr = split(/\t/, $_);
    
    #print "$arr[2]\n";

    if ($arr[2]=~/gene/) {
        $curr_gene = $arr[8];
        $curr_gene=~s/ID=//;
        $curr_gene_info = $_;
        $h{$arr[0]}{$curr_gene}{$_}{""}="";

    }
    elsif ($arr[2]=~/CDS/ || $arr[2]=~/exon/ ) {
        my @arr2= split(/;/, $arr[8]);
        my $curr_cds = $arr2[0];
        $curr_cds=~s/ID=//;
        
        $h{$arr[0]}{$curr_gene}{$curr_gene_info}{$curr_cds}=$_;
        #print "$curr_gene\t$curr_gene_info\t$curr_cds\t$_\n";
    }
    elsif  ($arr[2]=~/intron/ ) {
        print "int $_\n";

    }
    else {
        print "ELSE $_\n";
    }

}
close (GFF);




=pod

# read in the genes, and save them as {contig}{gene}{info}{CDS}=info
open (GFF, "<$genes") ||  die "I cant find file $genes " ;

my %h;
my $curr_gene = "0";
my $curr_gene_info = "0";




while (<GFF>) {
    chomp $_;
    my @arr = split(/\t/, $_);
    
    #print "$arr[2]\n";

    if ($arr[2]=~/gene/) {
        $curr_gene = $arr[8];
        $curr_gene=~s/ID=//;
        $curr_gene_info = $_;
        $h{$arr[0]}{$curr_gene}{$_}{""}="";

    }
    elsif ($arr[2]=~/CDS/ || $arr[2]=~/exon/ ) {
        my @arr2= split(/;/, $arr[8]);
        my $curr_cds = $arr2[0];
        $curr_cds=~s/ID=//;
        
        $h{$arr[0]}{$curr_gene}{$curr_gene_info}{$curr_cds}=$_;
        #print "$curr_gene\t$curr_gene_info\t$curr_cds\t$_\n";
    }
    else {
        #print "$_\n";
    }

}
close (GFF);

# read in the splice-junctions

open (JUN, "<$file") ||  die "I cant find file $file " ;

while (<JUN>) {
    chomp $_;
    print "$_\n";

}

close (JUN);
=cut




# conpare if the splice-junctions overlap with any gene



# output the splice-junctions that are not in genes to a separate file



# output the genes that only have non-overlapping splice-junctions

# output all alternative splice-forms for genes that have several overlapping splice-junctions




