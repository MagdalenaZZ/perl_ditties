#!/usr/local/bin/perl -w
# mz3 script for splitting a fasta-file to several chunks

use strict;

unless (@ARGV == 3) {
        &USAGE;
 }

 sub USAGE {

die 'Usage:  fasta_BED_my_genome.pl <input.fa>  <int> <ovl>

<int>  is the size of BED-regions you want 
<ovl> is the size of step you want between tiles

For instance 500 10 gives tiles of the length 500, every 10 bases; 




'
}

### this is the splitter-part of the script ####

my $in = shift;
my $bedsize = shift;
my $overlap = shift;


open (IN, "<$in") || die "cant find file $in \n";
open (OUT, ">$in.$bedsize.$overlap.bed") || die "cant open file $in.$bedsize.$overlap.bed\n";

# read in fasta

local $/ = ">";
while (my $line = <IN>)  {

  chomp($line);
  
  if ( $line!~/\w+/) {
    next;
  }
  my ($head,$seq)=split(/\n/, $line);
  
  if ($head =~/\w+/ and $seq=~/\w+/) {
	my $seqLen= length($seq);
	
	#print "FIRST $head\t$seqLen\t$bedsize\t$overlap\n";
	
	#my $i = 1;
	# for ($count = 10; $count >= 1; $count--) {
	for ( my $i = 1 ; $i < $seqLen ; $i= $i+$overlap+1) {
	    my $ie = $i+$bedsize;
	    print OUT "$head\t$i\t$ie\t$head\_$i\_$ie\t0\t+\n";
	    print OUT "$head\t$i\t$ie\t$head\_$i\_$ie\t0\t-\n";	    
	}
  }
  else {
      print "Some error with sequence $head\t$seq\n";
  }
  
}



local $/ = "\n";
close(OUT);

exit;

__END__
