#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die '



Usage: perl ~/bin/perl/gff-markup_cleaner.pl gff-file tag outfile


Give the program the gff-file you want to modify, and it will go and remove your chosen tags



'
}

	my $in = shift;
	my $tag = shift;
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

my @new;

# make format right 

foreach my $line (@in) {
chomp $line;

	my @arr = split(/\t/,  $line );

	if (exists $arr[9]) {
		my $len = scalar(@arr);
		$len--;
		my @small = @arr[9..$len];
		my $last = join("\t", @small);
#		$last=~s/_/ /g;
#		$last=~s/\,\"/\"/g;
#		$last=~s/ \"/\"/g;
#		$last=~s/db xref/db_xref/g;
#		$last=~s/GO REF/GO_REF/g;

#		print "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$last\n";
		push (@new, "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]\t$last");
	}
	else {
		push (@new,$line);
	}
}

	open (OUT, ">$out") || die "I can't open $out\n";

# remove selected products

foreach my $line (@new) {

	if ($line =~/gene/) {
#		print "Line:$line:\n";
		my @arr = split(/\t/,  $line );
		my $len = scalar(@arr);
		$len--;
		my $final;
		my $first;
		if ( $len > 8 ) {
			my @small = @arr[9..$len];
			my @first = @arr[0..8];
			$first = join("\t", @first);

# Sort out only unique product calls

			foreach my $all (@small) {
     		   		if ($all=~/$tag/) {
					print "Delete: $all\n";
				}
				else {
					print "Keep: $all\n";
				}
      			}
    		}
# if the gene doesnt have a product, give it a hypothetical one
		else {
			print OUT "$line\t/product=\"hypothetical protein\"\n";
		}			
	}

	else {
		print OUT "$line\n";
	}



}






close (OUT);