#!/usr/local/bin/perl -w

# mz3 script for taking tophat output accepted_hits.sam and turning it into cufflinks-ready file
#
use strict;

unless (@ARGV == 1) {
        &USAGE;
}

sub USAGE {

die 'Usage: tophat2cufflinks.pl <reference-genome.fas> &

Put files or softlinks to all .sam files you want to include in the working directory. The prefix given to them will be whatever is before the first  .  (dot)

The out-file is called aln-sorted.bam and this is the input for cufflinks

Do not bsub - it bsubs itself 



'
}




my $ref = shift;

print "Reference sequence: $ref \n";


# my @in2 = < all.sam >;

# if there is not an all.sam file already - make one

my $step1;

unless (-e "all.bam" ) {

my @infiles = < *accepted_hits.bam >;

unless ($infiles[0]=~/\w+/ {
        print "\nCant find any input files called *.accepted_hits.bam\n";
        die;
    }

foreach my $file (@infiles) {
    print "Reading infile $file\n";
}

my $files = join (" ", @infiles );

$step1 = "echo \"running Step1 concatenate bam-files\n\" ; samtools merge all.bam $files";
}


my $step2 = "echo \"running Step2 make faidx\n\" ; samtools faidx $ref ";

#my $step3 = "echo \"running Step3 make alignment \n\" ; samtools view -bt $ref.fai all.sam > aln.bam";

my $step4 = "echo \"running Step4 make sorted file \n\" ; samtools sort all.bam all.sorted";

my $step5 = "echo \"Running Step5 remove temporary files \n\" ; rm -fr all.sam";

my $step6 = "echo \"Skipping Step2 make faidx - using existing file $ref.fai \n\" ";

my $step7 = "rm -f t2c.e";

open CMD, ">tophat2cufflinks.sh";
# test if a .fai already exists

############ if there is already an all.sam file #########################################

if (-e "all.sam") {

    print CMD "$step2 && $step3 && $step4 && $step7 \n";

}


#####################################################
else {
    if (-e "$ref.fai") {
        print CMD "$step1 && $step6 && $step4 && $step7 \n";
    }
    else {
        print CMD "$step1 && $step2 && $step4 && $step7 \n";
    }
}
close CMD;


system ("team133-bsub.pl basement 10 t2c.o t2c.e t2c sh tophat2cufflinks.sh");

__END__



bsub.py 10 merge samtools merge all.bam EMUtophat5817_1.accepted_hits.bam EMUtophat5817_2.accepted_hits.bam EMUtophat5477_3.accepted_hits.bam EMUtophat7745_8_7.accepted_hits.bam EMUtophat7745_8_6.accepted_hits.bam EMUtophat7745_8_5.accepted_hits.bam EMUtophat7745_8_4.accepted_hits.bam EMUtophat7745_8_3.accepted_hits.bam
