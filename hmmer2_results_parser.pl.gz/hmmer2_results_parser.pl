#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: hmmer2_results_parser.pl results.out <e-val cutoff>

Example:

hmmer2_results_parser.pl results.out 0.001


'
}

	my $in = shift;
	my $cu = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	open (OUT, ">$in.gff") || die "I can't open $in.gff\n";
#	open (OUT2, ">$in.fas") || die "I can't open $in.fas\n";
#	my @in = <IN>;
#	close (IN);


while (<IN>) {
    chomp;
    #print "$line\n";

    if ($_=~/domain/ and $_=~/from/ and $_=~/score/) {
        #print "$_\n";
        my $first = <IN>;
        my $second =   <IN>;
        my $third =   <IN>;
        
        #print "$third\n";
        
        #print "4" .  <IN>;

        $_=~s/\://g;
        my @arr = split(/\s+/, $_);
        my @seq = split(/\s+/, $third);

        if ($cu > $arr[13]) {
            print OUT "$arr[0]\tHMMer\tCDS\t$arr[6]\t$arr[8]\t\.\t\+\t\.\tID=$arr[0]\_$arr[6]\_$arr[8];note=score\_$arr[10];note=eval\_$arr[13]\n";
            #print OUT2 ">$arr[0]\_$arr[6]\_$arr[8]\n$seq[3]\n";

        }
    }
}


system "cat $in.gff | sort -k1,1 -k4,4n > $in.sorted.gff ";
system "mv  $in.sorted.gff  $in.gff ";

close(IN);
close(OUT);
#close(OUT2);
exit;

