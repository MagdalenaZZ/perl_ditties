#!/usr/bin/perl -w
use strict;


if (@ARGV < 2) {

    print "\n fastq_fixori.pl file.fastq.gz|fastq text_to_insert\nExample: perl fastq_fixori.pl test.fastq.gz \"\/1\"  \n" ; 

    print "$0 fastq.gz|fastq\n" ; 
	exit ;
}



if ( $ARGV[0] =~ /.gz/ ) {
    open (IN, "zcat $ARGV[0] | ") or die "can not open $ARGV[0]\n" ;
}
else {
    open (IN , "$ARGV[0]") or die "can not open $ARGV[0]\n" ;
}

open my $out, ">" , "$ARGV[0].fq" or die "oops\n" ;
#open my $out2, ">" , "$ARGV[0].fasta.qual" or die "oops\n" ;

my $ins = $ARGV[1];


while (<IN>)
{
  	if (/^@(\S+)/) {
		print $out "$1". "$ins" . "\n" ;
		#print $out2 ">$1\n" ;
		my $read = <IN> ;
		print $out "$read" ;
		$read = <IN> ;
		#print "+\n" ;
		$read = <IN> ;
		#print "$read" ;

	#	chomp($read) ;
	#	my @read_quals = split "" , $read ;
	#	my @read_quals_converted = map( ord($_) - 33 , @read_quals) ;
	#	print $out2 "@read_quals_converted\n" ;

	}

}


