#!/usr/bin/perl -w
# mz3 script for making utr hints-files for augustus

use strict;
use Data::Dumper;

unless (@ARGV == 5) {
        &USAGE;
}

sub USAGE {

die '

Usage: perl ~/bin/perl/augustus_make_UTR_hints.pl <cufflinks-output> <augustus-ouput>  prefix  cut-off cut


launch art -test fasta out.gff aug.gff temp.out.gff



<cut-off> is the length of the UTR - if the resulting UTR is longer than this it will be trimmed down to <cut> basepairs
<cut> is the size of the fragment left behind


'
}

# Read in-files

# my $cut = 100;

    my $cufflink_file = shift;
    my $aug_file =shift;
    my $prefix = shift;
    my $cutoff = shift;
    my $cut = shift;
    my $newfile = "$prefix.aug.gff";
    my $outfile = "$prefix.temp.UTR.gff";

    $prefix = $prefix . "_" . $cutoff . "_" . $cut;

unless (-s "$cufflink_file.gff.chosen3") {

#=pod
#

### get all the cufflinks transcripts which overlaps with a gene

#system "perl ~/bin/perl/cufflinks2gff_dev2.pl  $cufflink_file > $cufflink_file.gff "; wait;
system "perl ~/bin/perl/cufflinks2gff.pl  $cufflink_file > $cufflink_file.gff "; wait;

system "cat  $cufflink_file.gff | grep -w gene > $cufflink_file.trans "; wait;

system "~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -b $aug_file -a $cufflink_file.trans -u -s > $prefix.intersect"; wait;

### get all the cufflinks exons for those transcripts

 system "cat $prefix.intersect |  awk -F'\t' '{print \$9}' > $cufflink_file.intersect.list"; wait;

# system "cat  $cufflink_file.gff | grep -w -f $cufflink_file.intersect.list | grep -w CDS >  $cufflink_file.gff.chosen  ";

  system "perl ~mz3/bin/perl/my_grep.pl -i $cufflink_file.gff -f $cufflink_file.intersect.list -o $cufflink_file.gff.chosen2 -w "; wait;

  system " cat $cufflink_file.gff.chosen2 | grep -w CDS >$cufflink_file.gff.chosen3 ";

### get rid of all those cufflinks exons which are internal to a gene

open (GFF, "<$aug_file" || die "I can't open $aug_file\n");
my @gff = <GFF>;
close (GFF);

open (CUFF, "<$cufflink_file.gff.chosen3" || die "I can't open $cufflink_file.gff.chosen3\n");
my @cuff = <CUFF>;
close (CUFF);


# make a hash of the genes

my %gff;

foreach my $line (@gff) {
    my @arr = split (/\t/,$line);
    $gff{$arr[0]}{"$arr[3]/t$arr[4]"} = $line ;
#    print "$arr[0]\t$arr[3]\t$arr[4]\n"; <STDIN>;
}

my %cuff;


foreach my $line2 (@cuff) {
    my @arr2 = split (/\t/,$line2);

    # if it is overlapping
    $cuff{$arr2[0]}{"$arr2[3]/t$arr2[4]"} = $line2 ;
    # if it is not overlapping
#    print "$arr2[0]\t$arr2[3]\t$arr2[4]\n"; <STDIN>;
}


foreach my $cont (keys %cuff) {

    # loop through all the cuff-entries
   foreach my $pos (keys %{$cuff{$cont}} ) {
       my ($start, $end) = split(/\t/, $pos);

       foreach my $gene  (keys %{$gff{$cont}} ) {
           my ($gstart, $gend) = split(/\t/, $pos);

           # if the cuff-CDS is contained in a gene - get rid
#           if ( $gstart =< $start and $end =< $gend ) {
           if (  $start >= $gstart  and $gend >= $end  ) {


               # delete that position
               delete $cuff{$cont}{$pos};
           }

       }
   }

}

}

### cut out the gene of the remaining ones

### make nice output


__END__




if ($file_type == 0) {
system `perl ~/bin/perl/augustus2gff.pl $aug_file > $newfile && 
cat  $newfile | grep -w mRNA > $prefix.temp.aug.gff &&
cat  $cufflink_file | grep -w transcript > $prefix.temp.cuff.gff &&
cat  $prefix.temp.cuff.gff | sed s/transcript/CDS/ > $prefix.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $prefix.temp.cuff.gff -b $prefix.temp.aug.gff -u -s > $prefix.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $prefix.bed.gff -b $prefix.temp.aug.gff | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i  $outfile -s > $prefix.temp2.UTR.gff `; wait;

}

elsif ($file_type == 1) {
    
system `cat $aug_file| grep -w mRNA > $prefix.temp.aug.gff &&
cat  $cufflink_file | grep -w transcript > $prefix.temp2.cuff.gff && cat $prefix.temp2.cuff.gff | sort -nk 4,4 > $prefix.temp.cuff.gff  &&
cat  $prefix.temp.cuff.gff | sed s/transcript/CDS/ > $prefix.cuff.art.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $prefix.temp.cuff.gff -b $prefix.temp.aug.gff -u -s > $prefix.bed.gff &&
~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $prefix.bed.gff -b $prefix.temp.aug.gff -s | sed s/transcript/CDS/ > $outfile &&
~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $outfile -s | sort -k1,1 -k3,3n > $prefix.temp2.UTR.gff `; wait;

#print "system `cat $aug_file| grep -w mRNA > $prefix.temp.aug.gff &&
#cat  $cufflink_file | grep -w transcript > $prefix.temp2.cuff.gff && cat $prefix.temp2.cuff.gff | sort -nk 4,4 > $prefix.temp.cuff.gff  &&
#cat  $prefix.temp.cuff.gff | sed s/transcript/CDS/ > $prefix.cuff.art.gff &&
#~jit/bin/BEDTools-Version-2.10.1/bin/intersectBed -a $prefix.temp.cuff.gff -b $prefix.temp.aug.gff -u -s > $prefix.bed.gff &&
#~jit/bin/BEDTools-Version-2.10.1/bin/subtractBed -a  $prefix.bed.gff -b $prefix.temp.aug.gff -s | sed s/transcript/CDS/ > $outfile &&
#~jit/bin/BEDTools-Version-2.10.1/bin/mergeBed -i $outfile -s | sort -k1,1 -k3,3n > $prefix.temp2.UTR.gff\n"

}
# intersectBed picks up the cufflinks models which overlaps with the genes
# subtractBed  Removes the portion(s) of an interval that is overlapped by another feature(s).
# mergeBed Merges overlapping BED/GFF/VCF entries into a single interval.

#=cut 

sleep (5);
# fix the output of mergeBed


my $infile ="$prefix.temp2.UTR.gff";

open (OUT, ">$prefix.UTR.gff.temp" || die "I can't open $prefix.UTR.gff.temp\n");

open (IN, "<$infile" || die "I can't open $infile\n");
my @list = <IN>;
my $counter = 1;

#my @lists = sort { $a <=> $b } (@list);

foreach my $line (@list) {
 	my ($scaffold, $start, $end, $strand) = split (/\s+/, $line);
	my $start2 = ($start+1);
	print OUT "$scaffold\thint\tUTR\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";
#	print "$scaffold\thint\tCDS\t$start2\t$end\t.\t$strand\t.\tID=hint$counter\n";

$counter++;
}

# system `rm -fr $prefix.temp2.cuff.gff $prefix.bed.gff $prefix.temp.aug.gff $prefix.temp.cuff.gff $outfile $prefix.temp2.UTR.gff `;

close (IN);
close (OUT);

#### fix the lengths of unreasonable UTRs  #### only tested with alternavtive 1 - nice gff

if ($cutoff == 0) {
exit;
}

system "cat $prefix.UTR.gff.temp $aug_file | grep -w -e mRNA -e transcript -e UTR | grep -v exon | sort  -k1,1  > $prefix.UTR.gff.temp2 ";


my $oldline= 0;

open (IN, "<$prefix.UTR.gff.temp2 ");
open (OUT2, ">$prefix.UTR.gff");
open (ERR, ">$prefix.UTR.gff.err");
open (ERR2, ">$prefix.UTR.gff.err.gff");

my @in = <IN>;

# make hash with genes and UTRs

my %gen=();
my %utr=();
my $lastline=0;

# $gen{geneID}{CDS} = line
#             {5UTR} = line
#             {3UTR} = line
#             {mRNA} = line
#             {gene} = line


foreach my $line (@in) {

    chomp $line;
	my @line = split (/\s+/, $line);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];

     if ($lastline=~/$name/) {

    if ($tag=~/mRNA/ or $tag=~/transcript/ ) {
#        print "mRNA:$line\n";
        $gen{$start} = $line;
        $gen{$end} = $line;
#       print "mRNA:$start\t$end\n";

    }
    elsif ($tag=~/UTR/ ) {
        my @utr;
        # split too long into two
           my $length = ($end-$start);

    		if ($length > $cutoff )	{

                # make a new for forward
    		    my $nstart = ($end - $cut);
#                my ($s, $e) = sort {$a <=> $b} ($nstart , $end);
                push (@utr, "$name\t$method\t$tag\t$nstart\t$end\t$score\t$strand\t$dot\t$key.a" );
                # make a new for reverse
    		    my $nend = ($start + $cut);
#                ($s, $e) = sort {$a <=> $b} ($start , $nend);
                push (@utr, "$name\t$method\t$tag\t$start\t$nend\t$score\t$strand\t$dot\t$key.b" );

#               print "$line\n";
#               print "$name\t$method\t$tag\t$nstart\t$end\t$score\t$dot\t$key.a\n";
#               print "$name\t$method\t$tag\t$start\t$nend\t$score\t$dot\t$key.b\n";

             }

             else {
                 push (@utr, $line);
            }

        foreach my $elem (@utr) {
#            print "Elem:$elem\n";

	my @uline = split (/\s+/, $elem);
	my $uname = $uline[0];
	my $umethod = $uline[1];
	my $utag = $uline[2];
	my $ustart = $uline[3];
	my $uend = $uline[4];
	my $uscore = $uline[5];
	my $ustrand = $uline[6];
	my $udot = $uline[7];
	my $ukey = $uline[8];

    if ($ustart == $uend) {
        next;
        print ERR "Warning 203: utr is 0 length $elem\n";
    }
        my $more = ($uend+1);
        my $less = ($uend-1);
        my $smore = ($ustart+1);
        my $sless = ($ustart-1);

        if ($more < 1) {
            $more = 1;
        }
        if ($smore < 1) {
            $smore = 1;
        }
        if ($less < 1) {
            $less = 1;
        }
        if ($sless < 1) {
            $sless = 1;
        }


        #        print "UTR:$line\n";
#        print "UTR:$more\t$less\t$smore\t$sless\t$ukey\n";

                if ( exists $utr{$more} and $utr{$more}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$more} with $elem\n";
                                print ERR2 "$utr{$more}\n";
                }
                  
                if ( exists $utr{$smore} and $utr{$smore}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$smore} with $elem\n";
                                print ERR2 "$utr{$smore}\n";
                }

                                if ( exists $utr{$less} and $utr{$less}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$less} with $elem\n";
                                print ERR2 "$utr{$less}\n";
                }

                                if ( exists $utr{$sless} and $utr{$sless}=~/\w+/ ) {
            print ERR "Warning 225: overwriting $utr{$sless} with $elem\n";
                                print ERR2 "$utr{$sless}\n";
                }


#        if ( exists $utr{$more} or exists $utr{$smore} or  exists  $utr{$less}  or exists $utr{$sless}  ) {
#            if ($utr{$more}=~/\w+/ or $utr{$smore}=~/\w+/  or $utr{$less}=~/\w+/  or $utr{$sless}=~/\w+/ ) {
#            print "Warning 225: overwriting $utr{$more} with $elem\n";
#        }
#       }
       $utr{$more}=$elem;
       $utr{$less}=$elem;
       $utr{$smore}=$elem;
       $utr{$sless}=$elem;

#        print "UTR:$more\nUTR:$less\nUTR:$smore\nUTR:$sless\n";

       }

    }
    else {
        print "Exception\n";

    }

}
    else {
        #now we are on a new scaffold
        unshift (@in, $line);
#        print "OLD:$lastline\nNEW:$line\n";
        $lastline=$line;
        &eval;
#        print OUT2 "-----NEW SCAFFOLD----\n";
          }

$lastline=$line;
}


&eval;


close (OUT2);
close (ERR);
close (ERR2);

# system `rm -fr $prefix.UTR.gff.temp $prefix.UTR.gff.temp2`;

 unless (-s "$prefix.UTR.gff.err") {
     system `rm -fr $prefix.UTR.gff.err $prefix.UTR.gff.err.gff`;
     print "Fishined with no errors\n";
 }


print "Looking for UTR introns\n";

system "perl /nfs/users/nfs_m/mz3/bin/perl/utr_splitter.pl $prefix.UTR.gff $cufflink_file $prefix";


exit 0;


#########################


sub eval {
my $contig;
foreach my $pos (sort {$a <=> $b} keys %utr) {
#            print "POS2:$pos\n";
            if (exists $gen{$pos}) {                
#                print "Match\n$utr{$pos}\n$gen{$pos}\n";
            my @line = split(/\s+/, $gen{$pos});
            my @nline = split(/\s+/, $utr{$pos});

     # get gene-details
    my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $dot = $line[7];
	my $key = $line[8];
        $contig=$name;
        my @arr= split(/[:;]/, $key);
        $arr[0]=~s/ID=//;
        $key = $arr[0];
        # get utr-details        
	    my $nname = $nline[0];
	    my $nmethod = $nline[1];
	    my $ntag = $nline[2];
	    my $nstart = $nline[3];
    	my $nend = $nline[4];
    	my $nscore = $nline[5];
    	my $ndot = $nline[7];
    	my $nkey = $nline[8];
        $nkey =~s/ID=hint/comment=hint/; 
        # plus-strand
            if ($strand=~m/^\+$/){
                if ( ($start - $nend) == 1) {
                            print OUT2 "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;colour=3;$nkey\n";
                        }
                elsif ( ($nstart - $end) == 1) {
                    	    print  OUT2 "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;colour=2;$nkey\n";
                }
                else {
                    print ERR "Warning 254: weird overlap $gen{$pos}\nWarning 254: weird overlap $utr{$pos}\n\n";
                    print ERR2 "$utr{$pos}\n";

                }
            }        
        # minus-strand
            elsif ($strand=~m/^\-$/){

                if ( ($start - $nend) == 1) {
    	    	    	print  OUT2  "$nname\t$nmethod\tthree_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:3UTR;Parent=$key;colour=2;$nkey\n";       
                        }
                elsif ( ($nstart - $end) == 1) {
                        print  OUT2  "$nname\t$nmethod\tfive_prime_UTR\t$nstart\t$nend\t$nscore\t$strand\t$ndot\tID=$key:5UTR;Parent=$key;colour=3;$nkey\n";
                }
                else {
                    print ERR "Warning 273: weird overlap $gen{$pos}\nWarning 273: weird overlap $utr{$pos}\n\n";
                    print ERR2 "$utr{$pos}\n";

                }
            }
            else {
                print "Warning: unknown strand\n";
            }
            }
            else {
#                print "NO MATCH:\n$pos\n";
            }
}        
# print "Finished contig $contig\n";
%utr=();
%gen=();
#print "dump\n";
#print Dumper(%utr);
#print "dump2\n";

}





__END__


