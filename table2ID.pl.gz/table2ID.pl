#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

if (@ARGV < 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: network2ID.pl network.pl-output 

Takes a networked result and get all the products for that domain

WARNING: relict and not functioning script


'
}




# Take the network file and get all the IDs

my %nam;
# %nam { dom-comb } { gene  } = "prod";


my $table = shift;
my $prod = shift;


        open (IN, "<$table") || die "I can't open $table\n";
    	my @table= <IN>;
    	close (IN);

        open (IN2, "<$prod") || die "I can't open $prod\n";
    	my @prods= <IN2>;
    	close (IN2);



foreach my $line ( @table ) {
    chomp $line;

    my @arr = split (/\t/,$line);
    my $dom = shift(@arr);
#    print "$dom:\t:$arr[0]\n";

    foreach my $elem (@arr) {
        $elem=~s/,/\t/g;
        $elem=~s/\t\t/\t/g;
        $elem=~s/\t\t/\t/g;
        $elem=~s/\t\t/\t/g;
        my @arr2 = split (/\s+/,$elem);
        foreach my $elem2 (@arr2) {
            if ($elem2=~/\D+/) {
                print "$dom\t$elem2\n";
            }
        }
    }
}


foreach my $pro ( @prods ) {

}




__END__    

