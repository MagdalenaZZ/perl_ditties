#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/bed2gff.pl junctions.bed




';

}


my $in = shift;
my $out = "$in.gff";

 open (IN, "<$in") or die 'Cant find infile $in ';

print "Outfile: $out\n";
 open (OUT, ">$out") or die 'Cant find outfile $out ';


 while (<IN>) {
     chomp;
     my @arr = split(/\s+/, $_);
     print OUT "$arr[0]\tFromBed\tCDS\t$arr[1]\t$arr[2]\tscore=$arr[4]\t$arr[5]\t.\tID=$arr[3]\n";



}


close (IN);
close (OUT);





