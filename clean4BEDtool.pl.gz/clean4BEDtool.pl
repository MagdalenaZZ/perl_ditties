#!/usr/bin/perl -w
# mz3 script for making output of SNAP augustus and Glim

use strict;


my %genes;
my %cds;
while (<>) {
	chomp;
	my @line = split (/\s+/, $_);
	my $name = $line[0];
	my $method = $line[1];
	my $tag = $line[2];
	my $start = $line[3];
	my $end = $line[4];
	my $score = $line[5];
	my $strand = $line[6];
	my $trans = $line[8];
	($start, $end) = sort {$a <=> $b} ($start, $end);
	if ($strand eq "-") {
		if ($tag eq "Einit") {
			push (@{$genes{"$trans $strand $name"}}, $start); 
		} 
		elsif  ($tag eq "Eterm") {
			unshift (@{$genes{"$trans $strand $name"}}, $end);
		}
	} else {
		if ($tag eq "Einit") {
			push (@{$genes{"$trans $strand $name"}}, $start); 
		} 
		elsif  ($tag eq "Eterm") {
			push (@{$genes{"$trans $strand $name"}}, $end);
		}
	}
	my $newline = "$name\t$method\tCDS\t$start\t$end\t$score\t$strand\t.";
	push (@{$cds{$trans}}, $newline);
}	

foreach my $gene (sort {(split /\./, (split /\s+/, $a)[0])[1] <=> (split /\./, (spli
t /\s+/, $b)[0])[1]} keys %genes) {
	my $name = (split /\s+/, $gene)[2];
	my $strand = (split /\s+/, $gene)[1];
	my $tag = (split /\s+/, $gene)[0];
	my $range = join("\t", @{$genes{$gene}});
	print "$name\tSNAP\tgene\t$range\t.\t$strand\t.\tID=$tag;\n"; #<STDIN>;
	print "$name\tSNAP\tmRNA\t$range\t.\t$strand\t.\tID=$tag.1;Parent=$tag;\n"; 
#<STDIN>;
	my $conta = 1;
	if ($strand eq "-") {
		$conta = scalar @{$cds{$tag}};
	}
	foreach my $cd (@{$cds{$tag}}) {
		if ($strand eq "-") {
			print "$cd\tID=$tag.1:exon:$conta;Parent=$tag.1;\n"; #<STDIN
>;	
			$conta--;
		} else {
			print "$cd\tID=$tag.1:exon:$conta;Parent=$tag.1;\n"; #<STDIN
>;
			$conta++;
		}
	}
}
