#!/usr/bin/perl
use strict;


unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die ' 

USAGE:  velvetParser.pl  trancripts.fa <cut-off>


Takes the output from velvet and calls consensus for each locus


';

}


my $fas = shift;
my $cut = shift;

my $uc = $fas;



my %fas;
my %clus;
my %single;

unless (-s "$fas.sl") {
    system "fasta2singleLine.py $fas $fas.sl";
}

###  parse fasta file  ####

open (FAS, "<$fas.sl") || die;


while ( <FAS> ) {
    chomp;
    if ($_=~/^>/) {
        my $head = $_;
        $head =~s/\>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head} = $seq;
        #print "$head\n";

        # make cluster-file
        my @arr = split (/\_Transcript/,$head);
        # is single seq
        if ($arr[1]=~/_1\/1_Confidence/) {
            #$clus{ $arr[0] } { $head } = 1;
            print "Single $arr[0]\t$head\n";
            $single{ $head } = 1 ;
        }
        else {
            $clus{ $arr[0] } { $head } = 1;
            #print "cluster $arr[0]\t$head\n";
        }
    }
    else {
        print "Warning, unparsed line $_\n";
    }
    
}


#foreach my $key (sort keys %clus) {
#    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
#    }
#}



close (FAS);



# marry up clusters and sequences, and make a separete fasta, and align it


# printing all fasta-files

mkdir "$uc\_fas";

open (OT, ">$uc\_fas.summary") || die "Cant make file $uc\_fas.summary \n";

my %files;

foreach my $key (sort keys %clus) {
    open (FH, ">$uc\_fas/$key.fas") || die "Cant open file $uc\_fas/$key.fas ";
    $files{ "$key.fas" } = 1;
    #print OT "\n$key\t";
    foreach my $key2 (sort keys %{$clus{$key}} ) {
        #print "$key\t$key2\n";
        if (exists $fas{$key2} ) {
            #print "$key\t$key2\t$fas{$key2}\n";
            print OT "$key\t$key2\n";
            print FH ">$key2\n$fas{$key2}\n";
            delete $fas{$key2};
        }
        else {
            print "Warning - no sequence for $key2 in file $fas\n";
        }
    }

    close (FH);
}

close (OT);
chdir "$uc\_fas";

# calculating consensus

foreach my $key (keys %files) {
    print "File $key\n";
    #system ("/software/pubseq/bin/mafft --quiet --anysymbol --maxiterate 1000 --genafpair --clustalout --reorder $key > $key.clu");wait;
    #system ("/software/pubseq/bin/mafft --quiet --anysymbol --maxiterate 1000 --genafpair --reorder $key > $key.mfa");wait;
    system  "muscle -clw -in $key -out $key.clu";
    system  "muscle -in $key -out $key.mfa";
    system "perl  ~/bin/perl/consensus_caller2.pl  $key.mfa $cut";wait;
}

chdir "..";



# now go back and retrieve those sequences that are not in a cluster 


open (FAS2, ">$fas.unclustered") || die;


foreach my $key (sort keys %fas) {
    print FAS2 ">$key\n$fas{$key}\n";
}


close (FAS2);

# now go and retrieve the consensi, and the rejected sequences

#sleep(10);

system "cat $uc\_fas/\*consensus.fa > $fas.consensus ";wait;
system "cat $uc\_fas/\*rejected > $fas.rejected ";wait;
system "cat $uc\_fas/\*accepted  > $fas.clustered ";wait;



# now go back and re-do all the rejected ones
#if (-s "$fas.fas.rejected.unclustered") {
print  "perl ~/bin/perl/velvetParser.pl $fas.rejected \n ";
#}


print "cat $fas.consensus $fas.unclustered $fas.rejected > $fas.merged.fas \n ";


exit;








