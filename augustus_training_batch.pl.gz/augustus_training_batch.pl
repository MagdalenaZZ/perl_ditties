#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;

unless (@ARGV > 0) {
        &USAGE;
}


sub USAGE {

die 'Usage: augustus_train_batch.pl 


'
}


unless (-d "autoAug/autoAugPred_abinitio/shells" ) {
        die 'I cant find the dir autoAug/autoAugPred_abinitio/shells/ ';
}

my $cwd = cwd();

chdir "$cwd/autoAug/autoAugPred_abinitio/shells/" ;

 $cwd = cwd();

 print "I'm in $cwd\n";

 # Get all files in folder $cwd
my @paths = read_dir( "$cwd", prefix => 1 ) ;

	foreach my $elem (@paths) {
        if ( $elem =~ m/aug\d+$/ ) {
#        	print "$elem\n";
           print "bsub.py -q basement 5 $elem sh $elem\n";
#            system "bsub.py 5 $elem sh $elem\n";
            
		}	

        }

exit;

__END__

