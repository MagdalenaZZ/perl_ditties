#!/usr/bin/perl -w

use strict;

unless (@ARGV > 1 ) {
        &USAGE;
}


sub USAGE {

    die '


Usage: 

Make a greylist for a genome 

fai file for the genome

bam - a merged BAM of all inputs data


' . "\n";

}


my $fai=shift; 
my $bam=shift;

my @fai=split(/\//,$fai);
my @bam=split(/\//,$bam);

system "cat $fai | cut -f1,2 > $fai.tmp\n";


open (R, ">$fai[-1].$bam[-1].R") || die "I can't open $fai[-1].$bam[-1].R\n";


# Import package
print R "library(GreyListChIP)\n";

# Make tiles
print R "gl <- new(\"GreyList\",karyoFile=\"$fai.tmp\")\n";
print R "gl <- countReads(gl,\"$bam\")\n";

# Calculate thresholds
print R "gl <- calcThreshold(gl,cores=1)\n";

# Make the greylist
print R "gl <- makeGreyList(gl,maxGap=16384)\n";

# Export results as a BED file
print R "export(gl,con=\"$fai[-1].$bam[-1].GreyList.bed\")\n";


# Save in approproate format for other software, such as ChIPQC
# gl@regions is a GRanges object


print "\n\nR CMD BATCH $fai[-1].$bam[-1].R > $fai[-1].$bam[-1].Rout\n\n";

exit;




