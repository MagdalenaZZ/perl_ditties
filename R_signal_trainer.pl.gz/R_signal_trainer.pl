#!/usr/bin/perl -w


if (@ARGV < 4 ) {
    print "\nUsage: R_signal_trainer.pl Eset signal model training set number-training-set\n\n\n" ;

    print "\nExample: R_signal_trainer.pl myv_COMBAT tmpsig Celltype~. 1412:1442 1:30 18\n\n\n" ;

        exit;
}




# Input
#
$eset= shift; # Expression set
$signal=shift; # List of signal genes
$model=shift;
$tt=shift;
$ts=shift; # Training set
$num= shift;

open (R, ">$eset.$signal.R") || die "I can't open $eset.$signal.R\n";

print R "ts2 <- sample($ts, $num)\n"; # Training set
print R "ts2\n";

print R "library(gplots)\n";
print R "library(Biobase)\n";
print R "library(\"MLInterfaces\")\n";



print R "attach(\"$eset.RData\")\n";
print R "try(eset <- $eset)\n";
print R "try(eset <- df)\n";


# Take only the relevant samples
print R "eset <- eset[,$tt]\n";


# Take only the signal part of the dataset
print R "ud =  read.table(\"$signal\", header=FALSE )\n";
print R "rownames(ud) <-ud\$V1\n";
print R "colnames(ud) <- \"Symbol\"\n";

print R "chosen <- rownames(exprs(eset)) %in% rownames(ud)\n";
print R "chosen2 <- rownames(ud) %in% rownames(exprs(eset))\n";
print R "ud2 <- as.data.frame(ud[chosen2,])\n";
print R "colnames(ud2) <- \"Symbol\"\n";
print R "rownames(ud2) <-ud2\$Symbol\n";

print R "esetsub <- exprs(eset)[chosen,]\n";
print R "exprs(eset) <- esetsub\n";


print R 'cols <- apply(as.data.frame(cbind(as.vector(eset@phenoData@data$Celltype),as.vector(eset@phenoData@data$Transformation))), 1, paste, collapse=".")
cols[cols=="CMP.Normal"] <- "green"
cols[cols=="CMP.ME"] <- "darkgreen"
cols[cols=="CMP.MAF6"] <- "darkgreen"
cols[cols=="HSC.Normal"] <- "pink"
cols[cols=="HSC.ME"] <- "red"
cols[cols=="HSC.MAF6"] <- "red"
cols[cols=="MPP.Normal"] <- "yellow"
cols[cols=="MPP.ME"] <- "orange"
cols[cols=="MPP.MAF6"] <- "orange"
';




print R "esetsub.o <-esetsub[rownames(ud2),]\n";
print R "fn <- paste(\"$eset.$signal\",\".heat.pdf\", sep=\"\")\n";
print R "hmcols<-colorpanel(100,\"darkred\",\"white\",\"darkgreen\")\n";
print R "pdf(file=fn, useDingbats=FALSE)\n";
print R "heatmap.2(esetsub.o, trace=\"none\", col=hmcols, Rowv=FALSE, ColSideColors=cols )\n";
print R "dev.off()\n";



# Double up the data - to check internal predition error
print R "dset <- eset\n";
print R "exprs(dset) <-cbind( esetsub, esetsub)\n";
print R "dset\@phenoData\@data <- rbind(dset\@phenoData\@data,dset\@phenoData\@data)\n";
print R "colnames(exprs(dset)) <- rownames(dset\@phenoData\@data)\n";

# This is how to sample an eset object
#print R "eset2 = myr_COMBAT[, sampleNames(myr_COMBAT) %in% subs]\n";
###################################################
### code chunk number 36: dld1
###################################################

print R "mdld1 = MLearn( $model, dset, dldaI, $ts )\n";

###################################################
### code chunk number 37: dld2
###################################################
print R "mdld1\n";
print R "confuMat(mdld1)\n";
print R 'sum(confuMat(mdld1))
sum(diag(confuMat(mdld1)))
sum(diag(confuMat(mdld1)))/sum(confuMat(mdld1))
';

###################################################
### code chunk number 38: dld3
###################################################
print R "nnALL = MLearn( $model, dset, nnetI, $ts, size=5, decay=.01, MaxNWts=5000 )\n";

###################################################
### code chunk number 39: dld4
###################################################
print R "confuMat(nnALL)\n";
print R 'sum(confuMat(nnALL))
sum(diag(confuMat(nnALL)))
sum(diag(confuMat(nnALL)))/sum(confuMat(nnALL))
';

###################################################
### code chunk number 40: dld5
###################################################
print R "rfALL = MLearn( $model, dset, randomForestI, $ts )\n";
print R 'sum(confuMat(rfALL))
sum(diag(confuMat(rfALL)))
sum(diag(confuMat(rfALL)))/sum(confuMat(rfALL))
';

###################################################
### code chunk number 41: dld6
###################################################
print R "rfALL\n";
print R "confuMat(rfALL)\n";

###################################################
### code chunk number 42: lkrda
###################################################
print R "set.seed(1234)\n";
print R "rdaALL = MLearn($model, dset, rdacvI, $ts )\n";

###################################################
### code chunk number 43: lkrda2
###################################################
print R 'rdaALL
confuMat(rdaALL)
';

print R 'sum(confuMat(rdaALL))
sum(diag(confuMat(rdaALL)))
sum(diag(confuMat(rdaALL)))/sum(confuMat(rdaALL))
';




# This is how to sample an eset object
#print R "eset2 = myr_COMBAT[, sampleNames(myr_COMBAT) %in% subs]\n";
###################################################
### code chunk number 36: dld1
###################################################

print R "mdld1 = MLearn( $model, eset, dldaI, ts2 )\n";

###################################################
### code chunk number 37: dld2
###################################################
print R "mdld1\n";
print R "confuMat(mdld1)\n";
print R 'sum(confuMat(mdld1))
sum(diag(confuMat(mdld1)))
sum(diag(confuMat(mdld1)))/sum(confuMat(mdld1))
';


###################################################
### code chunk number 38: dld3
###################################################
print R "nnALL = MLearn( $model, eset, nnetI, ts2, size=5, decay=.01, MaxNWts=5000 )\n";

###################################################
### code chunk number 39: dld4
###################################################
print R "confuMat(nnALL)\n";
print R 'sum(confuMat(nnALL))
sum(diag(confuMat(nnALL)))
sum(diag(confuMat(nnALL)))/sum(confuMat(nnALL))
';

###################################################
### code chunk number 40: dld5
###################################################
print R "rfALL = MLearn( $model, eset, randomForestI, ts2 )\n";

###################################################
### code chunk number 41: dld6
###################################################
print R "rfALL\n";
print R "confuMat(rfALL)\n";
print R 'sum(confuMat(rfALL))
sum(diag(confuMat(rfALL)))
sum(diag(confuMat(rfALL)))/sum(confuMat(rfALL))
';

###################################################
### code chunk number 42: lkrda
###################################################
print R "set.seed(1234)\n";
print R "rdaALL = MLearn($model, eset, rdacvI, ts2 )\n";

###################################################
### code chunk number 43: lkrda2
###################################################
print R 'rdaALL
confuMat(rdaALL)
';

print R 'sum(confuMat(rdaALL))
sum(diag(confuMat(rdaALL)))
sum(diag(confuMat(rdaALL)))/sum(confuMat(rdaALL))
';




close(R);


system "R CMD BATCH $eset.$signal.R > $eset.$signal.Rout ";


exit;


# Output









 
