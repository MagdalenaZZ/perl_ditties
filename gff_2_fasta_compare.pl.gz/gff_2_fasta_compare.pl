#!/usr/bin/perl
use strict;


unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/gff_2_fasta_compare.pl gff fasta

Ex:

perl ~/bin/perl/gff_2_fasta_compare.pl temp.gff temp.fasta   <optional reference sequence>

Takes a fasta and a gff after the fasta has been mapped. Counts how much of the fasta has been mapped.


';

}


my $gff = shift;
my $fasta = shift;
my $ref = "0"; 
# $ref shift;




 open (GFF, "<$gff") or die 'Cant find infile $gff ';
#  open (REF, "<$ref") or die 'Cant find infile $ref ';





 my @gff = <GFF>;

 my %gf;

 # Parse through the GFF and get the CDS coordinates
 # count their total length
 
 my $que = "0";

foreach my $line (@gff) {
   chomp $line;
   my @arr = split(/\t/, $line);
   if ($arr[2]=~/gene/) {
     my @ar2 = split(/;/, $arr[8]);

    $que = "$ar2[-1]";
    $que=~s/Query=//;
    chomp $que;
#    print "QUE:$que:\n";
   }
   elsif ($arr[2]=~/CDS/) {

       my $len = $arr[4]-$arr[3]+1;

#        print "CDS: $line\n";
        my @ar2 = split(/;/, $arr[8]);
#        print "ARR8:$arr[8]\n"; 
        foreach my $lin (@ar2) {
#            print "LIN:$lin\n"; 
               if ($lin=~/Parent/) {
                   $lin=~s/Parent=//;
#                   print "$lin\t$len\n";
                    $gf{ $que }{ "GFF" } =  ($gf{ $que }{GFF} + $len) ;
#                   print "QUE:$que: \t";
#                   print "BFR:$gf{ $que }{GFF}:\t";
#                   print "LEN:$len:\t";
#                   print ($gf{ $que }{GFF} + $len);
                    # print "\n";
                }
        }
        
   }


}

#foreach my $ele (keys %gf) {
#    print "$ele\t$gf{$ele}{"GFF"}\n";
#}

 # Parse through the fasta, and count the lengths of all seqs
 
 system "samtools faidx $fasta ";

  open (FAS, "<$fasta.fai") or die 'Cant find infile $fasta.fai ';


  while (<FAS>) {
    chomp;
#    print "$_\n";
    my @ar3 = split (/\s+/, $_);
#    print "$ar3[0]\t$ar3[1]\n"; 
    $gf { $ar3[0] }{"FAS"} = "$ar3[1]";
  
  }

      print "GENE\tMAPPED_LEN\tTOT_LEN\tDIFF\n";


foreach my $ele (sort keys %gf) {
    my $sum = $gf{$ele}{FAS} - $gf{$ele}{GFF} ;
    print "$ele\t$gf{$ele}{GFF}\t$gf{$ele}{FAS}\t$sum\n";

}




 close (GFF);
 close (REF);
 close (FAS);



