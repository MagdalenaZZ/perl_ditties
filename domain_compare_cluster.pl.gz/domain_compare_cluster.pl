#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: domain_compare_cluster.pl domain-file.1

Takes one file with domain-architectures and clusters them nicely
similar to domain_compare.pl, but with nicer cluster-output


'
}

#Each file should look like this, with all spaces tab-delimited:

#Gene-name1  domainA domainB domainC
#Gene-name2  domainA domainC
#Gene-name3  domainD ....


my $dom1 = shift;
#my $dom2 = shift;


# read all domain architectures into a hash
#
	open (IN, "<$dom1") || die "I can't open $dom1\n";
	my @doms = <IN>;
	close (IN);

    open (OUT, ">$dom1.out") || die "I can't open $dom1.out\n";

my %ddom;
my %h;

foreach my $lin (@doms) {
    chomp $lin; 
    if ($lin =~/\w+/) {
        #print "$lin\n";
        my @arr2 = split(/\s+/, $lin);

        if ($arr2[6] =~/\w+/ ) {
            $arr2[6]=~s/ //g;
            $arr2[6]=~s/\t//g;
            $h{$arr2[0]}{$arr2[6]} += 1;
#        print "$arr2[0]\t$arr2[6]\t$h{$arr2[0]}{$arr2[6]}\n";
        }
    }
}

print "Finished reading in input\n";


# compare all genes against each other

my %h2 = %h;
my %comp;

foreach my $gen (keys %h) {
    foreach my $gen2 (keys %h2) {
        foreach my $dom ( %{$h{$gen}} ) {
            # sort genes
#            print "U:$gen\t$gen2\n";
            my @array = sort {$a cmp $b} ( $gen, $gen2 ) ;
#            my  (sort { $a cmp $b } ($gen, $gen2))[-1];
#            print "S:$gen\t$gen2\n";
#            print "S:$array[0]\t$array[1]\n";
            unless (exists $comp{$array[0]}{$array[1]}  ) {
                $comp{$array[0]}{$array[1]} = 0 ;
            }
#            print "$dom\n";
                if ($dom =~/^\d+$/) {                
#                    print "DOM1: $dom\n";
                }
                else {
                    if (exists $h2{$gen2}{$dom} ) {
#                       print "SHARED:$gen\t$gen2\t$dom\t$comp{$gen}{$gen2}\n";

                    }
                    else {
#                        $comp{$gen}{$gen2} -= 1 ;
                         $comp{$array[0]}{$array[1]} -= 1 ;

#                        print "MISSING:$gen\t$gen2\t$dom\t$comp{$gen}{$gen2}\n";

                    }
                }

        }

    }
}

## merge 1-2 and 2-1
#my %comp3 

print "Finished calculating all values\n";

my $index = 0;
my %clusters;


open (OUT2, ">$dom1.clusters") || die "I can't open $dom1.clusters\n";
open (OUT3, ">$dom1.clusterkeys") || die "I can't open $dom1.clusterkeys\n";



foreach my $gens (keys %comp) {
    foreach my $gens2 (keys %{$comp{$gens}} ) {
        #print OUT "$gens\t$gens2\t$comp{$gens}{$gens2}\n";

        # if they are the same cluster
        if ( $comp{$gens}{$gens2} == 0 ) {
            # test if either already exists in cluster
            if (exists $clusters{$gens}  ) {
                $clusters{$gens2} = $clusters{$gens} ;
            }
            elsif (exists $clusters{$gens2}  ) {
                $clusters{$gens} = $clusters{$gens2} ;
            }
            else {
                $clusters{$gens} = $index;
                $clusters{$gens2} = $index;
                $index++;
            }
        }
    }
}

print "Finished printing clusters\n";

my %res;

# Invert the hash with unique values
%res = reverse %clusters;  

# invert the hash and keep values
my %inverse;
push @{ $inverse{ $clusters{$_} } }, $_ for keys %clusters;


#foreach my $line (keys %clusters) {
#    print OUT2 "$line\t$clusters{$line}\n";
#}

foreach my $line (sort keys %inverse) {
        print OUT2 "\n$line\t";
        my @sorted = sort @{$inverse{$line} };
        my @last =  split(/_/, $sorted[0] );
            foreach my $elem ( @sorted ) {

            my @prefix = split(/_/, $elem);
            if ($prefix[0] eq "$last[0]") {
                print OUT2 "$elem,";
            }
            else {
                print OUT2  "\t $elem,";
                $last[0] = $prefix[0];
            }
    }
}


foreach my $line (sort keys %res) {
    if (exists $h{ $res{$line} }) {
        print OUT3 "\n$line \t";
        foreach my $dom (sort keys %{$h{ $res{$line}  }}) {
            print OUT3 "$dom,";
        }

    }
    else {
        print "$line has no domain-structure\n";
    }
#    print "$line\t$res{$line}\n";
}

    print OUT2 "\n";
    print OUT3 "\n";

	close (OUT);
    close (OUT2);
    close (OUT3);

    print "Finished successfully\n";
    exit;
