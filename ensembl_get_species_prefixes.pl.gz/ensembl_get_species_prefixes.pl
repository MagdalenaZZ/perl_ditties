#!/usr/bin/perl
use strict;
use warnings;

use Bio::EnsEMBL::Registry;

my $registry = 'Bio::EnsEMBL::Registry';

$registry->load_registry_from_db(
    -host => 'ensembldb.ensembl.org', # alternatively 'useastdb.ensembl.org'
    -user => 'anonymous'
);

my @db_adaptors = @{ $registry->get_all_DBAdaptors() };

my @species;

foreach my $db_adaptor (@db_adaptors) {
    my $db_connection = $db_adaptor->dbc();

    printf(
#        "species/group\t%s/%s\ndatabase\t%s\nhost:port\t%s:%s\n\n",
         "species/group\t%s/%s\n",

        $db_adaptor->species(),   $db_adaptor->group(),
        $db_connection->dbname(), $db_connection->host(),
        $db_connection->port()
    );

#    my $gene = $db_adaptor->get_all

#    my $species = $db_adaptor->species() . "\n";

#    foreach my $spec (keys  %$species ) {
#        print "$spec \n";
#    }

}




__END__

#!/usr/bin/perl -w


use strict;
use warnings;

use Bio::EnsEMBL::Registry;
use Bio::EnsEMBL::DBSQL::DBConnection;
use Bio::EnsEMBL::DBSQL::DBAdaptor;


my $registry = "Bio::EnsEMBL::Registry";

$registry->load_registry_from_db(
  -host => 'ensembldb.ensembl.org',
  -user => 'anonymous',
#  -verbose => 1
);

# my $dba = new Bio::EnsEMBL::DBSQL::DBAdaptor(%{$db_args});

#my @all_species = @{$dba->all_species()};

#foreach my $species ( @all_species ) {
#    print "$species\n";
#}




sleep (2);

my $in = "file";


open (IN, "$in") or die "oops!\n" ;

my @all = <IN>;

my @spe;

foreach my $species ( @all ) {
chomp $species;

    my @arr = split(/\'/, $species);


    if ($arr[1] =~/\w+_\w+/) {
        push(@spe, $arr[1]);
            print "$arr[1]\n";
    }
}



close (IN);

foreach my $spi ( @spe) {

    my $species_adaptor = get_adaptor("$spi", "core", "Gene");


}
