#!/usr/bin/perl
use strict;

unless (@ARGV >0) {
        &USAGE;
}

sub USAGE {

die '

perl ~/bin/perl/SNP_pattern_matcher.pl pattern-file BCF-file


';

}

my $pat = shift;
my $in = shift;



open (IN, "<$in" ) || die "Error \n";

open (PAT, "<$pat" ) || die "Error \n";

open (OUT, "> $in.match") || die "\nCannot write to file $in.match\n";
open (OUT2, "> $in.no_match") || die "\nCannot write to file $in.no_match\n";


my %pats;


while (<PAT>) {
    chomp;
 
    $pats{$_}+=1;
}


while (<IN>) {
    chomp;
    my @ar= split(/\t/,$_);
    push(@ar, "END");
    my @ar2 = splice (@ar,18,-1);
    my @ar2 = splice (@ar,9,-1);    
    foreach my $elem (@ar2){
        my @a= split(/\:/, $elem);
        $elem =$a[0];
    }    

    my $patt = join("\t", @ar2);

    print "$patt\n";
	#print "@ar2" . "\n";

    if (exists $pats{$patt}) {
        print OUT "$_\n";
#        print "Match\n";
    }

    else {
        print OUT2 "$_\n";
#        print "No\n";
    }


}


