#!/usr/local/bin/perl -w

use strict;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die '


Usage: 

perl ~/bin/perl/gff_get_products.pl gff out


# make sure the fasta is single-line

'
}

	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);
	open (OUT, ">$out") || die "I can't open $out\n";

foreach my $line (@in) {
	chomp $line;
	my @arr=split(/\t/, $line);
	if ($arr[2]=~/gene/) {
		print OUT "$arr[8]\t";
	my $length =scalar(@arr);
	my $length2= $length-1;
#	print "Length:$length2:\n";
	my @small = @arr[9..$length2];
	my $length3 =scalar(@small);
#	print "Length3:$length3:\n";
#	print "Small:$small[-1]:\n";		
	foreach my $elem (@small) {
		if ($elem=~/\/product=/) {
			print OUT "$elem\t";
		}
	}
	print OUT "\n";
	}
}


