#!/usr/local/bin/perl -w

use strict;



unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_first_bases.pl <gff-file>  <INT>

Example:  gff_first_bases.pl EMU.gff 50


obs! only takes bases from CDSs


WARNING!!!!! only behaves suitable for forward strand, not reverse????




'
}

	my $in = shift;
	my $num = shift;
	my $out = $in . "\.$num" . ".gff";
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";


my $last_gene = "0";
my $last_len= 0;
my $full= 0;


foreach my $elem (@in) {
    chomp $elem;
    my @arr = split(/\t/, $elem);
    my @arr2 = split(/;/, $arr[8] );
        #print "\n";
        #print "$elem\n";

    if ($arr[2]=~/CDS/) {
        #print "$arr[3]\t$arr[4]\t$arr2[0]\n";
        # test if it is the same as previous, or new

        if ($arr2[0]=~/^$last_gene$/ and $last_gene=~/^$arr2[0]$/ and $full<0 ) {
            #print "FULL $arr2[0] $last_gene\n";
            #next;
        }
        elsif ($arr2[0]=~/^$last_gene$/ and $last_gene=~/^$arr2[0]$/  ) {
            #print "same $arr2[0] $last_gene\n";
            #$full = 0;
        }
        else {
            #print "diff $arr2[0] $last_gene\n";
            $last_len= 0;
            $full = 0;
        }

        # count up to num

        my $len = $arr[4]-$arr[3]+1;

        # if is full 
        if ($full> 0 ) {
            # do nothing
            #print "$elem\tFULL\n";
        }

        # if length is < num, add it
        elsif ( ($len + $last_len) < $num) {
            $last_len+=$len;
            #print "$arr2[0]\t$arr[4]\t$arr[3]\t$len\t$last_len\n";
            print OUT "$elem\n";
            $full = 0;
        }
        
        # else, count up and finish
        else {
            # count how much is missing
            my $miss = $num - $last_len;
            $arr[4] = ($arr[3] + $miss) -1 ;
            #print "$arr2[0]\t$arr[4]\t$arr[3]\t$len\t$last_len\n";

            my $new_elem = join("\t", @arr );
            print OUT "$new_elem\n";
            $full =1;
        }

        $last_gene = $arr2[0];

    }

}




close (OUT);

exit;




