#!/usr/bin/perl -w
use strict;


if (@ARGV < 2) {
    print "Usage fastq_add_ori.pl file.fastq.gz|fastq Orientation\n" ; 
	exit ;
}



if ( $ARGV[0] =~ /.gz/ ) {
    open (IN, "zcat $ARGV[0] | ") or die "can not open $ARGV[0]\n" ;
}
else {
    open (IN , "$ARGV[0]") or die "can not open $ARGV[0]\n" ;
}

open my $out, ">" , "$ARGV[0].ori.fastq" or die "oops\n" ;
#open my $out2, ">" , "$ARGV[0].fasta.qual" or die "oops\n" ;

my $ori = "$ARGV[1]";

while (<IN>)
{
  	if (/^@(\S+)/) {
		print $out "@"."$1/$ori\n" ;
		my $read = <IN> ;
		print $out "$read" ;
		$read = <IN> ;
		print $out "$read" ;
		$read = <IN> ;
		print $out "$read" ;
	}
}

exit;

