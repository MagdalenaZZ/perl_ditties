#!/usr/bin/perl
#use strict;

unless (@ARGV >0) {
        &USAGE;
}

sub USAGE {

die '

perl ~/bin/perl/SNP_summary.pl file.vcf.gz 


Makes two summaries of SNPs

';

}

my $in = shift;
my %call = shift;

my %syms;

#open (IN, "< bcftools view $in |") || die "Cannot find file $in \n";
#open my $ins, "<$in"  || die "Error \n";
open my $ins, "bcftools view $in |" || die "Error \n";

open (OUT, "> $in.sum") || die "\nCannot write to file $in.sum\n";
open (OUT2, "> $in.sum2") || die "\nCannot write to file $in.sum2\n";
open (OUT3, "> $in.sum3") || die "\nCannot write to file $in.sum3\n";

my $occ;
my %freq; 

#print "1\n";

while (<$ins>) {
    chomp;
    if ($_=~/#/) {
       #print "$_\n";
	 next;
    }
    my @ar=split(/\t/, $_);
    my @na = splice @ar, 9, -1;
	push (@na,@ar[-1]);

    foreach my $ele (@na) {
        my @a = split(/\:/,$ele);
        $ele = $a[0];
        $call{"$ar[0]\t$ar[1]"}{$ele}+=1;
    }
    my $na=join("\t", @na);
    $freq{$na}+=1;
    my $nl = "$ar[0]\t$ar[1]\t$na";
    print OUT "$nl\n";
}

#print "2\n";

foreach my $pat (keys %freq) {
	print OUT3 "$freq{$pat}\t$pat\n";
}

#print "3\n";

foreach my $snp (keys %call) {
    print OUT2 "$snp\t";
    foreach my $key (sort keys %{$call{$snp}}) {
        print OUT2 "$key\t$call{$snp}{$key}\t";
    }
    print OUT2 "\n";
}

#print "4\n";

close(OUT);

exit;


