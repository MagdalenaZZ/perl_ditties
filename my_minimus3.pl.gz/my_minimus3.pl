#!/usr/local/bin/perl -w

use strict;
use POSIX qw(ceil floor);

unless (@ARGV) {
	&USAGE;
}
my $binpath = "/nfs/users/nfs_m/mz3/bin/amos-3.1.0/bin";
#my $binpath = "/software/pathogen/external/applications/amos/amos/bin";
#my $minimus = "/nfs/users/nfs_a/as9/bin/minimus3";
my $minimus = "/nfs/users/nfs_m/mz3/bin/minimus3";

my $ref = $ARGV[0];
my $add = $ARGV[1];
my $r = $ARGV[2];
my $d = $ARGV[3];
my $prefix = $ARGV[4];

my $count = 0;


MINIMUS($ref, $add, $prefix);


sub MINIMUS {
	my $ref = $_[0];
	my $add = $_[1];
	my $prefix = $_[2];
	$count = `grep -c '>' $ref`;
	chomp $count;
	if (-e "./$prefix.fasta") {
		warn "$prefix.fasta exist! It will be used but not sure if is the correct one\n"; 
	} else {	
		system ("cat $ref $add > $prefix.fasta");
	}
	if (-e "./$prefix.afg") {
		warn "$prefix.afg exist! It will be used but not sure if is the correct one\n";
	} else {
		system ("$binpath/toAmos -s $prefix.fasta -o $prefix.afg");
	}
	my $nucparams = &NUCMER;
	#print "$nucparams"; <STDIN>;
	print "$minimus $prefix -D REFCOUNT=$count $nucparams"; <STDIN>;
	system ("$minimus $prefix -D REFCOUNT=$count $nucparams");
}



sub USAGE {
	die "\nUsage: my_minimus3.pl </path_to/ref_genome> </path_to/add_genome> <min_length> <max-substs> <prefix_output>\n";
}

sub NUCMER {
# Calculate nucmer parameters
	my $minmatch = ceil(($r-$d) / ($d+1));
	my $mincluster = $minmatch;
	my $maxgap = $d;
	my $breaklen = $r - $minmatch;
#	my $params = "-D BVAR=$breaklen -D CVAR=$mincluster -D GVAR=$maxgap -D LVAR=$minmatch";
	my $params = "-D BVAR=$breaklen -D CVAR=$mincluster -D GVAR=$maxgap -D LVAR=10";
	return $params;
}

exit;


