#!/usr/bin/perl -w
# mz3 script

use strict;


unless (@ARGV == 2) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl fasta_sort.pl fasta l/s 

Sorts a fasta by length so that the (l)ongest or (s)hortest contig is first 

'
}



my $in = shift;
my $ori = shift;

open (IN, "<$in") or die "Cant find infile $in\n" ;
open (OUT, ">$in.sorted.fa") or die "Cant find infile $in.sorted.fa\n" ;

my $i = 0;

$/=">";

my %fas;

while (<IN>) {
    my @arr = split("\n", $_);

    unless ( scalar(@arr) > 1) {
        print "Something is wrong with this sequence $_, perhaps 0 length? :$arr[0]:$arr[1]:\n";
        next;
    }

    my $len=length($arr[1]);
    
    if ($len > 1) {
	  $fas{$len}{$arr[0]} ="$arr[1]";
	  #print "$arr[0] $len\n";
	  $i++;
    }
    else {
        print "$arr[0] $len\n";
        }
}



$/="\n";

#print "I1 $i\n";
$i=0;

if ($ori=~/^s/) {

    foreach my $gene (sort {$a<=>$b} keys %fas) {
      foreach my $gene1 (sort keys %{$fas{$gene}}) {    
        print OUT ">$gene1\n$fas{$gene}{$gene1}\n";
        $i++;
      }
    }
}

elsif ($ori=~/^l/) {

    foreach my $gene (sort {$b<=>$a} keys %fas) {
      foreach my $gene2 (sort keys %{$fas{$gene}}) {    
        print OUT ">$gene2\n$fas{$gene}{$gene2}\n";
        $i++;
       } 
    }
}
else {
    print "Cant understand your sorting option, input s or l or something similar\n";
}

# print "I2 $i\n";

__END__



