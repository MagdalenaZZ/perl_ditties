#!/usr/local/bin/perl -w

# mz3 script for taking tophat output accepted_hits.sam and turning it into cufflinks-ready file


use strict;


sub USAGE {

die 'Usage: tophat2cufflinks.pl <reference-genome.fas> &

Put files or softlinks to all .bam files you want to include in the working directory.
Do not bsub - it bsubs itself

Warning!!! it bsubs one job for each contig


'
}

unless (@ARGV == 1) {
        &USAGE;
}



my $ref = shift;



print "Reference sequence: $ref \n";



my @infiles = < *accepted_hits.bam >;
#my @infiles = < *sorted.bam >;

my $first_file = $infiles[0];


# take each file and make a bamindex 

foreach my $file (@infiles) {
        chomp $file;

        print "Reading infile $file\n";
        unless (-e "$file.bai") {
            system "samtools index $file";
        }
    }



open ( REF , "$ref" )  || die "Cant find reference genome $ref\n";

my @scaf;
while (<REF>) {
    if ($_=~/^>\w+/) {
        #print "scaf $_\n";
        $_=~s/>//;
        chomp $_;
        push (@scaf, $_);
        unless (-d "$_") {
            system "mkdir $_";
        }
    }
}

close (REF);

my $h = $infiles[0];

# make header
system "samtools view -H $infiles[0] > header.sam";

my @outs;

# now process the scaffolds
foreach my $sca (@scaf) {

    open CMD, ">$sca.tophat2cufflinks.sh";
    push (@outs, "$sca.tophat2cufflinks.sh");

        foreach my $bam (@infiles) {
         print CMD "samtools view -h -b -o $sca/$bam $bam $sca \n ";
    }

    print CMD "cd $sca\n";
    print CMD "samtools merge -f -h ../header.sam   $sca.bam *.accepted_hits.bam \n";
    print CMD "rm -f *.accepted_hits.bam\n";
    #print "samtools reheader "@HD	VN:1.0	SO:coordinate"\n";
    print CMD "cd ..\n";

    close (CMD);
}

#__END__
foreach my $out (@outs) {
    print "bsub.py -q basement 2 $out.t2c sh $out\n";
    #system "bsub.py -q basement 2 $out.t2c sh $out";

}

__END__

