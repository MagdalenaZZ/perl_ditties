#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}



# housekeeping

my $jobid = shift;
my $mem = shift;
my $rand = substr( rand, 2, 5);
my @jobs;
open (OUT, ">>$jobid.wrapper.velvet.$rand.sh");




# read and reformat the command

# print "$com\n";


my @command = @ARGV;

my $com = join (" ",@command);

# print "\nCommand:$com\n\n";

my ($veh, $veg) = split("velvetg", $com);


# fix the velvetg command
my @vegarr = split(/ /, $veg);
shift @vegarr;
my $keep = shift @vegarr;
if ($keep=~/-\w+/) {
    unshift (@vegarr, $keep);
}
$veg = join (" ",@vegarr);
$veg =~s/ -read_trkg yes / /;

#print "VEG:$veg\n";

# fix the velveth command

$veh =~s/velveth/ /;
$veh =~s/  / /g;
$veh =~s/  / /g;

# print "\nVEH: $veh\n";

# check if there is binary data

my $bin = "0";

if ($veh=~/create_binary/) {
    $bin="1";
}

print "\nBinary prep-file $bin (0 = no, 1 = yes)\n";


# count number of kmers to be tested

my @nos;

foreach my $line (@command) {

    if ($line =~m/\,/) {
        push (@nos, $line);
    }

}

my $no = scalar(@nos);

# print "NO::$no\n";
my @kmers;
my @outs;
my $kmer;



# determine if there is one job or many to do, and prepare the shell scripts for them

# ALTERNATIVE 1 - weird command
if ( $no > 1) {
    print "Im a bit stupid and don't understand your input, try removing unessecary commas\n";
}

# ALTERNATIVE 2 - submit several jobs

elsif ( $no == 1) {
    print "submitting several jobs\n";

    my @jobs = split (/\,/ , $nos[0]);
    #print "NOS:$nos[0]\n"; 
    $kmer =  $jobs[1];

        if ( -e "$jobid.$kmer.velvet.$rand.sh" ) {
            print "Warning: file $jobid.$kmer.velvet.$rand.sh already exists, I wont over-write it. TERMINATING.\nStart again\n";
            exit;
        }

        # now do velveth hashes

    open (FH1, ">>$jobid.prep.velvet.$rand.sh");
    my @ar1 = split ( / /, $veh);
    my $lost1 = shift(@ar1);
    my $lost2 = shift(@ar1);
    my $lost3 = shift(@ar1);

    #print "\nCutting out commands $lost1 $lost2 $lost3\n\n"; 
    my $vep = join( " ", @ar1);

    # check if you have the binary option

    if ($bin=~/0/) {
        print FH1 " velveth $jobid.$rand.prep 31 -noHash $vep;\n ln -s $jobid.$rand.prep/Sequences Sequences.$rand;\n"; 
    }
    elsif ($bin=~/1/) {
        print FH1 " velveth $jobid.$rand.prep 31 -noHash $vep;\n ln -s $jobid.$rand.prep/CnyUnifiedSeq CnyUnifiedSeq.$rand ;\nln -s $jobid.$rand.prep/CnyUnifiedSeq.names CnyUnifiedSeq.names.$rand ;\n"; 
    }
    else {
        print "Error with the binary option\n";
        die;
    }

# MAKE the precomputing file

    print "bsub.py -q yesterday 10 $jobid.prep.vel_$rand sh $jobid.prep.velvet.$rand.sh\n"; 
    print OUT "bsub.py -q yesterday 10 $jobid.prep.vel_$rand sh $jobid.prep.velvet.$rand.sh\n";
    # system "bsub.py 10 prep.vel sh prep.velvet.sh\n"; 

    close (FH1);

    # Now make sh-files for each of the kmers
    my $first = 0;


    while (  $kmer >= ($jobs[0] )  ) {

        open (FH, ">>$jobid.$kmer.velvet.$rand.sh");

#  WRITE EACH JOB-FILE
                push (@kmers, $kmer);
                my @velopt = split (/$nos[0]/, $veh );
                print FH "mkdir $jobid.$rand.vel_$kmer;wait;\n";
                print FH "cd $jobid.$rand.vel_$kmer;wait;\n";
                
                if ($bin=~/0/) {
                   print FH "ln -s ../Sequences.$rand Sequences;wait;\n";
                }
                else {
                   print FH "ln -s ../CnyUnifiedSeq.$rand CnyUnifiedSeq ;wait;\n";
                   print FH "ln -s ../CnyUnifiedSeq.names.$rand CnyUnifiedSeq.names ;wait;\n";
                }

                print FH "cd ..;wait;\n";

                if ($first == "0") {

                    # print "\nvelveth $jobid.vel_$kmer $kmer -reuse_Sequences $velopt[1]\n";
                    print FH "velveth $jobid.$rand.vel_$kmer $kmer -reuse_Sequences $velopt[1];wait;\n";
                    print FH "velvetg  $jobid.$rand.vel_$kmer -read_trkg yes $veg;\n\n";
                }
                else {
                    # Make a link to last output
                    my $last_kmer = ($kmer + $jobs[2]) ;
                    $velopt[1]=~s/separate/interleaved/;
                    #print FH "ln -s ../$jobid.$rand.vel_$last_kmer/UnusedReads.fa\n";
                    print FH "ln -s $jobid.$rand.vel_$last_kmer/UnusedReads.fa $jobid.$rand.vel_$last_kmer.UnusedReads.fa \n";
                    print FH "velveth $jobid.$rand.vel_$kmer $kmer $jobid.$rand.vel_$last_kmer.UnusedReads.fa\n";

                    #print FH "velveth $jobid.vel_$kmer $kmer $velopt[1];wait;\n";
                    print FH "velvetg $jobid.$rand.vel_$kmer -read_trkg yes $veg;\n\n";


                }
                close (FH);

# WRITE WRAPPER                
                if ($first == "0") {
                    print "bsub.py --dep=$jobid.prep.vel_$rand -q hugemem $mem $jobid.vel_$kmer.$rand sh $jobid.$kmer.velvet.$rand.sh\n"; 
                    print OUT "bsub.py --dep=$jobid.prep.vel_$rand -q hugemem $mem $jobid.vel_$kmer.$rand sh $jobid.$kmer.velvet.$rand.sh\n";
                }
                else {
                    #print "not first\n";
                    my $last_kmer = ($kmer + $jobs[2]) ;

                    #velveth.vel_75.59436
                    print "bsub.py --dep=$jobid.vel_$last_kmer.$rand -q hugemem $mem $jobid.vel_$kmer.$rand sh $jobid.$kmer.velvet.$rand.sh\n"; 
                    print OUT "bsub.py --dep=$jobid.vel_$last_kmer.$rand -q hugemem $mem $jobid.vel_$kmer.$rand sh $jobid.$kmer.velvet.$rand.sh\n";
                }
                push (@outs, "$jobid.vel_$kmer.$rand" );
                push (@jobs, "$jobid.vel_$kmer.$rand" );
#               print "JOB: vel$kmer\n";
                $kmer = ($kmer - $jobs[2]) ;
                $first = 1; 
    }
 
}

# ALTERNATIVE 3 - submit one job - Untested!
elsif ( $no == 0) {
    print "submitting only one job\n";
    print "$veh\n";
    print "velvetg $veg\n\n";
}

# ALTERNATIVE 4 - major meltdown
else {
    print "Im really stupid and don't understand your input, try removing unessecary commas\n";

}


# WRITE A MERGING-FILE
# write a shell-script file
# bsub that shellscript
# Assume we want to create a merged assembly in a folder called MergedAssembly.


open (FH2, ">>$jobid.merge.velvet.$rand.sh");

#print "\nWhen all merged jobs have finished - do merging\n";
#print FH2 "velveth $jobid.MergedAssembly53 53 -long $jobid.vel_*/contigs.fa\n";
#print FH2  "velvetg $jobid.MergedAssembly53 -read_trkg yes -conserveLong yes \n";

#print FH2 "velveth MergedAssembly55 55 -long vel_*/contigs.fa\n";
#print FH2  "velvetg MergedAssembly55 -read_trkg yes -conserveLong yes \n";

print FH2 "velveth $jobid.$rand.MergedAssembly57 57 -long $jobid.$rand*vel_*/contigs.fa\n";
print FH2  "velvetg $jobid.$rand.MergedAssembly57 -read_trkg yes -conserveLong yes \n";

#print FH2 "velveth MergedAssembly59 59 -long vel_*/contigs.fa\n";
#print FH2  "velvetg MergedAssembly59 -read_trkg yes -conserveLong yes \n";


# print "oases MergedAssembly/ -merge \n";

my $jobx = join(" ", @outs);
my $jobx = @outs[-1];

#print "NNN:$jobx\n";
#
print "bsub.py --dep=\"$jobx\" -q normal 1 $jobid.merge.vel_$rand sh $jobid.merge.velvet.$rand.sh \n";
#
print OUT "bsub.py --dep=\"$jobx\" -q normal 1 $jobid.merge.vel_$rand sh $jobid.merge.velvet.$rand.sh; \n";



# do oases

 print "bsub.py --dep=\"$jobid.merge.vel_$rand\" -q normal 1 $jobid.oases.vel_$rand  oases $jobid.$rand.MergedAssembly57 -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes \n";
 print OUT "bsub.py --dep=\"$jobid.merge.vel_$rand\" -q normal 1 $jobid.oases.vel_$rand oases $jobid.$rand.MergedAssembly57 -min_trans_lgth 100 -scaffolding yes -merge yes -unused_reads yes -cov_cutoff 1 -scaffolding yes\n";


close (FH2);
close (OUT);

print "\nHave printed a file $jobid.wrapper.velvet.$rand.sh which contains all the jobs you need to sumit. Edit as you want, and then submit by:\n\nsh $jobid.wrapper.velvet.$rand.sh\n\n";


sub USAGE {

die ' 

Write your job as "jobID velvethmem velveth options velvetg options", and this script will read it all in and rationalise it a bit
For example write: velveth out 25,57,2 -fastq -shortPaired -separate 3967_1_1.fastq 3967_1_2.fastq velvetg read_trkg yes -ins_length 383 -unused_reads yes -min_contig_lgth 200 -clean yes

The script will then make a unified Sequence file, and then give you shell-script files to submit.
';

}


# bsub.py -q hugemem 60 3224 python ~/bin/oases_0.2.08/scripts/oases_pipeline.py --data="-fastq -shortPaired -separate 3224_1.CORR31_3_1.fastq 3224_1.CORR31_3_2.fastq -short 3224_1.CORR31_3SE.fastq" --options="-ins_length 205 -unused_reads yes " --clean --kmin=19 --kmax=31 --kstep=2 --merge=27 --output=3224_merge27

# bsub.py -q hugemem 100 veltestg23_100 velvetg out19-37_23 -cov_cutoff auto -long_cov_cutoff auto -exp_cov auto -ins_length 3026 -ins_length2 4050 -ins_length_long 8850  -min_contig_lgth 300 -read_trkg yes -unused_reads yes 
#7305345

# bsub.py -q basement 30 veltesth4 velveth out19-37 19,37,2 -create_binary -fastq  -separate -shortPaired F6Q05Q20_1.shortP.fq F6Q05Q20_2.shortP.fq  -separate -shortPaired2 GDGEG_1.shortP2.fq GDGEG_2.shortP2.fq  -separate -longPaired GLA9HR30_1.longP.fq GLA9HR30_2.longP.fq  -separate -shortPaired3 4189_4637_7330_1.shortP3.fq 4189_4637_7330_2.shortP3.fq -short 4962.SE.fq

__END__

