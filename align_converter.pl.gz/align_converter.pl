#!/usr/local/bin/perl -w

use strict;
#use Text::ParseWords;

unless (@ARGV==3) {
        &USAGE;
}

sub USAGE {

die 'Usage: align_converter.pl in format out format

Give a hmmer-searh output-file 
The program will merge all hits, and then report the best hit from several different models, if their evalue is less than eval


'
}

	my $in = shift;
	my $inf = shift;
#    my $maxlen = shift;
	my $out = shift;
	my $outf = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @input = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";


