#!/usr/bin/perl
use strict;


unless (@ARGV > 1) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/sim4_wrapper.pl query.fas db.fas [OPTIONS]

Example: perl ~/bin/perl/sim4_wrapper.pl  test3.fas ../pathogen_HYM_scaffold_70.sl.fas R=2 A=4 P=1


     W  -  word size. (W=12)
       X  -  value for terminating word extensions. (X=12)
       K  -  MSP score threshold for the first pass. (e.g., K=16)
       C  -  MSP score threshold for the second pass. (e.g., C=12)
       R  -  direction of search; 0 - search the + (direct) strand only; 
             1 - search the - strand only; 2 - search both strands and 
             report the best match. (R=2)
       D  -  bound for the range of diagonals within consecutive msps in an
             exon. (D=10)
       H  -  weight factor for MSP scores in relinking. (H=500)
       A  -  output format: exon endpoints only (A=0), alignment text (A=1),
             alignment in lav (block) format (A=2), or both exon endpoints
             and alignment text (A=3, A=4). If complement match, A=0,1,2,3
             give direct positions in the long sequence and complement 
             positions in the short sequence. A=4 gives direct positions in 
             the first sequence, regardless of the relative lengths.
             A=5 prints the exon and CDS coordinates (the latter, if known)
             in the -exon file- format required by PipMaker. To be used
             with full-length mRNA sequences.
       P  -  if not 0, remove poly-A tails; report coordinates in the 
             + (direct) strand for complement matches; use lav alignment 
             headers in all display options. (P=0) 
       N  -  accuracy of sequences (non-zero for highly accurate). (N=0)
       B  -  if 0, dis-allow ambiguity codes (other than N and X) in the
             sequence data. (B=1)
       S  -  coding region specification (available only with A=5);
             format: S=n1..n2


';

}



my $in = shift;
my $in2 = shift;

my $com = join(" ", @ARGV);

my $out = "$in.out";


 open (IN2, "<$in2") or die 'Cant find infile  $in2  ';

 # open (TEMP, ">temp.fas") or die 'Cant find temp.fas ';

 open (OUT, ">$out") or die 'Cant find outfile $out ';


# Read in database in hash

 my %db ;

while (<IN2>) {
    if ($_=~/^>/) {
        my $head = $_;
        my $seq = <IN2>;
#        print "$head$seq";
        chomp $head;
        chomp $seq;
        $seq= uc($seq);
        $db{$head}="$seq";


    }
    else {
    }

}


 close (IN2);



# Read in query and do calculations 

foreach my $key (sort keys %db) {

             open (TDB, ">temp.db.fas") or die 'Cant find temp.db.fas ';
             print TDB "$key\n$db{$key}\n";
             open (IN, "<$in") or die 'Cant find infile $in  ';

    while (<IN>) {
        if ($_=~/^>/) {
            my $head = $_;
            my $seq = <IN>;
    #        print "$head$seq";
             open (TEMP, ">temp.fas") or die 'Cant find temp.fas ';

            print TEMP "$head$seq";
#           print "/nfs/users/nfs_m/mz3/bin/sim4.2002-03-03/sim4 temp.fas temp.db.fas $com \n";
         my @res = qx "/nfs/users/nfs_m/mz3/bin/sim4.2002-03-03/sim4 temp.fas temp.db.fas $com";
#            print "::::: $res[1] ::::\n";

#             print "KEY: $key\n";
             print OUT "$key # $head";
            print OUT "@res";
#            system "rm -f temp.fas"; 
#            system "touch temp.fas";
            close (TEMP);
        
         }
         else {
         }

    }

    close (IN);
    close (TDB);

}

print "Done!!!!\n";

 close (OUT);

# parse output and make gff

my %res;
my %ord;

if ($com=~/A=5/) {
    open  (IN2, "<$out") or die 'Cant find $out ';

    my $hit;

    while (<IN2>) {
        chomp;
        if ( $_=~/^>/) {


            my $file1 = $_;
=pod
            print "$file1\n";
            my $file2 = <IN2>;
            my $no1 = <IN2>;
            my $seq1 = <IN2>;
            my $seq2 = <IN2>;
            my $no2 = <IN2>;
            my $coord = <IN2>;
            my $coord2 = <IN2>;
            my $coord3 = <IN2>;
            my $coord4 = <IN2>;

            chomp $seq1;
            chomp $seq2;
            chomp $coord;
            chomp $coord2;
            chomp $coord3;
            chomp $coord4;

#            print "$seq1\t$seq2\t$coord\t$coord2\t$coord3\t$coord4\n";
=cut
            #$res{$_}
            $hit = $_;

        }
        else {
            chomp $_;
            push ( @{ $res {$hit}} , $_ );
        }

    }


# Empty out values

    foreach my $aln ( sort keys %res ) {
        my $ori = '+';
#        print "$aln\n";
        my @arr = @{ $res {$aln}} ;
        my $re = join(" ", @arr);
#        print "$re\n";

        $aln=~s/\<//g;
        $aln=~s/\>//g;

        my @header = split(/#/, $aln);
        $header[0]=~s/\s+//g;
        $header[1]=~s/\s+//g;

        if ($re=~/complement/) { $ori='-';
            $re=~s/ \(complement\) //;
            $re=~s/  / /g;
        }

        my @coords = split(/\s+/, $re);

        

        if ($coords[3]=~/\w+/) {
            my $gff = "$header[0]\tsim4\tgene\t$coords[2]\t$coords[3]\t.\t$ori\t.\tID=$header[1]";
            my $mrna = "$header[0]\tsim4\tmRNA\t$coords[2]\t$coords[3]\t.\t$ori\t.\tID=$header[1].1;Parent=$header[1]";
            my $inx = "$coords[2]";
#            print "$gff\n$mrna\n";
            shift @coords;
            shift @coords;
            shift @coords;
            shift @coords;
#            shift @coords;
#            shift @coords;
            shift @coords;
            my $i="1";

            while(@coords) {
                my $start =shift @coords;
                my $end = shift @coords;
                my $cds = "$header[0]\tsim4\tCDS\t$start\t$end\t.\t$ori\t.\tID=$header[1].1:exon:$i;Parent=$header[1].1";
#                print "$cds\n";
                $i++;
                $ord{ $header[0] }{ $inx }{ "$gff\n$mrna\n" }{ $cds } = "1" ;

            }
            
         }

    }


}
else {
    print "Your output is $out, I can only parse output-file format A=5, so the rest is up to you\n";
}
 





if ($com=~/A=5/) {

    foreach my $key1 (sort keys %ord) {
        foreach my $key2 ( sort { $a <=> $b } keys %{$ord{$key1}} ) {
#                        print "$key2\n";

            foreach my $key3 (sort keys %{$ord{$key1}{$key2}} ) {
                        print "$key3";
                foreach my $key4 (sort keys %{$ord{$key1}{$key2}{$key3}} ) {
                        print "$key4\n";
                  
                } 
            }

        }
    }

        


}


