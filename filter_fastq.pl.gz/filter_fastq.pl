#!/usr/local/bin/perl -w
#mz3 script for submitting job to Jasons script

use strict;


unless (@ARGV == 2) {
        &USAGE;
}

unless (-e "adaptor.fa" and -e  "PCRadaptor.fa") {
system "cp /lustre/scratch103/sanger/jit/E.granulosus/adaptor.fa . ; cp/lustre/scratch103/sanger/jit/E.granulosus/PCRadaptor.fa .";
}

my $file1 = shift;
my $file2 = shift;

my $call1 = "/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa PCRadaptor.fa $file1 > $file1.o1";

my $call2 = "/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa adaptor.fa $file1 > $file1.o2";

my $call3 = "/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa PCRadaptor.fa $file2 > $file2.o3";

my $call4 =  "/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa adaptor.fa $file2 > $file2.o4";


if (-e "bsub.file") {
system `rm -fr bsub.file`;
}

if (-e "bsub.file2") {
system `rm -fr bsub.file2`;
}

my $bsubfile = "$file1.bsub.file";
my $bsubfile2 = "$file1.bsub.file2";

open (OUT, ">>$bsubfile") || die "I can't open $bsubfile\n";

print OUT "bsub -o $file1.1.o -e $file1.1.e -JC1 -M20000000 -R'select[mem>20000] rusage[mem=20000]'  $call1 ; bsub -o $file2.2.o -e $file2.2.e -JC2 -M20000000 -R'select[mem>20000] rusage[mem=20000]' $call2 ; bsub -o $file1.3.o -e $file1.3.e -JC3 -M20000000 -R'select[mem>20000] rusage[mem=20000]' $call3; bsub -o $file2.4.o -e $file2.4.e -JC4 -M20000000 -R'select[mem>20000] rusage[mem=20000]' $call4 ";

open (OUT2, ">>$bsubfile2") || die "I can't open $bsubfile2\n";

print OUT2 "perl /nfs/users/nfs_j/jit/repository/pathogen/user/jit/converter//fastq_3kb_clip.pl $file2.2.o $file2.4.o $file1.1.o $file1.3.o $file1 $file2 60 && rm -fr $file1.o* $file1*.e  $file2.o* $file2*.e $file1.*.o  $file2.*.o";




close (OUT);
close (OUT2);

sub USAGE {

die 'Usage: sort_length.pl infile.fas

Your result will come as outfile.txt


'
}


__END__

5777_8_1.fastq.cigar 5777_8_2.fastq.cigar 
5777_8_1.fastq.PCRadaptor.cigar 5777_8_2.fastq.PCRadaptor.cigar 
5777_8_1.fastq  5777_8_2.fastq 60

bsub -o sha.o -e sha.e /software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa PCRadaptor.fa 4189_1_1.fastq > 4189_1_1.fastq.cigar ;/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa adaptor.fa 4189_1_1.fastq > 4189_1_1.fastq.cigar ;/software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa PCRadaptor.fa 4189_1_2.fastq > 4189_1_2.fastq.cigar; /software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa adaptor.fa 4189_1_2.fastq > 4189_1_2.fastq.cigar


-R "select[type==X86_64 && mem > 60000]"

bsub -o c1x.o -e c1x.e -JC1 -M5000000 -R'select[mem>5000] rusage[mem=5000]' /software/pathogen/external/applications/ssaha_pileup/ssaha2 -output cigar -solexa PCRadaptor.fa 4189_1_1.fastq > 4189_1_1.fastq.cigarx


-M2000000 -R'select[mem>2000] rusage[mem=2000]'



perl /nfs/users/nfs_j/jit/repository/pathogen/user/jit/converter//fastq_3kb_clip.pl c2.o c4.o c1.o c3.o 4637_8_1_nonhuman.fastq 4637_8_2_nonhuman.fastq 60



-r--r--r-- 1 mz3 team133  2039405267 2011-06-24 12:09 4637_8_1_nonhuman.fastq
-r--r--r-- 1 mz3 team133  2039405267 2011-06-24 12:09 4637_8_2_nonhuman.fastq
-r--r--r-- 1 mz3 team133  2450663589 2011-06-24 11:59 4189_1_2.fastq
-r--r--r-- 1 mz3 team133  2450663589 2011-06-24 11:58 4189_1_1.fastq
-r--r--r-- 1 mz3 team133  7794331814 2011-07-11 09:45 4962_3_1_nonhuman.fastq
-r--r--r-- 1 mz3 team133  7794331814 2011-07-11 09:45 4962_3_2_nonhuman.fastq

-rw-r--r-- 1 mz3 team133 2450651174 2011-07-11 11:15 4189_1_1.fastq.filtered.60._1.fastq
-rw-r--r-- 1 mz3 team133 2450649202 2011-07-11 11:15 4189_1_1.fastq.filtered.60._2.fastq
-rw-r--r-- 1 mz3 team133 2039390171 2011-07-11 10:44 4637_8_1_nonhuman.fastq.filtered.60._1.fastq
-rw-r--r-- 1 mz3 team133 2039391571 2011-07-11 10:44 4637_8_1_nonhuman.fastq.filtered.60._2.fastq
-rw-r--r-- 1 mz3 team133  7794317312 2011-07-11 11:41 4962_3_1_nonhuman.fastq.filtered.60._1.fastq
-rw-r--r-- 1 mz3 team133  7794320080 2011-07-11 11:41 4962_3_1_nonhuman.fastq.filtered.60._2.fastq