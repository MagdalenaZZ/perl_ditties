#!/usr/bin/perl -w


use strict;


unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: in out

Give a list of gene-names and product description
This program filters the list


'
}


	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	open (OUT2, ">filtered.out2") || die "I can't open filtered.out2\n";

foreach my $line (@in) {
chomp $line;
my @line = split (/\t/, $line);
	$line[1] =~ s/ \-/\-/;
	$line[1] =~ s/\- /\-/;
	$line[1] =~ s/\-\-/\-/;
	$line[1] =~ s/HSP/heat_shock_protein/ ; 
	$line[1] =~ s/ homolog//;
	$line[1] =~ s/-like//;
	$line[1] =~ s/probable //;
	$line[1] =~ s/possible //;
	$line[1] =~ s/ putative//;
	$line[1] =~ s/\(i a\)//;
	$line[1] =~ s/\( coli\)//;	
	$line[1] =~ s/\( elegans\)//;
	$line[1] =~ s/\( cerevisiae\)//;
	$line[1] =~ s/\(autosomal mild\)//;
	$line[1] =~ s/\( \)//;
	$line[1] =~ s/\( function\)//;
	$line[1] =~ s/\( pombe\)//;
	$line[1] =~ s/\(rad54 cerevisiae\)//;
	$line[1] =~ s/universalstress/universal stress/;
	$line[1] =~ s/\(a disintegrin and metalloprotease//;
	$line[1] =~ s/ADAM/adam/ ; 
	$line[1] =~ s/HSP/heat_shock_protein/ ; 
	$line[1] =~ s/TSES/Taenia_soluim_Excretory_and_Secretory_Product(TSES)/ ; 
	$line[1] =~ s/TSP/thrombospondin/ ; 
	$line[1] =~ s/TGTP/Glucose_Transport_Protein_TGTP/ ;

#	$line[1] =~ s/\[*\]//;
	if ($line[1] =~/^EG95$/) {
		print OUT "$line[0]\t$line[1]\t$line[2]\t$line[3]\t$line[4]\n";
	}
	if ($line[1] =~/af172721_134kda cortical vesicle protein/) {
#		$line[1] =~ tr/A-Z/a-z/;
#		$line[1] =~ s/low_quality_protein:_//;
#		print OUT "$line[0]\t$line[1]\n";
		print OUT2 "mz3:af1:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^family protein$/) {
		print OUT2 "mz3:fp:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^cre-* protein$/) {
		print OUT2 "mz3:cre:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/partially confirmed by transcript evidence/) {
		print OUT2 "mz3:pcte:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/low quality protein/) {
		print OUT2 "mz3:lqp:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^im:\d+ protein$/) {
		print OUT2 "mz3:im:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/full=/) {
		print OUT2 "mz3:full:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/( function)/) {
		print OUT2 "mz3:():\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/\(\w\d+ family\)/) {
		print OUT2 "mz3:pfam:\t\t\t$line[1]\n";
		my @arr =split(/\(/, $line[1]);
		print OUT "$line[0]\t$arr[0]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^protein$/) {
		print OUT2 "mz3:prot:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^hypothetical protein$/) {
		print OUT2 "mz3:hyp:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^isoform/) {
		print OUT2 "mz3:iso:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/novel/) {
		print OUT2 "mz3:novel:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^leucine rich repeat/) {
		print OUT2 "mz3:lrp:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/Anopheles gambiae str\. PEST/) {
		print OUT2 "mz3:gam:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/Echinococcus granulosus/) {
		print OUT2 "mz3:eg:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/cg31613/) {
		print OUT2 "mz3:cg31613:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/tpa_inf/) {
		print OUT2 "mz3::\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^\w*\]$/) {
		print OUT2 "mz3:[]:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/unnamed/) {
		print OUT2 "mz3:unn:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^hypothetical protein/) {
		print OUT2 "mz3:hyp:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	elsif ($line[1] =~/^hypothetical conserved/) {
		print OUT2 "mz3:hc:\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}
	else {
		print OUT "$line[0]\t$line[1]\n";
	}
}
	close (OUT);
	close (OUT2);


__END__

	elsif ($line[1] =~/^$/) {
		print OUT2 "mz3::\t\t\t$line[1]\n";
#		print OUT "$line[0]\tmz3\n";
	}


predicted protein
unknown 
unnamed protein product 