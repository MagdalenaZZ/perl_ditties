#!/usr/bin/perl -w


use strict;

my @team133;
push (@team133, "Alejandro");

my $iamin;
foreach my $member (@team133) {
    if ($member =~ /Alejandro/) {
        my $s = "tgxzgtfrgqd";
       $s =~ tr/xfgdqtrz/9lsreaoi/;
       print "$s\n";
       $iamin++;
    }
} 