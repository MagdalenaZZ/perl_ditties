#!/usr/local/bin/perl -w
# mz3 script for understanding Chado_loader

use strict;

my $in = shift;
open (IN, "<$in");
my @in = <IN>;

foreach my $line (@in) {

if ($line=~/similarity=/) {
	my @new=split(/                   /, $line);

	print " $new[1]\n";

	my @sim= split (/;/,$new[1]);

 #           "(\\w+|\\w+ +\\w+ +v[\\d.]+);" +                                # 1.     Algorithm, e.g. fasta, blastp
	print "Algorithm: $sim[0]\n";
	if ($sim[0] =~/\w+/ or $sim[0] =~/\w+ +\w+ +v[\d.]+/) {
		print "0 OK\n";
	}
 #           "\\s*(\\w+):([\\w.]+)" +                                            # 2,3.   Primary dbxref, e.g. SWALL:Q26723
 #           "(?:\\s+\\((\\w+):([\\w.]+(?:,\\s*(?:\\w+:)?[\\w.]+)*)\\))?;" +     # 4,5.   Optional secondary dbxrefs, e.g. "EMBL:M20871", "EMBL:BC002634, AAH02634"
	print "dbxref: $sim[1]\n";
	if ($sim[1] =~/\s*(\w+):([\w.]+)(?:\s+\((\w+):([\w.]+(?:,\s*(?:\w+:)?[\w.]+)*)\))?/) {
		print "1 OK\n";
	}


 #           "\\s*([^;]+)?;" +                                                   # 6.     Organism name
	print "Organism: $sim[2]\n";
	if ($sim[2] =~/\s*([^;]+)?/) {
		print "2 OK\n";
	}

 #           "\\s*([^;]+)?;" +                                                   # 7.     Product name
	print "Product: $sim[3]\n";
	if ($sim[3] =~/\s*([^;]+)?/) {
		print "3 OK\n";
	}

#            "\\s*([^;]+)?;" +                                                   # 8.     Gene name
	print "Gene: $sim[4]:\n";
	if ($sim[4] =~/\s*([^;]+)?/) {
		print "4 OK\n";
	}

 #           "\\s*(?:length\\s+(\\d+)\\s+aa)?;" +                                # 9.     Optional match length
	print "Match: $sim[5]:\n";
#	if ($sim[6] =~/\s+E\(\)\=\d+e[+-]\d+/) {
	if ($sim[5] =~/\s*(?:length\s+(\d+)\s+aa)?/) {
		print "5 OK\n";
	}

#            "\\s*(?:id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +                        # 10.    Optional degree of identity (percentage)
	print "ID: $sim[6]:\n";
#	if ($sim[6] =~/\s*(?:score=(\\d+))?/) {
	if ($sim[6] =~/\s*(?:id=(\d{1,3}(?:\.\d{1,3})?)%)?/) {
		print "6 OK\n";
	}

 #           "\\s*(?:ungapped\\s+id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +            # 11.    Optional ungapped identity (percentage)
	print "IDungap: $sim[7]:\n";
	if ($sim[7] =~/\s*(?:ungapped\s+id=(\d{1,3}(?:\.\d{1,3})?)%)?/) {
#	if ($sim[6] =~/\s+E\(\)\=\d+e[+-]\d+/) {
		print "7 OK\n";
	}

 #           "\\s*E\\(\\)=(\\d*(?:\\.\\d+)?(?:e[+-]? ?\\d+)?);" +                # 12.    E-value
	print "eval: $sim[8]:\n";
	if ($sim[8] =~/\s*E\(\)=(\d*(?:\.\d+)?(?:e[+-]? ?\d+)?)/) {
		print "8 OK\n";
	}


 #           "\\s*(?:score=(\\d+))?;" +                                          # 13.    Optional score
	print "score: $sim[9]:\n";
	if ($sim[9] =~/\s*(?:score=(\\d+))?/) {
		print "9 OK\n";
	}


 #           "\\s*(?:(\\d+)\\s+aa\\s+overlap)?;" +                               # 14.    Optional overlap length (integer)
	print "ovl: $sim[10]:\n";
	if ($sim[10] =~/\s*(?:(\\d+)\\s+aa\\s+overlap)?/) {
		print "10 OK\n";
	}


#            "\\s*(?:query\\s+(\\d+)-\\s*(\\d+) aa)?;" +                         # 15,16. Optional query location
	print "query: $sim[11]:\n";
	if ($sim[11] =~/\s*(?:query\\s+(\\d+)-\\s*(\\d+) aa)?/) {
		print "11 OK\n";
	}


#            "\\s*(?:subject\\s+(\\d+)-\\s*?(\\d+) aa)?");                       # 17,18. Optional subject location
	print "subj: $sim[12]:\n";
	if ($sim[12] =~/\s*(?:subject\\s+(\\d+)-\\s*?(\\d+) aa)?/) {
		print "12 OK\n";
	}


 #           "(\\w+|\\w+ +\\w+ +v[\\d.]+);" +                                # 1.     Algorithm, e.g. fasta, blastp
 #           "\\s*(\\w+):([\\w.]+)" +                                            # 2,3.   Primary dbxref, e.g. SWALL:Q26723
 #           "(?:\\s+\\((\\w+):([\\w.]+(?:,\\s*(?:\\w+:)?[\\w.]+)*)\\))?;" +     # 4,5.   Optional secondary dbxrefs, e.g. "EMBL:M20871", "EMBL:BC002634, AAH02634"
 #           "\\s*([^;]+)?;" +                                                   # 6.     Organism name
 #           "\\s*([^;]+)?;" +                                                   # 7.     Product name
#            "\\s*([^;]+)?;" +                                                   # 8.     Gene name
 #           "\\s*(?:length\\s+(\\d+)\\s+aa)?;" +                                # 9.     Optional match length
#            "\\s*(?:id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +                        # 10.    Optional degree of identity (percentage)
 #           "\\s*(?:ungapped\\s+id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +            # 11.    Optional ungapped identity (percentage)
 #           "\\s*E\\(\\)=(\\d*(?:\\.\\d+)?(?:e[+-]? ?\\d+)?);" +                # 12.    E-value
 #           "\\s*(?:score=(\\d+))?;" +                                          # 13.    Optional score
 #           "\\s*(?:(\\d+)\\s+aa\\s+overlap)?;" +                               # 14.    Optional overlap length (integer)
#            "\\s*(?:query\\s+(\\d+)-\\s*(\\d+) aa)?;" +                         # 15,16. Optional query location
#            "\\s*(?:subject\\s+(\\d+)-\\s*?(\\d+) aa)?");                       # 17,18. Optional subject location

}
}

close (IN);


__END__

            "(\\w+|\\w+ +\\w+ +v[\\d.]+);" +                                # 1.     Algorithm, e.g. fasta, blastp
            "\\s*(\\w+):([\\w.]+)" +                                            # 2,3.   Primary dbxref, e.g. SWALL:Q26723
            "(?:\\s+\\((\\w+):([\\w.]+(?:,\\s*(?:\\w+:)?[\\w.]+)*)\\))?;" +     # 4,5.   Optional secondary dbxrefs, e.g. "EMBL:M20871", "EMBL:BC002634, AAH02634"
            "\\s*([^;]+)?;" +                                                   # 6.     Organism name
            "\\s*([^;]+)?;" +                                                   # 7.     Product name
            "\\s*([^;]+)?;" +                                                   # 8.     Gene name
            "\\s*(?:length\\s+(\\d+)\\s+aa)?;" +                                # 9.     Optional match length
            "\\s*(?:id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +                        # 10.    Optional degree of identity (percentage)
            "\\s*(?:ungapped\\s+id=(\\d{1,3}(?:\\.\\d{1,3})?)%)?;" +            # 11.    Optional ungapped identity (percentage)
            "\\s*E\\(\\)=(\\d*(?:\\.\\d+)?(?:e[+-]? ?\\d+)?);" +                # 12.    E-value
            "\\s*(?:score=(\\d+))?;" +                                          # 13.    Optional score
            "\\s*(?:(\\d+)\\s+aa\\s+overlap)?;" +                               # 14.    Optional overlap length (integer)
            "\\s*(?:query\\s+(\\d+)-\\s*(\\d+) aa)?;" +                         # 15,16. Optional query location
           "\\s*(?:subject\\s+(\\d+)-\\s*?(\\d+) aa)?");                       # 17,18. Optional subject location



 "(		f	1
?:\\s+\\(	f	2
(		fx
\\w+)		rx
:(		f	3
[\\w.]+(	f	4
?:,\\s*(	f	5
?:\\w+:)	r	1
?[\\w.]+)	r	2
*)		r	3
\\)		r	4
)		r	5
?;" 