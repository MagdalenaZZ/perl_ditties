#!/usr/bin/perl -w
#converts BLAST outfmt 6 to Artemis-style gff entries.
#Usage BLAST2joined_fasta.pl <input_BLAST_outfmt6> >output-file

use strict;

unless (@ARGV ==1) {
        &USAGE;
}


sub USAGE {

die 'Usage: transcriptome_eliminate_self-complimentary.pl fasta

Takes a fasta-file, blasts each sequence against itself and determines wether it is self-complimentary.
If it is, the programme tries to break it.

NOT FINISHED!!!!!

'
}


# read the fasta and make blasts agains itself 
my $in =shift;

	open (IN, "<$in") || die "I can't open $in\n";
#	my @in = <IN>;
#	close (IN);

#    	open (OUT, ">$in.gff") || die "I can't open $in.gff\n";


#$/ = '>';
$/ = ">";

my @rev;
my %right;

while (<IN>) {
    chomp;
    open (TMP, ">$in.tmp.fas") || die "I can't open $in.tmp.fas\n";

    print TMP ">$_";
    close (TMP);
    #print  ">$_";
    system "makeblastdb -in $in.tmp.fas -dbtype nucl -parse_seqids";
    system "blastn -db $in.tmp.fas -query $in.tmp.fas -out $in.tmp.blast -outfmt 6 -task megablast ";
    #system "tblastx -db $in.tmp.fas -query $in.tmp.fas -out $in.tmp.blast -outfmt 6 ";

    system "cat $in.tmp.blast >> $in.tmp.all.blast";
    $/ = "\n";

    open (TMP, "<$in.tmp.blast") || die "I can't open $in.tmp.blast\n";

	my @in = <TMP>;

# now parse the output and look for negative self-complimentary hits

    foreach my $ele (@in) {
        my @line = split(/\s+/, $ele);
        #print "$ele";
        #print "blast\n";
        my $query = $line[0];
        my $target = $line[1];
        my $similarity = $line[2];
        my $bitscore = $line[3];
        my $basechanges = $line[4];
        my $indels = $line[5];
        my $querystart = $line[6];
        my $queryend = $line[7];
        my $targetstart = $line[8];	
        my $targetend = $line[9];
        my $evalue = $line[10];	
        my $score = $line[11];
        my $qdiff = $queryend - $querystart;
        my $tdiff = $targetend - $targetstart;

        if ($querystart==$targetstart and $queryend==$targetend ) {
            # do nothing
            #print "SAME: $querystart\t$queryend\t$targetstart\t$targetend\n";
            $right{$query}{"$ele"}=1;
        }
        elsif ( $qdiff>0 and $tdiff<0  ) {
            push (@rev, "$ele");        
        }
        else {
            print "Warning different self-complimenarity than ++ or +- : $querystart\t$queryend\t$targetstart\t$targetend\n";
        }
    }
$/ = ">";
}

close (IN);

# now Ive got the right complimentary lines, and the reveres ones

my %res;


foreach my $line (@rev) {
    #print "$line";
    my @arr = split(/\s+/, $line);
    #print "break has to be between $arr[6] and $arr[8]\n";
    #print "$arr[0]\n"; 
    $res{"$arr[0]"}=1;

    foreach my $key ( keys %{$right{$arr[0]}} ) {
        if ($key=~$arr[0]) {
            #print "RIGHT: $key\n";
        }
    }

}

# print affected sequences
open (OUT, ">$in.res.list") || die "I can't open $in.res.list\n";

foreach my $key (keys %res) {
    print OUT "$key\n";
}
close (OUT);

system "perl ~mz3/bin/perl/fasta_retrieve_subsets.pl $in $in.res.list ";

system "perl ~mz3/bin/perl/scaff_split_agp.pl $in.res.list.in_list ";

system "cat  $in.res.list.not_in_list $in.res.list.in_list.all_split.fasta > $in.noself.fas";
system "rm -f $in.tmp.blast $in.tmp.fas   $in.res.list.in_list.contigs_singletons.fasta $in.res.list.in_list.contigs_in_scaffs.fasta $in.res.list.in_list.agp $in.tmp.fas.n* ";
# $in.res.list.in_list.all_split.fasta.res.list.in_list

exit;


__END__


