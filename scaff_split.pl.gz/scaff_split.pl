#!/usr/local/bin/perl -w
# as9 script, mz3 modifications

use strict;

my $name = "";
my %seqs;
my $minl = 0;


unless (@ARGV) {
        &USAGE;
}


open (INPUT,$ARGV[0]);

my @input= <INPUT>;

open SCAFF, ">$ARGV[0].contigs_in_scaffs.fasta";
open SINGLE, ">$ARGV[0].contigs_singletons.fasta";
open GAP, ">$ARGV[0].gaps";

while (@input) {
	chomp;
	if (/^>/) {
		tr/>//d;
		$name = (split /\s+/, $_)[0];
	} else {
		tr/n/N/s;
		$seqs{$name} .= $_;
	}
}

foreach my $key (sort keys %seqs) {
	my $conta = 1;
	if ($seqs{$key} =~ /N/) {
		my @gaps = $seqs{$key} =~ m/N+/g;
		my @contigs = split (/N+/, $seqs{$key});
		foreach my $contig (@contigs) {
			my $l = length $contig;
			if ($l >= $minl) {
				#print $seqs{$key}; <STDIN>;
				print SCAFF ">$key\_$conta\n$contig\n"; #<STDIN>;
				if ($conta-1 < $#contigs) {
					my $lgap = length $gaps[$conta-1];
					print GAP "$key\t$conta\t$lgap\n"; #<STDIN>;
				}
				$conta++;
			} 
		}
	} else {
		my $l = length $seqs{$key};
		if ($l >= $minl) {
			print SINGLE ">$key\n$seqs{$key}\n"; #<STDIN>;
		}
	}
}


sub USAGE {

die 'Usage: scaff_split.pl <infile>

Outfiles are named after infile with extensions 
.contigs_in_scaffs.fasta - file with scaffolds split with name_no ex. scaf1_1 scaf1_2 scaf2_1
.contigs_singletons.fasta - file with singletons
.gaps - file with scaffoldname gap_no gap_length 

'
}