#!/usr/bin/perl -w


use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV == 3) {
        &USAGE;
}


sub USAGE {

die 'Usage: network2ID.pl network.pl-output.info pfam.results product-names 

Takes a networked result and get all the products for that domain

'
}

# if a domain interacts with 5 or less other domains - then get the genes and get the products
# re-run on pruned all, 100, 50, 25 and 10 to see if the product changes


# Take the network file and get all the IDs

my %nam;
# %nam { dom-comb } { gene  } = "prod";


my $table = shift;
my $pfam = shift;
my $prod = shift;


        open (IN, "<$table") || die "I can't open $table\n";
    	my @table= <IN>;
    	close (IN);

        open (IN2, "<$pfam") || die "I can't open $pfam\n";
    	my @pfams= <IN2>;
    	close (IN2);
        
        open (IN3, "<$prod") || die "I can't open $prod\n";
    	my @prods= <IN3>;
    	close (IN3);


my %doms;

# Get domains from the network list

foreach my $line ( @table ) {
    chomp $line;

    my @arr = split (/\t/,$line);
    my $dom = shift(@arr);
    my $freq = shift(@arr);
#    print "$dom:\t:$freq\n";
    if ($freq < 6 ) {
#       foreach my $elem (@arr) {
#            print "$dom\t$freq\t$elem\n";
#        }
        $doms{$dom}{1}=1;
    }
}

print "Finished reading in network-info\n";

# read in pfam to get the genes which has this domain

foreach my $line ( @pfams ) {
    chomp $line;
    if ($line=~/\w+/) {
        my @arr = split(/\s+/, $line);
        my $gene = $arr[0];
        $gene=~s/\.1\.\.pep//;
        push (@arr, " ");
        push (@arr, " ");
        push (@arr, " ");
        push (@arr, " ");
        push (@arr, " ");
        push (@arr, " ");

        my $pfam = $arr[6];

#       print "PFAM:$gene\t$pfam\n";
       if (exists $doms{$pfam} ) {
            $doms{$pfam}{$gene}=1;
       }
    }
}

print "Finished reading in pfam\n";

my %out;

# read in a list of product names for genes 

foreach my $pro ( @prods ) {
    chomp $pro;
    $pro =~s/^ID=//;
#    print "Pro:$pro\n";
    my @arr = split(/\t/, $pro);
    push (@arr, " ");
    my $gen = $arr[0];
    my $prd = $arr[1];
    $gen=~s/\.1\.\.pep//;
#    print "$gen\t$prd\n";
    if ($prd =~/\w+/) { 
        foreach my $xx ( keys %doms ) {
            if ( exists $doms{$xx}{$gen} ) {
#            print "Exists:$xx\t$gen\t$prd\n";
            $out{ "$xx\t$prd" }=1;
            }
        }
    }
}

print "Finished reading in products\n";

open (OUT, ">$table.out.cyt") || die "I can't open $table.out.cyt\n";

# print an output where the domain has the product name

foreach my $key ( sort keys %out) {
    print OUT "$key\n";
}

close (OUT);

print "Finished output, doing product-mangler\n";

# run product mangler 

system "perl ~/bin/perl/product_mangler.pl $table.out.cyt $table.out.cyt.mangled";

exit;


__END__        





