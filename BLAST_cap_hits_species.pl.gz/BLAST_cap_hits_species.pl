#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

sub USAGE {

die 'Usage: BLAST_cap_hits_species.pl BLASToutput <n> outputname

Takes a blast tab-output, and chooses the n best hits for each species

(species are recognized from the gene_IDS e.g. SP_0001, SP_0002 )


'
}



my $blast = shift;
my $n = shift;
#$n--;
my $out = shift;



	open (IN, "<$blast") || die "I can't open $blast\n";
	my @blast = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
#	open (OUT2, ">$out.errors") || die "I can't open $out.errors\n";

my $index = 0;

my %hash;

# read in blast
#
foreach my $elem (@blast) {
        chomp $elem;

		my @arr = split(/\s+/, $elem);
		if ($arr[0]=~/\w+/) {
#			print "$arr[0]\t$elem\n";
			my @arr2 = split(/\_/ , $arr[1]);

            push (@{$hash{$arr[0]}{$arr2[0]}}, $elem);
#            print "IN:$arr[0]\t$arr2[0]\t$elem\n";
#			shift @list;
		}
		else {
#			print OUT2 "$arr[0] is not in gff-file\n";
#			shift @blast;
		}

}

# print output
#
foreach my $key (keys %hash) {

    foreach my $species (sort keys %{$hash{$key}} ) {


#    print "$key\t$species\n";

        my @arr3 = @{$hash{$key}{$species}};

#        foreach my $hit2 (@arr3) {
#            print OUT "$hit2\n";
#            print "OUT:$hit2\n";

#        }


        my @splice = splice(@arr3, 0, $n); 
#        print "SPLICE: $splice[0]\n";
        foreach my $hit (@splice) {
            print OUT "$hit\n";
#            print "RES:    $hit\n";

        }
    }
#print OUT2 "$line does not have a BLAST-hit\n";
}

close (OUT);
#close (OUT2);



