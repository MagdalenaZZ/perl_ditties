#!/usr/bin/perl -w

use strict;

unless (@ARGV == 2) {
        &USAGE;
}


sub USAGE {

die 'Usage: perl ~/bin/perl/gff_correct_augustus_codon.pl input.gff 


input.gff	Input gff-file, which can have additional features



'
}


my $in = shift;
my $in2 = shift;
my  $logfile = "$in\.error";

        open (STDERR, ">$logfile") || die "I can't open $logfile\n";

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (IN2, "<$in2") || die "I can't open $in2\n";
	my @in2 = <IN2>;
	close (IN2);


# Parse the file, and get all the lenghts of CDSs belonging to the same gene

# If the combined length is not equally dividable by 3

# then delete 1 or 2 bases until it is dividable

# print the new posistions to outputfile
