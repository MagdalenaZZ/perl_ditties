#!/usr/local/bin/perl -w

# 

use strict;

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die '


Usage: LTR_finder_from_HMM.pl  PPT.gff  LTR.gff

Takes one fasta-file, and HMM output, and merges them to complete and partial LTRs.





'
}


#my $fas = shift;
my $ppt = shift;
my $ltr = shift;



# make the outputs


open (OUT, ">$ppt.LTR_complete.gff") || die "I can't open $ppt.LTR_complete.gff\n";
open (OUT2, ">$ppt.LTR_partial.gff") || die "I can't open $ppt.LTR_partial.gff\n";
open (OUT3, ">$ppt.LTR_no_PPT.gff") || die "I can't open $ppt.LTR_no_PPT.gff\n";
open (OUT4, ">$ppt.PPT_only.gff") || die "I can't open $ppt.PPT_only.gff\n";



# read in the PPT file in a hash

my %h;
my %LTRs;
my %LTRa;


open (PPT, "<$ppt") || die "I can't open $ppt\n";






# hash looks like   h{ scaffold }      { PPT }        { ORI } = +/-
#                                                     { COORD }   { start \t end } = line
#                                                     { 3LTR }  { start \t end } = line
#                                                     { 5LTR }  { start \t end } = line



while (<PPT>) {
    chomp;
    my @a = split(/\t/,$_);

    my $name = $a[8];

    $h{"$a[0]"}{"$name"}{"COORD"} { "$a[3]\t$a[4]"  }=$_;
    $h{"$a[0]"}{"$name"}{"ORI"} = "$a[6]";

    #print "$a[0]\t$a[3]\t$a[4]\t$a[6]\t$name\n";

}



open (LTR, "<$ltr") || die "I can't open $ltr\n";




while (<LTR>) {
    chomp;
    my @a = split(/\t/,$_);

    my $name = $a[8];

    #print "$a[0]\t$a[3]\t$a[4]\t$a[6]\t$name\n";


    my $assigned = 0;


    # find and assign the 3'LTRs and 5'LTRs to PPTs


    foreach my $pt ( keys %{$h{$a[0]}} ) {
    
        foreach my $key ( keys $h{$a[0]}{$pt}{COORD}) {
            #print "$a[0] $key $pt\n";

            
            # check if the LTR is in close proximity to the PPT
            
            my ($ppts,$ppte) =  split(/\t/, $key);

            if ( $h{$a[0]}{$pt}{ORI} =~/\+/ ) {
                #print "plus\n";

                my $diff3 = $a[3] - $ppte;
                my $diff5 = $ppts - $a[4];

                
                if ( $diff3 < 100 and $diff3 > -100 ) {
                    $h{"$a[0]"}{"$pt"}{"3LTR"} { "$a[3]\t$a[4]" }=$_;
                    #print "$a[0]\t$pt\t3LTR\t$a[3]\t$a[4]\t$_\n";
                    #print "+ $a[3]\t$a[4]\t$ppts\t$ppte\t$diff3\t$pt\n";
                    $assigned = 1;
                    $LTRa{$_}=1;
                }
                

                elsif ( $diff5 < 2000 and $diff5 > 100  ) {
                    $h{"$a[0]"}{"$pt"}{"5LTR"} { "$a[3]\t$a[4]" }=$_;
                    #print "$a[0]\t$pt\t5LTR\t$a[3]\t$a[4]\t$_\n";
                    #print "+ $a[3]\t$a[4]\t$ppts\t$ppte\t$diff5\t$pt\n";
                    $assigned = 1;
                    $LTRa{$_}=1;
                }





            }
            elsif ( $h{$a[0]}{$pt}{ORI} =~/\-/ ) {
                #print "minus\n";

                my $diff3 = $ppts - $a[4];
                my $diff5 = $a[3] - $ppte;


                if ( $diff3 < 100 and $diff3 > -100 ) {
                    $h{"$a[0]"}{"$pt"}{"3LTR"} { "$a[3]\t$a[4]" }=$_;
                    #print "$a[0]\t$pt\t3LTR\t$a[3]\t$a[4]\t$_\n";
                    #print "- $a[3]\t$a[4]\t$ppts\t$ppte\t$diff3\t$pt\n";
                    $assigned = 1;
                    $LTRa{$_}=1;

                }

                elsif ( $diff5 < 2000 and $diff5 > 100  ) {
                    $h{"$a[0]"}{"$pt"}{"5LTR"} { "$a[3]\t$a[4]" }=$_;
                    #print "$a[0]\t$pt\t5LTR\t$a[3]\t$a[4]\t$_\n";
                    #print "+ $a[3]\t$a[4]\t$ppts\t$ppte\t$diff5\t$pt\n";
                    $assigned = 1;
                    $LTRa{$_}=1;

                }





            }









            else {
                print "Warning!!!\n";
                die;
            }

        }

        # save the LTR elements
        $LTRs{$_}=1;
        


    }



}



# print the whole united LTRs

my $i3 = 1;


foreach my $scaf ( sort keys %h ) {

    foreach my $pt ( sort keys %{$h{$scaf}} ) {

        my @ppt;
        my @ltr5;
        my @ltr3;
        my $fin_ppt;

        # get the PPT info back 
        foreach my $elem ( keys %{$h{$scaf}{$pt}{"COORD"}} )  {
            @ppt=split(/\t/, $h{$scaf}{$pt}{"COORD"}{$elem} );
            $fin_ppt = $h{$scaf}{$pt}{"COORD"}{$elem} ;
            chomp $fin_ppt ;
        }


        #check status of PPT
        my $status = "PPT";

        if ( exists $h{$scaf}{$pt}{"5LTR"} ) {
            $status = $status . "\t 5LTR";
        }
        if ( exists $h{$scaf}{$pt}{"3LTR"} ) {
            $status = $status . "\t 3LTR";

        }



        # process correctly by status

        my @res;

        # complete
        if ($status=~/5LTR/ and $status=~/3LTR/  ) {
          
            my $start=$ppt[3];
            my $end=$ppt[4];
            my $ins=$ppt[3];
            my $ine=$ppt[4];
            
            # first deal with the 5LTR
            foreach my $elem ( keys %{$h{$scaf}{$pt}{"5LTR"}} )  {
                @ltr5=split(/\t/, $h{$scaf}{$pt}{"5LTR"}{$elem} );
                my $res = $h{$scaf}{$pt}{"5LTR"}{$elem} . ";note=5LTR" . ";colour=9"  .  ";Parent=LTR_PPT_$i3";
                push(@res, $res);
                #print "$res";

                # adjust gene boundaires
                if ( $ltr5[3] < $start) {
                    $start = $ltr5[3] ;
                }
                if ( $ltr5[4] > $end) {
                    $end = $ltr5[4] ;
                }

                # adjust inner boundaries
                if ( $ltr5[4] < $ins) {
                    $ins = $ltr5[4] ;
                }
                if ( $ltr5[3] > $ine) {
                    $ine = $ltr5[3] ;
                }

            }

            # then with the PPT
            my $fin_fin = $fin_ppt . ";note=PPT" . ";colour=2"  . ";Parent=LTR_PPT_$i3" ;
            push(@res, "$fin_fin");

            # then with the 3LTR
            foreach my $elem ( keys %{$h{$scaf}{$pt}{"3LTR"}} )  {
                @ltr3=split(/\t/, $h{$scaf}{$pt}{"3LTR"}{$elem} );
                my $res = $h{$scaf}{$pt}{"3LTR"}{$elem} . ";note=3LTR" . ";colour=9"  . ";Parent=LTR_PPT_$i3";
                push(@res, $res);
                #print "$res";

                # adjust gene boundaires
                if ( $ltr3[3] < $start) {
                    $start = $ltr3[3] ;
                }
                if ( $ltr3[4] > $end) {
                    $end = $ltr3[4] ;
                }

                # adjust inner boundaries
                if ( $ltr3[4] < $ins) {
                    $ins = $ltr3[4] ;
                }
                if ( $ltr3[3] > $ine) {
                    $ine = $ltr3[3] ;
                }

            }


            # then with the gene
            print OUT "$ppt[0]\tLTR_find\tgene\t$start\t$end\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\n";
            print OUT "$ppt[0]\tLTR_find\tCDS\t$ins\t$ine\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\_insert;colour=7;Parent=LTR_PPT_$i3\n";
            foreach my $el (@res) {
                print OUT "$el\n";
            }
            $i3++;
        }

        # only start 

        elsif ($status=~/5LTR/ ) {
          
            my $start=$ppt[3];
            my $end=$ppt[4];
            my $ins=$ppt[3];
            my $ine=$ppt[4];
            
            # first deal with the 5LTR
            foreach my $elem ( keys %{$h{$scaf}{$pt}{"5LTR"}} )  {
                @ltr5=split(/\t/, $h{$scaf}{$pt}{"5LTR"}{$elem} );
                my $res = $h{$scaf}{$pt}{"5LTR"}{$elem} . ";note=5LTR" . ";colour=9"  .  ";Parent=LTR_PPT_$i3";
                push(@res, $res);
                #print "$res";

                # adjust gene boundaires
                if ( $ltr5[3] < $start) {
                    $start = $ltr5[3] ;
                }
                if ( $ltr5[4] > $end) {
                    $end = $ltr5[4] ;
                }

                # adjust inner boundaries
                if ( $ltr5[4] < $ins) {
                    $ins = $ltr5[4] ;
                }
                if ( $ltr5[3] > $ine) {
                    $ine = $ltr5[3] ;
                }

            }

            # then with the PPT
            my $fin_fin = $fin_ppt . ";note=PPT" . ";colour=2"  . ";Parent=LTR_PPT_$i3" ;
            push(@res, "$fin_fin");

            # then with the gene
            print OUT2 "$ppt[0]\tLTR_find\tgene\t$start\t$end\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\n";
            print OUT2 "$ppt[0]\tLTR_find\tCDS\t$ins\t$ine\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\_insert;colour=7;Parent=LTR_PPT_$i3\n";

            foreach my $el (@res) {
                print OUT2 "$el\n";
            }
            $i3++;
        }



        # only end
        
        elsif ($status=~/3LTR/  ) {
          
            my $start=$ppt[3];
            my $end=$ppt[4];
            my $ins=$ppt[3];
            my $ine=$ppt[4];
            
            # then with the PPT
            my $fin_fin = $fin_ppt . ";note=PPT" . ";colour=2"  . ";Parent=LTR_PPT_$i3" ;
            push(@res, "$fin_fin");

            # then with the 3LTR
            foreach my $elem ( keys %{$h{$scaf}{$pt}{"3LTR"}} )  {
                @ltr3=split(/\t/, $h{$scaf}{$pt}{"3LTR"}{$elem} );
                my $res = $h{$scaf}{$pt}{"3LTR"}{$elem} . ";note=3LTR" . ";colour=9"  . ";Parent=LTR_PPT_$i3";
                push(@res, $res);
                #print "$res";

                # adjust gene boundaires
                if ( $ltr3[3] < $start) {
                    $start = $ltr3[3] ;
                }
                if ( $ltr3[4] > $end) {
                    $end = $ltr3[4] ;
                }

                # adjust inner boundaries
                if ( $ltr3[4] < $ins) {
                    $ins = $ltr3[4] ;
                }
                if ( $ltr3[3] > $ine) {
                    $ine = $ltr3[3] ;
                }

            }


            # then with the gene
            print OUT2 "$ppt[0]\tLTR_find\tgene\t$start\t$end\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\n";
            print OUT2 "$ppt[0]\tLTR_find\tCDS\t$ins\t$ine\t\.\t$ppt[6]\t\.\tID=LTR_PPT_$i3\_insert;colour=7;Parent=LTR_PPT_$i3\n";
            foreach my $el (@res) {
                print OUT2 "$el\n";
            }
            $i3++;
        }


        

        
        # only PPT
        else {

            # then with the PPT
            my $fin_fin = $fin_ppt . ";note=PPT" . ";colour=2" ;
            print OUT4  "$fin_fin\n";
        
        }

        



    }
}








# now deal with the LTRs that were left over


my %LTR_left;

foreach my $key ( keys %LTRs) {

    unless (exists $LTRa{$key}) {
        $LTR_left{$key}=1;
    }

}

#my $key1 = scalar(keys %LTRs);
#my $key2 = scalar(keys %LTRa);
#my $key3 = scalar(keys %LTR_left);
#print "$key1\t$key2\t$key3\n";


my $i = 0;
my $i2 = 0;

foreach my $key (  keys %LTR_left ) {
    foreach my $key2 (  keys %LTR_left ) {

        my @a1 = split(/\t/,$key);
        my @a2 = split(/\t/,$key2);

        $i++;
        if ( $a1[0]!~/$a2[0]/ ) {
            # different scaffold ignore
        }
        elsif (  ( $a1[6]=~/\+/ and  $a2[6]=~/\-/  )  or  (  $a1[6]=~/\-/ and  $a2[6]=~/\+/  ) ) {
            # opposite strand ignore
        }
        elsif ($a1[8]=~/$a2[8]/) {
            # same ignore
        }
        elsif ($a1[4] > $a2[4] ) {
            # first is after second
        }
        elsif ($a1[4] > $a2[4] ) {
            # first is after second
        }
        elsif ( ($a2[4] - $a1[4] ) > 8000  ) {
            # ignore too far apart
        }
        elsif ( ($a2[3] - $a1[4] ) < 100  ) {
            # ignore too close
        }

        else {

            # make a gene for them

            print OUT3 "$a1[0]\tLTR_find\tgene\t$a1[3]\t$a2[4]\t\.\t$a1[6]\t\.\tID=LTR_no_PPT_$i2\n";

            #print "$a1[0]\tLTR_find\tg\t$a1[3]\t$a2[4]\t\.\t$a1[6]\t\.\tID=LTR_no_PPT_$i2.1;Parent=LTR_no_PPT_$i2\n";
            print OUT3 "$key;note=5LTR;colour=9;Parent=LTR_no_PPT_$i2\n";
            print OUT3 "$a1[0]\tLTR_find\tCDS\t$a1[4]\t$a2[3]\t\.\t$a1[6]\t\.\tID=LTR_no_PPT_$i2\_insert;colour=7;Parent=LTR_no_PPT_$i2\n";
            print OUT3 "$key2;note=3LTR;colour=9;Parent=LTR_no_PPT_$i2\n";
            $i2++;
        }


    }
}


#print "$i comparisons made $i2 interesting\n";




close(OUT);
close(OUT2);
close(OUT3);
close(OUT4);



system "perl ~mz3/bin/perl/gff2art.pl $ppt.LTR_complete.gff";
system "perl ~mz3/bin/perl/gff2art.pl $ppt.LTR_partial.gff";
system "perl ~mz3/bin/perl/gff2art.pl $ppt.LTR_no_PPT.gff";
system "perl ~mz3/bin/perl/gff2art.pl $ppt.PPT_only.gff";




exit;

