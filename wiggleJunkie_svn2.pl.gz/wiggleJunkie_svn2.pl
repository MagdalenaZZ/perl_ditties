#!/usr/bin/perl
use strict;
use Clone qw(clone);

unless (@ARGV > 0) {
        &USAGE;
}

sub USAGE {

die ' 

perl ~/bin/perl/wiggleJunkie.pl bam-file file.fas




';

}


my $in = shift;
my $fas = shift;


# run bump-caller and junction-finder on bam-file




system "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in 5 25"; wait;
system "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas"; wait;
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.genomeCoverageBed.bga.split";  wait;
system "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.genomeCoverageBed.bga";  wait;
system "perl ~/bin/perl/coverage2feature.pl $in.genomeCoverageBed.bga BED 5";  wait;
system "perl ~/bin/perl/coverage2feature.pl $in.genomeCoverageBed.bga.split BED 10";  wait;



# test if all files are made like they should


unless (-s "$in.5.25.gff") {
    print "You file $in.5.25.gff is not getting produced as expected, check the script SAM_extract_junctions.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/SAM_extract_junctions.pl $in 5 25";
    print "\n";
    die;
}

unless (-s "$in.genomeCoverageBed.bga.gff") {
    print "You file $in.genomeCoverageBed.bga.gff is not getting produced as expected, check the script coverage2feature.pl to make sure it is working\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.genomeCoverageBed.bga BED 5";
    print "\n";
    print "perl ~/bin/perl/coverage2feature.pl $in.genomeCoverageBed.bga.split BED 10";
    print "\n";
    die;
}

unless (-s "$fas.genome") {
    print "You genome-file is not getting produced as expected, check the script wj_make_genome.pl to make sure it is working\n";
    print "/nfs/users/nfs_m/mz3/bin/perl/wj_make_genome.pl $fas";
    print "\n";
    die;
}

unless (-s "$in.genomeCoverageBed.bga.split" or -s "$in.genomeCoverageBed.bga") {
    print "You file $in.genomeCoverageBed.bga.split is not getting produced as expected, check the BEDtools genomeCoverageBed  to make sure it is working\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -g $fas.genome > $in.genomeCoverageBed.bga.split  ";
    print "\n";
    print "~jit/bin/BEDTools-Version-2.12.0/bin/genomeCoverageBed  -ibam $in -bga -split -g $fas.genome > $in.genomeCoverageBed.bga  ";
    print "\n";
    die;
}






# read the junctions file, and make groups of junctions




open(FAS, "<$fas.sl") || die "Cant read file $fas.sl";

my %fas;

while (<FAS>) {
    chomp;
    #print "$_\n";
    if ($_=~/^>/) {
        my $head = $_;
        $head=~s/>//;
        my $seq = <FAS>;
        chomp $seq;
        $fas{$head}= $seq;
    }

}



# read in the junctions

my @res;

open(JN, "<$in.5.25.gff") || die "Cant read file $in.5.25.gff, check that it has been produced";
system "fasta2singleLine.py $fas $fas.sl";


while (<JN>) {
    chomp;
    #print "$_\n";
    my @arr = split(/\t/, $_);
    if (exists $fas{$arr[0]}) {

        $arr[2]= "intron";
        my $len = length($fas{$arr[0]});
        #print "Len $len\n";
        my $last = $arr[4]-2;
        my $left = substr( $fas{$arr[0]}, ($arr[3]-1 ), 2 );
        my $right = substr( $fas{$arr[0]}, $last, 2 ); 
        #print "$arr[8]\t$left\t$right\n";

        # check which orientation they are

        if ($left =~/gt/ and $right=~/ag/) {
            $arr[6]='+';
        }
        elsif ($left =~/ct/ and $right=~/ac/) {
            $arr[6]='-';
        }
        elsif ($left =~/gc/ and $right=~/ag/) {
            $arr[6]='+';
        }
        elsif ($left =~/ct/ and $right=~/gc/) {
            $arr[6]='-';
        }
        elsif ($left =~/gt/ and $right=~/at/) {
            $arr[6]='+';
        }
        elsif ($left =~/at/ and $right=~/ac/) {
            $arr[6]='-';
        }
        else {
            print "Cant determine orientation of strand: $arr[8]\t$left\t$right \n";
        }

        my $newl = join("\t", @arr);
        push(@res, $newl);
        #print "Made $newl\n";



    }
    else {
        print "Warning: Contig $arr[0] does not exist in fasta\n";
    }
}





#### read in exons, and filter the bad ones, and merge adjoining ones



my $laste;


open(EX, "<$in.genomeCoverageBed.bga.split.gff") || die "Cant read file $in.genomeCoverageBed.bga.split.gff, check that it has been produced";

my @ex = <EX>;

my @res1;
my $lkey=shift(@ex);

# merge features less than 10 bp apart
foreach my $k (@ex) {
    chomp $k;

    my @ar1 = split(/\t/, $k);
    my @ar2 = split(/\t/, $lkey);

    #print "Comparing $lkey to $k\n";

    # if the feature is > 20 bp apart
    if ( ($ar1[3]-20 ) < $ar2[4]) {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "   overlapping \t $ar2[3] $ar2[4] $ar1[3]  $ar1[4] $ovl\n";
                
        # if extension happended, update the feature length
 
        my $min = $ar2[3];
        my $max = $ar2[4];
        my $min2 = ($ar1[3], $min  )[$ar1[3] > $min ];
        my $ie2 = ($max, $ar1[4])[$max < $ar1[4]];
        $ar2[3] = $min2;
        $ar2[4] = $ie2;

        # if extension happended, update the note
        
        my @old_note = split(/"/,$ar2[8]);
        my @new_note = split(/"/,$ar1[8]);
        my $bridge = "0,$ovl:";

        $ar2[8]= "$old_note[0]\"$old_note[1] $bridge $new_note[1]\"\n";

        my $newl = join("\t", @ar2);
        #print "New feature $newl\n";
        $lkey=$newl;
    }
    else {
        my $ovl = ($ar1[3] ) -  $ar2[4] ; 
        #print "not overlapping \t$ar2[3] : $ar2[4] : $ar1[3]  :  $ar1[4]  :  $ovl\n";
        push(@res1, $lkey);
        
        $lkey = $k;
    }



}

# add the last one
push(@res1, $lkey);


foreach my $ke1 (@res1) {
    chomp $ke1;
#$_=~s/CDS/intron/;
    push(@res, $ke1);
    #print "$ke1\n";
}


#__END__


my @sorted = sort { (split '\t', $a)[3].(split '\t', $a)[4] <=> (split '\t', $b)[3].(split '\t', $b)[4] } @res;
@res = @sorted;




# combine the results to transcript-groups by finding overlapping ones




my $i = 1;
my $is = 10000000;
my $ie = 0;
my $strand="+";
my %groups;
my %unassigned;
my $lastl = shift(@res);
my $first=0;
my $ext = 0;

foreach my $line (@res) {
    chomp $line;
    #print "$line\n";
    
    my @ar1 = split(/\t/, $line);
    my @ar2 = split(/\t/, $lastl);
    my $scaf=$ar1[0];
    

    # make the first feature
    if ($first=~/^0$/) {
        $is = $ar2[3] ;
        $ie = $ar2[4] ;
        $first=1;
        #print "Feature $i initiated to $is $ie\n";

        # add feature to group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$lastl");
        push (@{$groups{$scaf}{$i}{F}},"$line");


        # set strand if I can
        if ( $ar1[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar1[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }
        if ( $ar2[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar2[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }


    }


    # if different strand on introns
    if ( $ar1[1]=~/FromBam/ and  $ar1[6]!~/\Q$strand\E/    ) {
#        push ( @{ $groups{$ar1[0]}{$i} } , $lastl );
            #$is = $ar1[3];
            #$i++;

            # start a new feature

            $i++;
            $is = $ar2[3] ;
            $ie = $ar2[4] ;
            $lastl=~s/\t$strand\t/\t$ar1[6]\t/;
            $strand=$ar1[6];

            #print "switch $i $strand \n$lastl\n$line\n";

            # claim the previous line too
            $groups{$scaf}{$i}{SE}="$is\t$ie";
            $groups{$scaf}{$i}{ORI}="$strand";
            push (@{$groups{$scaf}{$i}{F}},"$lastl");
            push (@{$groups{$scaf}{$i}{F}},"$line");
    }

    
    # replace the orientation on feature
    elsif ($ar1[1]=~/FromBed/) {
        $ar1[6]=$strand;
        $line=join("\t", @ar1);
    }





    # merge overlapping features
    if ( ($ar1[3]-100 ) < $ie) {
        my $ovl = ($ar1[3] ) -  $ie ; 
        #print "   overlapping \t$ar1[3]  $ar1[4] $is $ie  $ovl\n";
        #$ext = 1;
        #
        #
        # if extension happended, update the feature length
 
        my $min = $is;
        my $max = $ie;
        my $min2 = ($ar1[3], $min  )[$ar1[3] > $min ];
        my $ie2 = ($max, $ar1[4])[$max < $ar1[4]];
        $is = $min2;
        $ie = $ie2;
        #print "Feature $i extended to $is $ie\n";

        # add feature to group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$line");

        # add orientation
        if ( $ar2[1]=~/FromBam/ ) {
            if ($ar1[6]=~/\+/ or $ar1[6]=~/\-/  ) {
                $strand=$ar2[6];
                #$groups{$scaf}{$i}{ORI}{"$ar2[6]"}=1;
                $groups{$scaf}{$i}{ORI}="$ar2[6]";
            }
        }


    }
    
    else {
        my $ovl = ($ar1[3] ) -  $ie ; 
        #print "   else        \t\t$ar1[3]  $ar1[4]  $is $ie  $ovl\n";
        #$ext = 0;



        # now when there is no extension, I have to create a new feature
        $i++;
        $is = $ar1[3] ;
        $ie = $ar1[4] ;
        #print "No extension initiated $i at $is $ie\n";

       # add feature to new group
        $groups{$scaf}{$i}{SE}="$is\t$ie";
        push (@{$groups{$scaf}{$i}{F}},"$line");


    }




    $lastl= $line;

}






# print the resulting intron-groups


open(OUT, ">$in.trans.gff") || die "Cant read file $in.trans.gff";
open(OUT2, ">$in.trans.left.gff") || die "Cant read file $in.trans.left.gff";

foreach my $scaf (sort keys %groups) {

    #print "$scaf\n";
    
    foreach my $i (sort { $a <=> $b }  keys %{$groups{$scaf}}) {



        #foreach my $key (sort { $a <=> $b }  keys %{$groups{$scaf}{$i}}) {
        my $coord =$groups{$scaf}{$i}{"SE"};
        my $ori =$groups{$scaf}{$i}{"ORI"} ;
        #print "$scaf\t$i\t$coord\n";


        my @int = @{ $groups{$scaf}{$i}{"F"} };


        #foreach my $ele (@int) {
            #print "$ele\n";
            #}

        if (scalar(@int)> 1) {

            # make gene


            #my $first = @int[0];
            my $last = @int[-1];
            #my @min = split(/\t/,$first);
            my @max = split(/\t/,$last);
            #my $min = $min[3];
            #my $max = $max[4];
            if ($ori=~/^\.$/) {
                $ori = $max[6];
            }

            if ($ori=~/^$/) {
                #print "No ori\n";
                $ori="\.";
            }    
    
            print OUT  "$scaf\tassigned\tgene\t$coord\t.\t$ori\t.\tID=$i\n";
            print OUT "$scaf\tassigned\tmRNA\t$coord\t.\t$ori\t.\tID=$i.1;Parent=$i\n";


            open(OUT3, ">$in.tmp.gff") || die "Cant read file $in.tmp.gff";


            foreach my $ele (@int) {
                print OUT3"$ele\n";
            }


            close (OUT3);

            system "cat $in.tmp.gff | grep intron > $in.tmp.gff.intron ";
            system "cat $in.tmp.gff | grep CDS > $in.tmp.gff.CDS ";
            system "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/subtractBed  -a $in.tmp.gff.CDS -b $in.tmp.gff.intron -s > $in.tmp.gff";
            
            open(OUT3, "<$in.tmp.gff") || die "Cant read file $in.tmp.gff";
            my @intx=<OUT3>;
            close (OUT3);

            foreach my $elex (@intx) {
                chomp $elex;
                $elex=~s/\t\+\t/\t$ori\t/;
                $elex=~s/\t\-\t/\t$ori\t/;
                $elex=~s/\t.\t.\t.\t/\t\.\t$ori\t\.\t/;
                print OUT "$elex;Parent=$i.1\n";
            } 
=pod

            ###### here I have to cut the transcripts according to splice-junctions

                my %sjs;
                my %sj2;

                my $ts = "A";

            foreach my $ele (@int) {
                # find min
                # find max
                

                # go through all SJs and store them
                 if ($ele=~/$max[0]/ and $ele=~/FromBam/) {
                    my @sj = split(/\t/, $ele);
                    $sjs{"$sj[3]\t$sj[4]"}="$ele";
                    $sj2{$ts}{"$sj[3]\t$sj[4]"}="$ele";
                    #print "$sj[3]\t$sj[4]\t$sj[8]\n";
                }

            }


            
            
            #my %copy = %{ clone (\%hash) };
                my $ovl=0;
 # compare all sjs to each other
                foreach my $key (keys %sjs) {
                    my @assigned;
                    push(@assigned, $ts);

                    foreach my $key2 (keys %sjs) {
                        my($s1,$e1) = split(/\t/,$key);
                        my($s2,$e2) = split(/\t/,$key2);
                        # self
                        if ($key=~/$key2/ and $key2=~/$key/ ) {
                            #print "same $key $key2\n";
                        }
                        # non-overlapping
                        elsif ($e1 < $s2 or $e2 < $s1  ) {
                            #print  "novl $key $key2\n";

                        }
                        else {
                            $ovl=1;
                            #print  "OVL $key $key2\n";
#=pod
                            # for each copy already accrued
                            foreach my $ass (@assigned) {
                                # assign each new value to a new hash 
                                # copy the old hash to a new one
                                my $old_ts = $ts;
                                $ts++;
                                #print "$old_ts $ts\n";
                                # $hr2 is a hash reference to a copy of %h2.
                                
                                if (exists $sj2{$old_ts}) {
                                    #print "exists $sj2{$old_ts} \n";
                                    foreach my $key (keys %{$sj2{$old_ts}}) {
                                        $sj2{$ts}{$key}=$sj2{$old_ts}{$key};
                                        print "copying $old_ts $key to $ts $key\n";
                                    
                                    }
                                }
                               
                            }

                            push(@assigned, $ts);
                        

#=cut
                        }
                    }
                    $ovl=0;

                }

                #print "hi\n";



                if ($ovl=~/1/) {
                    
                    # do nothing for now
                    #print "ovl\n";

                }
                else {
                
                    #print "novl\n";
                    my @int2;
                    foreach my $ele2 (@int) {

                        #print "$ele2\n";
                        
                        my @arx = split(/\t/, $ele2);

                        if ($arx[0]=~/$max[0]/ and $ele2=~/CDS/) {
                            #$ele2=~s/\t\+\t/\t$ori\t/;
                            #$ele2=~s/\t\-\t/\t$ori\t/;
                            #$ele2=~s/\t.\t.\t.\t/\t\.\t$ori\t\.\t/;
                            $arx[6]=$ori;

                            # trim any positions overlapping with any intron
                            foreach my $key (keys %sjs) {
                                my($s3,$e3) = split(/\t/,$key);
                                #print "$key\n";

                                #$arx[3];
                                #$arx[4];

                                # not overlapping 
                                if ( $e3 <= $arx[3]  or $arx[4] <= $s3   ) {
                                    #print "novl $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                }
                                # complete overlap
                                elsif ( $arx[4] <= $e3  and $s3 <= $arx[3] ) {
                                    #$arx[3]=$e3;
                                    #$arx[4]= $s3;
                                    #print "tovl $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                    # delete whole thing
                                    #delete $int[$index];
                                    $arx[3]="removed";
                                    $arx[4]="removed";
                                }
                                # inside - make two features
                                elsif ( $arx[3] <= $s3  and $e3 <= $arx[4] ) {
                                    #$arx[3]=$e3;
                                    #$arx[4]= $s3;
                                    #print "whovl $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                    
                                    # print the first bit
                                    $arx[5]= "whovl" ;
                                    my $s33 = ($s3-1);
                                    $ele1="$arx[0]\t$arx[1]\t$arx[2]\t$arx[3]\t$s33\t$arx[5]\t$arx[6]\t$arx[7]\t$arx[8]a";
                                    

                                    # get the second bit ready
                                    $arx[3]=($e3+1);

                                }
                                # left overlap
                                elsif (  $arx[3] <= $e3 )  {
                                        $arx[5]= "lovl_" . "$arx[4]";
                                        $arx[4]=($s3-1);

                                        #print "lovl $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                        #push(@int2, $novl);
                                }
                                # right overlap
                                elsif ( $s3 <= $arx[4])  {
                                        $arx[5]= "rovl_" . "$arx[3]";
                                        $arx[3]= ($e3+1);
                                        #print "rovl $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                        #my $novl = join("\t", $ele2);
                                        #push(@int2, $novl);
                                }
                                else {
                                    print "unass $s3\t$e3\t$arx[3]\t$arx[4]\n";
                                        #my $novl = join("\t", $ele2);
                                        #push(@int2, $novl);
                                }
                            
                            }

                            $ele2 = join("\t", @arx);

                            print OUT "$ele2;Parent=$i.1\n";

                        }
                        else {
                            print OUT "$ele2;Parent=$i.1\n";
                        }

                        # print added exon
                        if ($ele1=~/\w+/) {
                            print OUT "$ele1;Parent=$i.1\n";
                        }

                        # now print the adjusted positions
                        #foreach my $elm (@int2) {
                        #    print OUT "$elm;Parent=$i.1\n";

                        #}



                    # foreach $ele2
                    }
                }


                
=cut

=pod
                if ($ele=~/$max[0]/ and $ele=~/CDS/) {

                    #my @arx = split(/\t/, $ele);
                    #$arx[6]=$ori;
                    #my $el = join("\t",@arx);
                    $ele=~s/\t\+\t/\t$ori\t/;
                    $ele=~s/\t\-\t/\t$ori\t/;
                    $ele=~s/\t.\t.\t.\t/\t.\t$ori\t.\t/;
                    print OUT "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }
                else {
                    print OUT "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }
=cut
                #########

            
        }
        else {
            # print leftovers in separate file
            my $int = join("\t", @int);
            my @los=split(/\t/, $int);
            my $res = "$los[0]\t$los[1]\t$los[2]\t$los[3]\t$los[4]\t$los[5]\t$los[6]\t$los[7]\t$los[8]";
            print OUT2 "$res\n";
        }
    }

}

$i++;
close (OUT);
close (OUT2);

__END__


# now merge in free-floating CDS to closest gene

system "cat $in.trans.gff | grep -w gene > $in.trans.gene.gff ";
system "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/closestBed -a  $in.trans.left.gff -b $in.trans.gene.gff -d -t first > $in.trans.left.merged.gff ";
print "/nfs/users/nfs_j/jit/bin/BEDTools-Version-2.12.0/bin/closestBed -a  $in.trans.left.gff -b $in.trans.gene.gff -d -t first > $in.trans.left.merged.gff \n";

open(IN3, "<$in.trans.left.merged.gff") || die "Cant read file $in.trans.left.merged.gff";



while (<IN3>) {
    chomp ;
    my @arr = split(/\t/,$_);

    # check if the distance is small to closest gene

    if ($arr[18] < 2000) {

    # if it is, add it to the right gene

    #print "Shorter than 2000 $arr[18]\n";
        
        my $i2 = $arr[17];
        $i2=~s/ID=//;
        if (exists $groups{$arr[0]}{$i2}{"F"}) {
            my $line = "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]";
            push (@{$groups{$arr[0]}{$i2}{F}},"$line");

        }
        else {
            print "Warning: Can't find gene $arr[17]\n";
        }
    }
    # if not - make a new gene
    else {
        #print "Too long $i $arr[18]\n";
        
        # add feature to group
        $groups{$arr[0]}{$i}{SE}="$arr[3]\t$arr[4]";
        $groups{$arr[0]}{$i}{ORI}="\.";
        my $line = "$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\t$arr[4]\t$arr[5]\t$arr[6]\t$arr[7]\t$arr[8]";
        push (@{$groups{$arr[0]}{$i}{F}},"$line");
        $i++;


    }


}





#### print the results out #######







# print the resulting intron-groups


open(OUT3, ">$in.final.gff") || die "Cant read file $in.final.gff";

foreach my $scaf (sort keys %groups) {

    #print "$scaf\n";
    
    foreach my $i (sort { $a <=> $b }  keys %{$groups{$scaf}}) {



        #foreach my $key (sort { $a <=> $b }  keys %{$groups{$scaf}{$i}}) {
        my $coord =$groups{$scaf}{$i}{"SE"};
        my $ori =$groups{$scaf}{$i}{"ORI"} ;
        #print "$scaf\t$i\t$coord\n";


        my @int = @{ $groups{$scaf}{$i}{"F"} };


        #foreach my $ele (@int) {
            #print "$ele\n";
            #}

        if (scalar(@int)> 0) { 
            #my $first = @int[0];
            my $last = @int[-1];
            #my @min = split(/\t/,$first);
            my @max = split(/\t/,$last);
            #my $min = $min[3];
            #my $max = $max[4];
            if ($ori=~/^\.$/) {
                $ori = $max[6];
            }

            if ($ori=~/^$/) {
                #print "No ori\n";
                $ori="\.";
            }    
    
            print OUT3  "$scaf\tassigned\tgene\t$coord\t.\t$ori\t.\tID=$i\n";
            print OUT3 "$scaf\tassigned\tmRNA\t$coord\t.\t$ori\t.\tID=$i.1;Parent=$i\n";

            foreach my $ele (@int) {
                # find min
                # find max
                


                if ($ele=~/$max[0]/ and $ele=~/CDS/) {

                    #my @arx = split(/\t/, $ele);
                    #$arx[6]=$ori;
                    #my $el = join("\t",@arx);
                    $ele=~s/\t\+\t/\t$ori\t/;
                    $ele=~s/\t\-\t/\t$ori\t/;
                    $ele=~s/\t.\t.\t.\t/\t.\t$ori\t.\t/;
                    print OUT3 "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }
                else {
                    #print OUT3 "$ele;Parent=$i.1\n";
                    #print "$ele;Parent=$i.1\n";


                }

            }
        }
        else {
            # print leftovers in separate file
            print  "Warning: @int\n";
        }
    }

}

$i++;
close (OUT3);










exit;



#### sub for translating non-spliced genes
#
#
#
#
