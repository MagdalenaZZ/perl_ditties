#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff_markup_preparation.pl infile.gff outfile

Checks that the added features don\'t have any tabs in them


'
}


	my $in = shift;
	my $out = shift;
	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$out") || die "I can't open $out\n";
	
   foreach my $line (@in) {
    chomp $line;
    my @arr = split(/\t/, $line);
    if (scalar(@arr)>9 and $arr[2]=~/gene/) {
        @slice = @arr[9..-1];
    }
    else {
        print OUT "$line";
    }

   }
    
    
    
    
    
    
    
    close (OUT);





