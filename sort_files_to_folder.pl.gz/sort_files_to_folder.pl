#!/usr/bin/perl -w

use strict;
use File::Slurp;
use Cwd;
use Data::Dumper;

unless (@ARGV ==2) {
        &USAGE;
}


sub USAGE {

die 'Usage: sort_files_2_folder.pl folder list

Takes a folder and moves all files in the list to that folder 

'
}

my $folder = shift;
my $list = shift;
my $cwd = cwd();

# read in everything in current directory
my @paths = read_dir( "$folder", prefix => 1 ) ;
my @npaths;

foreach my $file (@paths) {

#    if ($file =~m/\//) {	
    	if (-d "$file") {
#    		print "Dir: $file\n";
#    		foreach my $elem (@paths) {
#    			$elem = "$folder\/$elem";
#   			print "$elem\n";
#		    }	
	    }
#	    else {
#		    print "File: $file\n";
#	    }
#    }
	else {
#		print "File2: $file\n";
        push (@npaths, $file);
	}


}

# read in list in a hash
#
my %h;


open (IN, "$list") || die "I can't open $list\n";
my @in = <IN>;
close (IN);

foreach my $line (@in) {
    chomp $line;
    $line = $line . ".embl";
    $h{$line}= 1;
}


foreach my $file (@npaths) {
    foreach my $key (keys %h) {
        if ($file =~m/^$key$/ ) {
#    		print "$file is contig\n";
            system "mv $file contigs";
        }
        else {
#            print "$file is scaffold\n";
        }
    }
}





