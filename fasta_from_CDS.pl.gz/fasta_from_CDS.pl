#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: fasta_from_CDS.pl ref.fas input.gff  <offset>

Takes a gff-file and a fasta-file and makes fasta-file from it, with only the CDSs.


Example:
perl ~/bin/perl/fasta_from_CDS.pl genome.fa  file.gff 
perl ~/bin/perl/fasta_from_CDS.pl genome.fa  file.gff  10


# make sure the fasta is single-line

offset will add a set of bases to the start or the end of your sequence (it is optional, and should only be used when there are not CDS which should be cobbled together)




'
}


	my $ref = shift;
	my $in = shift;
	my $out = $in;
	open (IN, "<$in") || die "I can't open $in\n";
	my @gff = <IN>;
	close (IN);

	open (OUT, ">$in.fas") || die "I can't open $in.fas\n";

    # read in fasta

open (FAS, "<$ref") || die "I can't open $ref\n";
my %fas;
while (<FAS>) {
    chomp;
    if (/^>(\S+)/) {
        my $seq_name = $_;
        $seq_name=~s/>//;
        my $seq = <FAS> ;
        chomp($seq) ;
        $fas{$seq_name}="$seq";
        #print "$seq_name\n";
    }	
}


close(FAS);


foreach my $line (@gff) {

    chomp $line;
    my @arr= split(/\t/,$line);

    if (exists $fas{$arr[0]}) {
        my $len = $arr[4]-$arr[3];
        my $sub = substr($fas{$arr[0]}, $arr[3], $len);
        print OUT ">$arr[8] $arr[3] $arr[4]\n$sub\n";

    }
    else {
        print "Missing sequence $arr[0] in fasta-file\n";
    }

}

exit;

    


