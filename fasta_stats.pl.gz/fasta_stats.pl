#!/usr/local/bin/perl -w

# mz3 script for calculating gc-content


use strict;

unless (@ARGV == 1) {
        &USAGE;
}

my $fasta = shift;

open (IN, $fasta);

my @fasta = <IN>;

my $final_N = 0;
my $final_AT = 0;
my $final_GC = 0;
my @contam;

foreach my $line (@fasta) {
   chomp $line;

# filter headers

	if ($line =~ m/>/) {
        $line=~s/>//;
         print "$line\t";
	}
	else {
	my $N_count = $line =~ tr/Nn//;
	my $AT_count = $line =~ tr/AaTt//;
	my $GC_count = $line =~ tr/GgCc//;
	$line =~ tr/GgCcAaTtNn/\t/;
	my $others = $line;
#	print "$others\n";
	push (@contam, $others);
#	my $N_count = $line =~ tr/N//;
#	print "Sequence: $line \n";
#	print "$N_count\n";
#	print "$AT_count\n";
#	print "$GC_count\n";
	$final_N =$final_N +$N_count;
	$final_AT =$final_AT + $AT_count;
	$final_GC =$final_GC +$GC_count;
    my $tot = $AT_count + $GC_count +  $N_count ;
	#print	"Final: $final_N\n";
	#print	"Final: $final_AT\n";
	#print	"Final: $final_GC\n";
    print "$tot\n";
	}

}

#print	"Total N: $final_N\n";
#print	"Total AT: $final_AT\n";
#print	"Total GC: $final_GC\n";

my $all = $final_AT + $final_GC;
my $gc_content = $final_GC/$all;

#print	"Final GC content: $gc_content\n";

__END__
foreach my $line (@contam) {
$line =~ s/\t//g;
$line =~ s/ /space=" "  /g;
if ($line =~m/./ ){
print "other characters: $line";
}
}
