#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >0) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff2genelengths.pl file


'
}

my $file = shift;

open (IN, "< $file")  || die "I can't open $file\n";
open (OUT2, "> $file.genelengths")  || die "I can't open $file.genelengths\n";

my %genes;


while(<IN>){
	chomp $_;
	my @arr=split(/\s+/,$_);
	my $diff = $arr[4]-$arr[3]+1;
	unless (exists $genes{$arr[9]}) {
		$genes{$arr[9]}=0;
		#print "Initiate $arr[9]\n";
	}
	
	$genes{$arr[9]}+=$diff;
	#print "$arr[9] now $genes{$arr[9]}\n";
	
}

# output

foreach my $key (sort keys %genes) {
	print OUT2 "$key\t$genes{$key}\n";
}

exit;



