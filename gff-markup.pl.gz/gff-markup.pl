#!/usr/local/bin/perl -w

use strict;
use Data::Dumper;

unless (@ARGV==3) {
        &USAGE;
}


sub USAGE {

die 'Usage: gff-markup.pl gff-file    gff-markup.file    outfile


Give the program the gff-file you want to modify, and a gff-markup.file

gff-markup-format
genename    <TAB>   /feature=""   <TAB>  /feature="" ....

'
}


	my $gff = shift;
	my $in = shift;	
	my $out = shift;

	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);


my %hash;

# Take each line and take the gene-name as a key, and then fill the variable array with annotation

foreach my $line (@in) {
chomp $line;
	my @arr= split (/\t/, $line);
	my $key = $arr[0];
#	print "Key:$key:\n";
	shift(@arr);

	foreach my $elem (@arr) {
		push(@{$hash{$key}}, $elem);
#		print "Elem:$elem:\n";
	}
}


# print Dumper(%hash);

#read the gff-file and add att the elements of the %hash to the end of the file


	open (GFF, "<$gff") || die "I can't open $gff\n";
	my @gff = <GFF>;
	close (GFF);

	open (OUT, ">$out") || die "I can't open $out\n";



foreach my $line (@gff) {
chomp $line;

#only mark genes
	if ($line =~/gene/) {
        my @arr3 = split (/;/,$line);
 
		my @arr=split (/[\t]/,$arr3[0]);
		$arr[8]=~s/ID=//;

#		print "Gene:$arr[8]:\n";
		if (exists $hash{$arr[8]}) {
#			foreach my $keys (@{$hash{$arr[8]}})	{
#				print "$keys\n";
#			}	
			my $anot=join("\t", @{$hash{$arr[8]}});
			print OUT "$line\t$anot\n";
		}
		else {
			print OUT "$line\n";
		}
	}
# others straight ahead
	else {
		print OUT "$line\n";
	}

}



	close (OUT);






