#!/usr/bin/perl -w

use strict;


unless (@ARGV > 0) {
        &USAGE;
}




sub USAGE {

    die '


Usage: dotplot_in_R.pl y=Y-max x=X-max file(s)

i.e.
dotplot_in_R.pl *.numbers.txt
dotplot_in_R.pl   y=1000 x=10  *.numbers.txt


This program takes a file with a column with numbers and draws a dotplot from it in R.
Each input file as a separate distribution


File:
        X      Y  


Gene1   0.34    0.62
Gene2   0.31    0.57
...



    ' . "\n";
}




my @files = @ARGV;

open (R, ">$files[0].heatdot.R") || die "I can't open $files[0].heatdot.R\n";
#open (OUT, ">$files[0].out") || die "I can't open $files[0].out\n";


my $i = "1";



# make the file to print to

print R "library(colorRamps)\n";
print R "library(spatstat)\n set.seed(3)\n";

print R '
xlab ="Units"
ylab = "Dotplot"
mfrow = c(1,1)
dcol = 1
lcol = 1

';

my $a = scalar(@files);

print R " col<-rgb(runif($a),runif($a),runif($a))\ncol \n";

# read in data

foreach my $file (@files) {

        print R " x$i<-read.table(\"$file\",header=F) \n";

        print R '

        # make vectors
            x <- x1[,2]
            y <- x1[,3]

        # calculate regression
        fit <- lm(y ~ x)
        summary(fit)
        fit <- lm(x ~ y)
        summary(fit)

        # make density object
        #X <- ppp(x, y,  ylim=c(-4,5), xlim=c(-4,5) )
        X <- ppp(x, y,  c(-4,5), c(-4,5) )
        # change xlim and ylim to right values

        # make a log-scale for the colour gradient
        myBreaks <- round(exp(seq(log(0.0000001), log(35000), length = 33)), 10)
        # make the lowest point -1
        myBreaks[1] <- as.numeric("-1")

        # make a colour ramp using colorRamps
        co <- colourmap(matlab.like(32),  breaks=myBreaks )
        # this has to be as long as myBreaks -1

        ';

        # now plot the graph
	
            print R "pdf(\"$files[0]\.heatdot\.pdf\", useDingbats=FALSE)\n";

            print R "plot(density(X, 0.2), col=co) \n";
            print R "axis(side = 1 ) \n";
            print R "axis(side = 2, las = 1) \n";

}



print R "dev.off()\n";
	

system "R CMD BATCH $files[0].heatdot.R";









