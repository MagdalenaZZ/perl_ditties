#!/usr/local/bin/perl -w
# mz3 script for making scaffolds from an agp-file and contigs

use strict;

unless (@ARGV == 5) {
        &USAGE;
}

sub USAGE {

die 'Usage: agp2scaffolds.pl <final.agp> <final.fasta> prefix

one sequence per line for the fasta-files

'
}


# Read final.stats file

    my $finalstats_file = shift;
    my $agp_file =shift;
    my $input_fasta =shift;
    my $IMAGE_fasta =shift;
    my $prefix = shift;

open (STATS, "<$finalstats_file");
my @stats = <STATS>;
chomp @stats;


#### Get overlap stats from final.stats file



#### Get overlap stats from agp-file








