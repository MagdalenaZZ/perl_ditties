#!/usr/local/bin/perl -w

use strict;

unless (@ARGV >=2) {
        &USAGE;
}


sub USAGE {

die 'Usage: promer_inverted_repeats.pl tabfile.coords  <distance between hits>  <nucmer/promer>


Run promer, and filter the output with show-coords 

i.e.
show-coords -c -d -I 70 -l -L 50 -T file.delta > file.coords


'
}



	my $in = shift;
	my $dist = shift;
	my $mer = shift;


	open (IN, "<$in") || die "I can't open $in\n";
	my @in = <IN>;
	close (IN);

	open (OUT, ">$in.$dist.out") || die "I can't open $in.$dist.out\n";


    # change coords depending on nucmer and promer
    my $c1;   
    my $c2;

    if ($mer =~/pro/i) {
        $c1 = "15";
        $c2 = "16";
    }
    else    {
        $c1 = "13";
        $c2 = "14";

    }


    # read in coords

my %h;

foreach my $line (@in) {
    chomp $line;
    my @arr= split(/\t/,$line);
    #if it is not header 
    if (scalar(@arr)>$c2) {
        # if it is in same scaffold
        if ($arr[$c1]=~/$arr[$c2]/ and $arr[$c2]=~/$arr[$c1]/ ) {


                # invert positions to 1,2,3,4
                my $S1 = 0;
                my $E1 = 0;
                my $S2 = 0;
                my $E2 = 0 ;
                my $ori = "0";
                                # inverted other way  <- ->
                if ($arr[0] < $arr[1] and $arr[2] > $arr[3] and $arr[0] < $arr[2])   {
                    $S1 = $arr[0];
                    $E1 = $arr[1];
                    $S2 = $arr[3];
                    $E2 = $arr[2];
                    $ori="inv2";
                }
                                # inverted other way  <- ->
                elsif ($arr[0] < $arr[1] and $arr[2] > $arr[3] and $arr[2] < $arr[0])   {
                    $S2 = $arr[0];
                    $E2 = $arr[1];
                    $S1 = $arr[3];
                    $E1 = $arr[2];
                    $ori="inv1";
                }

                # if positions is inverted   ->  <-
                elsif  ($arr[0] > $arr[1] and $arr[2] < $arr[3] )   {
                    print "never happens\n";
                }
                else {
                    # not inverted
                }


                my $dist2 = $S2-$E1;
                if ($ori=~/inv/ and $dist2 < $dist) {
                    #print "$ori\t$S1\t$E1\t$S2\t$E2\t||\t$arr[0]\t$arr[1]\t$arr[2]\t$arr[3]\n";
                        if (exists $h{$arr[$c2]}) {
                            #foreach my $key (keys  %{$h{$arr[$c2]}}) {
                                    #my ($s1,$e1,$s2,$e2) = split(/\t/, $key);
                                    #print "$S1\t$E1\t$S2\t$E2\t|\t$s1\t$e1\t$s2\t$e2\n";
                                    $h{$arr[$c2]}{ "$S1\t$E1\t$S2\t$E2" }=1;
                        }
                            
   
                        else {
                                $h{$arr[$c2]}{"$S1\t$E1\t$S2\t$E2"}=1;
                        }

            }
        }
    }
}


# now go through the overlaps and print them

my $i = 1;
foreach my $key (sort keys  %h) {

     foreach my $key2 (keys  %{$h{$key}}) {
        my @arr = split(/\t/, $key2);

        my $mids = $arr[1]+1;
        my $mide = $arr[2]-1;
        unless ($mids > $mide) {
            print OUT "$key\tpromerINV\tCDS\t$arr[0]\t$arr[1]\t.\t.\t.\tInv_$i.left;Parent=Inv_$i\n";
            print OUT "$key\tpromerINV\tCDS\t$mids\t$mide\t.\t.\t.\tInv_$i.mid;Parent=Inv_$i\n";
            print OUT "$key\tpromerINV\tCDS\t$arr[2]\t$arr[3]\t.\t.\t.\tInv_$i.right;Parent=Inv_$i\n";
        }

         $i++;
     }

}



close(OUT);

exit;





__END__


                    if ($arr[2]> $arr[1]) {
                        my $dist2 = $arr[2] - $arr[0];
                        # test if distance is small
                        if ( $dist2 < $dist and $dist2 > 0 ) {
                            # add to hit-list
                            if (exists $h{$arr[$c2]}) {
                                # identify overlaps with previous hits
                                foreach my $key (keys  %{$h{$arr[$c2]}}) {
                                    my ($s1,$e1,$s2,$e2) = split(/\t/, $key);
                                    #print "$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]\t|\t$s1\t$e1\t$s2\t$e2\n";
                                    # if there is an overlap left
                                    if ( $e2 < $arr[1] and $arr[3] < $e2   ) {
                                        print "Never happens\n";            
                                    }
                                    elsif ( $s1 > $arr[1] and $arr[3] > $s1   ) {
                                        #print "OVLR\t$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]\t|\t$s1\t$e1\t$s2\t$e2\n";
                                        my $max1 = ($arr[0], $e1)[$arr[0] < $e1];
                                        my $max2 = ($arr[3], $e2)[$arr[3] < $e2];
                                        my $min1 = ($arr[1], $s1)[$arr[1] > $s1];
                                        my $min2 = ($arr[2], $s2)[$arr[2] > $s2];
                                        #print "OVLR\t$min1\t$max1\t$min2\t$max2\n";
                                        delete $h{$arr[$c2]}{$key};
                                        $h{$arr[$c2]}{ "$min1\t$max1\t$min2\t$max2" }=1;
                                    }
                                    else {
                                    }
                                }
                            }
                            else {
                                $h{$arr[$c2]}{ "$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]"  }=1;
                            }
                        }
                    }
                    else {
                        my $dist2 = $arr[1] - $arr[3] ;
                        # test if distance is small
                        if ( $dist2 < $dist and $dist2 > 0 ) {
                            #print "DONE $arr[2]  $arr[3] and  $arr[1] $arr[0] $dist2 \n"; 
                            # add to hit-list
                            if (exists $h{$arr[$c2]}) {
                                # identify overlaps with previous hits
                                foreach my $key (keys  %{$h{$arr[$c2]}}) {
                                    my ($s1,$e1,$s2,$e2) = split(/\t/, $key);
                                    #print "$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]\t|\t$s1\t$e1\t$s2\t$e2\n";
                                    # if there is an overlap left
                                    if ( $e2 < $arr[1] and $arr[3] < $e2   ) {
                                        print "Never happens\n";
                                    }
                                    elsif ( $s1 > $arr[1] and $arr[3] > $s1   ) {
                                        #print "OVLR\t$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]\t|\t$s1\t$e1\t$s2\t$e2\n";
                                        my $max1 = ($arr[0], $e1)[$arr[0] < $e1];
                                        my $max2 = ($arr[3], $e2)[$arr[3] < $e2];
                                        my $min1 = ($arr[1], $s1)[$arr[1] > $s1];
                                        my $min2 = ($arr[2], $s2)[$arr[2] > $s2];
                                        #print "OVLR\t$min1\t$max1\t$min2\t$max2\n";
                                        delete $h{$arr[$c2]}{$key};
                                        $h{$arr[$c2]}{ "$min1\t$max1\t$min2\t$max2" }=1;
                                    }
                                }
                            }
                            else {
                                $h{$arr[$c2]}{ "$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]"  }=1;
                            }
                        }
                    }
                }
                # inverted other way  <- ->
                elsif ($arr[0] < $arr[1] and $arr[2] > $arr[3])   {
                    #print "Never happens\n";
                    # invert positions to 1,2,3,4
                    if ($arr[2]> $arr[1]) {
                        print "RIGHT   $arr[0] $arr[1] and   $arr[3] $arr[2]\n";
                    }
                    else {
                        print "DONE  $arr[3] $arr[2] and   $arr[0] $arr[1] \n";
                    }
                }
                else {
                    #print "$line\n";
                }
            }
    }

}




=pod
                                    # if there is an overlap left
                                    if ( $e2 > $S1 and $E2 > $e2   ) {
                                        print "Never happens\n";
                                        print "OVLR $S1\t$E1\t$S2\t$E2\t|\t$s1\t$e1\t$s2\t$e2\n";

                                    }
                                    elsif ( $s1 >= $S1 and $E2 >= $s1   ) {
                                        #print "OVLR $S1\t$E1\t$S2\t$E2\t|\t$s1\t$e1\t$s2\t$e2\n";
                                        #my $max1 = ($arr[0], $e1)[$arr[0] < $e1];
                                        #my $max2 = ($arr[3], $e2)[$arr[3] < $e2];
                                        #my $min1 = ($arr[1], $s1)[$arr[1] > $s1];
                                        #my $min2 = ($arr[2], $s2)[$arr[2] > $s2];
                                        #print "OVLR\t$min1\t$max1\t$min2\t$max2\n";
                                        #delete $h{$arr[$c2]}{$key};
                                        #$h{$arr[$c2]}{ "$min1\t$max1\t$min2\t$max2" }=1;
                                    }
                                    else {
                                        #print "novl $S1\t$E1\t$S2\t$E2\t|\t$s1\t$e1\t$s2\t$e2\n";
                                    }
                                #}
                                # identify overlaps with previous hits

                                    # if there is an overlap left
                                    if ( $e2 < $S1 and $S2 < $e2   ) {
                                        print "Never happens\n";
                                    }
                                    elsif ( $s1 > $E1 and $E3 > $s1   ) {
                                        #print "OVLR\t$arr[1]\t$arr[0]\t$arr[2]\t$arr[3]\t|\t$s1\t$e1\t$s2\t$e2\n";
                                        #my $max1 = ($arr[0], $e1)[$arr[0] < $e1];
                                        #my $max2 = ($arr[3], $e2)[$arr[3] < $e2];
                                        #my $min1 = ($arr[1], $s1)[$arr[1] > $s1];
                                        #my $min2 = ($arr[2], $s2)[$arr[2] > $s2];
                                        #print "OVLR\t$min1\t$max1\t$min2\t$max2\n";
                                        #delete $h{$arr[$c2]}{$key};
                                        #$h{$arr[$c2]}{ "$min1\t$max1\t$min2\t$max2" }=1;
                                    }
                                }
=cut                             

