#!/usr/local/bin/perl
use strict;

use Bio::SeqIO;
use Bio::Tools::GFF;

# Bio::Seq::RichSeq object is created when Bio::SeqIO is given formats like Genbank or EMBL, which may contain features and annotations

my $file         = shift; # get the file name, somehow
my $seqio_object = Bio::SeqIO->new(-file => $file);
my $seq_object   = $seqio_object->next_seq;

#	 Bio::SeqIO::embl

#Despite this specification some non-standard feature tags have crept into Genbank, like "bond". When the Bioperl Genbank parser encounters a non-standard feature like this it's going to throw a fatal exception. The work-around is to use eval{} so your script doesn't die, something like:
eval { $seq_object = $seqio_object-> next_seq; };       
# if there's an error       
print "Problem in $file. Bad feature perhaps?\n" if $@;

__END__

####################################################

my ($seqfile) = @ARGV;
die("must define a valid seqfile to read") unless ( defined $seqfile && -r $seqfile);

my $seqio = new Bio::SeqIO(-format => 'embl', -file => $seqfile);
my $count = 0;
while( my $seq = $seqio->next_seq ) {
    $count++;
    # defined a default name
    my $fname = sprintf("%s.gff", $seq->display_id || "seq-$count");
    my $gffout = new Bio::Tools::GFF(-file => ">$fname" , -gff_version => 2);
    foreach my $feature ( $seq->top_SeqFeatures() ) {
$gffout->write_feature($feature);
    }
}


# PRIOR to parsing; this will ensure that the Seqs have the features attached; ie you will then be able to call

$seq->get_SeqFeatures();

=pod
The SeqFeature::Generic object uses tag/value pairs to store information, and the values are always returned as arrays. A simple way to access all the data in the features of a Seq object would look something like this:

for my $feat_object ($seq_object->get_SeqFeatures) {          
   print "primary tag: ", $feat_object->primary_tag, "\n";          
   for my $tag ($feat_object->get_all_tags) {             
      print "  tag: ", $tag, "\n";             
      for my $value ($feat_object->get_tag_values($tag)) {                
         print "    value: ", $value, "\n";             
      }          
   }       
}

This bit would print out something like:

primary tag: source
  tag: chromosome
    value: X
  tag: db_xref
    value: taxon:9606
  tag: map
    value: Xp11.4
  tag: organism
    value: Homo sapiens
primary tag: gene
  tag: gene
    value: NDP
  tag: note
    value: ND
primary tag: CDS
  tag: codon_start
    value: 1



## So to retrieve specific values, like all the database identifiers, you could do:

for my $feat_object ($seq_object->get_SeqFeatures) {        
   push @ids, $feat_object->get_tag_values("db_xref") if ($feat_object->has_tag("db_xref"));     
}

Important: Make sure to include that if ($feat_object->has_tag("...")) part, otherwise you'll get errors when the feature does not have the tag you're requesting. 

=cut



