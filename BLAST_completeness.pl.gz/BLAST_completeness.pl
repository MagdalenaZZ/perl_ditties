#!/usr/bin/perl -w

use strict;


unless (@ARGV > 2) {
        &USAGE;
}




sub USAGE {

    die '


Usage: blast_completeness.pl blast.out query.fasta reference.fasta

This program takes the output from BLASTx, plus query-fasta and reference-fasta.
It tries to determine whether the query is as complete as the reference.



    ' . "\n";
}

my $blast = shift;
my $query = shift;
my $ref = shift;


# Open query 

system "fasta2singleLine.py $query $query.sl";

system "samtools faidx $query.sl ";
open (FAS, "<$query.sl.fai") || die "I can't open $query.sl.fai\n";
#my @fas = <FAS>;
#close (FAS);
# Open reference 
my %fas;

while (<FAS>) {
    my @arr = split(/\s+/, $_);
    $fas{$arr[0]} = $arr[1];
    #print "$arr[0]\t$arr[1]\n";

}


system "samtools faidx $ref ";
open (REF, "<$ref.fai") || die "I can't open $ref.fai\n";
#my @ref = <REF>;
#close (REF);

my %ref;

while (<REF>) {
    my @arr = split(/\s+/, $_);
    $ref{$arr[0]} = $arr[1];
    #print "$arr[0]\t$arr[1]\n";
}


# Cap BLAST-hit to the best one

system "perl ~mz3/bin/perl/BLAST_cap_hits.pl $blast 1 $blast.filtered ";

# Read in BLAST-output

	open (IN, "<$blast.filtered ") || die "I can't open $blast.filtered \n";
	my @blast = <IN>;
	close (IN);

    open (LIST, ">$query.list ") || die "I can't open $query.list \n";


my %hash;

foreach my $elem (@blast) {
        chomp $elem;

		my @arr = split(/\s+/, $elem);
		if ($arr[0]=~/\w+/) {
            #print "$arr[0]\t$arr[1]\n";
            if (exists $ref{$arr[1]} and exists $fas{$arr[0]} ) {
                
                if ($arr[2] > 50 and $arr[10]< 0.0001) {
                    #print "Match\n";

                    

                    # reference and called have to be of similar length
                    if ( $fas{$arr[0]} >  ($ref{$arr[1]} * 0.9) and $arr[2] > 60 and $arr[10] < 0.00001 and  $arr[3] > ($ref{$arr[1]} * 0.9) and $arr[8] < 20 and $arr[9] > ($ref{$arr[1]} - 20)  ) {
                        #print "qseqid\tsseqid\tpident\tlength\tmismatch\tgapopen\tqstart\tqend\tsstart\tend\tevalue\tbitscore\n$elem\t";
                        #print "$arr[1]\t$ref{$arr[1]}\t";
                        #print "$arr[0]\t$fas{$arr[0]}\n";
                        print LIST "$arr[0]\n";
                    }
                    else {
                        # discarded hit
                    }

                }

            }
            else {
               print " You have sequences in the blast-file which do not exist in your reference or fasta\n$arr[0]\t$arr[1]\n\n";
               die;
            }


        # okay, now we have the original lengths of the genes + blast-output
        # time to do something sensible
    

		}
		else {
		}

}


close (LIST);


system "perl ~/bin/perl/fasta_retrieve_subsets.pl $query.sl $query.list";
print  "perl ~/bin/perl/fasta_retrieve_subsets.pl $query.sl $query.list\n";

print "\nYour output has been written to file $query.list.in_list\n\n";




__END__


open (IN, "<$in") || die "I can't open $in\n";

foreach my $elem  (@in2) { 
	chomp $elem; 
#	my $name;
#	print "Line $elem\n"; <STDIN>;
	if ($elem=~/^>/) { 
		$elem =~tr/\>//d;
		my $x =0 ;
		($name, $x)= split(/x/, $elem);
#	print "Name $name\n"; <STDIN>;		
	} 
	else { 
		push(@{$seqs{$name}}, $elem);
#	print "Name $name\n"; <STDIN>;	
#	print "Seq $elem\n"; <STDIN>;	
 	} 
} 

