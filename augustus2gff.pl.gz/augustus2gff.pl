#!/usr/bin/perl -w
# mz3 script for changing augustus output into gff

use strict;

unless (@ARGV == 3) {
        &USAGE;
}

sub USAGE {

die 'Usage: perl ~/bin/perl/augustus2gff.pl august_output_file your_outputfile mode

mode=0 - genes, mRNAs and CDSs (beware, only one gene even for multiple transcripts)
mode=1 - CDSs only - suitable for fix_children... script

Waring! not finished script, check output carefully



'
}




my $in= shift;
my $out = shift;
my $mode = shift;

my @array;

# make a random temp-file and take away all lines with #

my $range = 100;
my $rand = int(rand($range));
my @lines = system(" cat $in | grep -v '#' | grep -v b2h | grep -v w2h   >temp.$rand");
chomp @lines;

### check that temp-file was made 

if (open(MYFILE, "temp.$rand")) {
# print "opened temp\n";	
} 

else {
    print "Cannot open mydatafile!\n";
    exit 1;
}

# # # # # # # # # # # # # # # # # 

## Take tmp-file and get rid of empty lines

my @cleanlines=<MYFILE>;
my @cleanlines2;

foreach my $line  (@cleanlines){
    chomp $line;
    if ($line=~/\w+/) {
        push(@cleanlines2, $line);
    }
}
my @newlines = @cleanlines2;


## Get the name of the method 

my (  $s0, $first, $second, $s3) = split (/\s+/, $cleanlines[100]);
# print "Now first: $first\n"; #<STDIN>;
close (MYFILE);


=pod

open (OUT, ">$out");


foreach my $line (@newlines) {
    chomp $line;
 	 my @line = split (/\s+/, $line);

     if ($line[2]=~/CDS/ || $line[2]=~/gene/ || $line[2]=~/transcript/) {
         $line=~s/transcript/mRNA/;
         print "$line\n";
         #print OUT "$line\n";
        

     }
    
}
=cut


#=pod

#__END__

# make nice format

my $counter =1;
my $gene = 0;
my $mrna = 0;

 foreach my $line (@newlines) {
    chomp $line;

 	 my @line = split (/\t/, $line);
        #$line =~s/\;//g;	 
		my $name = $line[0];
		$name =~s/ //;
		my $method = $line[1];
		my $tag = $line[2];
		my $start = $line[3];
		my $end = $line[4];
		my $score = $line[5];
		my $strand = $line[6];
		my $trans = $line[7];
		my $note = $line[8];
        #my $note2 = $line[9];		
		$note=~s/"//;
        
# print ":$tag:\t:$name:$method:$start:$end:$score:$strand:$trans:$note:$line:\n";



# take out transcripts -> gene and CDS

		if ($tag=~"gene") {
		$counter=1;
		my $newline = "$name\t$method\tgene\t$start\t$end\t.\t$strand\t$trans\tID=$note";
            $gene = $note;
            #$gene=~s/ID=//;
		    push (@array, $newline);
            #print "Gene: $newline\n"; #  <STDIN>;
		}
		elsif ($tag=~"transcript") {
		 	 my @var = split (/;/, $note);	
		 	 my @var2 = split (/\./, $var[0]);
            $var2[1]=~s/"//g;
            $var2[0]=~s/"//g;
            my $newline = "$name\t$method\tmRNA\t$start\t$end\t.\t$strand\t$trans\tID=$note;Parent=$gene";
		    push (@array, $newline);
            #print "Transcript: $note\t:$newline\n"; #<STDIN>;
        #print "$var2[2]\n";
            ##$mrna = "$var2[0].$var2[2]";
            $mrna=$note;
		}


		elsif ($tag=~"CDS") {
            #print "Line $line\n";
		    $note=~s/"//g;
		    $note=~s/\;//g;
            #print ":$note:\n";
            my @var2 = split (/\s+/, $note);
             #$var2[1]=~s/;//;
             #$var2[1]=~s/"//g;
             #$var2[0]=~s/"//g;
             # print "VAR0:$var2[0]\n";
             my $newline = "$name\t$method\tCDS\t$start\t$end\t.\t$strand\t$trans\tID=$var2[1]:exon:$counter; Parent=$mrna;colour=3";
             #print "$newline\n";
             push (@array, $newline);
		$counter++;
		}

		
 }

# print "$lite\n";


#=cut
open (OUT, ">$out");

if  ($mode=~/0/) {
foreach my $line (@array) {
 print OUT "$line\n";
}

}

if  ($mode=~/1/) {
    foreach my $line (@array) {
        #        print "LINE:$line\n";
        my @arrx=split(/\:/, $line);
        if ($arrx[0]=~/CDS/) {
             print OUT "$arrx[0]\n";
        }
    }

}



#my $size = @array;
#my $lite = length(@array);
# print "$size\n";

# print @array;

 system("rm -f temp.$rand");

close (OUT);

exit;


